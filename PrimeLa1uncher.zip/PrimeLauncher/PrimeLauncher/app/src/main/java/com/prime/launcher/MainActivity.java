package com.prime.launcher;

import android.Manifest;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // ЗАМЕНИТЕ ССЫЛКИ ПРИ НЕОБХОДИМОСТИ
    private static final String GAME_APK_URL = "http://xn--80aaa8apphd7e.xn--p1ai/PRIMERUSSIA1.apk";
    
    // Обновление лаунчера теперь указывает на этот же файл
    private static final String LAUNCHER_UPDATE_URL = "http://xn--80aaa8apphd7e.xn--p1ai/PRIMERUSSIA1.apk"; 

    private static final String GAME_PACKAGE_NAME = "com.prime.russia";

    private TextView btnMainAction;
    private TextView btnSettings;
    private LinearLayout layoutProgress;
    private TextView tvProgressStatus;
    private ProgressBar progressBar;

    private boolean isGameInstalled = false;
    private boolean isDownloading = false;
    private boolean pendingSelfUninstall = false;

    // Лаунчер для удаления игры — после возврата автоматически удалит сам себя
    private final androidx.activity.result.ActivityResultLauncher<Intent> uninstallGameLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (pendingSelfUninstall) {
                            pendingSelfUninstall = false;
                            // Теперь удаляем сам Запускатор
                            Intent deleteSelfIntent = new Intent(Intent.ACTION_UNINSTALL_PACKAGE);
                            deleteSelfIntent.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(deleteSelfIntent);
                        }
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Принудительно ставим иконку медведя для меню недавних приложений (Task Switcher)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            android.graphics.Bitmap bm = android.graphics.BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
            android.app.ActivityManager.TaskDescription taskDesc = new android.app.ActivityManager.TaskDescription(getString(R.string.app_name), bm, ContextCompat.getColor(this, R.color.prime_red));
            setTaskDescription(taskDesc);
        }

        initViews();
        setupCarousel();
        setupButtons();
        
        checkPermissions();
        checkLauncherUpdate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(!isDownloading) {
            cleanupApkFiles();
            checkGameState();
        }
    }

    private void initViews() {
        btnMainAction = findViewById(R.id.btn_main_action);
        btnSettings = findViewById(R.id.btn_settings);
        layoutProgress = findViewById(R.id.layout_progress);
        tvProgressStatus = findViewById(R.id.tv_progress_status);
        progressBar = findViewById(R.id.progress_bar);
    }

    private void setupCarousel() {
        RecyclerView recycler = findViewById(R.id.recycler_carousel);
        recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        
        List<CarouselAdapter.CarouselItem> items = new ArrayList<>();
        items.add(new CarouselAdapter.CarouselItem("Как получить бонусы?", "Вы можете получить бонусы, участвуя в ежедневных ивентах."));
        items.add(new CarouselAdapter.CarouselItem("Где найти правила серверов?", "Раздел с правилами серверов, жалобами на игроков и другими..."));
        items.add(new CarouselAdapter.CarouselItem("Как начать играть?", "Просто нажмите кнопку ИГРАТЬ и погрузитесь в мир..."));
        
        recycler.setAdapter(new CarouselAdapter(items));
    }

    private void setupButtons() {
        findViewById(R.id.btn_telegram).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/primee_dev"));
            startActivity(intent);
        });

        findViewById(R.id.btn_donate).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/primee_dev"));
            startActivity(intent);
        });

        btnMainAction.setOnClickListener(v -> {
            if (isDownloading) return;
            if (isGameInstalled) {
                launchGame();
            } else {
                startDownload(GAME_APK_URL, "game.apk", false);
            }
        });

        btnSettings.setOnClickListener(v -> showSettingsDialog());
    }

    private void checkGameState() {
        isGameInstalled = isPackageInstalled(GAME_PACKAGE_NAME);
        if (isGameInstalled) {
            btnMainAction.setText(R.string.btn_play);
        } else {
            btnMainAction.setText(R.string.btn_install);
        }
    }

    private boolean isPackageInstalled(String packageName) {
        try {
            getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void launchGame() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(GAME_PACKAGE_NAME);
        if (intent != null) {
            startActivity(intent);
        } else {
            // Если у игры нет CATEGORY_LAUNCHER, LaunchIntent вернет null.
            // Ищем любую активность с ACTION_MAIN в этом пакете:
            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.setPackage(GAME_PACKAGE_NAME);
            List<android.content.pm.ResolveInfo> pkgAppsList = getPackageManager().queryIntentActivities(mainIntent, 0);
            
            if (!pkgAppsList.isEmpty()) {
                android.content.pm.ActivityInfo activityInfo = pkgAppsList.get(0).activityInfo;
                Intent fallbackLaunch = new Intent(Intent.ACTION_MAIN);
                fallbackLaunch.setComponent(new android.content.ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
                fallbackLaunch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try {
                    startActivity(fallbackLaunch);
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Ошибка запуска скрытого лаунчера.", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Не найдена главная активность в com.prime.russia", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showSettingsDialog() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_settings);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.findViewById(R.id.btn_delete_client).setOnClickListener(v -> {
            clearGameCache();
            dialog.dismiss();
            
            if (isPackageInstalled(GAME_PACKAGE_NAME)) {
                // Ставим флаг: после удаления игры — удалить и себя
                pendingSelfUninstall = true;
                Intent intent = new Intent(Intent.ACTION_UNINSTALL_PACKAGE);
                intent.setData(Uri.parse("package:" + GAME_PACKAGE_NAME));
                intent.putExtra(Intent.EXTRA_RETURN_RESULT, true);
                uninstallGameLauncher.launch(intent);
            } else {
                // Игра не установлена — удаляем только себя
                Intent deleteSelfIntent = new Intent(Intent.ACTION_UNINSTALL_PACKAGE);
                deleteSelfIntent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(deleteSelfIntent);
            }
        });

        dialog.findViewById(R.id.btn_close).setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void clearGameCache() {
        try {
            File dataDir = new File(Environment.getExternalStorageDirectory(), "Android/data/" + GAME_PACKAGE_NAME);
            if (dataDir.exists()) {
                deleteRecursive(dataDir);
                Toast.makeText(this, "Кэш очищен (android/data/com.prime.russia)", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Папка кэша не найдена", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка при удалении кэша (нет разрешений Storage)", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] files = fileOrDirectory.listFiles();
            if (files != null) {
                for (File child : files) {
                    deleteRecursive(child);
                }
            }
        }
        fileOrDirectory.delete();
    }

    private void cleanupApkFiles() {
        try {
            File cacheDir = getCacheDir();
            File[] files = cacheDir.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.getName().endsWith(".apk")) {
                        f.delete();
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    // --- ОБНОВЛЕНИЕ И СКАЧИВАНИЕ ---

    // Ссылка на JSON файл с версией 라унчера
    // СОЗДАЙ ФАЙЛ update.json НА СВОЕМ ХОСТИНГЕ (содержимое: {"versionCode": 2})
    private static final String LAUNCHER_UPDATE_JSON_URL = "http://xn--80aaa8apphd7e.xn--p1ai/update.json";

    private void checkLauncherUpdate() {
        new Thread(() -> {
            try {
                URL url = new URL(LAUNCHER_UPDATE_JSON_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.connect();
                
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    BufferedInputStream in = new BufferedInputStream(connection.getInputStream());
                    byte[] contents = new byte[1024];
                    int bytesRead = in.read(contents);
                    if (bytesRead > 0) {
                        String jsonString = new String(contents, 0, bytesRead);
                        if (jsonString.contains("\"versionCode\"")) {
                            int startIndex = jsonString.indexOf(":") + 1;
                            int endIndex = jsonString.indexOf("}");
                            if(endIndex == -1) endIndex = jsonString.length();
                            
                            int serverVersionCode = Integer.parseInt(jsonString.substring(startIndex, endIndex).trim());
                            
                            // Читаем сохраненную версию из локальных настроек (по умолчанию 1)
                            android.content.SharedPreferences prefs = getSharedPreferences("LauncherPrefs", MODE_PRIVATE);
                            int currentSavedVersion = prefs.getInt("savedVersionCode", 1);

                            if (serverVersionCode > currentSavedVersion) {
                                // Сохраняем новую версию, чтобы не скачивать бесконечно
                                prefs.edit().putInt("savedVersionCode", serverVersionCode).apply();

                                runOnUiThread(() -> {
                                    Toast.makeText(MainActivity.this, "Доступна новая версия лаунчера! Обновляем...", Toast.LENGTH_LONG).show();
                                    startDownload(LAUNCHER_UPDATE_URL, "launcher_update.apk", true);
                                });
                            }
                        }
                    }
                }
                connection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void startDownload(String urlString, String fileName, boolean isLauncherUpdate) {
        isDownloading = true;
        btnMainAction.setEnabled(false);
        layoutProgress.setVisibility(View.VISIBLE);
        
        new DownloadTask(fileName, isLauncherUpdate).execute(urlString);
    }

    private class DownloadTask extends AsyncTask<String, Integer, File> {
        private String fileName;
        private boolean isLauncherUpdate;

        public DownloadTask(String fileName, boolean isLauncherUpdate) {
            this.fileName = fileName;
            this.isLauncherUpdate = isLauncherUpdate;
        }

        @Override
        protected void onPreExecute() {
            tvProgressStatus.setText(isLauncherUpdate ? "Обновление лаунчера..." : "Скачивание игры...");
            progressBar.setProgress(0);
            
            // Удаляем старый кеш/файл перед новым скачиванием
            File oldFile = new File(getCacheDir(), fileName);
            if(oldFile.exists()){
                oldFile.delete();
            }
        }

        @Override
        protected File doInBackground(String... urls) {
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                int fileLength = connection.getContentLength();
                File outputFile = new File(getCacheDir(), fileName);
                
                BufferedInputStream input = new BufferedInputStream(connection.getInputStream(), 65536);
                FileOutputStream output = new FileOutputStream(outputFile);

                byte data[] = new byte[65536]; // Увеличенный буфер для ультра-быстрого скачивания
                long total = 0;
                int count;
                while ((count = input.read(data)) != -1) {
                    total += count;
                    if (fileLength > 0) {
                        publishProgress((int) (total * 100 / fileLength));
                    }
                    output.write(data, 0, count);
                }

                output.flush();
                output.close();
                input.close();
                return outputFile;

            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onProgressUpdate(Integer... progress) {
            progressBar.setProgress(progress[0]);
            tvProgressStatus.setText((isLauncherUpdate ? "Обновление: " : "Скачивание: ") + progress[0] + "%");
        }

        @Override
        protected void onPostExecute(File file) {
            isDownloading = false;
            layoutProgress.setVisibility(View.GONE);

            if (file != null && file.exists()) {
                installApk(file);
            } else {
                Toast.makeText(MainActivity.this, "Ошибка скачивания. Проверьте подключение к сети.", Toast.LENGTH_SHORT).show();
                btnMainAction.setEnabled(true);
                checkGameState();
            }
        }
    }

    private final androidx.activity.result.ActivityResultLauncher<Intent> installLauncher =
            registerForActivityResult(new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        // Удаляем скачанный APK после установки
                        cleanupApkFiles();
                        checkGameState();
                        btnMainAction.setEnabled(true);
                    });

    private void installApk(File file) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(FileProvider.getUriForFile(this, getPackageName() + ".provider", file), "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            installLauncher.launch(intent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Ошибка при открытии установщика", Toast.LENGTH_SHORT).show();
            btnMainAction.setEnabled(true);
            checkGameState();
        }
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.addCategory("android.intent.category.DEFAULT");
                    intent.setData(Uri.parse(String.format("package:%s", getApplicationContext().getPackageName())));
                    startActivity(intent);
                } catch (Exception e) {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivity(intent);
                }
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
            }
        }
    }
}

// RESTORED: pawno/include/system/accessory.pwn
// Functions: 28

stock AccessoryEdit_DestroyCoordsText(playerid)
{
    GetPVarInt(8, playerid, 199037828);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawDestroy(8, playerid);
    DeletePVar(8, playerid, 199037920);
    return 1;
}


stock AccessoryShop_IsValidIndex(index)
{
    return 1;
}


stock AccessoryShop_GetPriceByIndex(index)
{
    AccessoryShop_IsValidIndex(4, index);
    return 1;
}


stock AccessoryShop_GetModelByIndex(index)
{
    AccessoryShop_IsValidIndex(4, index);
    return 1;
}


stock AccessoryShop_GetInventoryItemB(modelid)
{
    return 1;
    Inv11_GetAccItemByModel(4, modelid);
    return 1;
}


stock AccessoryShop_GiveInventoryItem(playerid, index)
{
    AccessoryShop_IsValidIndex(4, index);
    return 1;
    AccessoryShop_GetModelByIndex(4, index);
    AccessoryShop_GetInventoryItemB(4, L_4);
    printf(16, 199096528);
    return 1;
    Inventory11_AddItemToDatabase(24, playerid, L_8, L_4, 1, 0, 0);
    printf(20, 199096852);
    return 1;
}


stock CreatePlTDButtonBR(playerid)
{
    CreatePlayerTextDraw(16, playerid, 1134551951, 1136318215, 199097176);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    return 1;
}


stock CreateTextDrawButtonBR()
{
    TextDrawCreate(12, 1116340224, 1128923136, 199097220);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1141342208, 1128923136, 199097280);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1131071249, 1136231560, 199097344);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1131442622, 1136656384, 199097428);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1134566510, 1136607445, 199097484);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    return 1;
}


stock HAT_OnPlayerSpawn(playerid)
{
    LoadAccessory(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    name_OnPlayerSpawn(4, playerid);
    return 1;
}


stock AccessoryEditSetMovementLock(playerid, enable)
{
    GetPlayerPos(16, playerid);
    SetPVarInt(12, playerid, 199097540, 1);
    SetPVarFloat(12, playerid, 199097604, L_4);
    SetPVarFloat(12, playerid, 199097664, L_8);
    SetPVarFloat(12, playerid, 199097724, L_12);
    SetPlayerVelocity(16, playerid, 0, 0, 0);
    TogglePlayerControllable(8, playerid, 1);
    printf(20, 199097784);
    DeletePVar(8, playerid, 199098000);
    DeletePVar(8, playerid, 199098064);
    DeletePVar(8, playerid, 199098124);
    DeletePVar(8, playerid, 199098184);
    SetPlayerVelocity(16, playerid, 0, 0, 0);
    TogglePlayerControllable(8, playerid, 1);
    printf(8, 199098244);
    return 1;
}


public OnPlayerUpdate(playerid)
{
    GetPVarInt(8, playerid, 199098380);
    GetPVarFloat(8, playerid, 199098444);
    GetPVarFloat(8, playerid, 199098504);
    GetPVarFloat(8, playerid, 199098564);
    GetPlayerPos(16, playerid);
    floatsub(8);
    floatabs(4);
    func_0x2ac(8);
    floatsub(8);
    floatabs(4);
    func_0x2ac(8);
    floatsub(8);
    floatabs(4);
    func_0x2ac(8);
    SetPlayerPos(16, playerid, L_4, L_8);
    SetPlayerVelocity(16, playerid, 0, 0, 0);
    acsedit_OnPlayerUpdate(4, playerid);
    return 1;
}


stock blackjack_OnPlayerClickTextDraw(playerid, clickedid)
{
    DestroyPlayerObject(8, playerid);
    CreatePlayerObject(36, playerid);
    SetPriceAccesory(8, playerid);
    DestroyPlayerObject(8, playerid);
    CreatePlayerObject(36, playerid);
    SetPriceAccesory(8, playerid);
    DestroyPlayerObject(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    SetPlayerPosEx(32, playerid, 1130267024, 1146574169, 1095011477, 1094390503, 0, 0, 1);
    DeletePVar(8, playerid, 199098624);
    DeletePVar(8, playerid, 199098696);
    DeletePVar(8, playerid, 199098768);
    DeletePVar(8, playerid, 199098840);
    DeletePVar(8, playerid, 199098912);
    DeletePVar(8, playerid, 199098992);
    CancelSelectTextDraw(4, playerid);
    TogglePlayerControllable(8, playerid, 1);
    ShowHud(4, playerid);
    TogglePlayerHudElement(12, playerid, 0, 1);
    AccessoryShop_IsValidIndex(4, L_4);
    SendClientMessage(12, playerid, -825307393);
    return 1;
    AccessoryShop_GetPriceByIndex(4, L_4);
    AccessoryShop_GiveInventoryItem(8, playerid, L_4);
    ShowNotificationNew(28, playerid, 2, 6, 0, 0, 199099180, 199099264);
    return 1;
    random(4, 4);
    format(24, -520, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    gettime(12);
    mysql_format(40, 166387936, -520, 128);
    mysql_query(12, 166387936);
    GivePlayerMoneyEx(20, playerid);
    format(16, -1044, 128);
    ShowNewNotification(28, playerid, 3, 6, 0, 0, -1044, 199099928);
    SendClientMessage(12, playerid, -1);
    TextDrawHideForPlayer(8, playerid);
    TogglePlayerHudElement(12, playerid, 0, 1);
    DeletePVar(8, playerid, 199100036);
    DeletePVar(8, playerid, 199100068);
    DeletePVar(8, playerid, 199100132);
    DeletePVar(8, playerid, 199100152);
    DeletePVar(8, playerid, 199100180);
    DeletePVar(8, playerid, 199100200);
    DeletePVar(8, playerid, 199100256);
    DeletePVar(8, playerid, 199100308);
    DeletePVar(8, playerid, 199100376);
    DeletePVar(8, playerid, 199100404);
    DeletePVar(8, playerid, 199100432);
    DeletePVar(8, playerid, 199100460);
    DeletePVar(8, playerid, 199100492);
    DeletePVar(8, playerid, 199100524);
    DeletePVar(8, playerid, 199100556);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CancelSelectTextDraw(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    TogglePlayerAllHudElements(8, playerid, 1);
    TextDrawHideForPlayer(8, playerid);
    TogglePlayerHudElement(12, playerid, 0, 1);
    GetPVarInt(8, playerid, 199100600);
    GetPVarInt(8, playerid, 199100860);
    mysql_format(24, 166387936, -2048, 512);
    mysql_query(12, 166387936);
    GetPVarFloat(8, playerid, 199101672);
    GetPVarFloat(8, playerid, 199101640);
    GetPVarFloat(8, playerid, 199101608);
    GetPVarFloat(8, playerid, 199101576);
    GetPVarFloat(8, playerid, 199101548);
    GetPVarFloat(8, playerid, 199101520);
    GetPVarFloat(8, playerid, 199101492);
    GetPVarInt(8, playerid, 199101472);
    GetPVarInt(8, playerid, 199101420);
    GetPVarInt(8, playerid, 199101400);
    mysql_format(60, 166387936, -2048, 512);
    mysql_query(12, 166387936);
    DeletePVar(8, playerid, 199101716);
    DeletePVar(8, playerid, 199101748);
    DeletePVar(8, playerid, 199101812);
    DeletePVar(8, playerid, 199101832);
    DeletePVar(8, playerid, 199101860);
    DeletePVar(8, playerid, 199101880);
    DeletePVar(8, playerid, 199101936);
    DeletePVar(8, playerid, 199101988);
    DeletePVar(8, playerid, 199102056);
    DeletePVar(8, playerid, 199102084);
    DeletePVar(8, playerid, 199102112);
    DeletePVar(8, playerid, 199102140);
    DeletePVar(8, playerid, 199102172);
    DeletePVar(8, playerid, 199102204);
    DeletePVar(8, playerid, 199102236);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CancelSelectTextDraw(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    TogglePlayerAllHudElements(8, playerid, 1);
    ShowHud(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPVarInt(8, playerid, 199102392);
    GetPVarFloat(8, playerid, 199103256);
    GetPVarFloat(8, playerid, 199103224);
    GetPVarFloat(8, playerid, 199103192);
    GetPVarFloat(8, playerid, 199103160);
    GetPVarFloat(8, playerid, 199103132);
    GetPVarFloat(8, playerid, 199103104);
    GetPVarFloat(8, playerid, 199103076);
    GetPVarInt(8, playerid, 199103056);
    GetPVarInt(8, playerid, 199103004);
    GetPVarInt(8, playerid, 199102984);
    printf(56, 199102448);
    GetPVarFloat(8, playerid, 199104256, -2056);
    GetPVarFloat(8, playerid, 199104212);
    GetPVarFloat(8, playerid, 199104168);
    GetPVarFloat(8, playerid, 199104136);
    GetPVarFloat(8, playerid, 199104104);
    GetPVarFloat(8, playerid, 199104072);
    GetPVarFloat(8, playerid, 199104044);
    GetPVarFloat(8, playerid, 199104016);
    GetPVarFloat(8, playerid, 199103988);
    GetPVarInt(8, playerid, 199103968);
    mysql_format(64, 166387936, -2048, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(24, 199104300);
    printf(16, 199104732);
    LoadPlayerAccessories(4, playerid);
    GetPVarInt(8, playerid, 199105832);
    GetPVarFloat(8, playerid, 199105788);
    GetPVarFloat(8, playerid, 199105756);
    GetPVarFloat(8, playerid, 199105724);
    GetPVarFloat(8, playerid, 199105692);
    GetPVarFloat(8, playerid, 199105664);
    GetPVarFloat(8, playerid, 199105636);
    GetPVarFloat(8, playerid, 199105608);
    GetPVarInt(8, playerid, 199105588);
    GetPVarInt(8, playerid, 199105560);
    format(56, -2048, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    GetPVarInt(8, playerid, 199106256);
    printf(24, 199105852);
    GetPVarInt(8, playerid, 199106556);
    printf(16, 199106276);
    cache_delete(8, L_2052, 1);
    GetPVarInt(8, playerid, 199106576);
    GetPVarInt(8, playerid, 199106604);
    AccessoryGetIndexByModel(4);
    GetPVarInt(8, playerid, 199106908);
    mysql_format(24, 166387936, -2048, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    GetPVarInt(8, playerid, 199107332);
    printf(24, 199106928);
    GetPVarFloat(8, playerid, 199108148);
    GetPVarFloat(8, playerid, 199108116);
    GetPVarFloat(8, playerid, 199108084);
    GetPVarFloat(8, playerid, 199108052);
    GetPVarFloat(8, playerid, 199108024);
    GetPVarFloat(8, playerid, 199107996);
    GetPVarFloat(8, playerid, 199107968);
    GetPVarInt(8, playerid, 199107948, -2060);
    GetPVarInt(8, playerid, 199107928);
    mysql_format(60, 166387936, -2048, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    GetPVarInt(8, playerid, 199108636, -2060);
    printf(28, 199108192);
    GetPVarInt(8, playerid, 199108972, -2060);
    printf(20, 199108656);
    DeletePVar(8, playerid, 199108992);
    DeletePVar(8, playerid, 199109024);
    DeletePVar(8, playerid, 199109088);
    DeletePVar(8, playerid, 199109108);
    DeletePVar(8, playerid, 199109136);
    DeletePVar(8, playerid, 199109156);
    DeletePVar(8, playerid, 199109212);
    DeletePVar(8, playerid, 199109264);
    DeletePVar(8, playerid, 199109332);
    DeletePVar(8, playerid, 199109360);
    DeletePVar(8, playerid, 199109388);
    DeletePVar(8, playerid, 199109416);
    DeletePVar(8, playerid, 199109448);
    DeletePVar(8, playerid, 199109480);
    DeletePVar(8, playerid, 199109512);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CancelSelectTextDraw(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    TogglePlayerAllHudElements(8, playerid, 1);
    SendClientMessage(12, playerid, -1);
    ShowHud(4, playerid);
    GetPVarInt(8, playerid, 199109668);
    TextDrawHideForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    SetPVarInt(12, playerid, 199109732);
    GetPVarFloat(8, playerid, 199109796);
    GetPVarFloat(8, playerid, 199109824);
    GetPVarFloat(8, playerid, 199109852);
    GetPVarFloat(8, playerid, 199109880);
    GetPVarFloat(8, playerid, 199109924);
    GetPVarFloat(8, playerid, 199109956);
    GetPVarFloat(8, playerid, 199109988);
    // casetbl cases=8
    format(16, -144, 32);
    PlayerTextDrawSetString(12, playerid);
    return 1;
    GetPVarInt(8, playerid, 199110040);
    GetPVarFloat(8, playerid, 199110132);
    floatmul(8);
    floatadd(8);
    SetPVarFloat(12, playerid, 199110104);
    GetPVarFloat(8, playerid, 199110180);
    format(16, -140, 32);
    GetPVarFloat(8, playerid, 199110236);
    floatmul(8);
    floatadd(8);
    SetPVarFloat(12, playerid, 199110208);
    GetPVarFloat(8, playerid, 199110284);
    format(16, -140, 32);
    GetPVarFloat(8, playerid, 199110340);
    floatmul(8);
    floatadd(8);
    SetPVarFloat(12, playerid, 199110312);
    GetPVarFloat(8, playerid, 199110388);
    format(16, -140, 32);
    GetPVarFloat(8, playerid, 199110460);
    floatmul(8);
    floatadd(8);
    SetPVarFloat(12, playerid, 199110416);
    GetPVarFloat(8, playerid, 199110524);
    format(16, -140, 32);
    GetPVarFloat(8, playerid, 199110600);
    floatmul(8);
    floatadd(8);
    SetPVarFloat(12, playerid, 199110568);
    GetPVarFloat(8, playerid, 199110652);
    format(16, -140, 32);
    GetPVarFloat(8, playerid, 199110716);
    floatmul(8);
    floatadd(8);
    SetPVarFloat(12, playerid, 199110684);
    GetPVarFloat(8, playerid, 199110768);
    format(16, -140, 32);
    GetPVarFloat(8, playerid, 199110832);
    floatmul(8);
    floatadd(8);
    SetPVarFloat(12, playerid, 199110800);
    GetPVarFloat(8, playerid, 199110884);
    format(16, -140, 32);
    return 1;
    // casetbl cases=8
    PlayerTextDrawSetString(12, playerid);
    GetPVarFloat(8, playerid, 199111356, 0, 0);
    GetPVarFloat(8, playerid, 199111312);
    GetPVarFloat(8, playerid, 199111268);
    GetPVarFloat(8, playerid, 199111236);
    GetPVarFloat(8, playerid, 199111204);
    GetPVarFloat(8, playerid, 199111172);
    GetPVarFloat(8, playerid, 199111144);
    GetPVarFloat(8, playerid, 199111116);
    GetPVarFloat(8, playerid, 199111088);
    GetPVarInt(8, playerid, 199111068);
    GetPVarInt(8, playerid, 199110936);
    GetPVarInt(8, playerid, 199110988);
    GetPVarInt(8, playerid, 199111040);
    GetPVarInt(8, playerid, 199110916);
    SetPlayerAttachedObject(60, playerid);
    return 1;
    btn_OnPlayerClickTextDraw(8, playerid, clickedid);
    return 1;
}


stock HAT_OnGameModeInit()
{
    print(4);
    CreateTextDrawButtonBR(0);
    CreateEditAccessoryTD_Accessory(0);
    SetTimer(12, 199111568, "SO");
    acs_OnGameModeInit(0);
    return 1;
}


stock EntryAccessoryMarket(playerid)
{
    GetPlayerPos(16, playerid);
    GetPlayerFacingAngle(8, playerid, -16);
    SetPVarFloat(12, playerid, 199111668, L_4);
    SetPVarFloat(12, playerid, 199111740, L_8);
    SetPVarFloat(12, playerid, 199111812, L_12);
    SetPVarFloat(12, playerid, 199111884, L_16);
    GetPlayerInterior(4, playerid);
    SetPVarInt(12, playerid, 199111956);
    GetPlayerVirtualWorld(4, playerid);
    SetPVarInt(12, playerid, 199112036);
    SetPlayerPosEx(32, playerid, 1161103814, 1153106476, 1159476608, 1135706604, 1);
    HideHud(4, playerid);
    TogglePlayerControllable(8, playerid, 0);
    SendClientMessage(12, playerid, -1);
    TogglePlayerHudElement(12, playerid, 0, 0);
    InterpolateCameraPos(36, playerid, 1161125690, 1153123327, 1159476608, 1161119543, 1153140496, 1159476690, 2000, 1);
    InterpolateCameraLookAt(36, playerid, 1161133012, 1153131819, 1159476608, 1161114030, 1153166428, 1159477504, 2000, 1);
    CreatePlayerObject(36, playerid);
    CreatePlTDButtonBR(4, playerid);
    SetPriceAccesory(8, playerid, 0);
    TogglePlayerControllable(8, playerid, 0);
    SelectTextDraw(8, playerid, -11382017);
    TextDrawShowForPlayer(8, playerid);
    PlayerTextDrawShow(8, playerid);
    GetPlayerCameraPos(16, playerid, -20, -24, -28);
    TogglePlayerControllable(8, playerid, 0);
    return 1;
}


stock SetPriceAccesory(playerid, acs)
{
    AccessoryShop_IsValidIndex(4, acs);
    return 1;
    AccessoryShop_GetPriceByIndex(4, acs, -156, 15);
    ConvertMoney(12);
    format(16, -96, 24);
    PlayerTextDrawSetString(12, playerid);
    return 1;
}


stock pc_cmd_testacs(playerid)
{
    mysql_format(24, 166387936, -512, 128);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_delete(8, L_516, 1);
    mysql_format(24, 166387936, -512, 128);
    mysql_query(12, 166387936);
    SendClientMessage(12, playerid, 1724671743);
    cache_delete(8, L_516, 1);
    SendClientMessage(12, playerid, -825307393);
    AccessoryShowInventory(4, playerid);
    return 1;
}


stock pc_cmd_myacs(playerid)
{
    AccessoryShowInventory(4, playerid);
    return 1;
}


stock AccessoryShowInventory(playerid)
{
    mysql_format(20, 166387936, -16384, 4096);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1717986817);
    ShowNewNotification(28, playerid, 2, 6, 0, 0, 199113388, 199113488);
    cache_delete(8, L_16388, 1);
    return 1;
    format(12, -16384, 4096);
    cache_get_field_content_int(12, L_17332, 199113552);
    cache_get_field_content_int(12, L_17332, 199113564);
    cache_get_field_content_int(12, L_17332, 199113592);
    format(12, -17324, 70);
    format(12, -17324, 70);
    format(24, -17036, 160);
    strcat(12, -16384);
    format(16, -17036, 160);
    SetPVarInt(12, playerid, -17036, L_17044);
    SendClientMessage(12, playerid, -825307393);
    cache_delete(8, L_16388, 1);
    return 1;
    Dialog(28, playerid, 1190, 5, 199114084, -16384, 199114284, 199114312);
    cache_delete(8, L_16388, 1);
    return 1;
}


stock HAT_OnDialogResponse(playerid, dialogid, response, listitem)
{
    SetPVarInt(12, playerid, 199114336, L_4);
    format(16, -100, 24);
    GetPVarInt(8, playerid, -100);
    Dialog(28, playerid, 1191, 5, 199114416, 199114652, 199115500, 199115532);
    SetPVarInt(12, playerid, 199115564, 0);
    Dialog(28, playerid, 1191, 5, 199115596, 199115832, 199116412, 199116444);
    SetPVarInt(12, playerid, 199116476, 1);
    GetPVarInt(8, playerid, 199116508);
    GetPVarInt(8, playerid, 199116552);
    UseAccessory(8, playerid, L_4);
    SellAccessory(8, playerid, L_4);
    DeleteAccessory(8, playerid, L_4);
    // casetbl cases=4
    TakeOffAccessory(8, playerid, L_4);
    EditAccessory(8, playerid, L_4);
    // casetbl cases=3
    sscanf(16, V_28, 199116584, -4, -8);
    SendClientMessage(12, playerid, -1);
    return 1;
    IsPlayerConnected(4);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPVarInt(8, playerid, 199117108);
    SetPVarInt(12, playerid, 199117024);
    SetPVarInt(12, playerid, 199117152, L_8);
    SendPlayerOffer(20, playerid, L_4, 25, 0, 0);
    acs_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock UseAccessory(playerid, database)
{
    mysql_format(24, 166387936, -880, 220);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_delete(8, L_884, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    cache_get_field_content_int(12, 0, 199117664);
    cache_delete(8, L_884, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    // casetbl cases=14
    SendClientMessage(12, playerid, -1);
    return 1;
    mysql_format(24, 166387936, -880, 220);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, 0, 199118348);
    cache_delete(8, L_884, 1);
    mysql_format(24, 166387936, -880, 220);
    mysql_query(12, 166387936);
    mysql_format(24, 166387936, -880, 220);
    mysql_query(12, 166387936);
    IsPlayerAttachedObjectSlotUsed(8, playerid, L_896);
    RemovePlayerAttachedObject(8, playerid, L_896);
    cache_delete(8, L_884, 1);
    mysql_format(32, 166387936, -880, 220);
    mysql_query(12, 166387936);
    mysql_format(20, 166387936, -880, 220);
    mysql_query(12, 166387936);
    mysql_format(20, 166387936, -880, 220);
    mysql_query(12, 166387936);
    SetPlayerAttachedObject(60, playerid, L_896);
    SendClientMessage(12, playerid, -1);
    return 1;
}


stock TakeOffAccessory(playerid, database)
{
    mysql_format(20, 166387936, -740, 184);
    mysql_query(12, 166387936);
    cache_get_field_content_int(12, 0, 199120064);
    cache_delete(8, L_744, 1);
    mysql_errno(4);
    mysql_format(24, 166387936, -740, 184);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_get_row_int(12, 0, 0, 1);
    cache_delete(8, L_744, 1);
    mysql_format(24, 166387936, -740, 184);
    mysql_query(12, 166387936);
    mysql_format(20, 166387936, -740, 184);
    mysql_query(12, 166387936);
    RemovePlayerAttachedObject(8, playerid, L_4);
    ShowNewNotification(28, playerid, 3, 6, 0, 0, 199120884, 199120944);
    return 1;
}


stock SellAccessory(playerid, database)
{
    mysql_format(20, 166387936, -496, 124);
    mysql_query(12, 166387936);
    cache_get_row_int(12, 0, 0, 1);
    SetPVarInt(12, playerid, 199121160);
    cache_delete(8, L_500, 1);
    Dialog(28, playerid, 1192, 1, 199121188, 199121280, 199121724, 199121748);
    return 1;
}


stock DeleteAccessory(playerid, database)
{
    mysql_format(20, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    return 1;
}


stock EditAccessory(playerid, database)
{
    SendClientMessage(12, playerid, -1);
    TogglePlayerHudElement(12, playerid, 0, 0);
    format(16, -880, 220);
    mysql_query(12, 166387936);
    cache_get_row_int(12, 0, 0, 1);
    cache_delete(8, L_888, 1);
    format(20, -880, 220);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, 0, 199122620);
    cache_get_field_content_int(12, 0, 199122640);
    cache_get_field_content_float(12, 0, 199122660, 1);
    cache_get_field_content_float(12, 0, 199122668, 1);
    cache_get_field_content_float(12, 0, 199122676, 1);
    cache_get_field_content_float(12, 0, 199122684, 1);
    cache_get_field_content_float(12, 0, 199122696, 1);
    cache_get_field_content_float(12, 0, 199122708, 1);
    cache_get_field_content_float(12, 0, 199122720, 1);
    SetPVarInt(12, playerid, 199122744, L_900);
    SetPVarInt(12, playerid, 199122764, L_892);
    DeletePVar(8, playerid, 199122792);
    SetPVarInt(12, playerid, 199122848);
    SetPVarInt(12, playerid, 199122900, L_896);
    SetPVarFloat(12, playerid, 199122920, L_908);
    SetPVarFloat(12, playerid, 199122948, L_912);
    SetPVarFloat(12, playerid, 199122976, L_904);
    SetPVarFloat(12, playerid, 199123004, L_916);
    SetPVarFloat(12, playerid, 199123036, L_920);
    SetPVarFloat(12, playerid, 199123068, L_924);
    SetPVarFloat(12, playerid, 199123100, L_928);
    RemovePlayerAttachedObject(8, playerid, L_900);
    GetPVarFloat(8, playerid, 199123584, 0, 0);
    GetPVarFloat(8, playerid, 199123540);
    GetPVarFloat(8, playerid, 199123496);
    GetPVarFloat(8, playerid, 199123464);
    GetPVarFloat(8, playerid, 199123432);
    GetPVarFloat(8, playerid, 199123400);
    GetPVarFloat(8, playerid, 199123372);
    GetPVarFloat(8, playerid, 199123344);
    GetPVarFloat(8, playerid, 199123316);
    GetPVarInt(8, playerid, 199123296);
    GetPVarInt(8, playerid, 199123164);
    GetPVarInt(8, playerid, 199123216);
    GetPVarInt(8, playerid, 199123268);
    GetPVarInt(8, playerid, 199123144);
    SetPlayerAttachedObject(60, playerid);
    HideHud(4, playerid);
    SelectTextDraw(8, playerid, -11382017);
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    GetPVarFloat(8, playerid, 199123640);
    format(16, -1000, 18);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CreatePlayerTextDraw(16, playerid, 1141004691, 1133671213, -1000);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawShow(8, playerid);
    SetPVarInt(12, playerid, 199123668, 1);
    SetPVarInt(12, playerid, 199123760, 1);
    TogglePlayerAllHudElements(8, playerid, 0);
    AccessoryEditSetMovementLock(8, playerid, 1);
    cache_delete(8, L_888, 1);
    return 1;
}


stock AccessoryGetIndexByModel(modelid)
{
    return 1;
}


stock LoadAccessory(playerid)
{
    format(16, -880, 220);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    printf(16, 199124040);
    cache_get_field_content_int(12, L_932, 199124308);
    cache_get_field_content_int(12, L_932, 199124328);
    cache_get_field_content_int(12, L_932, 199124356);
    cache_get_field_content_float(12, L_932, 199124376, 1);
    cache_get_field_content_float(12, L_932, 199124384, 1);
    cache_get_field_content_float(12, L_932, 199124392, 1);
    cache_get_field_content_float(12, L_932, 199124400, 1);
    cache_get_field_content_float(12, L_932, 199124412, 1);
    cache_get_field_content_float(12, L_932, 199124424, 1);
    cache_get_field_content_float(12, L_932, 199124436, 1);
    SetPlayerAttachedObject(60, playerid, L_892);
    printf(56, 199124460);
    cache_delete(8, L_888, 1);
    return 1;
}


stock CreateEditAccessoryTD_Accessory()
{
    TextDrawCreate(12, 1108082688, 1099956224, 199124964);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1142292480, 1036831949, 199125020);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1138917376, 1135706112, 199125088);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1115815936, 199125144);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1121714176, 199125192);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1125842944, 199125240);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1128792064, 199125288);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1131741184, 199125336);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1133576192, 199125384);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1135050752, 199125432);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1115815936, 199125480);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1121714176, 199125528);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1125842944, 199125576);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1128792064, 199125624);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1131741184, 199125672);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1133576192, 199125720);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1135050752, 199125768);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125816);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125864);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125912);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125960);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199126008);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199126056);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199126104);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1139146752, 1129119744, 199126152);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1141145600, 1129119744, 199126216);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    return 1;
}


stock CREATE_TABLIST_ACCESSORY()
{
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_query(12, 166387936);
    mysql_errno(4);
    printf(4, 199128260);
    return 1;
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_query(12, 166387936);
    mysql_errno(4);
    printf(4, 199129276);
    return 1;
}


// RESTORED: pawno/include/system/blackjack_full.pwn
// Functions: 36

stock BJSetPlayerCleanChat(playerid, clean)
{
    BS_New(0);
    BS_WriteValue(12, L_4);
    BS_WriteValue(12, L_4);
    PR_SendRPC(20, L_4, playerid, 168, 3, 9);
    BS_Delete(4, -4);
    return 1;
}


stock Iter_OnPlayerDisconnect(playerid, reason)
{
    // casetbl cases=5
    blackjack_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


public OnPlayerClickTextDraw(playerid, clickedid)
{
    SendClientMessage(12, playerid, -1);
    CancelSelectTextDraw(4, playerid);
    format(12, -4096, 1024);
    format(16, -4096, 1024);
    format(16, -4096, 1024);
    fg_ShowPlayerDialog(28, playerid, "c_cmd_fuel", 0, 182173396, -4096, 182173456, 182173488);
    return 1;
    SendClientMessage(12, playerid, -1);
    fg_ShowPlayerDialog(28, playerid, "_cmd_fuel", 1, 182173496, 182173568, 182173960, 182173988);
    return 1;
    SendClientMessage(12, playerid, -1);
    ShowNotification(24, playerid, 2, 182174024, 3, 182174220, 182174224);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182174228, 182174424);
    return 1;
    format(16, -272, 67);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    GivePlayerMoneyBjEx(20, playerid);
    format(16, -332, 15);
    PlayerTextDrawSetString(12, playerid);
    format(16, -332, 15);
    PlayerTextDrawSetString(12, playerid);
    random(4, 13);
    random(4, 4);
    format(16, -332, 15);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 1);
    CheckTableBlackJack(8, L_4, 1);
    random(4, 13);
    random(4, 4);
    format(16, -332, 15);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 2);
    CheckTableBlackJack(8, L_4, 2);
    random(4, 13);
    random(4, 4);
    format(16, -332, 15);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 3);
    CheckTableBlackJack(8, L_4, 3);
    random(4, 13);
    random(4, 4);
    format(16, -332, 15);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 4);
    CheckTableBlackJack(8, L_4, 4);
    // casetbl cases=5
    ShowNotification(24, playerid, 2, 182174716, 3, 182174792, 182174796);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182174800, 182174876);
    BJAdvanceTurnIfCurrent(8, playerid, L_4);
    return 1;
    SendClientMessage(12, playerid, -1);
    format(16, -260, 64);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    random(4, 13);
    random(4, 4);
    format(16, -260, 64);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 1);
    CheckTableBlackJack(8, L_4, 1);
    random(4, 13);
    random(4, 4);
    format(16, -260, 64);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 2);
    CheckTableBlackJack(8, L_4, 2);
    random(4, 13);
    random(4, 4);
    format(16, -260, 64);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 3);
    CheckTableBlackJack(8, L_4, 3);
    random(4, 13);
    random(4, 4);
    format(16, -260, 64);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, L_4, 4);
    CheckTableBlackJack(8, L_4, 4);
    // casetbl cases=5
    SendClientMessage(12, playerid, -1);
    ShowNotification(24, playerid, 2, 182175088, 3, 182175164, 182175168);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182175172, 182175248);
    BJAdvanceTurnIfCurrent(8, playerid, L_4);
    return 1;
    SendClientMessage(12, playerid, -1);
    format(16, -260, 64);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    BJAdvanceTurnIfCurrent(8, playerid, L_4);
    ShowNotification(24, playerid, 2, 182175316, 3, 182175392, 182175396);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182175400, 182175476);
    return 1;
    SendClientMessage(12, playerid, -1);
    ShowNotification(24, playerid, 2, 182175484, 3, 182175588, 182175592);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182175596, 182175700);
    return 1;
    ExitPlayerLobby(12, playerid, L_4, L_8);
    return 1;
    blackjack_OnPlayerClickTextDraw(8, playerid, clickedid);
    return 1;
}


stock fg_OnDialogResponse(playerid, dialogid, response, listitem)
{
    SelectTextDraw(8, playerid, 1);
    blackjack_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
    SendClientMessage(12, playerid, -1);
    sscanf(12, V_28, 182175708, -516);
    ShowNotification(24, playerid, 2, 182175716, 3, 182175884, 182175888);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182175892, 182176060);
    fg_ShowPlayerDialog(28, playerid, "_cmd_fuel", 1, 182176064, 182176136, 182176528, 182176556);
    return 1;
    ShowNotification(24, playerid, 2, 182176588, 3, 182176808, 182176812);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182176816, 182177036);
    fg_ShowPlayerDialog(28, playerid, "_cmd_fuel", 1, 182177040, 182177112, 182177504, 182177532);
    return 1;
    ShowNotification(24, playerid, 2, 182177564, 3, 182177676, 182177680);
    ShowNewNotification(28, playerid, 2, 5, 1, 1, 182177684, 182177796);
    fg_ShowPlayerDialog(28, playerid, "_cmd_fuel", 1, 182177800, 182177872, 182178264, 182178292);
    return 1;
    format(16, -512, 128);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    TextDrawHideForPlayer(8, L_528);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawShowForPlayer(8, L_528);
    TextDrawHideForPlayer(8, L_532);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawShowForPlayer(8, L_532);
    TextDrawHideForPlayer(8, L_536);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawShowForPlayer(8, L_536);
    TextDrawHideForPlayer(8, L_540);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawShowForPlayer(8, L_540);
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    SetTimerEx(20, 182178448, 3000, 0);
    blackjack_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock InitPlayerLobby(playerid, lobby, table)
{
    BJSetPlayerCleanChat(8, playerid, 1);
    SendClientMessage(12, playerid, -1);
    TextDrawShowForPlayer(8, playerid, 182118644);
    TextDrawShowForPlayer(8, playerid, 182118648);
    TextDrawShowForPlayer(8, playerid, 182118652);
    TextDrawShowForPlayer(8, playerid, 182118656);
    TextDrawShowForPlayer(8, playerid, 182118660);
    TextDrawShowForPlayer(8, playerid, 182118664);
    TextDrawShowForPlayer(8, playerid, 182118672);
    TextDrawShowForPlayer(8, playerid, 182118900);
    TextDrawShowForPlayer(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    format(16, -100, 24);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    TogglePlayerControllable(8, playerid, 0);
    HideHud(4, playerid);
    ShowPlayerNameTagForPlayer(12, playerid, L_104, 0);
    GetPlayerName(12);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12, playerid, -196);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawSetString(12, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    TextDrawShowForPlayer(8, L_200);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12, playerid, -196);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawSetString(12, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    TextDrawShowForPlayer(8, L_200);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12, playerid, -196);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawSetString(12, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    TextDrawShowForPlayer(8, L_200);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12, playerid, -196);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawSetString(12, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    PlayerTextDrawShow(8, L_200);
    TextDrawShowForPlayer(8, L_200);
    TextDrawSetString(8);
    TextDrawColor(8);
    SelectTextDraw(8, playerid, 1);
    return 1;
}


stock ExitPlayerLobby(playerid, lobby, table)
{
    SetTimerEx(28, 182178868, 1000, 0);
    // casetbl cases=5
    TextDrawHideForPlayer(8, playerid, 182118644);
    TextDrawHideForPlayer(8, playerid, 182118648);
    TextDrawHideForPlayer(8, playerid, 182118652);
    TextDrawHideForPlayer(8, playerid, 182118656);
    TextDrawHideForPlayer(8, playerid, 182118660);
    TextDrawHideForPlayer(8, playerid, 182118664);
    TextDrawHideForPlayer(8, playerid, 182118668);
    PlayerTextDrawHide(8, playerid);
    TextDrawHideForPlayer(8, playerid, 182118672);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid, 182118900);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    // casetbl cases=5
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    CancelSelectTextDraw(4, playerid);
    ClearAnimations(8, playerid, 0);
    TogglePlayerControllable(8, playerid, 1);
    ShowHud(4, playerid);
    ShowPlayerNameTagForPlayer(12, playerid, L_4, 1);
    return 1;
}


stock ExitPlayerLobbyTimer(playerid, lobby, table)
{
    // casetbl cases=5
    TextDrawHideForPlayer(8, playerid, 182118644);
    TextDrawHideForPlayer(8, playerid, 182118648);
    TextDrawHideForPlayer(8, playerid, 182118652);
    TextDrawHideForPlayer(8, playerid, 182118656);
    TextDrawHideForPlayer(8, playerid, 182118660);
    TextDrawHideForPlayer(8, playerid, 182118664);
    TextDrawHideForPlayer(8, playerid, 182118668);
    PlayerTextDrawHide(8, playerid);
    TextDrawHideForPlayer(8, playerid, 182118672);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid, 182118900);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    // casetbl cases=5
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    PlayerTextDrawHide(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, L_8);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    CancelSelectTextDraw(4, playerid);
    ClearAnimations(8, playerid, 0);
    TogglePlayerControllable(8, playerid, 1);
    ShowHud(4, playerid);
    ShowPlayerNameTagForPlayer(12, playerid, L_4, 1);
    return 1;
}


stock LoadBlackJack()
{
    format(16, -512, 128);
    CreateDynamic3DTextLabel(60, -512, -1);
    CreateDynamicSphere(32);
    ReloadTable(4, L_516);
    LoadBJLobbyTimer(4, L_516);
    LoadBJLobbyPoint(4, L_516);
    LoadBJLobbyReady(4, L_516);
    LoadBJLobbyDealerCard(4, L_516);
    LoadBJTextBlackJack(4, L_516);
    LoadBJLobbyResult(4, L_516);
    LoadTextDrawBj(0);
    SetTimerEx(20, 182180036, 1000, 1);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawCreate(12, 1134598556, 1132351104, 182180252);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1134598556, 1132930880, 182180256);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    return 1;
}


stock LoadBJLobbyTimer(lobby)
{
    TextDrawCreate(12, 1134434713, 1131262345, 182180260);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    return 1;
}


stock LoadBJLobbyPoint(lobby)
{
    TextDrawCreate(12, 1117257730, 1134129313, 182180284);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1129172171, 1125292428, 182180316);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1139055008, 1125309030, 182180348);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1141640405, 1134137614, 182180380);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    return 1;
}


stock LoadBJLobbyReady(lobby)
{
    TextDrawCreate(12, 1117467445, 1134569718, 182180412);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1129237750, 1126189837, 182180448);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1139087801, 1126189837, 182180484);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1141666621, 1134569718, 182180520);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    return 1;
}


stock LoadBJLobbyDealerCard(lobby)
{
    TextDrawCreate(12, 1129434314, 1128228454, 182180556);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1131125147, 1128245056, 182180628);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1134369179, 1128261658, 182180700);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    return 1;
}


stock LoadBJTextBlackJack(lobby)
{
    TextDrawCreate(12, 1106876830, 1134300580, 182180772);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1126236162, 1125651561, 182180868);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1137587003, 1125651561, 182180964);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1140906400, 1134300580, 182181060);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    return 1;
}


stock LoadBJLobbyResult(lobby)
{
    TextDrawCreate(12, 1118935450, 1127983787, 182181156);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1129801319, 1104744700, 182181228);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1139369580, 1104744700, 182181304);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1141784586, 1127983787, 182181388);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawFont(8);
    return 1;
}


stock ReloadTable(lobby)
{
    return 1;
}


stock TimerSecondUpdateBJ(lobby)
{
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    PlayerTextDrawHide(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    SetTimerEx(20, 182181504, 2000, 0);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    random(4, 13);
    random(4, 4);
    TextDrawSetString(8);
    format(16, -20, 2);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    format(16, -20, 2);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    format(16, -20, 2);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    format(16, -20, 2);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    format(16, -44, 10);
    PlayerTextDrawSetString(12);
    random(4, 13);
    random(4, 4);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 1, 0, L_48, L_52);
    random(4, 13);
    random(4, 4);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 2, 0, L_48, L_52);
    random(4, 13);
    random(4, 4);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 3, 0, L_48, L_52);
    random(4, 13);
    random(4, 4);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 4, 0, L_48, L_52);
    // casetbl cases=10
    TextDrawSetString(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    format(16, -44, 10);
    PlayerTextDrawSetString(12);
    random(4, 13);
    random(4, 4);
    CheckTableBlackJack(8, lobby, 1);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 1, 1, L_48, L_52);
    format(16, -44, 10);
    PlayerTextDrawSetString(12);
    random(4, 13);
    random(4, 4);
    CheckTableBlackJack(8, lobby, 2);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 2, 1, L_48, L_52);
    format(16, -44, 10);
    PlayerTextDrawSetString(12);
    random(4, 13);
    random(4, 4);
    CheckTableBlackJack(8, lobby, 3);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 3, 1, L_48, L_52);
    format(16, -44, 10);
    PlayerTextDrawSetString(12);
    random(4, 13);
    random(4, 4);
    CheckTableBlackJack(8, lobby, 4);
    format(16, -44, 10);
    TextDrawSetString(8);
    ShowMembersCardBJL(20, lobby, 4, 1, L_48, L_52);
    // casetbl cases=10
    return 1;
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    SetTimerEx(20, 182182236, 2000, 0);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    format(16, -100, 24);
    TextDrawSetString(8);
    TextDrawColor(8);
    return 1;
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    SetTimerEx(20, 182182576, 2000, 0);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    format(16, -100, 24);
    TextDrawSetString(8);
    TextDrawColor(8);
    return 1;
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    SetTimerEx(20, 182182916, 2000, 0);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    format(16, -100, 24);
    TextDrawSetString(8);
    TextDrawColor(8);
    return 1;
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    SetTimerEx(20, 182183256, 2000, 0);
    TextDrawSetString(8);
    TextDrawColor(8);
    GetPlayerName(12);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    format(16, -100, 24);
    TextDrawSetString(8);
    TextDrawColor(8);
    // casetbl cases=6
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    random(4, 13);
    random(4, 4);
    TextDrawSetString(8);
    format(16, -52, 10);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    random(4, 13);
    random(4, 4);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    format(16, -52, 10);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    TextDrawSetString(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    GivePlayerMoneyBjEx(20);
    BJNotifyWin(8);
    TextDrawSetString(8);
    BJUpdateMoneyLabel(4);
    BJUpdateMoneyLabel(4);
    BJUpdateMoneyLabel(4);
    BJUpdateMoneyLabel(4);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawSetString(8);
    BJResetRoundPlayer(8);
    BJResetRoundPlayer(8);
    BJResetRoundPlayer(8);
    BJResetRoundPlayer(8);
    // casetbl cases=16
    SnowNotificarionBJL(12, lobby, 182187028, 3);
    printf(8, 182187088);
    printf(8, 182187132);
    printf(8, 182187176);
    printf(8, 182187220);
    SendClientMessage(12);
    SendClientMessage(12);
    SendClientMessage(12);
    SendClientMessage(12);
    SendClientMessage(12);
    ExitPlayerLobby(12);
    GivePlayerMoneyBjEx(20);
    format(16, -388, 96);
    ShowNotification(24);
    ShowNotificationNew(28);
    BJUpdateMoneyLabel(4);
    SendClientMessage(12);
    ExitPlayerLobby(12);
    GivePlayerMoneyBjEx(20);
    format(16, -388, 96);
    ShowNotification(24);
    ShowNotificationNew(28);
    BJUpdateMoneyLabel(4);
    SendClientMessage(12);
    ExitPlayerLobby(12);
    GivePlayerMoneyBjEx(20);
    format(16, -388, 96);
    ShowNotification(24);
    ShowNotificationNew(28);
    BJUpdateMoneyLabel(4);
    SendClientMessage(12);
    ExitPlayerLobby(12);
    GivePlayerMoneyBjEx(20);
    format(16, -388, 96);
    ShowNotification(24);
    ShowNotificationNew(28);
    BJUpdateMoneyLabel(4);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    TextDrawHideForPlayer(8);
    format(16, -28, 6);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawSetString(8);
    TextDrawSetString(8);
    return 1;
}


stock TimerDealerNext(lobby)
{
    return 1;
}


stock TimerHideBetText(playerid)
{
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    return 1;
}


stock TimerHideYouTurn(playerid)
{
    PlayerTextDrawHide(8, playerid);
    return 1;
}


stock BJAdvanceTurnIfCurrent(playerid, lobby)
{
    PlayerTextDrawHide(8, playerid);
    return 1;
}


stock BJNotifyWin(playerid, amount)
{
    return 1;
    format(16, -384, 96);
    ShowNotificationNew(28, playerid, 3, 6, 0, 0, -384, 182189128);
    return 1;
}


stock BJUpdateMoneyLabel(playerid)
{
    return 1;
    format(16, -96, 24);
    PlayerTextDrawSetString(12, playerid);
    return 1;
}


stock BJResetRoundPlayer(playerid, lobby)
{
    return 1;
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    BJUpdateMoneyLabel(4, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    TextDrawHideForPlayer(8, playerid, 182118668);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    InitPlayerLobby(12, playerid, lobby);
    return 1;
}


stock SCMBJL(lobby, color)
{
    SendClientMessage(12);
    SendClientMessage(12);
    SendClientMessage(12);
    SendClientMessage(12);
    return 1;
}


stock SnowNotificarionBJL(lobby, type)
{
    ShowNewNotification(28);
    ShowNotification(24);
    ShowNewNotification(28);
    ShowNotification(24);
    ShowNewNotification(28);
    ShowNotification(24);
    ShowNewNotification(28);
    ShowNotification(24);
    return 1;
}


stock CheckTableBlackJack(lobby, table)
{
    GiveTableBlackJack(12, lobby);
    GiveTableLose(8, lobby);
    GiveTableBlackJack(12, lobby);
    GiveTableLose(8, lobby);
    GiveTableBlackJack(12, lobby);
    GiveTableLose(8, lobby);
    GiveTableBlackJack(12, lobby);
    GiveTableLose(8, lobby);
    // casetbl cases=5
    return 1;
}


stock GiveTableBlackJack(lobby, playerid, table)
{
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    TextDrawShowForPlayer(8);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawHide(8, playerid);
    return 1;
}


stock GiveTableLose(lobby, player)
{
    format(16, -128, 32);
    SCMBJL(12, lobby, -1, -128);
    return 1;
}


stock ShowMembersCardBJL(lobby, table, card, suit, type)
{
    // casetbl cases=5
    format(16, -388, 96);
    TextDrawSetString(8);
    TextDrawColor(8);
    TextDrawSetString(8);
    TextDrawColor(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    PlayerTextDrawShow(8);
    PlayerTextDrawSetString(12);
    PlayerTextDrawShow(8);
    return 1;
}


stock LoadTextDrawBj()
{
    TextDrawCreate(12, 0, 0, 182189892);
    TextDrawLetterSize(12, 182118644, 0, 0);
    TextDrawTextSize(12, 182118644, 1142947840, 1138753536);
    TextDrawAlignment(8, 182118644, 1);
    TextDrawColor(8, 182118644, -1);
    TextDrawSetShadow(8, 182118644, 0);
    TextDrawSetOutline(8, 182118644, 0);
    TextDrawFont(8, 182118644, 4);
    TextDrawCreate(12, 1132868401, 1136845565, 182189952);
    TextDrawLetterSize(12, 182118656, 0, 0);
    TextDrawTextSize(12, 182118656, 1119984019, 1108498624);
    TextDrawAlignment(8, 182118656, 1);
    TextDrawColor(8, 182118656, -1);
    TextDrawSetShadow(8, 182118656, 0);
    TextDrawSetOutline(8, 182118656, 0);
    TextDrawFont(8, 182118656, 4);
    TextDrawSetSelectable(8, 182118656, 1);
    TextDrawCreate(12, 1099222228, 1136845565, 182190028);
    TextDrawLetterSize(12, 182118648, 0, 0);
    TextDrawTextSize(12, 182118648, 1119984019, 1108498624);
    TextDrawAlignment(8, 182118648, 1);
    TextDrawColor(8, 182118648, -1);
    TextDrawSetShadow(8, 182118648, 0);
    TextDrawSetOutline(8, 182118648, 0);
    TextDrawFont(8, 182118648, 4);
    TextDrawSetSelectable(8, 182118648, 1);
    TextDrawCreate(12, 1123234619, 1136845565, 182190112);
    TextDrawLetterSize(12, 182118652, 0, 0);
    TextDrawTextSize(12, 182118652, 1119984019, 1108498624);
    TextDrawAlignment(8, 182118652, 1);
    TextDrawColor(8, 182118652, -1);
    TextDrawSetShadow(8, 182118652, 0);
    TextDrawSetOutline(8, 182118652, 0);
    TextDrawFont(8, 182118652, 4);
    TextDrawSetSelectable(8, 182118652, 1);
    TextDrawCreate(12, 1137862254, 1136845565, 182190188);
    TextDrawLetterSize(12, 182118660, 0, 0);
    TextDrawTextSize(12, 182118660, 1119984019, 1108498624);
    TextDrawAlignment(8, 182118660, 1);
    TextDrawColor(8, 182118660, -1);
    TextDrawSetShadow(8, 182118660, 0);
    TextDrawSetOutline(8, 182118660, 0);
    TextDrawFont(8, 182118660, 4);
    TextDrawSetSelectable(8, 182118660, 1);
    TextDrawCreate(12, 1141083345, 1136845565, 182190264);
    TextDrawLetterSize(12, 182118664, 0, 0);
    TextDrawTextSize(12, 182118664, 1119984019, 1108498624);
    TextDrawAlignment(8, 182118664, 1);
    TextDrawColor(8, 182118664, -1);
    TextDrawSetShadow(8, 182118664, 0);
    TextDrawSetOutline(8, 182118664, 0);
    TextDrawFont(8, 182118664, 4);
    TextDrawSetSelectable(8, 182118664, 1);
    TextDrawCreate(12, 1132560385, 1136796638, 182190340);
    TextDrawLetterSize(12, 182118668, 0, 0);
    TextDrawTextSize(12, 182118668, 1122500600, 1112413309);
    TextDrawAlignment(8, 182118668, 1);
    TextDrawColor(8, 182118668, -1);
    TextDrawSetShadow(8, 182118668, 0);
    TextDrawSetOutline(8, 182118668, 0);
    TextDrawFont(8, 182118668, 4);
    TextDrawCreate(12, 1099327078, 1123444327, 182190420);
    TextDrawLetterSize(12, 182118672, 0, 0);
    TextDrawTextSize(12, 182118672, 1120927744, 1108498620);
    TextDrawAlignment(8, 182118672, 1);
    TextDrawColor(8, 182118672, -256);
    TextDrawSetShadow(8, 182118672, 0);
    TextDrawSetOutline(8, 182118672, 0);
    TextDrawFont(8, 182118672, 4);
    TextDrawSetSelectable(8, 182118672, 1);
    TextDrawCreate(12, 1134585447, 1116691499, 182190484);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1134565787, 1118584177, 182190528);
    TextDrawLetterSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawSetShadow(8);
    TextDrawSetOutline(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawCreate(12, 1134428159, 1129777728, 182190596);
    TextDrawLetterSize(12, 182118900, 1058326868, 1076104052);
    TextDrawAlignment(8, 182118900, 2);
    TextDrawColor(8, 182118900, -1);
    TextDrawSetShadow(8, 182118900, 0);
    TextDrawSetOutline(8, 182118900, 1);
    TextDrawBackgroundColor(8, 182118900, 51);
    TextDrawFont(8, 182118900, 1);
    TextDrawSetProportional(8, 182118900, 1);
    return 1;
}


stock LoadPlayerTextDraw(playerid)
{
    CreatePlayerTextDraw(16, playerid, 1100585372, 1114174918, 182190688);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1100585372, 1119367111, 182190712);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1134480584, 1137358933, 182190736);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1100795088, 1128636523, 182190748);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1125331782, 1109547170, 182190776);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1137108597, 1109547170, 182190804);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140346070, 1128636523, 182190832);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1077936124, 1129190521, 182190860);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1102577663, 1129190521, 182190940);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110179840, 1129190521, 182191020);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1115422720, 1129190521, 182191100);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1124204544, 1111113050, 182191180);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1125515264, 1111113050, 182191260);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1126825984, 1111113050, 182191340);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1128136704, 1111113050, 182191420);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1136558080, 1111113050, 182191500);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1137213440, 1111113050, 182191580);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1137868800, 1111113050, 182191660);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1138524160, 1111113050, 182191740);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1139834880, 1129190521, 182191820);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140523008, 1129190521, 182191900);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1141030912, 1129190521, 182191980);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1141374976, 1129190521, 182192060);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1125852556, 1132028671, 182192140);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetOutline(12, playerid);
    PlayerTextDrawFont(12, playerid);
    return 1;
}


stock GivePlayerMoneyBjEx(playerid, money, save, game_text)
{
    return 1;
    GivePlayerMoney(8, playerid, money);
    gettime(12);
    format(32, -740, 185);
    mysql_query(12, 166387936);
    format(20, -740, 185);
    mysql_query(12, 166387936);
    format(16, -868, 32);
    ShowNewNotification(28, playerid, 0, 5, 1, 1, -868, 182192788);
    ShowNotification(24, playerid, 0, -868, 3, 182192792, 182192796);
    format(16, -868, 32);
    ShowNewNotification(28, playerid, 1, 5, 1, 1, -868, 182192836);
    ShowNotification(24, playerid, 1, -868, 3, 182192840, 182192844);
    return 1;
}


public OnPlayerEnterDynamicArea(playerid, areaid)
{
    ShowNotification(24, playerid, 4, 182192848, 3, 182192908, 182192952);
    ShowNewNotification(28, playerid, 5, 5, 61, 1, 182192964, 182193024);
    blackjack_OnPlayerEnterDynamicA(8, playerid, areaid);
    return 1;
}


stock n_veh_OnGameModeInit()
{
    LoadBlackJack(0);
    blackjack_OnGameModeInit(0);
    return 1;
}


stock fixp_OnPlayerConnect(playerid)
{
    LoadPlayerTextDraw(4, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    blackjack_OnPlayerConnect(4, playerid);
    return 1;
}


stock pc_cmd_blackjack(playerid)
{
    IsPlayerInRangeOfPoint(20, playerid, 1084227584);
    HideHud(4, playerid);
    InitPlayerLobby(12, playerid, L_8, 1);
    HideHud(4, playerid);
    InitPlayerLobby(12, playerid, L_8, 2);
    HideHud(4, playerid);
    InitPlayerLobby(12, playerid, L_8, 3);
    HideHud(4, playerid);
    InitPlayerLobby(12, playerid, L_8, 4);
    SendClientMessage(12, playerid, -13618945);
    SendClientMessage(12, playerid, -13618945);
    SendClientMessage(12, playerid, -13618945);
    return 1;
}


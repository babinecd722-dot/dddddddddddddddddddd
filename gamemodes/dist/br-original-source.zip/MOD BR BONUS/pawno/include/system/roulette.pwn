// RESTORED: pawno/include/system/roulette.pwn
// Functions: 17

stock acs_OnGameModeInit()
{
    printf(4, 199233376);
    RuletkaMenu(0);
    LoadPrizeRuletka(0);
    SetTimer(12, 199233548, 1500);
    rul_OnGameModeInit(0);
    return 1;
}


stock acs_OnDialogResponse(playerid, dialogid, response, listitem)
{
    GetPVarInt(8, playerid, 199233636);
    mysql_format(20, 166387936, -380, 94);
    mysql_query(12, 166387936);
    strcat(12, -2904);
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, L_2908, 199234024);
    cache_get_field_content_int(12, L_2908, 199234048);
    format(20, -608, 52);
    strcat(12, -2904);
    format(16, -608, 52);
    SetPVarInt(12, playerid, -608, L_400);
    cache_delete(8, L_384, 1);
    SetPVarInt(12, playerid, 199234148, L_4);
    Dialog(28, playerid, 2832, 2, 199234192, -2904, 199234288, 199234312);
    return 1;
    format(12, -540, 134);
    SendClientMessage(12, playerid, -1);
    return 1;
    GivePlayerCarRoulette(16, playerid);
    format(16, -540, 134);
    random(4, 150);
    GivePlayerDonateRub(20, playerid, L_544);
    format(16, -540, 134);
    random(4);
    GivePlayerMoneyEx(20, playerid, L_544);
    format(16, -540, 134);
    UpdatePlayerDatabaseInt(12, playerid, 199234944);
    format(16, -540, 134);
    gettime(12);
    timestamp_to_date(28);
    format(24, -540, 134);
    UpdatePlayerDatabaseInt(12, playerid, 199235460, 3);
    UpdatePlayerDatabaseInt(12, playerid, 199235492);
    UpdatePlayerDatabaseInt(12, playerid, 199235544, 2);
    UpdatePlayerDatabaseInt(12, playerid, 199235592, 1);
    format(16, -540, 134);
    random(4, 7);
    GivePlayerWeapon(12, playerid);
    format(16, -540, 134);
    UpdatePlayerDatabaseInt(12, playerid, 199235960);
    SetPlayerLevelInit(4, playerid);
    SendClientMessage(12, playerid, -1);
    format(16, -540, 134);
    // casetbl cases=13
    SendClientMessage(12, playerid, -1);
    format(16, -540, 134);
    GetPVarInt(8, playerid, -540);
    mysql_format(20, 166387936, -540, 134);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    return 1;
    name_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock weekly_OnPlayerConnect(playerid)
{
    SetTimerEx(20, 199236548, "ã'", 0);
    rul_OnPlayerConnect(4, playerid);
    return 1;
}


stock btn_OnPlayerClickTextDraw(playerid, clickedid)
{
    SendClientMessage(12, playerid, -1);
    return 1;
    UpdatePlayerDatabaseInt(12, playerid, 199236796);
    SendClientMessage(12, playerid, -1);
    GivePlayerDonateRub(20, playerid, -50);
    format(16, -40, 10);
    PlayerTextDrawSetString(12, playerid);
    SendClientMessage(12, playerid, -1);
    UpdateLastPlayerRuletka(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    UpdatePlayerDatabaseInt(12, playerid, 199237336);
    format(16, -40, 10);
    PlayerTextDrawSetString(12, playerid);
    SetTimerEx(20, 199237408, 500, 1);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    return 1;
    TogglePlayerControllable(8, playerid, 1);
    ShowHud(4, playerid);
    TextDrawHideForPlayer(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    CancelSelectTextDraw(4, playerid);
    rul_OnPlayerClickTextDraw(8, playerid, clickedid);
    return 1;
}


stock pc_cmd_openroulette(playerid)
{
    TogglePlayerControllable(8, playerid, 0);
    HideHud(4, playerid);
    RuletkaPlayer(4, playerid);
    SelectTextDraw(8, playerid, -1);
    SendClientMessage(12, playerid, -1);
    TextDrawShowForPlayer(8, playerid);
    random(4, 12);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    UpdateLastPlayerRuletka(4, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    format(16, -40, 10);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawShow(8, playerid);
    return 1;
}


stock RuletkaMenu()
{
    TextDrawCreate(12, 1080731632, 1129338189, 199237784);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1111290754, 1094323274, 199237868);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1132402770, 1126653841, 199237940);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1122257168, 1115981755, 199238020);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1141537251, 1136080876, 199238096);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1142073242, 1137170278, 199238160);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1128573606, 1133529347, 199238212);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1131369805, 1130039673, 199238296);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1137166624, 1136094469, 199238336);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138271378, 1137197462, 199238400);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1139678836, 1136080880, 199238452);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1140772661, 1137197466, 199238516);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1141504485, 1129695478, 199238568);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1142062319, 1131901465, 199238632);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1137155703, 1129722662, 199238684);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138260456, 1131928650, 199238748);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1139667914, 1129695478, 199238800);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1141981181, 1074114278, 199238864);
    TextDrawCreate(12, 1140761739, 1131928656, 199238936);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1141499023, 1132750674, 199238988);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1142056857, 1133853668, 199239052);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1137144778, 1132764266, 199239104);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138249535, 1133867260, 199239168);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1139656992, 1132750678, 199239220);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1140750818, 1133867264, 199239284);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1141509946, 1134408978, 199239336);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1142067782, 1135511975, 199239400);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1137166624, 1134422570, 199239452);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138271378, 1135525567, 199239516);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1139678836, 1134408981, 199239568);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1140772661, 1135525567, 199239632);
    TextDrawLetterSize(12);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1104974342, 1125117474, 199239684);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1141116730, 1126150518, 199239756);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1132582224, 1116259798, 199239836);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    return 1;
}


stock RuletkaPlayer(playerid)
{
    CreatePlayerTextDraw(16, playerid, 1138171501, 1096552441, 199239916);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1135629645, 1096531575, 199239976);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1133129915, 1097836423, 199240044);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1123536667, 1097517131, 199240108);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1128820140, 1097927229, 199240172);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1136832699, 1110702162, 199240232);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1134292402, 1111134018, 199240276);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1131101415, 1111248968, 199240312);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1125992733, 1111578273, 199240380);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1139371442, 1110922756, 199240432);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1094363539, 1135819001, 199240508);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1120359757, 1135926752, 199240576);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1111415613, 1136816092, 199240640);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1118699507, 1136416090, 199240684);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1093664558, 1134092734, 199240744);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1111328214, 1135089825, 199240812);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1120359757, 1134173297, 199240856);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1118699507, 1134662635, 199240920);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1094014049, 1132270859, 199240980);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1111415613, 1133363560, 199241048);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1120359757, 1132474214, 199241092);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1118699507, 1132963552, 199241156);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1134471853, 1127076476, 199241216);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    return 1;
}


stock LoadPrizeRuletka()
{
    TextDrawSetString(8);
    TextDrawSetString(8);
    return 1;
}


stock weekly_OnPlayerDisconnect(playerid, reason)
{
    rul_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock RunRuletka(playerid)
{
    format(16, -540, 135);
    SendClientMessage(12, playerid, -1);
    GivePrizeRoulette(8, playerid);
    KillTimer(4);
    format(12);
    format(12);
    format(12);
    return 1;
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    random2(8, -592, 12);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    return 1;
}


stock UpdateLastPlayerRuletka(playerid)
{
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    return 1;
}


stock random2(size_w)
{
    return 1;
    random(4, L_4);
    return 1;
}


stock GivePrizeRoulette(playerid, prize_id)
{
    mysql_format(24, 166387936, -376, 94);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    return 1;
}


stock CreateTablistRoulette()
{
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 199242752);
    cache_delete(8, L_4, 1);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 199243416);
    cache_delete(8, L_4, 1);
    return 1;
}


stock GivePlayerCarRoulette(playerid, modelid, color_1, color_2)
{
    GetPlayerPos(16, L_4);
    GetFreeOwnableCarID(0);
    strmid(20);
    gettime(12);
    format(12);
    n_veh_CreateVehicle(44);
    format(12);
    SetVehicleRuNumberPlate(12, L_924);
    SetVehicleParam(12, L_924, 3, 0);
    gettime(12);
    format(48, -912, 220);
    mysql_query(12, 166387936);
    cache_insert_id(4, 1);
    cache_delete(8, L_916, 1);
    return 1;
}


stock pc_cmd_roulette(playerid)
{
    mysql_format(20, 166387936, -376, 94);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    strcat(12, -2896);
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, L_2900, 199244644);
    cache_get_field_content_int(12, L_2900, 199244668);
    format(20, -600, 52);
    strcat(12, -2896);
    format(16, -600, 52);
    SetPVarInt(12, playerid, -600, L_392);
    SetPVarInt(12, playerid, 199244768, 1);
    Dialog(28, playerid, 2832, 2, 199244812, -2896, 199244908, 199244932);
    return 1;
}


stock LoadRuletka(playerid)
{
    mysql_format(20, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    cache_get_row_int(12, 0, 0, 1);
    cache_delete(8, L_500, 1);
    return 1;
}


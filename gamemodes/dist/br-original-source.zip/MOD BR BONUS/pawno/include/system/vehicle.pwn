// RESTORED: pawno/include/system/vehicle.pwn
// Functions: 11

stock SetVehicleDataAll(vehicleid, modelid, angle, color1, color2, respawn_delay, addsiren, action_type, action_id)
{
    IsABike(4, vehicleid, 0, 0, 0, 0, 0, 0);
    SetVehicleParamsEx(32, vehicleid);
    return 1;
}


stock n_veh_AddStaticVehicleEx(modelid, angle, color1, color2, respawn_delay, addsiren, action_type, action_id)
{
    Iter_AddStaticVehicleEx(36, modelid, V_16, V_20, V_24, angle, color1, color2, respawn_delay, 0);
    SetVehicleDataAll(48, 1186228, modelid, V_16, V_20, V_24, angle, color1, color2, respawn_delay, addsiren, action_type, action_id);
    return 1;
}


stock n_veh_CreateVehicle(modelid, angle, color1, color2, respawn_delay, addsiren, action_type, action_id)
{
    Iter_CreateVehicle(36, modelid, V_16, V_20, V_24, angle, color1, color2, respawn_delay, 0);
    SetVehicleDataAll(48, 1186232, modelid, V_16, V_20, V_24, angle, color1, color2, respawn_delay, addsiren, action_type, action_id);
    return 1;
}


stock n_veh_DestroyVehicle(vehicleid)
{
    DestroyVehicleLabel(4, vehicleid);
    Iter_DestroyVehicle(4, vehicleid);
    return 1;
}


stock n_OnGameModeInit()
{
    n_veh_OnGameModeInit(0);
    return 1;
}


stock SetVehicleParamsInit(vehicleid)
{
    GetVehicleParamsEx(32, vehicleid);
    return 1;
}


stock GetVehicleParam(vehicleid, paramid)
{
    SetVehicleParamsInit(4, vehicleid);
    return 1;
}


stock SetVehicleParam(vehicleid, paramid, set_value)
{
    SetVehicleParamsInit(4, vehicleid);
    SetVehicleParamsEx(32, vehicleid);
    return 1;
}


stock CreateVehicleLabel(vehicleid, color, drawdistance, testlos, worldid, interiorid, playerid, streamdistance)
{
    IsValidVehicle(4, vehicleid);
    CreateDynamic3DTextLabel(60, V_16, color, V_24, V_28, V_32, drawdistance, "	'Ì¹ÏX'", vehicleid, testlos, worldid, interiorid, playerid, streamdistance, -1, 0);
    return 1;
}


stock UpdateVehicleLabel(vehicleid, color)
{
    IsValidDynamic3DTextLabel(4);
    UpdateDynamic3DTextLabelText(12);
    return 1;
}


stock DestroyVehicleLabel(vehicleid)
{
    IsValidDynamic3DTextLabel(4);
    DestroyDynamic3DTextLabel(4);
    return 1;
}


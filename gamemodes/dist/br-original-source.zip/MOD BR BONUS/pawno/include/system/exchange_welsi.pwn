// RESTORED: pawno/include/system/exchange_welsi.pwn
// Functions: 15

stock car_OnGameModeInit()
{
    print(4);
    ch_OnGameModeInit(0);
    return 1;
}


stock car_OnPlayerDisconnect(playerid, reason)
{
    SendClientMessage(12, L_4, -1);
    name_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock car_OnPlayerConnect(playerid)
{
    ch_OnPlayerConnect(4, playerid);
    return 1;
}


stock car_OnDialogResponse(playerid, dialogid, response, listitem)
{
    return 1;
    IsPlayerConnected(4);
    DeleteFullPVarExchange(4, playerid);
    return 1;
    GetPVarInt(8, playerid, 197997744);
    SendClientMessage(12, L_4, -1);
    ShowNotification(24, playerid, 1, 197998100, 3, 197998204, 197998208);
    SendClientMessage(12, L_4, -1);
    Exchange_ShowVehicleList(16, playerid, L_12, 0, L_8);
    ShowDialogSelectTypeExchange(4, playerid);
    DeleteFullPVarExchange(4, L_4);
    DeleteFullPVarExchange(4, playerid);
    GetPVarInt(8, playerid, 197998504);
    IsPlayerConnected(4);
    return 1;
    GetPVarInt(8, playerid, 197998572);
    Exchange_ShowVehicleList(16, playerid, L_8);
    return 1;
    GetPVarInt(8, playerid, 197998644);
    Exchange_ShowVehicleList(16, playerid, L_8);
    return 1;
    ShowDialogSelectTypeExchange(4, playerid);
    return 1;
    SetPVarInt(12, L_8, 197998716, L_12);
    mysql_format(20, 166387936, 197995192, 285);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    print(4);
    cache_delete(8, L_16, 1);
    ShowDialogSelectTypeExchange(4, playerid);
    return 1;
    cache_get_field_content_int(12, 0, 197999112);
    GetVehicleModelName(12, L_20, -292, 68);
    strlen(4);
    format(16, -292, 68);
    SetPVarString(12, L_8, 197999184, -292);
    cache_delete(8, L_16, 1);
    IsPlayerConnected(4);
    return 1;
    format(20, -872, 144);
    format(20, -872, 144);
    SendClientMessage(12, L_296, -1);
    GetPVarInt(8, playerid, 197999744);
    ShowNotification(24, playerid, 1, 197999812, 3, 197999932, 197999936);
    SetPVarInt(12, playerid, 197999940, 1);
    ShowDialogSelectTypeExchange(4, playerid);
    Dialog(28, playerid, 1613, 2, 198000008, 198000160, 198000344, 198000376);
    ShowDialogSelectTypeExchange(4, playerid);
    GetPVarInt(8, playerid, 198000404);
    strval(4, V_28);
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPVarInt(8, playerid, 198000652);
    SetPVarInt(12, playerid, 198000712, L_4);
    SendExchange(4, L_8);
    DeleteFullPVarExchange(4, playerid);
    SetPVarInt(12, playerid, 198000752, L_4);
    SendExchange(4, L_8);
    DeleteFullPVarExchange(4, playerid);
    return 1;
    format(16, -512, 128);
    SendClientMessage(12, playerid, -1);
    SendExchange(4);
    Dialog(28, playerid, 1613, 1, 198001064, 198001216, 198001452, 198001476);
    SetPVarInt(12, playerid, 198001500, 1);
    Dialog(28, playerid, 1613, 1, 198001560, 198001712, 198001948, 198001972);
    SetPVarInt(12, playerid, 198001996, 2);
    // casetbl cases=4
    ShowDialogSelectTypeExchange(4, playerid);
    GetPVarInt(8, playerid, 198002056);
    GetPVarInt(8, L_4, 198002140);
    GetPVarInt(8, L_4, 198002224);
    GetPVarInt(8, L_4, 198002264);
    GetPVarInt(8, playerid, 198002324);
    GetPVarInt(8, L_4, 198002392);
    Exchange(32, L_8, L_12, playerid, L_4, L_16, L_20, L_24, L_28);
    SendClientMessage(12);
    SendClientMessage(12, playerid, -1);
    DeleteFullPVarExchange(4, playerid);
    DeleteFullPVarExchange(4);
    ch_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock pc_cmd_changeprop(playerid)
{
    sscanf(12, V_16, 198002812, -4);
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    IsPlayerConnected(4);
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    IsPlayerInRangeOfPlayer(12, playerid, L_4, 1086324736);
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    format(16, -580, 144);
    SendClientMessage(12, playerid, 865730559);
    format(16, -580, 144);
    ShowNotificationNew(28, L_4, 4, 10, 9201, 0, -580, 198003688);
    SetPVarInt(12, L_4, 198003700, playerid);
    SetPVarInt(12, playerid, 198003740, L_4);
    return 1;
}


stock pc_cmd_yeschange(playerid)
{
    GetPVarInt(8, playerid, 198003776);
    IsPlayerConnected(4);
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    GetPVarInt(8, L_4, 198003944);
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    SendClientMessage(12, L_4, -2555649);
    SendClientMessage(12, playerid, -2555649);
    ShowDialogSelectTypeExchange(4, L_4);
    return 1;
}


stock Exchange(type, type_1, player, player_1, surcharge, surcharge_p, vehicle_sql, vehicle_sql_1)
{
    ExchangeHouse(8, player, player_1);
    ExchangeVehicle(8, player_1, vehicle_sql);
    ExchangeBusiness(8, player, player_1);
    ExchangeFuelStation(8, player, player_1);
    print(4);
    // casetbl cases=5
    ExchangeHouse(8, player_1, player);
    ExchangeVehicle(8, player, vehicle_sql_1);
    ExchangeBusiness(8, player_1, player);
    ExchangeFuelStation(8, player_1, player);
    print(4);
    // casetbl cases=5
    print(4);
    return 1;
    GivePlayerMoneyEx(20, L_4, surcharge);
    GivePlayerMoneyEx(20, L_8);
    SendClientMessage(12, player, -1);
    SendClientMessage(12, player, -1);
    SendClientMessage(12, player, -1);
    SendClientMessage(12, player, -1);
    SendClientMessage(12, player_1, -1);
    SendClientMessage(12, player_1, -1);
    SendClientMessage(12, player_1, -1);
    SendClientMessage(12, player_1, -1);
    format(16, -512, 128);
    SendClientMessage(12, player, -1);
    format(16, -512, 128);
    SendClientMessage(12, player_1, -1);
    DeleteFullPVarExchange(4, player);
    DeleteFullPVarExchange(4, player_1);
    return 1;
}


stock ExchangeVehicle(playerid, sql_id)
{
    UnloadPlayerOwnableCar(8);
    mysql_format(24, 166387936, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
}


stock ExchangeFuelStation(playerid, to_player)
{
    GetPlayerFuelStation(4, playerid);
    mysql_format(20, 166387936, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    format(28, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    mysql_errno(4);
    gettime(12);
    format(16);
    CallLocalFunction(12, 198008588, 198008680, -4);
    SendClientMessage(12, to_player, 1724645631);
    format(40, 197995192, 285);
    mysql_query(12, 166387936);
    format(16, 197995192, 285);
    mysql_query(12, 166387936);
    return 1;
}


stock ExchangeBusiness(playerid, to_player)
{
    GetPlayerBusiness(4, playerid);
    mysql_format(20, 166387936, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    mysql_format(32, 166387936, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    printf(8, 198010548);
    mysql_errno(4);
    gettime(12);
    format(16);
    CallLocalFunction(12, 198010576, 198010656, -4);
    SendClientMessage(12, to_player, 1724645631);
    format(36, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    format(16, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
}


stock ExchangeHouse(playerid, to_player)
{
    GetPlayerHouse(8, playerid, -1);
    mysql_format(20, 166387936, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    format(32, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    printf(8, 198012844);
    mysql_errno(4);
    gettime(12);
    GetElapsedTime(12);
    CallLocalFunction(12, 198012872, 198012948, -24);
    mysql_errno(4);
    print(4);
    return 1;
    format(16);
    cache_delete(8, L_28, 1);
    UpdateHouse(4, L_4);
    HouseHealthInit(8, L_4, -1);
    HouseStoreInit(8, L_4, -1);
    format(24, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
}


stock Exchange_ShowVehicleList(viewerid, ownerid, page, is_select_other)
{
    IsPlayerConnected(4);
    return 1;
    mysql_format(20, 166387936, 197995192, 285);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    cache_delete(8, L_4, 1);
    return 1;
    cache_get_row_count(4, 1);
    SendClientMessage(12, viewerid, -1);
    cache_delete(8, L_4, 1);
    return 1;
    format(12, -16404, 4096);
    cache_get_field_content_int(12, L_17052, 198014624);
    cache_get_field_content_int(12, L_17052, 198014636);
    GetVehicleModelName(12, L_17060, -17188, 32);
    strlen(4);
    format(16, -17188, 32);
    format(20, -17044, 160);
    strlen(4);
    strlen(4);
    strcat(12, -16404);
    format(12, -17044, 160);
    strlen(4);
    strlen(4);
    strcat(12, -16404);
    format(12, -17044, 160);
    strlen(4);
    strlen(4);
    strcat(12, -16404);
    SetPVarInt(12, viewerid, 198015072, page);
    SetPVarInt(12, ownerid, 198015144, 2);
    Dialog(28, viewerid, 1612, 5, 198015228, -16404, 198015424, 198015456);
    cache_delete(8, L_4, 1);
    return 1;
}


stock ShowDialogSelectTypeExchange(playerid)
{
    Dialog(28, playerid, 1610, 5, 198015484, 198015684, 198016084, 198016116);
    return 1;
}


stock SendExchange(playerid)
{
    GetPVarInt(8, L_4, 198016144);
    GetPVarString(16, playerid, 198016228, -472, 68);
    GetPVarString(16, L_4, 198016288, -744, 68);
    strlen(4);
    format(12, -472, 68);
    strlen(4);
    format(12, -744, 68);
    GetPVarInt(8, L_4, 198016436);
    format(16, -200, 48);
    format(16, -200, 48);
    // casetbl cases=3
    format(28, 197995192, 285);
    Dialog(28, playerid, 1614, 0, 198017308, 197995192, 198017440, 198017464);
    return 1;
}


stock DeleteFullPVarExchange(playerid)
{
    DeletePVar(8, playerid, 198017488);
    DeletePVar(8, playerid, 198017528);
    DeletePVar(8, playerid, 198017568);
    DeletePVar(8, playerid, 198017628);
    DeletePVar(8, playerid, 198017696);
    DeletePVar(8, playerid, 198017756);
    DeletePVar(8, playerid, 198017824);
    DeletePVar(8, playerid, 198017908);
    return 1;
}


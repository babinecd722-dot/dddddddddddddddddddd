// RESTORED: pawno/include/system/new_promo.pwn
// Functions: 32

stock blackjack_OnGameModeInit()
{
    print(4);
    SetTimer(12, 197881028, 1500);
    SetTimer(12, 197881132, 3000);
    prom_OnGameModeInit(0);
    return 1;
}


public OnPromoTimerTick(playerPromoSQLID)
{
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    cache_get_row_count(4, L_1028);
    mysql_errno(4);
    printf(12, 197882108);
    IsPlayerConnected(4);
    KillTimer(4);
    cache_delete(8, L_1028, 1);
    return 1;
    cache_get_field_content_int(12, 0, 197882496);
    cache_get_field_content_int(12, 0, 197882540);
    cache_get_field_content_int(12, 0, 197882584);
    cache_get_field_content_int(12, 0, 197882628);
    cache_get_field_content_int(12, 0, 197882676);
    cache_get_field_content_int(12, 0, 197882736);
    gettime(12);
    GetPlayerIDFromAccountID(4, L_1032);
    RevokePromoPrize(16, L_1032, L_1036, L_1040, L_1044);
    SendClientMessage(12, L_1048, -1);
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    IsPlayerConnected(4);
    KillTimer(4);
    mysql_format(24, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    cache_delete(8, L_1028, 1);
    return 1;
}


stock CheckAndCreatePromoTables()
{
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    printf(4, 197883552);
    mysql_format(20, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 197885864);
    printf(4, 197886104);
    cache_delete(8, L_4, 1);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    printf(4, 197886556);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 197887956);
    printf(4, 197888220);
    cache_delete(8, L_4, 1);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    printf(4, 197888596);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 197890512);
    printf(4, 197890760);
    cache_delete(8, L_4, 1);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    cache_get_field_count(4, L_4);
    printf(4, 197891124);
    mysql_errno(4);
    mysql_query(12, 166387936);
    printf(4, 197891652);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 197893400);
    printf(4, 197893652);
    cache_delete(8, L_4, 1);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    printf(4, 197894148);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 197894796);
    printf(4, 197895036);
    cache_delete(8, L_4, 1);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    printf(4, 197895472);
    mysql_format(16, 166387936, -2052, 512);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 197896200);
    printf(4, 197896472);
    cache_delete(8, L_4, 1);
    return 1;
}


stock LoadPromoCodesFromDatabase()
{
    printf(4, 197896712);
    mysql_format(16, 166387936, -516, 128);
    printf(8, 197897180);
    mysql_query(12, 166387936);
    mysql_errno(4);
    printf(8, 197897312);
    mysql_errno(4);
    mysql_errno(4);
    printf(8, 197897468);
    cache_delete(8, L_4, 1);
    return 1;
    cache_get_row_count(4, L_4);
    printf(8, 197897664);
    printf(16, 197897900);
    printf(4, 197898316);
    cache_get_field_content_int(12, L_520, 197898548);
    cache_get_field_content(20, L_520, 197898560);
    cache_get_field_content_int(12, L_520, 197898580);
    cache_get_field_content_int(12, L_520, 197898624);
    cache_get_field_content_int(12, L_520, 197898664);
    cache_delete(8, L_4, 1);
    printf(8, 197898708);
    printf(4, 197898956);
    return 1;
}


stock blackjack_OnPlayerConnect(playerid)
{
    OnPlayerLogin(4, playerid);
    prom_OnPlayerConnect(4, playerid);
    return 1;
}


public OnPlayerLogin(playerid)
{
    mysql_format(20, 166387936, -1032, 256);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, L_1040, 197900128);
    cache_get_field_content_int(12, L_1040, 197900140);
    cache_get_field_content_int(12, L_1040, 197900184);
    cache_get_field_content_int(12, L_1040, 197900244);
    cache_get_field_content_int(12, L_1040, 197900304);
    cache_get_field_content_int(12, L_1040, 197900348);
    cache_get_field_content_int(12, L_1040, 197900396);
    gettime(12);
    mysql_format(24, 166387936, -1032, 256);
    mysql_query(12, 166387936);
    SetPlayerPromoTimer(12, playerid, L_1044, L_1056);
    RevokePromoPrize(16, L_4, L_1060, L_1064, L_1068);
    mysql_format(20, 166387936, -1032, 256);
    mysql_query(12, 166387936);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_8, 1);
    return 1;
}


stock blackjack_OnPlayerDisconnect(playerid, reason)
{
    StopPlayerPromoTimer(4, playerid);
    prom_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock GetPlayerIDFromAccountID(accountId)
{
    IsPlayerConnected(4);
    return 1;
}


stock SetPlayerPromoTimer(playerid, playerPromoSQLID, durationHours)
{
    printf(20, 197901080);
    return 1;
    SetTimerEx(20, 197901536, "4k", 1);
    printf(20, 197901612);
    return 1;
}


stock StopPlayerPromoTimer(playerid)
{
    KillTimer(4);
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    cache_get_row_count(4, L_1028);
    cache_get_field_content_int(12, 0, 197902276);
    cache_get_field_content_int(12, 0, 197902320);
    mysql_format(20, 166387936, -1572, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    cache_get_row_count(4, L_1060);
    cache_get_field_content_int(12, 0, 197902864);
    cache_delete(8, L_1060, 1);
    gettime(12);
    min(8, L_1052, L_1576);
    mysql_format(24, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    printf(20, 197903160);
    cache_delete(8, L_1028, 1);
    return 1;
}


stock RevokePromoPrize(accountId, prizeType, prizeValue, promoIdForCarRevoke)
{
    GetPlayerIDFromAccountID(4, accountId);
    return 1;
    UpdatePlayerDatabaseInt(12, L_4, 197903660, 0);
    SendClientMessage(16, L_4, -1);
    GivePlayerMoneyEx(20, L_4);
    SendClientMessage(16, L_4, -1);
    GivePlayerDonateRub(20, L_4);
    SendClientMessage(16, L_4, -1);
    GivePlayerDonateRub(20, L_4);
    SendClientMessage(16, L_4, -1);
    mysql_format(28, 166387936, -1028, 256);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, 0, 197906000);
    cache_get_field_content_int(12, 0, 197906012);
    mysql_format(20, 166387936, -1028, 256);
    mysql_query(12, 166387936);
    IsValidVehicle(4, L_1044);
    n_veh_DestroyVehicle(4, L_1044);
    IsValidVehicle(4);
    n_veh_DestroyVehicle(4);
    SendClientMessage(12, L_4, -1);
    printf(20, 197906500);
    cache_delete(8, L_1032, 1);
    return 1;
    // casetbl cases=5
    printf(20, 197906968);
    return 1;
}


stock GetPromoCodeDataByString()
{
    strcmp(16);
    strmid(20);
    return 1;
}


stock GetPromoCodeIndexByString()
{
    strcmp(16);
    return 1;
}


stock GivePromoCar(playerid, modelid, promoSqlId)
{
    GetPlayerPos(16, playerid);
    gettime(12);
    format(56, -1060, 256);
    mysql_query(12, 166387936);
    cache_delete(8, L_1064, 1);
    return 1;
}


stock ShowPromoCreationConfirmation(playerid)
{
    strmid(20, -5248);
    format(12, -4096, 1024);
    format(16, -5120, 256);
    strcat(12, -4096);
    format(12, -5384, 32);
    format(16, -5384, 32);
    format(16, -5120, 256);
    strcat(12, -4096);
    strcat(12, -4096);
    format(12, -6168, 64);
    format(16, -6168, 64);
    format(24, -5912, 128);
    format(24, -5912, 128);
    format(28, -5912, 128);
    // casetbl cases=4
    strcat(12, -4096);
    fg_ShowPlayerDialog(28, playerid, "usesRenters", 0, 197909448, -4096, 197909700, 197909732);
    return 1;
}


stock CreatePromoCodeInDatabase(playerid)
{
    strmid(20, -4224);
    mysql_format(32, 166387936, -4096, 1024);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    format(16, -5264, 256);
    SendClientMessage(12, playerid, -1);
    mysql_errno(4);
    printf(8, 197910444);
    cache_delete(8, L_4240, 1);
    return 1;
    cache_insert_id(4, L_4240);
    cache_delete(8, L_4240, 1);
    SendClientMessage(12, playerid, -1);
    printf(8, 197910968);
    return 1;
    mysql_format(36, 166387936, -4096, 1024);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    format(20, -5264, 256);
    SendClientMessage(12, playerid, -1);
    mysql_errno(4);
    printf(16, 197912028);
    format(20, -5264, 256);
    SendClientMessage(12, playerid, -1);
    LoadPromoCodesFromDatabase(0);
    return 1;
}


stock blackjack_OnDialogResponse(playerid, dialogid, response, listitem)
{
    pc_cmd_mypromo(8, playerid, 197912644);
    GetPromoLevelForOwner(4, playerid);
    format(12, -4228, 32);
    format(12, -4228, 32);
    format(28, -4096, 1024);
    strlen(4);
    strlen(4);
    fg_ShowPlayerDialog(28, playerid, "ers", 2, 197914156, -4096, 197914220, 197914256);
    fg_ShowPlayerDialog(28, playerid, "enters", 0, 197914280, 197914352, 197916492, 197916516);
    pc_cmd_mypromo(8, playerid, 197916520);
    // casetbl cases=5
    GetPromoLevelForOwner(4, playerid);
    mysql_format(20, 166387936, -1044, 256);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_1048);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_1048, 1);
    return 1;
    cache_get_field_content_int(12, 0, 197917084);
    cache_get_field_content_int(12, 0, 197917096);
    cache_get_field_content_int(12, 0, 197917144);
    cache_delete(8, L_1048, 1);
    SendClientMessage(12, playerid, -1);
    pc_cmd_mypromo(8, playerid, 197917488);
    return 1;
    SendClientMessage(12, playerid, -1);
    pc_cmd_mypromo(8, playerid, 197917716);
    return 1;
    format(24, -3108, 512);
    format(24, -3108, 512);
    SendClientMessage(12, playerid, -1);
    pc_cmd_mypromo(8, playerid, 197919884);
    return 1;
    fg_ShowPlayerDialog(28, playerid, "rs", 0, 197919888, -3108, 197920032, 197920056);
    pc_cmd_mypromo(8, playerid, 197920080);
    mysql_format(20, 166387936, -1040, 256);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_1044);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_1044, 1);
    return 1;
    cache_get_field_content_int(12, 0, 197920644);
    cache_get_field_content_int(12, 0, 197920656);
    cache_get_field_content_int(12, 0, 197920704);
    cache_delete(8, L_1044, 1);
    mysql_format(24, 166387936, -1040, 256);
    mysql_query(12, 166387936);
    SavePromoLevelPrizes(12, playerid, L_16, L_4);
    SendClientMessage(12, playerid, -1);
    mysql_format(28, 166387936, -1040, 256);
    mysql_query(12, 166387936);
    SavePromoLevelPrizes(12, playerid, L_16, L_4);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    pc_cmd_mypromo(8, playerid, 197922248);
    pc_cmd_mypromo(8, playerid, 197922252);
    pc_cmd_mypromo(8, playerid, 197922256);
    SendClientMessage(12, playerid, -1);
    return 1;
    pc_cmd_bcode(8, playerid, 197922448);
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197922652);
    HasPlayerCreatedPromo(4, playerid);
    pc_cmd_mypromo(8, playerid, 197922656);
    fg_ShowPlayerDialog(28, playerid, "esRenters", 1, 197922660, 197922768, 197925608, 197925632);
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_1028);
    cache_get_row_count(4, L_1028);
    cache_get_field_content(20, 0, 197926416, 1, 1);
    format(16, -5124, 1024);
    cache_get_field_content(20, L_5136, 197926436, -5264, 32, 32);
    format(20, -5124, 1024);
    format(12, -5124, 1024);
    cache_delete(8, L_1028, 1);
    format(16, -5644, 128);
    fg_ShowPlayerDialog(28, playerid, "Renters", 2, -5644, -5124, 197926920, 197926932);
    // casetbl cases=5
    SendClientMessage(12, playerid, -1);
    return 1;
    strlen(4);
    SendClientMessage(12, playerid, -1);
    fg_ShowPlayerDialog(28, playerid, "esRenters", 1, 197927404, 197927512, 197930352, 197930376);
    return 1;
    strlen(4);
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197930676);
    return 1;
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197930964);
    return 1;
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197931408);
    return 1;
    OnPromoCodeCheckComplete(8, playerid, V_28);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    strlen(4);
    SendClientMessage(12, playerid, -1);
    pc_cmd_addcpromo(8, playerid, 197931836);
    return 1;
    strfind(16, V_28, 197931840);
    SendClientMessage(12, playerid, -1);
    pc_cmd_addcpromo(8, playerid, 197932116);
    return 1;
    strlen(4);
    format(16, -512, 128);
    SendClientMessage(12, playerid, -1);
    pc_cmd_addcpromo(8, playerid, 197932416);
    return 1;
    GetPromoCodeIndexByString(4, V_28);
    SendClientMessage(12, playerid, -1);
    pc_cmd_addcpromo(8, playerid, 197932664);
    return 1;
    strmid(20);
    fg_ShowPlayerDialog(28, playerid, "LoadHousesRenters", 1, 197932668, 197932864, 197932996, 197933020);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    strval(4, V_28);
    SendClientMessage(12, playerid, -1);
    fg_ShowPlayerDialog(28, playerid, "LoadHousesRenters", 1, 197933472, 197933668, 197933800, 197933824);
    return 1;
    fg_ShowPlayerDialog(28, playerid, 12347, 1, 197933852, 197934048, 197934272, 197934296);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    strval(4, V_28);
    SendClientMessage(12, playerid, -1);
    fg_ShowPlayerDialog(28, playerid, 12347, 1, 197934780, 197934976, 197935200, 197935224);
    return 1;
    format(20, -516, 128);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -516, 197935484, 197935772, 197935804);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    format(12, -1028, 256);
    format(12, -1028, 256);
    format(12, -1028, 256);
    format(12, -1028, 256);
    // casetbl cases=5
    format(20, -1540, 128);
    fg_ShowPlayerDialog(28, playerid, "adHousesRenters", 1, -1540, -1028, 197936768, 197936792);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    strval(4, V_28);
    format(20, -524, 128);
    SendClientMessage(12, playerid, -1);
    format(12, -1548, 256);
    format(12, -1548, 256);
    format(12, -1548, 256);
    format(12, -1548, 256);
    // casetbl cases=5
    fg_ShowPlayerDialog(28, playerid, "adHousesRenters", 1, -524, -1548, 197938100, 197938124);
    return 1;
    format(20, -524, 128);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -524, 197938384, 197938672, 197938704);
    ShowPromoCreationConfirmation(4, playerid);
    return 1;
    fg_ShowPlayerDialog(28, playerid, "dHousesRenters", 2, -524, 197938732, 197939008, 197939040);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    format(20, -520, 128);
    fg_ShowPlayerDialog(28, playerid, "HousesRenters", 1, -520, 197939524, 197939668, 197939692);
    return 1;
    format(20, -520, 128);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -520, 197939952, 197940240, 197940272);
    ShowPromoCreationConfirmation(4, playerid);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    strval(4, V_28);
    SendClientMessage(12, playerid, -1);
    format(20, -520, 128);
    fg_ShowPlayerDialog(28, playerid, "HousesRenters", 1, -520, 197941048, 197941192, 197941216);
    return 1;
    format(20, -520, 128);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -520, 197941452, 197941740, 197941772);
    ShowPromoCreationConfirmation(4, playerid);
    return 1;
    CreatePromoCodeInDatabase(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    strlen(4);
    SendClientMessage(12, playerid, -1);
    pc_cmd_bcode(8, playerid, 197942452);
    return 1;
    mysql_format(20, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    return 1;
    cache_get_row_count(4, L_1296);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_1296, 1);
    pc_cmd_bcode(8, playerid, 197943012);
    cache_get_field_content_int(12, 0, 197943016);
    cache_get_field_content_int(12, 0, 197943028);
    cache_get_field_content_int(12, 0, 197943104);
    cache_get_field_content_int(12, 0, 197943152);
    cache_get_field_content_int(12, 0, 197943200);
    cache_delete(8, L_1296, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    pc_cmd_bcode(8, playerid, 197943896);
    return 1;
    cache_delete(8, L_1296, 1);
    GetPromoCodeDataByString(8, V_28, -144);
    mysql_format(24, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_1296);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_1296, 1);
    return 1;
    cache_delete(8, L_1296, 1);
    mysql_format(24, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_1296);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_1296, 1);
    return 1;
    cache_delete(8, L_1296, 1);
    format(16, -5412, 1024);
    strcat(12, -5412);
    mysql_format(20, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    cache_get_row_count(4, L_1296);
    SendClientMessage(12, playerid, -1);
    mysql_errno(4);
    printf(12, 197946444);
    cache_delete(8, L_1296, 1);
    return 1;
    cache_get_row_count(4, L_1296);
    cache_get_field_content_int(12, 0, 197946692);
    cache_get_field_content_int(12, 0, 197946704);
    cache_get_field_content_int(12, 0, 197946748);
    cache_get_field_content_int(12, 0, 197946796);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5684, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197947488);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197948092);
    cache_insert_id(4, L_7036);
    SetPlayerPromoTimer(12, playerid, L_7040, L_5688);
    cache_delete(8, L_7036, 1);
    cache_get_field_content_int(12, 0, 197948356);
    cache_get_field_content_int(12, 0, 197948368);
    cache_get_field_content_int(12, 0, 197948412);
    cache_get_field_content_int(12, 0, 197948460);
    cache_get_field_content_int(12, 1, 197948520);
    cache_get_field_content_int(12, 1, 197948532);
    cache_get_field_content_int(12, 1, 197948576);
    cache_get_field_content_int(12, 1, 197948624);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5684, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197949316);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197949920);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5688);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5700, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197950816);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197951420);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5704);
    cache_delete(8, L_6780, 1);
    cache_get_field_content_int(12, 0, 197951684);
    cache_get_field_content_int(12, 0, 197951696);
    cache_get_field_content_int(12, 0, 197951740);
    cache_get_field_content_int(12, 0, 197951788);
    cache_get_field_content_int(12, 1, 197951848);
    cache_get_field_content_int(12, 1, 197951860);
    cache_get_field_content_int(12, 1, 197951904);
    cache_get_field_content_int(12, 1, 197951952);
    cache_get_field_content_int(12, 2, 197952012);
    cache_get_field_content_int(12, 2, 197952024);
    cache_get_field_content_int(12, 2, 197952068);
    cache_get_field_content_int(12, 2, 197952116);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5684, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197952808);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197953412);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5688);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5700, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197954308);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197954912);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5704);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5716);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5716);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5716, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197955808);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197956412);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5720);
    cache_delete(8, L_6780, 1);
    cache_get_field_content_int(12, 0, 197956676);
    cache_get_field_content_int(12, 0, 197956688);
    cache_get_field_content_int(12, 0, 197956732);
    cache_get_field_content_int(12, 0, 197956780);
    cache_get_field_content_int(12, 1, 197956840);
    cache_get_field_content_int(12, 1, 197956852);
    cache_get_field_content_int(12, 1, 197956896);
    cache_get_field_content_int(12, 1, 197956944);
    cache_get_field_content_int(12, 2, 197957004);
    cache_get_field_content_int(12, 2, 197957016);
    cache_get_field_content_int(12, 2, 197957060);
    cache_get_field_content_int(12, 2, 197957108);
    cache_get_field_content_int(12, 3, 197957168);
    cache_get_field_content_int(12, 3, 197957180);
    cache_get_field_content_int(12, 3, 197957224);
    cache_get_field_content_int(12, 3, 197957272);
    cache_get_field_content_int(12, 0, 197957332);
    cache_get_field_content_int(12, 0, 197957344);
    cache_get_field_content_int(12, 0, 197957388);
    cache_get_field_content_int(12, 0, 197957436);
    cache_get_field_content_int(12, 1, 197957496);
    cache_get_field_content_int(12, 1, 197957508);
    cache_get_field_content_int(12, 1, 197957552);
    cache_get_field_content_int(12, 1, 197957600);
    cache_get_field_content_int(12, 2, 197957660);
    cache_get_field_content_int(12, 2, 197957672);
    cache_get_field_content_int(12, 2, 197957716);
    cache_get_field_content_int(12, 2, 197957764);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5684, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197958456);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197959060);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5688);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5700, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197959956);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197960560);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5704);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5716);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5716);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5716, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197961456);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197962060);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5720);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5732);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5732);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5732, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197962956);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197963560);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5736);
    cache_delete(8, L_6780, 1);
    cache_get_field_content_int(12, 0, 197963824);
    cache_get_field_content_int(12, 0, 197963836);
    cache_get_field_content_int(12, 0, 197963880);
    cache_get_field_content_int(12, 0, 197963928);
    cache_get_field_content_int(12, 1, 197963988);
    cache_get_field_content_int(12, 1, 197964000);
    cache_get_field_content_int(12, 1, 197964044);
    cache_get_field_content_int(12, 1, 197964092);
    cache_get_field_content_int(12, 2, 197964152);
    cache_get_field_content_int(12, 2, 197964164);
    cache_get_field_content_int(12, 2, 197964208);
    cache_get_field_content_int(12, 2, 197964256);
    cache_get_field_content_int(12, 3, 197964316);
    cache_get_field_content_int(12, 3, 197964328);
    cache_get_field_content_int(12, 3, 197964372);
    cache_get_field_content_int(12, 3, 197964420);
    cache_get_field_content_int(12, 4, 197964480);
    cache_get_field_content_int(12, 4, 197964492);
    cache_get_field_content_int(12, 4, 197964536);
    cache_get_field_content_int(12, 4, 197964584);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5684);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5684, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197965276);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197965880);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5688);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5700);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5700, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197966776);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197967380);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5704);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5716);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5716);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5716, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197968276);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197968880);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5720);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5732);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5732);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5732, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197969776);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197970380);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5736);
    cache_delete(8, L_6780, 1);
    format(12, -5672, 64);
    format(16, -5672, 64);
    GivePlayerMoneyEx(20, playerid, L_5748);
    format(20, -6776, 256);
    GivePlayerDonateRub(20, playerid, L_5748);
    format(20, -6776, 256);
    GivePromoCar(12, playerid, L_5748, L_1300);
    format(24, -6776, 256);
    UpdatePlayerDatabaseInt(12, playerid, 197971276);
    format(16, -6776, 256);
    // casetbl cases=5
    strcat(12, -5412);
    gettime(12);
    mysql_format(32, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197971880);
    cache_insert_id(4, L_6780);
    SetPlayerPromoTimer(12, playerid, L_6784, L_5752);
    cache_delete(8, L_6780, 1);
    cache_delete(8, L_1296, 1);
    mysql_format(20, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    GetPromoCodeIndexByString(4, V_28);
    mysql_format(24, 166387936, -1292, 286);
    mysql_query(12, 166387936);
    GetPlayerIDFromAccountID(4, L_1304);
    format(16, -6784, 256);
    SendClientMessage(12, L_5760, -1);
    fg_ShowPlayerDialog(28, playerid, "ew", 0, 197973252, -5412, 197973452, 197973464);
    AddPlayerActivatedPromo(8);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    // casetbl cases=16
    prom_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock CheckUsePromoCode(playerid, accountId, promoSqlId)
{
    mysql_format(24, 166387936, -624, 156);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_628);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_628, 1);
    return 1;
    cache_delete(8, L_628, 1);
    return 1;
}


public OnPromoCodeCheckComplete(playerid)
{
    IsPlayerConnected(4);
    return 1;
    mysql_format(20, 166387936, -1032, 258);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197975196);
    cache_delete(8, L_2196, 1);
    return 1;
    cache_get_row_count(4, L_2196);
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197975544);
    cache_delete(8, L_2196, 1);
    return 1;
    cache_delete(8, L_2196, 1);
    strlen(4);
    format(20, -2468, 64);
    format(16, -2468, 64);
    mysql_format(28, 166387936, -1032, 258);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197976576);
    cache_delete(8, L_2196, 1);
    return 1;
    cache_delete(8, L_2196, 1);
    format(20, -2192, 256);
    SendClientMessage(12, playerid, -1);
    pc_cmd_promo(8, playerid, 197976928);
    return 1;
    GivePlayerDonateRub(20, playerid);
    format(20, -2192, 256);
    SendClientMessage(12, playerid, -1);
    pc_cmd_mypromo(8, playerid, 197977384);
    LoadPromoCodesFromDatabase(0);
    GivePlayerMoneyEx(20, playerid);
    format(20, -2192, 256);
    SendClientMessage(12, playerid, -1);
    pc_cmd_mypromo(8, playerid, 197977828);
    LoadPromoCodesFromDatabase(0);
    return 1;
}


stock HasPlayerCreatedPromo(playerid)
{
    mysql_format(20, 166387936, -512, 128);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_516);
    cache_delete(8, L_516, 1);
    return 1;
}


stock AddPlayerActivatedPromo(account_id, promo_id)
{
    mysql_format(24, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    return 1;
}


stock SavePromoLevelPrizes(promoId, level)
{
    mysql_format(20, 166387936, -1028, 256);
    mysql_query(12, 166387936);
    // casetbl cases=11
    mysql_format(36, 166387936, -1028, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 197979236);
    return 1;
}


stock GetPromoLevelForOwner(playerid)
{
    mysql_format(20, 166387936, -512, 128);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_520);
    cache_get_field_content_int(12, 0, 197979924);
    cache_delete(8, L_520, 1);
    return 1;
}


stock pc_cmd_createpromo(playerid)
{
    pc_cmd_addcpromo(8, playerid, 197979972);
    return 1;
}


stock pc_cmd_createytpromo(playerid)
{
    pc_cmd_addcpromo(8, playerid, 197979976);
    return 1;
}


stock pc_cmd_addcpromo(playerid)
{
    SendClientMessage(12, playerid, -1);
    return 1;
    fg_ShowPlayerDialog(28, playerid, "w", 1, 197980276, 197980472, 197980644, 197980668);
    return 1;
}


stock pc_cmd_promo(playerid)
{
    HasPlayerCreatedPromo(4, playerid);
    format(12, -2304, 64);
    format(12, -2304, 64);
    format(16, -2048, 512);
    fg_ShowPlayerDialog(28, playerid, "sesRenters", 2, 197982340, -2048, 197982412, 197982436);
    return 1;
}


stock pc_alias_promo()
{
    PC_RegAlias(8, 197982460, 197982484);
    return 1;
}


stock pc_cmd_mypromo(playerid)
{
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_3216);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_3216, 1);
    return 1;
    cache_get_field_content(20, 0, 197983120, -3200, 32, 32);
    cache_get_field_content_int(12, 0, 197983140);
    cache_get_field_content_int(12, 0, 197983188);
    format(28, -3072, 512);
    fg_ShowPlayerDialog(28, playerid, "nters", 2, 197984156, -3072, 197984228, 197984252);
    cache_delete(8, L_3216, 1);
    return 1;
}


stock pc_alias_mypromo()
{
    PC_RegAlias(8, 197984276, 197984308);
    return 1;
}


stock pc_cmd_checkpromo(playerid)
{
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    cache_get_row_count(4, L_3684);
    SendClientMessage(12, playerid, -1);
    cache_delete(8, L_3684, 1);
    return 1;
    cache_get_field_content_int(12, 0, 197985044);
    cache_get_field_content(20, 0, 197985056, -3812, 32, 32);
    cache_get_field_content_int(12, 0, 197985076);
    cache_get_field_content_int(12, 0, 197985124);
    cache_get_field_content_int(12, 0, 197985172);
    cache_delete(8, L_3684, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    format(16, -3680, 152);
    format(24, -3072, 512);
    fg_ShowPlayerDialog(28, playerid, "s", 0, -3680, -3072, 197986116, 197986140);
    return 1;
    GivePlayerMoneyEx(20, playerid, L_3824);
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    return 1;
}


stock pc_cmd_bcode(playerid)
{
    fg_ShowPlayerDialog(28, playerid, "ousesRenters", 1, 197986384, 197986452, 197986640, 197986668);
    return 1;
}


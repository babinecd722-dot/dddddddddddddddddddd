// RESTORED: pawno/include/system/cp_race.pwn
// Functions: 4

stock ClearPlayerRCPInfo(playerid)
{
    return 1;
}


stock n_SetPlayerRaceCheckpoint(playerid, type, nextx, nexty, nextz, size, action_type)
{
    SetPlayerRaceCheckpoint(36, playerid, type, V_20, V_24, V_28, nextx, nexty, nextz, size);
    return 1;
}


stock n_IsPlayerInRaceCheckpoint(playerid)
{
    IsPlayerInRangeOfPoint(20, playerid);
    return 1;
}


stock n_DisablePlayerRaceCheckpoint(playerid)
{
    DisablePlayerRaceCheckpoint(4, playerid);
    return 1;
}


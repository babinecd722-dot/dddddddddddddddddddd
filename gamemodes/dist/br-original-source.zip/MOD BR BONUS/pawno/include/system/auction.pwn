// RESTORED: pawno/include/system/auction.pwn
// Functions: 27

stock e_OnDialogResponse(playerid, dialogid, response, listitem)
{
    strval(4, V_28);
    GetPVarInt(8, playerid, 200101468);
    SendClientMessage(12, playerid, -1);
    return 1;
    GivePlayerMoneyEx(20, L_68);
    SendClientMessage(12, L_68, -1);
    format(20, -560, 124);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    GivePlayerMoneyEx(20, playerid);
    default_select_slot(4, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    valstr(12, -44);
    PlayerTextDrawSetString(12, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPVarInt(8, playerid, 200102624);
    SetPVarInt(12, playerid, 200102676, 2);
    SetPVarInt(12, playerid, 200102720, 3);
    SetPVarInt(12, playerid, 200102764, 1);
    SetPVarInt(12, playerid, 200102808, 4);
    SetPVarInt(12, playerid, 200102852, 5);
    SetPVarInt(12, playerid, 200102896, 6);
    // casetbl cases=7
    PlayerTextDrawSetString(12, playerid);
    GetPVarInt(8, playerid, 200102940);
    PlayerTextDrawSetString(12, playerid);
    GetPVarInt(8, playerid, 200102984);
    PlayerTextDrawSetString(12, playerid);
    SetPVarString(12, playerid, 200103028, V_28);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    sscanf(12, V_28, 200103108, -4);
    SendClientMessage(12, playerid, -1);
    return 1;
    SetPVarInt(12, playerid, 200103368, L_4);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    // casetbl cases=4
    return 1;
    GetPVarInt(8, playerid, 200103416);
    GetPVarString(16, playerid, 200103460, -620, 7);
    printf(8, 200103524);
    mysql_format(20, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    cache_get_field_content(20, 0, 200104096, -652, 166387936, 7);
    format(16, -496, 124);
    SetPVarString(12, playerid, 200104316, -652);
    format(12, -592, 24);
    Dialog(28, playerid, "l'", 0, 200104380, -496, 200104444, 200104468);
    GetPVarInt(8, playerid, 200104492);
    return 1;
    mysql_format(20, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    cache_get_field_content_int(12, 0, 200104916);
    format(16, -496, 124);
    SetPVarInt(12, playerid, 200105112, L_596);
    SetPVarInt(12, playerid, 200105160, L_604);
    format(12, -592, 24);
    Dialog(28, playerid, "l'", 0, 200105236, -496, 200105300, 200105324);
    GetPVarInt(8, playerid, 200105348);
    format(12, -592, 24);
    GetPVarInt(8, playerid, 200105452);
    format(16, -592, 24);
    GetPVarInt(8, playerid, 200105528, 0);
    valstr(12, -616);
    format(12, -592, 24);
    GetPVarInt(8, playerid, 200105576);
    GetVehicleModel(4);
    ProbelText(4);
    format(12, -592, 24);
    // casetbl cases=7
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    GetPVarInt(8, playerid, 200105652);
    LeafAuction(8, playerid, 3);
    DeletePVar(8, playerid, 200105724);
    return 1;
    sscanf(16, V_28, 200105796, -4, -8);
    SendClientMessage(12, playerid, -1717986817);
    e_OnDialogResponse(20, playerid, 5993, 1, 1, 200105896);
    return 1;
    SendClientMessage(12, playerid, -1);
    e_OnDialogResponse(20, playerid, 5993, 1, 1, 200106188);
    return 1;
    SendClientMessage(12, playerid, -1);
    e_OnDialogResponse(20, playerid, 5993, 1, 1, 200106452);
    return 1;
    LeafAuction(8, playerid, 3);
    return 1;
    // casetbl cases=4
    format(20, -1352, 54);
    strcat(12, -1136);
    Dialog(28, playerid, 5993, 2, 200106488, -1136, 200106548, 200106572);
    SetPVarInt(12, playerid, 200106596, 1);
    return 1;
    Dialog(28, playerid, 5993, 2, 200106668, 200106728, 200106928, 200106952);
    return 1;
    LeafAuction(8, playerid, 3);
    LeafAuction(8, playerid, 3);
    LeafAuction(8, playerid, 3);
    LeafAuction(8, playerid, 3);
    LeafAuction(8, playerid, 3);
    // casetbl cases=7
    Dialog(28, playerid, 5993, 2, 200106976, 200107036, 200107356, 200107380);
    return 1;
    Dialog(28, playerid, 5993, 1, 200107404, 200107464, 200107676, 200107700);
    return 1;
    // casetbl cases=3
    auc_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock PlayerTextDrawAuction(playerid)
{
    CreatePlayerTextDraw(16, playerid, 1104849561, 1120435490, 200107724);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140151632, 1129577520, 200107776);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140151632, 1131181461, 200107784);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140151632, 1132650925, 200107792);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140151632, 1133466485, 200107800);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140151632, 1134282047, 200107808);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1127131814, 1133706052, 200107816);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1128355155, 1134445150, 200107880);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1134024029, 1134472338, 200107888);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1136569005, 1134784967, 200107896);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1127131814, 1125163309, 200107904);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1128355155, 1126641513, 200107968);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1134024029, 1126695882, 200107976);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1136569005, 1127321148, 200107984);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1127131814, 1128479916, 200107992);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1128355155, 1129958120, 200108056);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1134024029, 1130012488, 200108064);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1136569005, 1130637754, 200108072);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1127131814, 1131714970, 200108080);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1128355155, 1132827627, 200108144);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1134024029, 1132854811, 200108152);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1136569005, 1133167444, 200108160);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140206250, 1124374938, 200108168);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110267213, 1123697728, 200108224);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110267213, 1126848797, 200108280);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110354585, 1129893554, 200108344);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110267213, 1133434198, 200108400);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1119660710, 1136144230, 200108456);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1126957056, 1133556534, 200108464);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1126913363, 1125815760, 200108528);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1126957056, 1128806135, 200108588);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1127000742, 1131687779, 200108656);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1140195318, 1134254850, 200108736);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1131435341, 1124347747, 200108760);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1136962214, 1125272047, 200108816);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1124859911, 1135954169, 200108888);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1109218637, 1135967761, 200108948);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1139878570, 1134548789, 200109004);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1138458624, 1122392841, 200109056);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1139878570, 1134548789, 200109120);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    return 1;
}


stock e_OnGameModeInit()
{
    SetTimer(12, 200109184, 1500);
    CreateDynamic3DTextLabel(60, 200109248, -1, 1148846095, 1159513399, 1153122260, 1084227584, "	'Ì¹ÏX'", "	'Ì¹ÏX'", 0, -1, -1, -1, 1128792064, -1, 0);
    CreateDynamicSphere(32, 1157810628, -988889379, 1102628136, 1065353216, 0, 0, -1, 0);
    CreateDynamicSphere(32, 1148845509, 1159431517, 1153132992, 1065353216, 183, 1, -1, 0);
    CreateDynamicPickup(44, "cmd_dice", 23, 1157810628, -988889379, 1102628136, 0, 0, -1, 1128792064, -1, 0);
    CreateDynamicPickup(44, "cmd_dice", 23, 1148845509, 1159431517, 1153132992, 183, 1, -1, 1128792064, -1, 0);
    Create3DTextLabel(32, 200109520, -1, 1157810628, -988889379, 1102628136, 1092616192, 0, 0);
    defualt_slot(0);
    SetTimer(12, 200109756, 5000);
    auc_OnGameModeInit(0);
    return 1;
}


stock e_OnPlayerConnect(playerid)
{
    SetTimerEx(20, 200109812, "ã'", 0);
    auc_OnPlayerConnect(4, playerid);
    return 1;
}


stock pc_cmd_tpa(playerid)
{
    CallLocalFunction(16, 200109908, 200110008, 12, 199262724);
    return 1;
}


stock e_OnPlayerEnterDynamicArea(playerid, areaid)
{
    SetPlayerPosEx(32, playerid, 1148845881, 1159437023, 1153132992, 1135848190, 1, 183, 1);
    SetPlayerPosEx(32, playerid, 1157803793, -988889090, 1102630914, 1119424472, 0, 0, 1);
    auc_OnPlayerEnterDynamicArea(8, playerid, areaid);
    return 1;
}


stock default_select_slot(playerid)
{
    strcat(12, -80);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    // casetbl cases=5
    return 1;
}


public OnPlayerClickPlayerTextDraw(playerid, playertextid)
{
    printf(8, 200110020);
    default_select_slot(4, playerid);
    return 1;
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    gettime(12);
    ConvertUnixTime(8);
    format(16, -56, 9);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    default_select_slot(4, playerid);
    return 1;
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    gettime(12);
    ConvertUnixTime(8);
    format(16, -56, 9);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    default_select_slot(4, playerid);
    return 1;
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    gettime(12);
    ConvertUnixTime(8);
    format(16, -56, 9);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    default_select_slot(4, playerid);
    return 1;
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    format(16, -56, 13);
    PlayerTextDrawSetString(12, playerid);
    gettime(12);
    ConvertUnixTime(8);
    format(16, -56, 9);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    ShowTabBuy(4, playerid);
    ShowTabSell(4, playerid);
    ShowTabMy(4, playerid);
    HideTextDrawAuction(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    Dialog(28, playerid, 5991, 1, 200110516, 200110584, 200110936, 200110960);
    SetPVarInt(12, playerid, 200110984, 3);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    DeletePVar(8, playerid, 200111044);
    DeletePVar(8, playerid, 200111104);
    GetPVarInt(8, playerid, 200111168);
    DeletePVar(8, playerid, 200111212);
    GetPVarInt(8, playerid, 200111256);
    DeletePVar(8, playerid, 200111332);
    GetPVarInt(8, playerid, 200111408);
    DeletePVar(8, playerid, 200111456);
    GetPVarInt(8, playerid, 200111504);
    DeletePVar(8, playerid, 200111552);
    GetPVarInt(8, playerid, 200111600);
    DeletePVar(8, playerid, 200111648);
    Dialog(28, playerid, 5991, 2, 200111696, 200111760, 200112080, 200112104);
    SetPVarInt(12, playerid, 200112128, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPVarInt(8, playerid, 200112292);
    GetVehicleModel(4, L_1140);
    SetPVarInt(12, playerid, 200112336);
    SetPVarInt(12, playerid, 200112384, L_1140);
    format(20, -1136, 284);
    Dialog(28, playerid, "l'", 0, 200112660, -1136, 200112724, 200112748);
    SendClientMessage(12, playerid, -1);
    GetPlayerBusiness(4, playerid);
    GetPlayerBusiness(4, playerid);
    SetPVarInt(12, playerid, 200112992, L_1144);
    SetPVarInt(12, playerid, 200113040, L_1140);
    format(20, -1136, 284);
    Dialog(28, playerid, "l'", 0, 200113284, -1136, 200113348, 200113372);
    SendClientMessage(12, playerid, -1);
    GetPlayerHouse(8, playerid, -1);
    GetPlayerHouse(8, playerid, -1);
    SetPVarInt(12, playerid, 200113544, L_1144);
    SetPVarInt(12, playerid, 200113592, L_1140);
    format(16, -1136, 284);
    Dialog(28, playerid, "l'", 0, 200113824, -1136, 200113888, 200113912);
    SendClientMessage(12, playerid, -1);
    SetPVarInt(12, playerid, 200114104, L_1140);
    format(16, -1136, 284);
    Dialog(28, playerid, "l'", 0, 200114332, -1136, 200114396, 200114420);
    SendClientMessage(12, playerid, -1);
    mysql_format(20, 166387936, -1136, 284);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    cache_get_row_count(4, 1);
    format(12, -1136, 284);
    cache_get_field_content_int(12, L_1400, 200115224);
    cache_get_field_content_int(12, L_1400, 200115236);
    cache_get_field_content(20, L_1400, 200115272, -1396, 1, 7);
    format(24, -1360, 54);
    strcat(12, -1136);
    printf(12, 200115384);
    Dialog(28, playerid, "l'", 2, 200115484, -1136, 200115548, 200115572);
    format(16, -1136, 284);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    cache_get_row_count(4, 1);
    format(12, -1136, 284);
    cache_get_field_content_int(12, L_1372, 200116200);
    cache_get_field_content_int(12, L_1372, 200116212);
    format(20, -1360, 54);
    strcat(12, -1136);
    Dialog(28, playerid, "l'", 2, 200116308, -1136, 200116372, 200116396);
    // casetbl cases=7
    SendClientMessage(12, playerid, -1);
    return 1;
    Dialog(28, playerid, 5991, 1, 200116512, 200116576, 200116960, 200116984);
    SetPVarInt(12, playerid, 200117008, 2);
    gettime(12);
    ConvertUnixTime(8);
    format(24, -196, 48);
    strcat(12, -1332);
    ShowNotification(24, playerid, 2, 200117124, 3, 200117236, 200117240);
    return 1;
    Dialog(28, playerid, -1, 2, 200117244, -1332, 200117308, 200117332);
    gettime(12);
    ConvertUnixTime(8);
    format(24, -196, 48);
    strcat(12, -1332);
    ShowNotification(24, playerid, 2, 200117400, 3, 200117512, 200117516);
    return 1;
    Dialog(28, playerid, -1, 2, 200117520, -1332, 200117584, 200117608);
    // casetbl cases=5
    return 1;
    gettime(12);
    SendClientMessage(12, playerid, -1);
    return 1;
    format(20, -1020, 254);
    ShowNotification(24, playerid, 2, -1020, 2, 200117936, 200117940);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPlayerBusiness(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPlayerHouse(8, playerid, -1);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    mysql_format(20, 166387936, -1532, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1);
    return 1;
    cache_delete(8, L_1536, 1);
    SendClientMessage(12, playerid, -1);
    // casetbl cases=5
    format(28, -1020, 254);
    Dialog(28, playerid, 5990, 1, 200120884, -1020, 200120944, 200120968);
    SetPVarInt(12, playerid, 200120992, L_4);
    Dialog(28, playerid, 5993, 2, 200121040, 200121100, 200121288, 200121312);
    LeafAuction(8, playerid, 3);
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPVarInt(8, playerid, 200121496);
    GetPVarInt(8, playerid, 200121540);
    GetPVarString(16, playerid, 200121588, -500, 124);
    GetPVarString(16, playerid, 200121648, -540, 7);
    GetPVarInt(8, playerid, 200121712);
    GetPVarInt(8, playerid, 200121760);
    GetPVarInt(8, playerid, 200121836);
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPVarInt(8, playerid, 200122080);
    GetVehicleModel(4);
    GetPVarInt(8, playerid, 200122156);
    create_auction_slot(32, playerid, L_4, -500, L_504, L_508, L_512, -540, L_544);
    return 1;
    LeafAuction(8, playerid, L_4);
    return 1;
    LeafAuction(8, playerid, L_4);
    auc_OnPlayerClickPlayer(8, playerid, playertextid);
    return 1;
}


stock pc_cmd_auction(playerid)
{
    gettime(12, -4);
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPlayerVirtualWorld(4, playerid);
    EnablePlayerGPS(24, playerid, 55, 1157803793, -988889090, 1102630914, 200122408);
    return 1;
    HideTextDrawAuction(4, playerid);
    gettime(12);
    HideHud(4, playerid);
    SetPlayerCleanChat(8, playerid, 1);
    SetPlayerCleanChat(8, playerid, 0);
    ShowTabBuy(4, playerid);
    return 1;
}


stock HideTextDrawAuction(playerid)
{
    ShowHud(4, playerid);
    SetPlayerCleanChat(8, playerid, 0);
    default_select_slot(4, playerid);
    HideTabBuy(4, playerid);
    HideTabSell(4, playerid);
    HideTabMy(4, playerid);
    // casetbl cases=4
    TogglePlayerControllable(8, playerid, 1);
    return 1;
}


stock ShowTabBuy(playerid)
{
    gettime(12);
    SendClientMessage(12, playerid, -1);
    return 1;
    HideTabSell(4, playerid);
    HideTabMy(4, playerid);
    return 1;
    // casetbl cases=4
    SelectTextDraw(8, playerid, -1);
    strcat(12, -140);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    LeafAuction(8, playerid, L_8);
    PlayerTextDrawShow(8, playerid);
    return 1;
}


stock ShowTabSell(playerid)
{
    gettime(12);
    SendClientMessage(12, playerid, -1);
    return 1;
    HideTabBuy(4, playerid);
    HideTabMy(4, playerid);
    return 1;
    // casetbl cases=3
    SelectTextDraw(8, playerid, -1);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    return 1;
}


stock HideTabSell(playerid)
{
    CancelSelectTextDraw(4, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    return 1;
}


stock HideTabBuy(playerid)
{
    default_select_slot(4, playerid);
    CancelSelectTextDraw(4, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    return 1;
}


stock HideTabMy(playerid)
{
    CancelSelectTextDraw(4, playerid);
    PlayerTextDrawDestroy(8, playerid);
    PlayerTextDrawDestroy(8, playerid);
    CreatePlayerTextDraw(16, playerid, 1104849561, 1120435490, 200122912);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110267213, 1123697728, 200122964);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110267213, 1126848797, 200123020);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110354585, 1129893554, 200123084);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1110267213, 1133434198, 200123140);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawHide(8, playerid);
    return 1;
}


stock ShowTabMy(playerid)
{
    gettime(12);
    SendClientMessage(12, playerid, -1);
    return 1;
    HideTabBuy(4, playerid);
    HideTabSell(4, playerid);
    return 1;
    // casetbl cases=3
    SelectTextDraw(8, playerid, -1);
    PlayerTextDrawDestroy(8, playerid);
    PlayerTextDrawDestroy(8, playerid);
    CreatePlayerTextDraw(16, playerid, 1118306291, 1120870452, 200123280);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1120053913, 1122447196, 200123328);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1120097613, 1126468197, 200123388);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1120097613, 1129676066, 200123452);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    CreatePlayerTextDraw(16, playerid, 1120097613, 1132999233, 200123504);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawSetSelectable(12, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    PlayerTextDrawShow(8, playerid);
    return 1;
}


stock AuctionUpdate()
{
    SetTimer(12, 200123560, 1000);
    LoadBusinessToAuction(0);
    gettime(12, -4);
    gettime(12);
    finish_auction_slot(4, L_8);
    return 1;
}


stock create_auction_slot(playerid, type, start_rate, data_base, server_id, number_SUM)
{
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    DeletePVar(8, playerid, 200123616);
    DeletePVar(8, playerid, 200123676);
    DeletePVar(8, playerid, 200123740);
    DeletePVar(8, playerid, 200123784);
    DeletePVar(8, playerid, 200123860);
    DeletePVar(8, playerid, 200123908);
    DeletePVar(8, playerid, 200123956);
    PlayerTextDrawSetString(12, playerid);
    strfind(16, V_36);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    format(12);
    format(12);
    gettime(12, -12);
    gettime(12, -20, -24, -28);
    gettime(12);
    gettime(12);
    // casetbl cases=5
    format(12);
    ProbelText(4);
    format(12);
    UnloadPlayerOwnableCar(8, playerid, 0);
    format(16);
    format(12);
    format(12);
    valstr(12, -40, number_SUM, 0);
    format(12);
    format(12);
    // casetbl cases=7
    SendClientMessage(12, playerid, -1);
    return 1;
}


stock finish_auction_slot(slot)
{
    reset_slot_auction(4, slot);
    SendClientMessage(12, L_8, -1);
    GivePlayerMoneyEx(20, L_8);
    mysql_format(24, 166387936, -516, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    SendClientMessage(12, L_520, -1);
    AuctionBusiness(8);
    SendClientMessage(12, L_520, -1);
    AuctionHouse(12, slot);
    SendClientMessage(12, L_520, -1);
    mysql_format(24, 166387936, -516, 128);
    mysql_query(12, 166387936);
    reset_slot_auction(4, slot);
    mysql_errno(4);
    print(4);
    return 1;
    SendClientMessage(12, L_520, -1);
    SendClientMessage(12, L_520, -1);
    mysql_format(24, 166387936, -516, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    mysql_format(24, 166387936, -516, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    reset_slot_auction(4, slot);
    SendClientMessage(12, L_520, -1);
    SendClientMessage(12, L_520, -1);
    mysql_format(24, 166387936, -516, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    mysql_format(20, 166387936, -516, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    reset_slot_auction(4, slot);
    SendClientMessage(12, L_520, -1);
    SendClientMessage(12, L_520, -1);
    mysql_format(24, 166387936, -516, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    mysql_format(20, 166387936, -516, 128);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    reset_slot_auction(4, slot);
    // casetbl cases=7
    return 1;
}


stock reset_slot_auction(slot)
{
    format(12);
    format(12);
    format(12);
    format(12);
    return 1;
}


stock AuctionBusiness(sql_id, slot)
{
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    mysql_format(32, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    printf(8, 200131176);
    mysql_errno(4);
    gettime(12);
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_row(20, 0, 0, -1136, 1, 24);
    mysql_errno(4);
    print(4);
    return 1;
    format(16);
    CallLocalFunction(12, 200131632, 200131712, -1032);
    cache_delete(8, L_1140, 1);
    SendClientMessage(12, L_1028, 1724645631);
    format(36, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    format(16, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    reset_slot_auction(4, slot);
    return 1;
}


stock SetBusinessName()
{
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_format(16, 166387936, -496, 124);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
}


stock LoadBusinessToAuction()
{
    mysql_format(16, 166387936, -456, 114);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_row_count(4, 1);
    return 1;
    format(12);
    cache_get_field_content(20, L_472, 200136160);
    cache_get_field_content_int(12, L_472, 200136180);
    cache_get_field_content_int(12, L_472, 200136192);
    gettime(12, -476, -480, -484);
    gettime(12);
    format(16);
    printf(8, 200136264);
    cache_delete(8, L_460, 1);
    return 1;
}


stock defualt_slot()
{
    format(12);
    format(12);
    format(12);
    format(12);
    return 1;
}


stock AuctionHouse(slot, win_slot, houseid)
{
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    format(32, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    printf(8, 200137088);
    mysql_errno(4);
    gettime(12);
    CallLocalFunction(12, 200137116, 200137192, -1036);
    mysql_format(20, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    cache_get_field_content(20, 0, 200137524, -1136, 166387936, 24);
    format(16);
    cache_delete(8, L_1040, 1);
    UpdateHouse(4, houseid);
    HouseHealthInit(8, houseid, -1);
    HouseStoreInit(8, houseid, -1);
    format(24, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
    reset_slot_auction(4, slot);
    return 1;
}


stock LeafAuction(playerid, all_slot)
{
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    default_select_slot(4, playerid);
    valstr(12, -36);
    PlayerTextDrawSetString(12, playerid);
    // casetbl cases=7
    // casetbl cases=3
    PlayerTextDrawSetString(12, playerid);
    PlayerTextDrawSetString(12, playerid);
    printf(12, 200138176);
    valstr(12, -36);
    PlayerTextDrawSetString(12, playerid);
    return 1;
}


stock ProbelText()
{
    // casetbl cases=2
    return 1;
}


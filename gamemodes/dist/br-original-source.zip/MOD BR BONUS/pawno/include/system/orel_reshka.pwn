// RESTORED: pawno/include/system/orel_reshka.pwn
// Functions: 12

stock weekly_OnGameModeInit()
{
    printf(4, 199024644);
    HAT_OnGameModeInit(0);
    return 1;
}


stock pc_cmd_spin(playerid)
{
    sscanf(12, V_16, 199024824, -4);
    SendClientMessage(12, playerid, -1);
    return 1;
    IsPlayerInRangeOfPlayer(12, playerid, L_4, 1080033280);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    fg_ShowPlayerDialog(28, playerid, 4374, 1, 199025552, 199025604, 199025948, 199025972);
    return 1;
}


stock pc_cmd_spins(playerid)
{
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    strcmp(16, V_16);
    return 1;
    KillTimer(4);
    StartHAT(8, playerid, L_4);
    StartHAT(8, L_4, playerid);
    strcmp(16, V_16);
    SendClientMessage(12, L_4, -1);
    SendClientMessage(12, playerid, -1);
    DefaultHAT(4, playerid);
    DefaultHAT(4, L_4);
    SendClientMessage(12, playerid, -1);
    return 1;
}


stock StartHAT(heads, tails)
{
    IsPlayerConnected(4);
    IsPlayerConnected(4);
    SendClientMessage(12, heads, -1);
    SendClientMessage(12, tails, -1);
    DefaultHAT(4, heads);
    DefaultHAT(4, tails);
    return 1;
    SendClientMessage(12, heads, -1);
    SendClientMessage(12, tails, -1);
    DefaultHAT(4, heads);
    DefaultHAT(4, tails);
    return 1;
    format(16, -580, 144);
    format(16, -580, 144);
    SendClientMessage(12, heads, -577699841);
    SendClientMessage(12, tails, -577699841);
    format(16, -580, 144);
    format(16, -580, 144);
    SetTimerEx(24, 199028476, 3000, 0);
    return 1;
}


stock EndHAT(heads, tails)
{
    IsPlayerConnected(4);
    IsPlayerConnected(4);
    SendClientMessage(12, heads, -1);
    SendClientMessage(12, tails, -1);
    DefaultHAT(4, heads);
    DefaultHAT(4, tails);
    return 1;
    random(4, 2);
    format(16, -588, 144);
    SendClientMessage(12, heads, -1);
    SendClientMessage(12, tails, -1);
    GivePlayerMoneyEx(20, L_8);
    GivePlayerMoneyEx(20, L_4, L_600, 199029208, 1, 1);
    SendClientMessage(12, L_8, -1);
    SendClientMessage(12, L_4, -1);
    fg_ShowPlayerDialog(28, L_592, 4377, 2, 199029624, 199029676, 199029888, 199029912);
    return 1;
}


stock DefaultHAT(playerid)
{
    return 1;
}


stock DialogThrowHAT(playerid)
{
    format(20, -576, 144);
    fg_ShowPlayerDialog(28, playerid, 4375, 2, 199030024, -576, 199030076, 199030108);
    return 1;
}


stock DialogRoleHAT(playerid)
{
    format(20, -576, 144);
    fg_ShowPlayerDialog(28, playerid, 4376, 2, 199030300, -576, 199030352, 199030384);
    return 1;
}


stock AcceptHAT(playerid, to_player)
{
    SendClientMessage(12, playerid, -1);
    DefaultHAT(4, playerid);
    return 1;
    format(16, -748, 42);
    format(20, -580, 144);
    SendClientMessage(12, to_player, -7012097);
    format(16, -580, 144);
    SendClientMessage(12, to_player, -7012097);
    format(20, -580, 144);
    SendClientMessage(12, playerid, -7012097);
    format(16, -580, 144);
    SendClientMessage(12, playerid, -7012097);
    SendClientMessage(12, to_player, -1);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, to_player, -1);
    SetTimerEx(24, 199032092, 10000, 0);
    return 1;
}


stock CancelAcceptHAT(playerid, to_player)
{
    SendClientMessage(12, to_player, -1);
    SendClientMessage(12, playerid, -1);
    DefaultHAT(4, playerid);
    DefaultHAT(4, to_player);
    return 1;
}


stock weekly_OnDialogResponse(playerid, dialogid, response, listitem)
{
    sscanf(12, V_28, 199032656, -4);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    return 1;
    IsPlayerInRangeOfPlayer(12, playerid, L_8, 1083179008);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    DialogRoleHAT(4, playerid);
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    AcceptHAT(8, playerid, L_4);
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    DialogThrowHAT(4, playerid);
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    DialogRoleHAT(4, playerid);
    AcceptHAT(8, playerid);
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    HAT_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock fixp_OnPlayerSpawn(playerid)
{
    DefaultHAT(4, playerid);
    HAT_OnPlayerSpawn(4, playerid);
    return 1;
}


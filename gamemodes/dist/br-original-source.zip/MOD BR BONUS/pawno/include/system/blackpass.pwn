// RESTORED: pawno/include/system/blackpass.pwn
// Functions: 76

stock BlackPass_LogEvent(playerid, reward_id, reward_type, reward_value, amount, extra)
{
    IsPlayerConnected(4);
    return 1;
    mysql_format(48, 166387936, -2048, 512);
    mysql_query(12, 166387936);
    return 1;
}


stock BlackPass_ResetPlayer(playerid)
{
    BlackPass_FindTaskDefIndex(4, L_8);
    return 1;
}


stock BlackPass_GetLevelFromExperienc(experience)
{
    return 1;
}


stock BlackPass_GetMaxExperience()
{
    return 1;
}


stock BlackPass_BuildClaimFlagsString(playerid, is_premium, output_len)
{
    strcat(12, V_20);
    return 1;
}


stock BlackPass_ParseClaimFlagsString(playerid, is_premium)
{
    strlen(4);
    return 1;
}


stock BlackPass_GetCurrentLevel(playerid)
{
    BlackPass_GetLevelFromExperienc(4);
    return 1;
}


stock BlackPass_GetClientPremiumStatu(status)
{
    return 1;
    // casetbl cases=3
    return 1;
}


stock BlackPass_GetRewardInventoryIte(level, is_premium)
{
    return 1;
}


stock BlackPass_GetDeluxeInventoryIte(index)
{
    return 1;
}


stock BlackPass_IsRewardInventoryItem(itemid)
{
    return 1;
}


stock BlackPass_GetRewardInventoryDat(itemid, name_len)
{
    format(16, V_16, name_len);
    return 1;
    format(16, V_16, name_len);
    return 1;
    format(16, V_16, name_len);
    return 1;
}


stock BlackPass_HasQueuedReward(playerid, itemid)
{
    return 1;
}


stock BlackPass_QueueInventoryReward(playerid, itemid)
{
    BlackPass_IsRewardInventoryItem(4, itemid);
    return 1;
    BlackPass_HasQueuedReward(8, playerid, itemid);
    return 1;
    printf(12, 229802484);
    return 1;
    printf(12, 229802744);
    SavePlayerCaseRewardDB(16, playerid, 99, itemid, 0);
    return 1;
}


stock BlackPass_QueueLevelReward(playerid, level, is_premium)
{
    return 1;
    BlackPass_GetRewardInventoryIte(8, level, is_premium);
    BlackPass_QueueInventoryReward(8, playerid);
    return 1;
}


stock BlackPass_QueueDeluxeRewards(playerid, skip_level_reward)
{
    BlackPass_GetDeluxeInventoryIte(4, L_4);
    BlackPass_QueueInventoryReward(8, playerid);
    return 1;
}


stock BlackPass_ShowLootNotification(playerid)
{
    ShowClientNotification(24, playerid, 3, 3, 0, 0, V_16);
    return 1;
}


stock BlackPass_SendLayoutPacket(playerid, layout_id)
{
    JSON_Object(0);
    BlackPass_SendMainPacket(12, playerid, L_4, layout_id);
    JSON_Cleanup(8, L_4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendStateRefresh(playerid, current_layout, visible_layout)
{
    JSON_Object(0);
    BlackPass_FillBasePacket(8, playerid, L_4);
    JSON_SetInt(12, L_4, 229802924);
    JSON_SetInt(12, L_4, 229802932);
    JSON_SetInt(12, L_4, 229802944);
    JSON_SetInt(12, L_4, 229802956);
    JSON_SetInt(12, L_4, 229802968);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, L_4, 229802980);
    JSON_SetInt(12, L_4, 229802988);
    JSON_SetInt(12, L_4, 229803000);
    JSON_SetInt(12, L_4, 229803008);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, L_4, 229803020);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, L_4, 229803032);
    OnPacketIncoming(12, playerid, 22, L_4);
    JSON_Cleanup(8, L_4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_AutoClaimRewardsRange(playerid, start_level, end_level, claim_standard, claim_premium)
{
    return 1;
    BlackPass_QueueLevelReward(12, playerid, L_4, 0);
    BlackPass_QueueLevelReward(12, playerid, L_4, 1);
    return 1;
}


stock BlackPass_GrantExperience(playerid, experience)
{
    BlackPass_LoadPlayer(4, playerid);
    return 1;
    BlackPass_GetMaxExperience(0);
    BlackPass_GetMaxExperience(0);
    BlackPass_GetLevelFromExperienc(4);
    BlackPass_SavePlayer(4, playerid);
    return 1;
}


stock BlackPass_SetLevelWithReset(playerid, target_level)
{
    BlackPass_LoadPlayer(4, playerid);
    return 1;
    BlackPass_SavePlayer(4, playerid);
    return 1;
}


stock BlackPass_AddLevelsWithReset(playerid, levels_to_add)
{
    BlackPass_GetCurrentLevel(4, playerid);
    return 1;
    BlackPass_GetCurrentLevel(4, playerid);
    BlackPass_SetLevelWithReset(8, playerid, L_8);
    BlackPass_GetCurrentLevel(4, playerid);
    return 1;
}


stock BlackPass_SendLevelSyncPacket(playerid, level, exp_value)
{
    JSON_Object(0);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, L_4, 229803044);
    JSON_SetInt(12, L_4, 229803052);
    JSON_SetInt(12, L_4, 229803064);
    JSON_SetInt(12, L_4, 229803076);
    JSON_SetInt(12, L_4, 229803084);
    OnPacketIncoming(12, playerid, 22, L_4);
    JSON_Cleanup(8, L_4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendLevelSyncRange(playerid, old_level, new_level)
{
    BlackPass_SendLevelSyncPacket(12, playerid, -1, -1);
    return 1;
    BlackPass_SendLevelSyncPacket(12, playerid, L_4);
    return 1;
}


stock BlackPass_SavePlayer(playerid)
{
    return 1;
    BlackPass_BuildClaimFlagsString(16, playerid, 0, -248, 62);
    BlackPass_BuildClaimFlagsString(16, playerid, 1, -496, 62);
    mysql_format(56, 166387936, -4592, 1024);
    mysql_query(12, 166387936);
    printf(36, 229804096);
    return 1;
}


stock BlackPass_SendRewardClaimPacket(playerid, reward_id, is_premium, layout_id)
{
    JSON_Object(0);
    JSON_SetInt(12, L_4, 229804472);
    JSON_SetInt(12, L_4, 229804480);
    JSON_SetInt(12, L_4, 229804492);
    JSON_SetInt(12, L_4, 229804504);
    JSON_SetInt(12, L_4, 229804512);
    JSON_SetInt(12, L_4, 229804524);
    OnPacketIncoming(12, playerid, 22, L_4);
    JSON_Cleanup(8, L_4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendClaimPacketsRange(playerid, start_level, end_level, claim_standard, claim_premium, layout_id)
{
    return 1;
    BlackPass_SendRewardClaimPacket(16, playerid, L_4, 0, layout_id);
    BlackPass_SendRewardClaimPacket(16, playerid, L_4, 1, layout_id);
    return 1;
}


stock BlackPass_SendAutoClaimSyncRang(playerid, old_level, new_level, claim_standard, claim_premium, layout_id)
{
    return 1;
    BlackPass_SendLevelSyncPacket(12, playerid, L_4);
    BlackPass_SendRewardClaimPacket(16, playerid, L_4, 0, layout_id);
    BlackPass_SendRewardClaimPacket(16, playerid, L_4, 1, layout_id);
    return 1;
}


stock BlackPass_LoadPlayer(playerid)
{
    BlackPass_ResetPlayer(4, playerid);
    mysql_format(24, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(20, 229804856);
    cache_delete(8, L_1028, 1);
    return 1;
    cache_get_row_count(4, 1);
    mysql_format(32, 166387936, -1024, 256);
    mysql_query(12, 166387936);
    cache_delete(8, L_1028, 1);
    return 1;
    cache_get_field_content_int(12, 0, 229806672);
    cache_get_field_content_int(12, 0, 229806716);
    cache_get_field_content_int(12, 0, 229806740);
    cache_get_field_content_int(12, 0, 229806800);
    cache_get_field_content_int(12, 0, 229806820);
    cache_get_field_content_int(12, 0, 229806884);
    cache_get_field_content(20, 0, 229806976, -1276, 62, 62);
    cache_get_field_content(20, 0, 229807044, -1524, 62, 62);
    BlackPass_ParseClaimFlagsString(12, playerid, 0, -1276);
    BlackPass_ParseClaimFlagsString(12, playerid, 1, -1524);
    BlackPass_GetLevelFromExperienc(4);
    cache_delete(8, L_1028, 1);
    return 1;
}


stock BlackPass_GetCurrentTaskPeriod(task_group)
{
    gettime(12);
    return 1;
    gettime(12);
    return 1;
    // casetbl cases=3
    return 1;
}


stock BlackPass_GetTaskResetTimer()
{
    gettime(12);
    return 1;
}


stock BlackPass_FindTaskDefIndex(task_id)
{
    return 1;
}


stock BlackPass_FindTaskSlot(playerid, task_id)
{
    return 1;
}


stock BlackPass_GetTaskDefIndexFromSl(playerid, task_index)
{
    return 1;
    BlackPass_FindTaskDefIndex(4);
    return 1;
}


stock BlackPass_ClearTaskSlot(playerid, task_index, task_group)
{
    BlackPass_GetCurrentTaskPeriod(4, task_group);
    return 1;
}


stock BlackPass_AssignTaskSlot(playerid, task_index, task_id, row_id)
{
    BlackPass_FindTaskDefIndex(4, task_id);
    return 1;
    BlackPass_GetCurrentTaskPeriod(4);
    return 1;
}


stock BlackPass_GetNextFreeTaskSlot(playerid, task_group)
{
    return 1;
}


stock BlackPass_IsTaskActive(playerid, task_id)
{
    BlackPass_FindTaskSlot(8, playerid, task_id);
    return 1;
}


stock BlackPass_GetTaskDescription(task_id, output_len)
{
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    format(12, V_16, output_len);
    // casetbl cases=16
    return 1;
}


stock BlackPass_TaskHasAction(playerid, task_index)
{
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    return 1;
}


stock BlackPass_GetStoredTaskStatus(playerid, task_index)
{
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    return 1;
    BlackPass_TaskHasAction(8, playerid, task_index);
    return 1;
}


stock BlackPass_GetClientTaskStatus(playerid, task_index)
{
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    return 1;
    BlackPass_TaskHasAction(8, playerid, task_index);
    return 1;
    BlackPass_TaskHasAction(8, playerid, task_index);
    return 1;
}


stock BlackPass_EnableTaskGps(playerid, task_id)
{
    EnablePlayerGPS(24, playerid);
    return 1;
    EnablePlayerGPS(24, playerid);
    return 1;
    EnablePlayerGPS(24, playerid);
    return 1;
    EnablePlayerGPS(24, playerid);
    return 1;
    EnablePlayerGPS(24, playerid);
    return 1;
    EnablePlayerGPS(24, playerid);
    return 1;
    EnablePlayerGPS(24, playerid);
    return 1;
    // casetbl cases=10
    return 1;
}


stock BlackPass_SaveTaskSlot(playerid, task_index)
{
    return 1;
    BlackPass_GetStoredTaskStatus(8, playerid, task_index);
    mysql_format(36, 166387936, -2048, 512);
    mysql_query(12, 166387936);
    return 1;
}


stock BlackPass_InsertTaskSlot(playerid, task_index)
{
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    return 1;
    mysql_format(60, 166387936, -3076, 768);
    mysql_query(12, 166387936);
    return 1;
}


stock BlackPass_LoadTasks(playerid)
{
    IsPlayerConnected(4);
    return 1;
    BlackPass_GetCurrentTaskPeriod(4, 1);
    BlackPass_GetCurrentTaskPeriod(4, 2);
    return 1;
    BlackPass_ClearTaskSlot(12, playerid, L_12, 1);
    BlackPass_ClearTaskSlot(12, playerid, L_12, 2);
    mysql_format(40, 166387936, -1104, 256);
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_errno(4);
    printf(16, 229811616);
    cache_delete(8, L_1108, 1);
    return 1;
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, L_1112, 229811884);
    cache_get_field_content_int(12, L_1112, 229811916);
    BlackPass_FindTaskDefIndex(4, L_1116);
    cache_get_field_content_int(12, L_1112, 229811960);
    BlackPass_GetNextFreeTaskSlot(8, playerid, L_1120);
    cache_get_field_content_int(12, L_1112, 229811988);
    BlackPass_AssignTaskSlot(16, playerid, L_1132, L_1116);
    cache_get_field_content_int(12, L_1112, 229812000);
    cache_get_field_content_int(12, L_1112, 229812044);
    cache_get_field_content_int(12, L_1112, 229812080);
    cache_get_field_content_int(12, L_1112, 229812108);
    cache_get_field_content_int(12, L_1112, 229812140);
    cache_delete(8, L_1108, 1);
    BlackPass_FindTaskDefIndex(4, L_1120);
    BlackPass_AssignTaskSlot(16, playerid, L_1116, L_1120, 0);
    BlackPass_InsertTaskSlot(8, playerid, L_1116);
    return 1;
}


stock BlackPass_ShowTaskReadyGui(playerid, task_id)
{
    JSON_Object(0);
    JSON_SetInt(12, L_4, 229812212);
    JSON_SetInt(12, L_4, 229812220);
    JSON_SetInt(12, L_4, 229812228);
    JSON_SetString(16, L_4, 229812240, 229812248, 28);
    JSON_SetString(16, L_4, 229812360, 229812368, 91);
    JSON_SetString(16, L_4, 229812732, 229812740, 9);
    ShowPlayerGUI(12, playerid, 65, L_4);
    JSON_Cleanup(8, L_4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_ShowTrackedTaskGui(playerid, task_id)
{
    BlackPass_GetTaskDescription(12, task_id, -384, 96);
    JSON_Object(0);
    JSON_SetInt(12, L_388, 229812776);
    JSON_SetInt(12, L_388, 229812784);
    JSON_SetInt(12, L_388, 229812792);
    JSON_SetString(16, L_388, 229812800, -384, 96);
    JSON_SetInt(12, L_388, 229812812);
    JSON_SetInt(12, L_388, 229812824);
    JSON_SetString(16, L_388, 229812836, 229812848, 8);
    JSON_Array(0);
    JSON_SetArray(12, L_388, 229812880);
    JSON_Array(0);
    JSON_SetArray(12, L_388, 229812892);
    JSON_Array(0);
    JSON_SetArray(12, L_388, 229812904);
    JSON_Array(0);
    JSON_SetArray(12, L_388, 229812916);
    JSON_SetInt(12, L_388, 229812928);
    ShowPlayerGUI(12, playerid, 39, L_388);
    JSON_Cleanup(8, L_388, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_OpenTasksScreen(playerid)
{
    BlackPass_LoadPlayer(4, playerid);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    return 1;
    JSON_Object(0);
    JSON_SetInt(12, L_4, 229812936);
    JSON_SetInt(12, L_4, 229812944);
    JSON_SetInt(12, L_4, 229812952);
    JSON_SetInt(12, L_4, 229812964);
    JSON_SetInt(12, L_4, 229812972);
    JSON_SetInt(12, L_4, 229812984);
    GetPlayerMoney(4, playerid);
    JSON_SetInt(12, L_4, 229812996);
    JSON_SetInt(12, L_4, 229813004);
    JSON_SetInt(12, L_4, 229813012);
    JSON_SetArray(12, L_4, 229813020);
    strcmp(16, 229813028);
    JSON_SetString(16, L_4, 229813048);
    JSON_SetString(16, L_4, 229813060, 229813072, 2);
    JSON_SetString(16, L_4, 229813080);
    ShowPlayerGUI(12, playerid, 22, L_4);
    JSON_Cleanup(8, L_4, 0);
    JSON_Object(0);
    BlackPass_SendMainPacket(12, playerid, L_8, 0);
    JSON_Cleanup(8, L_8, 0);
    JSON_Object(0);
    BlackPass_SendMainPacket(12, playerid, L_12, 1);
    JSON_Cleanup(8, L_12, 0);
    func_0xcd48(8);
    func_0xcd48(8);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_AddTaskProgress(playerid, task_id, amount)
{
    return 1;
    BlackPass_LoadPlayer(4, playerid);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, L_4);
    return 1;
    BlackPass_ShowTaskReadyGui(8, playerid, task_id);
    BlackPass_SaveTaskSlot(8, playerid, L_4);
    BlackPass_SendLayoutPacket(8, playerid, 1);
    return 1;
}


stock BlackPass_ClaimTaskReward(playerid, task_id)
{
    BlackPass_LoadPlayer(4, playerid);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, L_4);
    return 1;
    BlackPass_GetCurrentLevel(4, playerid);
    HidePlayerGUI(8, playerid, 39);
    DisablePlayerGPS(4, playerid);
    HidePlayerGUI(8, playerid, 65);
    BlackPass_SaveTaskSlot(8, playerid, L_4);
    BlackPass_ClearTaskSlot(12, playerid, L_4, L_24);
    BlackPass_GrantExperience(8, playerid, L_16);
    GivePlayerMoneyEx(20, playerid, L_20, 229813092, 1, 1);
    BlackPass_LogEvent(28, playerid, 229813180, task_id, 10, L_16, 1, L_24);
    format(16, -408, 96);
    ShowNotificationNew(28, playerid, 3, 4, 0, 0, -408, 229813312);
    BlackPass_GetCurrentLevel(4, playerid);
    ShowNotificationNew(28, playerid, 3, 3, 0, 0, 229813324, 229813508);
    BlackPass_GetCurrentLevel(4, playerid);
    BlackPass_SendLevelSyncRange(12, playerid, L_12);
    BlackPass_OpenTasksScreen(4, playerid);
    return 1;
}


stock BlackPass_BeginTrackTask(playerid, task_id)
{
    BlackPass_LoadTasks(4, playerid);
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    return 1;
    BlackPass_TaskHasAction(8, playerid, L_4);
    return 1;
    BlackPass_SaveTaskSlot(8, playerid, L_8);
    BlackPass_SaveTaskSlot(8, playerid, L_4);
    BlackPass_EnableTaskGps(8, playerid, task_id);
    HidePlayerGUI(8, playerid, 22);
    ShowNotificationNew(28, playerid, 3, 3, 0, 0, 229813520, 229813632);
    BlackPass_ShowTrackedTaskGui(8, playerid, task_id);
    return 1;
}


stock BlackPass_StopTrackTask(playerid, task_id)
{
    BlackPass_LoadTasks(4, playerid);
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    return 1;
    BlackPass_SaveTaskSlot(8, playerid, L_4);
    DisablePlayerGPS(4, playerid);
    HidePlayerGUI(8, playerid, 39);
    BlackPass_OpenTasksScreen(4, playerid);
    return 1;
}


stock BlackPass_FindExchangeReplaceme(playerid, task_index)
{
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    return 1;
    BlackPass_IsTaskActive(8, playerid);
    return 1;
}


stock BlackPass_HandleTaskPress(playerid, json)
{
    BlackPass_LoadPlayer(4, playerid);
    func_0xcd48(8);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    func_0xcd48(8);
    return 1;
    JSON_GetInt(12, json, 229813644, -4);
    BlackPass_FindTaskSlot(8, playerid, L_4);
    BlackPass_SendMainPacket(12, playerid, json, 1);
    func_0xcd48(8);
    return 1;
    BlackPass_GetClientTaskStatus(8, playerid, L_8);
    BlackPass_ClaimTaskReward(8, playerid, L_4);
    func_0xcd48(8);
    return 1;
    BlackPass_StopTrackTask(8, playerid, L_4);
    func_0xcd48(8);
    return 1;
    BlackPass_BeginTrackTask(8, playerid, L_4);
    func_0xcd48(8);
    return 1;
    // casetbl cases=4
    BlackPass_SendMainPacket(12, playerid, json, 1);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleTaskExchange(playerid, json)
{
    JSON_GetInt(12, json, 229813656, -4);
    BlackPass_LoadPlayer(4, playerid);
    func_0xcd48(8);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    func_0xcd48(8);
    return 1;
    BlackPass_FindTaskSlot(8, playerid, L_4);
    func_0xcd48(8);
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, L_8);
    func_0xcd48(8);
    return 1;
    func_0xcd48(8);
    return 1;
    func_0xcd48(8);
    return 1;
    ShowNotificationNew(28, playerid, 2, 3, 0, 0, 229813668, 229813736);
    func_0xcd48(8);
    return 1;
    BlackPass_FindExchangeReplaceme(8, playerid, L_8);
    ShowNotificationNew(28, playerid, 2, 3, 0, 0, 229813748, 229813892);
    func_0xcd48(8);
    return 1;
    DisablePlayerGPS(4, playerid);
    HidePlayerGUI(8, playerid, 39);
    GivePlayerDonateRub(20, playerid, -10, 229813904, 1, 1);
    BlackPass_GetCurrentTaskPeriod(4);
    mysql_format(56, 166387936, -3092, 768);
    mysql_query(12, 166387936);
    BlackPass_LogEvent(28, playerid, 229815012, L_4, 0, 10, 1);
    ShowNotificationNew(28, playerid, 3, 3, 0, 0, 229815068, 229815348);
    BlackPass_OpenTasksScreen(4, playerid);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleExtraGui(playerid, guiid, json)
{
    JSON_GetInt(12, json, 229815360, -4);
    JSON_GetInt(12, json, 229815368, -8);
    HidePlayerGUI(8, playerid, 65);
    func_0xcd48(8);
    return 1;
    HidePlayerGUI(8, playerid, 65);
    BlackPass_OpenTasksScreen(4, playerid);
    func_0xcd48(8);
    return 1;
    HidePlayerGUI(8, playerid, 39);
    func_0xcd48(8);
    return 1;
    HidePlayerGUI(8, playerid, 39);
    BlackPass_OpenTasksScreen(4, playerid);
    func_0xcd48(8);
    return 1;
    // casetbl cases=3
    func_0xcd48(8);
    return 1;
}


stock BlackPass_OnPlayerLogged(playerid)
{
    BlackPass_LoadPlayer(4, playerid);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    return 1;
    BlackPass_AddTaskProgress(12, playerid, 254, 1);
    return 1;
}


stock BlackPass_OnPlayedHour(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 52, 1);
    return 1;
}


stock BlackPass_OnScooterRent(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 108, 1);
    return 1;
}


stock BlackPass_OnAdvertSent(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 96, 1);
    return 1;
}


stock BlackPass_OnPlateRegenerated(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 97, 1);
    return 1;
}


stock BlackPass_OnBankDeposit(playerid, amount)
{
    BlackPass_AddTaskProgress(12, playerid, 2, 1);
    BlackPass_AddTaskProgress(12, playerid, 99, amount);
    return 1;
}


stock BlackPass_OnMoneyEarned(playerid, amount)
{
    return 1;
    strfind(16, V_20, 229815376);
    return 1;
    BlackPass_AddTaskProgress(12, playerid, 257, amount);
    return 1;
}


stock BlackPass_OnCaseOpened(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 255, 1);
    return 1;
}


stock BlackPass_OnPlayerGreeting(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 143, 1);
    return 1;
}


stock BlackPass_OnTestDriveStarted(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 104, 1);
    return 1;
}


stock BlackPass_FillBasePacket(playerid, json)
{
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229815416);
    JSON_SetInt(12, json, 229815424);
    JSON_SetInt(12, json, 229815436);
    JSON_SetInt(12, json, 229815448);
    JSON_SetInt(12, json, 229815460);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, json, 229815472);
    JSON_SetInt(12, json, 229815480);
    JSON_SetInt(12, json, 229815492);
    JSON_SetInt(12, json, 229815500);
    JSON_SetInt(12, json, 229815512);
    JSON_SetInt(12, json, 229815524);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendMainPacket(playerid, json, latype)
{
    printf(12, 229815536);
    JSON_SetInt(12, json, 229815672);
    JSON_SetInt(12, json, 229815680);
    JSON_SetInt(12, json, 229815692);
    JSON_SetString(16, json, 229815704, 229815716, 15);
    JSON_SetString(16, json, 229815776);
    JSON_SetInt(12, json, 229815788);
    JSON_SetInt(12, json, 229815800);
    JSON_SetInt(12, json, 229815812);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, json, 229815824);
    JSON_SetInt(12, json, 229815832);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229815844);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229815856);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    printf(4, 229815868);
    BlackPass_LoadTasks(4, playerid);
    JSON_SetInt(12, json, 229815992);
    JSON_SetInt(12, json, 229816000);
    JSON_SetInt(12, json, 229816012);
    JSON_SetString(16, json, 229816024, 229816036, 15);
    JSON_SetString(16, json, 229816096);
    JSON_SetInt(12, json, 229816108);
    JSON_SetInt(12, json, 229816120);
    JSON_Array(0);
    JSON_Object(0);
    JSON_SetInt(12, L_12, 229816132);
    JSON_SetInt(12, L_12, 229816144);
    BlackPass_GetClientTaskStatus(8, playerid, L_8);
    JSON_SetInt(12, L_12, 229816152);
    JSON_Array(4, -12);
    JSON_Append(8, L_4);
    func_0xcd48(8);
    JSON_SetArray(12, json, 229816160, L_4);
    BlackPass_GetTaskResetTimer(0);
    JSON_SetInt(12, json, 229816172);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    func_0xcd48(8);
    return 1;
    JSON_SetInt(12, json, 229816184);
    JSON_SetInt(12, json, 229816192);
    JSON_SetInt(12, json, 229816204);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    printf(4, 229816216);
    JSON_SetInt(12, json, 229816344);
    JSON_SetInt(12, json, 229816352);
    JSON_SetInt(12, json, 229816364);
    mysql_format(20, 166387936, -4096, 1024);
    mysql_query(12, 166387936);
    JSON_Array(0);
    cache_get_row_count(4, 1);
    JSON_Object(0);
    cache_get_field_content(20, L_4108, 229817764, -4208, 25, 25);
    JSON_SetString(16, L_4212, 229817784, -4208, 25);
    cache_get_field_content_int(12, L_4108, 229817808);
    JSON_SetInt(12, L_4212, 229817792);
    JSON_Array(4, -4212);
    JSON_Append(8, L_4104);
    func_0xcd48(8);
    cache_delete(8, L_4100, 1);
    mysql_format(28, 166387936, -4096, 1024);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_get_field_content_int(12, 0, 229819668);
    cache_delete(8, L_4108, 1);
    JSON_SetArray(12, json, 229819716, L_4104);
    JSON_SetInt(12, json, 229819724);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    func_0xcd48(8);
    return 1;
    JSON_SetInt(12, json, 229819732);
    JSON_SetInt(12, json, 229819740);
    JSON_SetInt(12, json, 229819752);
    JSON_SetInt(12, json, 229819764);
    JSON_SetInt(12, json, 229819772);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, json, 229819784);
    JSON_SetString(16, json, 229819792, 229819832, 19);
    JSON_SetString(16, json, 229819908, 229819952, 20);
    JSON_SetString(16, json, 229820032, 229820068, 14);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    // casetbl cases=6
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleBuyLevels(playerid, json)
{
    JSON_GetInt(12, json, 229820124, -4);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229820132);
    JSON_SetInt(12, json, 229820140);
    JSON_SetInt(12, json, 229820152);
    JSON_SetInt(12, json, 229820164);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    JSON_SetInt(12, json, 229820172);
    JSON_SetInt(12, json, 229820180);
    JSON_SetInt(12, json, 229820192);
    JSON_SetInt(12, json, 229820204);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    BlackPass_SetLevelWithReset(8, playerid, L_12);
    BlackPass_GetCurrentLevel(4, playerid);
    BlackPass_AutoClaimRewardsRange(20, playerid);
    GivePlayerDonateRub(20, playerid);
    BlackPass_SavePlayer(4, playerid);
    BlackPass_LogEvent(28, playerid, 229820316, 0, 10, 0, L_4, L_16);
    JSON_SetInt(12, json, 229820360);
    JSON_SetInt(12, json, 229820368);
    JSON_SetInt(12, json, 229820380);
    JSON_SetInt(12, json, 229820392);
    OnPacketIncoming(12, playerid, 22, json);
    BlackPass_SendAutoClaimSyncRang(24, playerid, L_8, L_20, 1);
    BlackPass_SendMainPacket(12, playerid, json, 0);
    BlackPass_SendStateRefresh(12, playerid, 0, -1);
    BlackPass_ShowLootNotification(8, playerid, 229820400);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandlePurchasePremium(playerid, json)
{
    JSON_GetInt(12, json, 229820512, -4);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229820524);
    JSON_SetInt(12, json, 229820532);
    JSON_SetInt(12, json, 229820544);
    JSON_SetInt(12, json, 229820556);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, json, 229820564);
    JSON_SetInt(12, json, 229820572);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    JSON_SetInt(12, json, 229820584);
    JSON_SetInt(12, json, 229820592);
    JSON_SetInt(12, json, 229820604);
    JSON_SetInt(12, json, 229820616);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    GivePlayerDonateRub(20, playerid);
    BlackPass_AddLevelsWithReset(8, playerid, 10);
    BlackPass_GetCurrentLevel(4, playerid, 1, 1);
    BlackPass_AutoClaimRewardsRange(20, playerid, 1);
    BlackPass_QueueDeluxeRewards(8, playerid, 1);
    BlackPass_GetCurrentLevel(4, playerid, 0, 1);
    BlackPass_AutoClaimRewardsRange(20, playerid, 1);
    BlackPass_SavePlayer(4, playerid);
    BlackPass_LogEvent(28, playerid, 229820828, 0, 0, L_12, 1, L_20);
    JSON_SetInt(12, json, 229820864);
    JSON_SetInt(12, json, 229820872);
    JSON_SetInt(12, json, 229820884);
    JSON_SetInt(12, json, 229820896);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, json, 229820904);
    JSON_SetInt(12, json, 229820912);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229820924);
    JSON_SetInt(12, json, 229820936);
    OnPacketIncoming(12, playerid, 22, json);
    BlackPass_GetCurrentLevel(4, playerid);
    BlackPass_SendAutoClaimSyncRang(24, playerid, L_16, L_24, 1);
    BlackPass_SendMainPacket(12, playerid, json, 0);
    BlackPass_SendStateRefresh(12, playerid, 0, -1);
    BlackPass_ShowLootNotification(8, playerid, 229820948);
    BlackPass_GetCurrentLevel(4, playerid, 0, 1, 0);
    BlackPass_SendClaimPacketsRange(24, playerid, 1);
    BlackPass_SendMainPacket(12, playerid, json, 0);
    BlackPass_SendStateRefresh(12, playerid, 0, -1);
    BlackPass_ShowLootNotification(8, playerid, 229821120);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleGetPrize(playerid, json)
{
    JSON_GetInt(12, json, 229821264, -4);
    JSON_GetInt(12, json, 229821276, -8);
    JSON_GetInt(12, json, 229821284, -12);
    func_0xcd48(8);
    return 1;
    BlackPass_GetCurrentLevel(4, playerid);
    func_0xcd48(8);
    return 1;
    func_0xcd48(8);
    return 1;
    func_0xcd48(8);
    return 1;
    BlackPass_QueueLevelReward(12, playerid, L_4, 1);
    func_0xcd48(8);
    return 1;
    BlackPass_QueueLevelReward(12, playerid, L_4, 0);
    BlackPass_SavePlayer(4, playerid);
    BlackPass_LogEvent(28, playerid, 229821296, L_4, 0, 0, 1, L_8);
    JSON_SetInt(12, json, 229821348);
    JSON_SetInt(12, json, 229821356);
    JSON_SetInt(12, json, 229821368);
    JSON_SetInt(12, json, 229821380);
    JSON_SetInt(12, json, 229821388);
    JSON_SetInt(12, json, 229821400);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleRefreshRating(playerid, json)
{
    gettime(12);
    printf(12, 229821408);
    ShowNotificationNew(28, playerid, 2, 4, 0, 0, 229821596, 229821756);
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 3);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandlePacket(playerid, json)
{
    IsPlayerConnected(4);
    func_0xcd48(8);
    return 1;
    BlackPass_LoadPlayer(4, playerid);
    func_0xcd48(8);
    return 1;
    JSON_GetInt(12, json, 229821768, -4);
    JSON_GetInt(12, json, 229821776, -8);
    JSON_GetInt(12, json, 229821788, -12);
    JSON_SetInt(12, json, 229821800);
    JSON_SetInt(12, json, 229821808);
    JSON_SetInt(12, json, 229821820);
    JSON_SetInt(12, json, 229821832);
    JSON_SetInt(12, json, 229821840);
    JSON_SetInt(12, json, 229821852);
    JSON_SetInt(12, json, 229821864);
    JSON_SetInt(12, json, 229821876);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, json, 229821888);
    JSON_SetInt(12, json, 229821896);
    JSON_SetInt(12, json, 229821908);
    JSON_SetInt(12, json, 229821916);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229821928);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229821940);
    JSON_SetInt(12, json, 229821952);
    JSON_SetInt(12, json, 229821960);
    JSON_SetInt(12, json, 229821972);
    JSON_SetString(16, json, 229821984, 229821996, 15);
    JSON_SetString(16, json, 229822056);
    JSON_SetInt(12, json, 229822068);
    JSON_SetInt(12, json, 229822080);
    JSON_SetInt(12, json, 229822092);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(12, json, 229822104);
    JSON_SetInt(12, json, 229822112);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229822124);
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(12, json, 229822136);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    // casetbl cases=2
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 0);
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 0);
    func_0xcd48(8);
    return 1;
    JSON_GetInt(12, json, 229822148, -16);
    BlackPass_HandleTaskPress(8, playerid, json);
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 1);
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 2);
    func_0xcd48(8);
    return 1;
    BlackPass_HandleRefreshRating(8, playerid, json);
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 4);
    func_0xcd48(8);
    return 1;
    // casetbl cases=7
    func_0xcd48(8);
    return 1;
    JSON_SetInt(12, json, 229822160);
    JSON_SetInt(12, json, 229822168);
    BlackPass_HandleBuyLevels(8, playerid, json);
    func_0xcd48(8);
    return 1;
    BlackPass_HandleTaskExchange(8, playerid, json);
    func_0xcd48(8);
    return 1;
    BlackPass_HandleRefreshRating(8, playerid, json);
    func_0xcd48(8);
    return 1;
    BlackPass_HandlePurchasePremium(8, playerid, json);
    func_0xcd48(8);
    return 1;
    // casetbl cases=5
    func_0xcd48(8);
    return 1;
    BlackPass_HandleGetPrize(8, playerid, json);
    func_0xcd48(8);
    return 1;
    // casetbl cases=2
    func_0xcd48(8);
    return 1;
    // casetbl cases=5
    func_0xcd48(8);
    return 1;
    // casetbl cases=2
    func_0xcd48(8);
    return 1;
}


stock pc_cmd_blackpass(playerid)
{
    JSON_Object(0);
    JSON_SetInt(12, L_4, 229822180);
    BlackPass_HandlePacket(8, playerid, L_4);
    JSON_Cleanup(8, L_4, 0);
    func_0xcd48(8);
    return 1;
}


// RESTORED: pawno/include/system/pickup.pwn
// Functions: 7

stock n_CreatePickup(model, type, Virtualworld, action_type, action_id)
{
    CreatePickup(24, model, type, V_20, V_24, V_28, Virtualworld);
    CreateDynamicSphere(32, V_20, V_24, V_28, 1068708659, Virtualworld, -1, -1, 0);
    CreateDynamicSphere(32, V_20, V_24, V_28, 1068708659, Virtualworld, -1, -1, 0);
    return 1;
}


stock n_DestroyPickup(pickupid)
{
    DestroyDynamicArea(4);
    DestroyPickup(4, pickupid);
    return 1;
}


public OnPlayerPickUpPickup(playerid, pickupid)
{
    GetPVarInt(8, playerid, "ù");
    return 1;
    SetPVarInt(12, playerid, 168116, 1);
    GetTickCount(0);
    GetTickCount(0);
    OnPlayerPickUpPickupEx(16, playerid, pickupid, L_4, L_8);
    return 1;
}


stock Iter_OnGameModeInit()
{
    print(4);
    print(4);
    print(4);
    print(4);
    print(4);
    print(4);
    n_OnGameModeInit(0);
    return 1;
}


stock fg_OnPlayerConnect(playerid)
{
    SetPVarInt(12, playerid, "N", 0);
    fixp_OnPlayerConnect(4, playerid);
    return 1;
}


public OnPlayerSpawn(playerid)
{
    SetPVarInt(12, playerid, 168988, 0);
    fixp_OnPlayerSpawn(4, playerid);
    return 1;
}


public OnPlayerLeaveDynamicArea(playerid, areaid)
{
    SetPVarInt(12, playerid, 169068, 0);
    fixp_OnPlayerLeaveDynamicArea(8, playerid, areaid);
    return 1;
}


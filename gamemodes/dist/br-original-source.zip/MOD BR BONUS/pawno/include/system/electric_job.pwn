// RESTORED: pawno/include/system/electric_job.pwn
// Functions: 11

stock rul_OnPlayerDisconnect(playerid, reason)
{
    OrdinaryNewElectric(4, playerid);
    e_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock rul_OnPlayerConnect(playerid)
{
    OrdinaryNewElectric(4, playerid);
    e_OnPlayerConnect(4, playerid);
    return 1;
}


stock name_OnPlayerSpawn(playerid)
{
    OrdinaryNewElectric(4, playerid);
    e_OnPlayerSpawn(4, playerid);
    return 1;
}


stock name_OnDialogResponse(playerid, dialogid, response, listitem)
{
    n_veh_CreateVehicle(44, 428, -987716615, -1008575755, 1104731645, 1127426746, 0, 0, 0, 0, -1, -1);
    PutPlayerInVehicle(12, playerid);
    GivePlayerMoneyEx(20, playerid, -1000);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    GetPlayerSkin(4, playerid);
    SetPlayerSkinInit(4, playerid);
    SendClientMessage(12, playerid, -1);
    SetPlayerSkin(8, playerid, 206);
    SendClientMessage(12, playerid, -1);
    EnablePlayerGPS(24, playerid, 55, -987806217, -1008907781, 1105198962, 199252236);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    EnablePlayerGPS(24, playerid, 55, -988144542, 1135638947, 1153147584, 199252808);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    OrdinaryNewElectric(4, playerid);
    GetPlayerSkin(4, playerid);
    SetPlayerSkinInit(4, playerid);
    SendClientMessage(12, playerid, -1);
    GetPVarInt(8, playerid, 199253560);
    GetPVarInt(8, playerid, 199253632);
    // casetbl cases=4
    SetPVarInt(12, playerid, 199253860, 1);
    Dialog(28, playerid, 3247, 2, 199253932, 199254044, 199254228, 199254260);
    DeletePVar(8, playerid, 199254264);
    GetPVarInt(8, playerid, 199254336);
    GetPVarInt(8, playerid, 199254380);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    GivePlayerMoneyEx(20, playerid, -2500);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    format(16, -596, 148);
    GivePlayerMoneyEx(20, playerid);
    DeletePVar(8, playerid, 199255928);
    e_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock blackjack_OnPlayerEnterDynamicA(playerid, areaid)
{
    SetPlayerPosEx(32, playerid, -988096408, 1135649954, 1153147584, 1132745447, 1, 1, 1);
    SetPlayerPosEx(32, playerid, -987833034, -1009503688, 1105351722, 1132822919, 0, 0, 1);
    Dialog(28, playerid, 3244, 0, 199255972, 199256124, 199256564, 199256588);
    Dialog(28, playerid, 3245, 0, 199256612, 199256700, 199256908, 199256932);
    Dialog(28, playerid, 3246, 0, 199256956, 199257084, 199257304, 199257328);
    Dialog(28, playerid, 3246, 0, 199257352, 199257476, 199257688, 199257712);
    SendClientMessage(12, playerid, -1);
    SendClientMessage(12, playerid, -1);
    return 1;
    IsPlayerInOrdersElectric(4, playerid);
    IsPlayerInAnyVehicle(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    ApplyAnimationEx(44, playerid, 199258256, 199258292, 1078355558, 1, 1, 1, 0, 0, 0, -1);
    SetTimerEx(20, 199258336, 5000, 0);
    SendClientMessage(12, playerid, -1);
    e_OnPlayerEnterDynamicArea(8, playerid, areaid);
    return 1;
}


stock rul_OnGameModeInit()
{
    print(4);
    CreateElectric(0);
    e_OnGameModeInit(0);
    return 1;
}


stock CreateElectric()
{
    print(4);
    CreateDynamicSphere(32);
    func_0x1d0(8);
    Create3DTextLabel(32, 199258808, -1);
    CreateActorEx(40, 199258908, 199259092, 84, -988096066, 1135921152, 1153147584, 1132745447, 1, 1, 1);
    CreateDynamicSphere(32, -988096066, 1135921152, 1153147584, 1077936128, 1, 1, -1, 0);
    CreateDynamicPickup(44, "pc_cmd_dice", 23, -987806217, -1008907781, 1105198962, 0, 0, -1, 1128792064, -1, 0);
    CreateDynamicSphere(32, -987806217, -1008907781, 1105198962, 1077936128, 0, 0, -1, 0);
    Create3DTextLabel(32, 199259096, -1, -987806217, -1008907781, 1105198962, 1092616192, 0, 0);
    CreateDynamicPickup(44, 1275, 23, -988144542, 1135638947, 1153147584, 1, 1, -1, 1128792064, -1, 0);
    CreateDynamicSphere(32, -988144542, 1135638947, 1153147584, 1077936128, 1, 1, -1, 0);
    Create3DTextLabel(32, 199259312, -1, -988144542, 1135638947, 1153147584, 1092616192, 1, 0);
    CreateDynamicSphere(32, -987828746, -1009493336, 1105346418, 1065353216, 0, 0, -1, 0);
    Create3DTextLabel(32, 199259500, -1, -987828746, -1009493336, 1105346418, 1092616192, 0, 0);
    CreateDynamicSphere(32, -988090365, 1135636158, 1153147584, 1065353216, 1, 1, -1, 0);
    CreateDynamicPickup(44, "cmd_dice", 23, -987828746, -1009493336, 1105346418, 0, 0, -1, 1128792064, -1, 0);
    CreateDynamicPickup(44, "cmd_dice", 23, -988090365, 1135636158, 1153147584, 1, 1, -1, 1128792064, -1, 0);
    return 1;
}


stock pc_cmd_eorders(playerid)
{
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPlayerSkin(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    GetPlayerVehicleID(4, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    random(4, 10);
    GetPlayerDistanceFromPoint(16, playerid);
    floatround(8, L_464, 0);
    func_0x2c(8);
    random(4, 2500);
    func_0x128(8);
    floatround(8, L_468, 0);
    format(20, -460, 114);
    SendClientMessage(12, playerid, -1);
    EnablePlayerGPS(24, playerid, 55);
    EnablePlayerGPS(24, playerid, 55);
    return 1;
}


stock IsPlayerInOrdersElectric(playerid)
{
    IsPlayerInDynamicArea(12, playerid);
    return 1;
}


stock OrdinaryNewElectric(playerid)
{
    n_veh_DestroyVehicle(4);
    GetPVarInt(8, playerid, 199260960);
    DeletePVar(8, playerid, 199261004);
    return 1;
}


stock NextStageElectric(playerid)
{
    ClearAnimations(8, playerid, 0);
    random(4, 3);
    // casetbl cases=4
    SetPVarInt(12, playerid, 199261232, L_4);
    format(16, -804, 184);
    Dialog(28, playerid, 3247, 0, 199261580, -804, 199261696, 199261720);
    return 1;
}


// RESTORED: pawno/include/system/carshare_welsi.pwn
// Functions: 8

stock prom_OnPlayerConnect(playerid)
{
    car_OnPlayerConnect(4, playerid);
    return 1;
}


stock prom_OnPlayerDisconnect(playerid, reason)
{
    DeleteCarShareVehicle(4, playerid);
    car_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock prom_OnGameModeInit()
{
    print(4);
    car_OnGameModeInit(0);
    return 1;
}


stock prom_OnDialogResponse(playerid, dialogid, response, listitem)
{
    DeleteCarShareVehicle(4, playerid);
    SendClientMessage(12, playerid, -1);
    // casetbl cases=2
    GetPVarInt(8, playerid, 197990204);
    SetPVarInt(12, playerid, 197990124);
    GetPVarInt(8, playerid, 197990364);
    SetPVarInt(12, playerid, 197990284);
    GetPVarInt(8, playerid, 197990444);
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    format(24, -524, 128);
    strcat(12, -5844);
    strcat(12, -5844);
    strcat(12, -5844);
    DialogCarShare(28, playerid, 2311, 5, 197991084, -5844, 197991124, 197991148);
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    format(20, -344, 84);
    format(32, -840, 124);
    Dialog(28, playerid, 2313, 2, -344, -840, 197991672, 197991696);
    SetPVarInt(12, playerid, 197991720, L_4);
    // casetbl cases=6
    GetPVarInt(8, playerid, 197991760);
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    GivePlayerMoneyEx(20, playerid);
    format(24, -748, 184);
    SendClientMessage(12, playerid, -1);
    GivePlayerMoneyEx(20, playerid);
    SendClientMessage(12, playerid, -1);
    return 1;
    SetTimerEx(20, 197992436);
    GetPlayerDistanceFromPoint(16, playerid);
    GetPlayerDistanceFromPoint(16, playerid);
    func_0x358(8);
    n_veh_CreateVehicle(44);
    format(20, -1276, 124);
    CreateVehicleLabel(48);
    EnablePlayerGPS(24, playerid, 1, L_768, L_772, L_776, 197992732);
    // casetbl cases=6
    GetPVarInt(8, playerid, 197992912);
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    GivePlayerMoneyEx(20, playerid);
    format(24, -744, 184);
    SendClientMessage(12, playerid, -1);
    GivePlayerMoneyEx(20, playerid);
    SendClientMessage(12, playerid, -1);
    DeleteCarShareVehicle(4, playerid);
    return 1;
    SetTimerEx(20, 197993588);
    DeleteCarShareVehicle(4, playerid);
    car_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


stock pc_cmd_arendacar(playerid)
{
    Dialog(28, playerid, 2310, 2, 197993632, 197993672, 197993788, 197993812);
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    format(24, -516, 128);
    strcat(12, -5836);
    strcat(12, -5836);
    SetPVarInt(12, playerid, 197994276, 1);
    DialogCarShare(28, playerid, 2311, 5, 197994356, -5836, 197994396, 197994420);
    return 1;
}


stock DialogCarShare(playerid, dialogid, style)
{
    fg_ShowPlayerDialog(28, playerid, 0, 2, 197994444, 197994460, 197994476, 197994492);
    fg_ShowPlayerDialog(28, playerid, dialogid, style, V_24, V_28, V_32, V_36);
    return 1;
}


stock CarShare(playerid)
{
    return 1;
    SendClientMessage(12, playerid, -1);
    Dialog(28, playerid, 2312, 2, 197994688, 197994728, 197995144, 197995168);
    KillTimer(4);
    return 1;
}


stock DeleteCarShareVehicle(playerid)
{
    DestroyVehicleLabel(4);
    n_veh_DestroyVehicle(4);
    KillTimer(4);
    return 1;
}


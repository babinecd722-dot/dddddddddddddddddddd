// RESTORED: pawno/include/system/weekly_prizes.pwn
// Functions: 9

stock CREATE_ACCOUNTS_TABLE_WP()
{
    mysql_query(12, 166387936);
    mysql_errno(4);
    mysql_query(12, 166387936);
    mysql_errno(4);
    print(4);
    return 1;
}


stock LoadWeeklyPrizes(playerid)
{
    mysql_format(20, 166387936, -336, 84);
    mysql_query(12, 166387936);
    mysql_errno(4);
    cache_get_row(20, 0, 0, -532, 1, 48);
    sscanf(12, -532, 199012456);
    cache_get_row_int(12, 0, 1, 1);
    cache_delete(8, L_340, 1);
    return 1;
}


stock UnLoadWeeklyPrizes(playerid)
{
    format(40, -192, 48);
    mysql_format(28, 166387936, -928, 184);
    mysql_query(12, 166387936);
    return 1;
}


stock ch_OnPlayerConnect(playerid)
{
    SetTimerEx(20, 199012872, 2000, 0);
    weekly_OnPlayerConnect(4, playerid);
    return 1;
}


stock name_OnPlayerDisconnect(playerid, reason)
{
    UnLoadWeeklyPrizes(4, playerid);
    weekly_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock ch_OnGameModeInit()
{
    SetTimer(12, 199012948, 3000);
    SetTimer(12, 199013048, 5000);
    print(4);
    weekly_OnGameModeInit(0);
    return 1;
}


stock CheckWeeklyPrizes()
{
    getdate(12, -4, -8, -12);
    gettime(12, -16, -20);
    GetDayOfWeek(12, L_4, L_8, L_12);
    mysql_query(12, 166387936);
    mysql_query(12, 166387936);
    SendClientMessage(12, L_32, -1);
    UnLoadWeeklyPrizes(4, L_32);
    return 1;
}


stock pc_cmd_everyprize(playerid)
{
    format(12, -1508, 28);
    format(12, -1508, 28);
    format(12, -1508, 28);
    // casetbl cases=4
    format(24, -1844, 84);
    strcat(12, -1392);
    fg_ShowPlayerDialog(28, playerid, 3882, 2, 199014388, -1392, 199014472, 199014508);
    return 1;
}


stock skin_OnDialogResponse(playerid, dialogid, response, listitem)
{
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    GivePlayerDonateRub(20, playerid);
    GivePlayerMoneyEx(20, playerid);
    gettime(12);
    timestamp_to_date(28);
    UpdatePlayerDatabaseInt(12, playerid, 199015916, 3);
    UpdatePlayerDatabaseInt(12, playerid, 199015948);
    UpdatePlayerDatabaseInt(12, playerid, 199016000);
    // casetbl cases=5
    format(16, -580, 144);
    SendClientMessage(12, playerid, -1);
    UnLoadWeeklyPrizes(4, playerid);
    SendClientMessage(12, playerid, -1);
    // casetbl cases=4
    weekly_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


// RESTORED: pawno/include/system/cp.pwn
// Functions: 4

stock ClearPlayerCPInfo(playerid)
{
    return 1;
}


stock n_SetPlayerCheckpoint(playerid, size, action_type)
{
    SetPlayerCheckpoint(20, playerid, V_16, V_20, V_24, size);
    return 1;
}


stock n_IsPlayerInCheckpoint(playerid, size)
{
    floatadd(8);
    IsPlayerInRangeOfPoint(20, playerid);
    return 1;
}


stock n_DisablePlayerCheckpoint(playerid)
{
    DisablePlayerCheckpoint(4, playerid);
    return 1;
}


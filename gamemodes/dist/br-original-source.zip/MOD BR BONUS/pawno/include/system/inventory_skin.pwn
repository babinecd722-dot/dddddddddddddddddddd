// RESTORED: pawno/include/system/inventory_skin.pwn
// Functions: 4

stock pc_cmd_myskinsz(playerid)
{
    mysql_format(20, 166387936, -2560, 640);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    SendClientMessage(12, playerid, -1717986817);
    CheckSkinPlayer(4, playerid);
    format(12, -2560, 640);
    cache_get_field_content_int(12, L_2920, 198097488);
    cache_get_field_content_int(12, L_2920, 198097500);
    cache_get_field_content_int(12, L_2920, 198097532);
    format(24, -2812, 60);
    strcat(12, -2560);
    Dialog(28, playerid, 1789, 2, 198097740, -2560, 198097828, 198097860);
    cache_delete(8, L_2564, 1);
    return 1;
}


stock CheckSkinPlayer(playerid)
{
    mysql_format(20, 166387936, -576, 144);
    mysql_query(12, 166387936);
    cache_get_row_count(4, 1);
    cache_delete(8, L_580, 1);
    GetPlayerSkinEx(4, playerid);
    mysql_format(24, 166387936, -576, 144);
    mysql_query(12, 166387936);
    mysql_errno(4);
    SendClientMessage(12, playerid, -1);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
}


stock ShowOwnableSkinLoadDialog(playerid, id)
{
    SetPVarInt(12, playerid, 198098708, id);
    Dialog(28, playerid, 1790, 2, 198098768, 198098904, 198099044, 198099076);
    return 1;
}


stock ch_OnDialogResponse(playerid, dialogid, response, listitem)
{
    ShowOwnableSkinLoadDialog(8, playerid, L_4);
    GetPVarInt(8, playerid, 198099108);
    mysql_format(20, 166387936, -660, 164);
    mysql_query(12, 166387936);
    cache_get_row_int(12, 0, 0, 1);
    cache_get_row_int(12, 0, 1, 1);
    cache_delete(8, L_676, 1);
    mysql_format(16, 166387936, -660, 164);
    mysql_query(12, 166387936);
    cache_get_row_int(12, 0, 0, 1);
    cache_delete(8, L_676, 1);
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    UpdatePlayerDatabaseInt(12, playerid, 198099736, L_664);
    mysql_format(20, 166387936, -660, 164);
    mysql_query(12, 166387936);
    mysql_format(20, 166387936, -660, 164);
    mysql_query(12, 166387936);
    SetPlayerSkinInit(4, playerid);
    SendClientMessage(12, playerid, 1724658687);
    SendClientMessage(12, playerid, -1717986817);
    return 1;
    mysql_format(20, 166387936, -660, 164);
    mysql_query(12, 166387936);
    // casetbl cases=3
    return 1;
    skin_OnDialogResponse(20, playerid, dialogid, response, listitem, V_28);
    return 1;
}


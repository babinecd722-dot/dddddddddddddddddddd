// RESTORED: gamemodes/modules/core/vehicle/auto-race/dialogs.pwn
// Functions: 0

// AMX 0x77350
stock DC_P_AUTORACE(playerid)
{
    // --- line 4 ---
    // --- line 6 ---
    Dialog_Open(28, playerid, 199143592, 0, 199143636, 199143720, 199143964, 199143996);
    // --- line 7 ---
    return 1;
}


// AMX 0x773b4
stock DR_P_AUTORACE(playerid, response, listitem)
{
    // --- line 10 ---
    // --- line 12 ---
    // load response
    if (!_) {} // goto 0x773e4
    // --- line 13 ---
    return 1;
    // --- line 19 ---
    // stack -4
    // var_-4 = _;
    // --- line 22 ---
    // load var_-4
    if (!_) {} // goto 0x77468
    // --- line 23 ---
    SendClientMessage(12, playerid, -825307393);
    // stack 16
    // --- line 24 ---
    // stack 4
    return 1;
    // --- line 26 ---
    if (!_) {} // goto 0x774d0
    // --- line 27 ---
    SendClientMessage(12, playerid, -825307393);
    // stack 16
    // --- line 28 ---
    // stack 4
    return 1;
    // --- line 30 ---
    // _ = 199136576;
    // load var_-4
    // _ = 199141276;
    // load var_-4
    // goto 0x77568
    // --- line 31 ---
    SendClientMessage(12, playerid, -825307393);
    // stack 16
    // --- line 32 ---
    // stack 4
    return 1;
    // --- line 34 ---
    // _ = 199138680;
    // load playerid
    if (!_) {} // goto 0x775cc
    // _ = 199139680;
    // load playerid
    // goto 0x775cc
    // goto 0x775d0
    if (!_) {} // goto 0x7775c
    // --- line 37 ---
    // stack -4
    // _ = 199136576;
    // load var_-4
    // var_-8 = _;
    // --- line 40 ---
    // _ = 199136608;
    // load var_-4
    // load var_-8
    // load playerid
    // --- line 41 ---
    // _ = 199138680;
    // load playerid
    // --- line 42 ---
    // _ = 199139680;
    // load playerid
    // --- line 43 ---
    // _ = 199140680;
    // load playerid
    // load var_-8
    // --- line 44 ---
    SendClientMessage(12, playerid, -1);
    // stack 16
    // --- line 45 ---
    // stack 8
    return 1;
    // --- line 47 ---
    // stack 4
    return 1;
}


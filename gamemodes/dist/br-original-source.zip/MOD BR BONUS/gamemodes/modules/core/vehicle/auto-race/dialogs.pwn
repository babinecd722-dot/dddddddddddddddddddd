// RESTORED: gamemodes/modules/core/vehicle/auto-race/dialogs.pwn
// Functions: 2

stock DC_P_AUTORACE(playerid)
{
    Dialog_Open(28, playerid, 199143592, 0, 199143636, 199143720, 199143964, 199143996);
    return 1;
}


stock DR_P_AUTORACE(playerid, response, listitem)
{
    return 1;
    SendClientMessage(12, playerid, -825307393);
    return 1;
    SendClientMessage(12, playerid, -825307393);
    return 1;
    SendClientMessage(12, playerid, -825307393);
    return 1;
    SendClientMessage(12, playerid, -1);
    return 1;
}


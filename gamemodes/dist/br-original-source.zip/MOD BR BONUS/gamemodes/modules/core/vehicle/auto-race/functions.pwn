// RESTORED: gamemodes/modules/core/vehicle/auto-race/functions.pwn
// Functions: 2

public OnTimerMinuteOne()
{
    gettime(12, -4, -8);
    SendClientMessageToAll(8, -1);
    SendClientMessageToAll(8, -1);
    SendClientMessageToAll(8, -1);
    return 1;
    SetPlayerVirtualWorld(8, L_20);
    random(4, 128, -1, 0, -1, -1);
    random(4, 128);
    n_veh_CreateVehicle(44);
    SetVehicleVirtualWorld(8);
    PutPlayerInVehicle(12, L_20);
    CreateDynamicRaceCP(56, 0);
    Streamer_Update(8, L_20, 3);
    TogglePlayerControllable(8, L_20, 0);
    SetTimer(12, 199143372, 1000);
    // casetbl cases=4
    return 1;
}


public OnPlayerDisconnectAndSpawn(playerid, reason)
{
    n_veh_DestroyVehicle(4);
    DestroyDynamicRaceCP(4);
    SendClientMessage(12, playerid, -825307393);
    return 1;
}


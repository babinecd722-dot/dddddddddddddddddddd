// RESTORED: gamemodes/modules/core/vehicle/auto-race/functions.pwn
// Functions: 0

// AMX 0x75ee8
public OnTimerMinuteOne()
{
    // --- line 4 ---
    // --- line 6 ---
    // stack -4
    gettime(12, -4, -8);
    // stack 16
    // var_-12 = _;
    // stack -4
    // var_-16 = _;
    // --- line 11 ---
    // switch -> 0x76d9c
    // --- line 13 ---
    // load var_-4
    // goto 0x75fdc
    // load var_-4
    // goto 0x75fdc
    // load var_-4
    // goto 0x75fdc
    // goto 0x75fe4
    if (!_) {} // goto 0x76014
    // load var_-8
    if (!_) {} // goto 0x76014
    // goto 0x76018
    if (!_) {} // goto 0x760c8
    // --- line 14 ---
    // load var_-16
    if (!_) {} // goto 0x760c8
    // --- line 15 ---
    // stor.pri 199136560
    // var_-16 = _;
    // --- line 16 ---
    // --- line 17 ---
    // _ = 199136568;
    // load var_-16
    // load var_-12
    // --- line 18 ---
    SendClientMessageToAll(8, -1);
    // stack 12
    // goto 0x76dc0
    // --- line 23 ---
    // load var_-16
    // _ = -1;
    // goto 0x76128
    // _ = 199136568;
    // load var_-16
    // goto 0x76128
    // goto 0x7612c
    if (!_) {} // goto 0x761b0
    // --- line 25 ---
    // stor.pri 199136564
    // --- line 26 ---
    // _ = 199136568;
    // load var_-16
    // load var_-12
    // --- line 27 ---
    SendClientMessageToAll(8, -1);
    // stack 12
    // goto 0x76dc0
    // --- line 31 ---
    // load var_-16
    // _ = -1;
    // goto 0x76210
    // _ = 199136568;
    // load var_-16
    // goto 0x76210
    // goto 0x76214
    if (!_) {} // goto 0x76d94
    // --- line 33 ---
    // _ = 199136576;
    // load var_-16
    // _ = 3;
    // goto 0x765a0
    // --- line 35 ---
    // --- line 38 ---
    // stor.pri 199136560
    // --- line 39 ---
    // stor.pri 199136564
    // --- line 40 ---
    // _ = 199136568;
    // load var_-16
    // --- line 41 ---
    // stack -4
    // _ = 199136576;
    // load var_-16
    // var_-24 = _;
    // goto 0x762f0
    // load var_-24
    // _ = -1;
    // goto 0x764f8
    // --- line 42 ---
    // _ = 199136608;
    // load var_-16
    // load var_-24
    // var_-20 = _;
    // --- line 43 ---
    // load var_-20
    // _ = 65535;
    // goto 0x763f8
    // _ = 199138680;
    // load var_-20
    // load var_-16
    // goto 0x763dc
    // _ = 199139680;
    // load var_-20
    if (!_) {} // goto 0x763dc
    // goto 0x763e0
    if (!_) {} // goto 0x763f8
    // goto 0x763fc
    if (!_) {} // goto 0x764f0
    // --- line 45 ---
    // _ = 199136608;
    // load var_-16
    // load var_-24
    // --- line 46 ---
    // _ = 199138680;
    // load var_-20
    // --- line 47 ---
    // _ = 199139680;
    // load var_-20
    // --- line 48 ---
    // _ = 199140680;
    // load var_-20
    // goto 0x762e4
    // stack 4
    // --- line 51 ---
    // _ = 199136592;
    // load var_-16
    // --- line 52 ---
    // _ = 199136576;
    // load var_-16
    // --- line 53 ---
    SendClientMessageToAll(8, -1);
    // stack 12
    // --- line 54 ---
    // stack 20
    return 1;
    // --- line 57 ---
    // --- line 60 ---
    // stor.pri 199136564
    // --- line 61 ---
    // _ = 199136584;
    // load var_-16
    // --- line 62 ---
    // stack -4
    // _ = 199136576;
    // load var_-16
    // var_-24 = _;
    // goto 0x76630
    // load var_-24
    // _ = -1;
    // goto 0x76d28
    // --- line 63 ---
    // _ = 199136608;
    // load var_-16
    // load var_-24
    // var_-20 = _;
    // --- line 64 ---
    // load var_-20
    // _ = 65535;
    // goto 0x76740
    // _ = 199138680;
    // load var_-20
    // load var_-16
    // goto 0x76724
    // _ = 199139680;
    // load var_-20
    if (!_) {} // goto 0x76724
    // goto 0x76728
    if (!_) {} // goto 0x76740
    // goto 0x76744
    if (!_) {} // goto 0x76d20
    // --- line 66 ---
    // _ = 199139680;
    // load var_-20
    // --- line 67 ---
    // _ = 199140932;
    // load var_-16
    SetPlayerVirtualWorld(8, var_-20);
    // stack 12
    // --- line 68 ---
    // _ = 199136680;
    // load var_-20
    random(4, 128, -1, 0, -1, -1);
    // stack 8
    random(4, 128);
    // stack 8
    // _ = 199140948;
    // load var_-24
    // load var_-16
    // _ = 199140948;
    // load var_-16
    // load var_-24
    // _ = 199140948;
    // load var_-16
    // load var_-24
    // _ = 199140948;
    // load var_-16
    // load var_-24
    // _ = 199140940;
    // load var_-16
    n_veh_CreateVehicle(44);
    // --- line 69 ---
    // _ = 199140932;
    // load var_-16
    // _ = 199136680;
    // load var_-20
    SetVehicleVirtualWorld(8);
    // stack 12
    // --- line 70 ---
    // _ = 199136680;
    // load var_-20
    PutPlayerInVehicle(12, var_-20);
    // stack 16
    // --- line 71 ---
    // _ = 199137680;
    // load var_-20
    // _ = 199141284;
    // load var_-16
    // _ = 199141284;
    // load var_-16
    // _ = 199141284;
    // load var_-16
    // _ = 199141284;
    // load var_-16
    // _ = 199141284;
    // load var_-16
    // _ = 199141284;
    // load var_-16
    CreateDynamicRaceCP(56, 0);
    // stack 60
    // --- line 73 ---
    Streamer_Update(8, var_-20, 3);
    // stack 12
    // --- line 74 ---
    TogglePlayerControllable(8, var_-20, 0);
    // stack 12
    // goto 0x76624
    // stack 4
    // --- line 77 ---
    // _ = 199136600;
    // load var_-16
    SetTimer(12, 199143372, 1000);
    // stack 16
    // stack 4
    // goto 0x76dc0
    // casetbl cases=4
    // --- line 81 ---
    // stack 16
    return 1;
}


// AMX 0x76dd8
public OnPlayerDisconnectAndSpawn(playerid, reason)
{
    // --- line 88 ---
    // --- line 90 ---
    // stack -4
    // _ = 199138680;
    // load playerid
    // var_-4 = _;
    // --- line 93 ---
    // load var_-4
    // _ = -1;
    // goto 0x76e5c
    // _ = 199139680;
    // load playerid
    // goto 0x76e5c
    // goto 0x76e64
    if (!_) {} // goto 0x77338
    // --- line 96 ---
    // stack -8
    // --- line 99 ---
    // _ = 199140680;
    // load playerid
    // --- line 100 ---
    // _ = 199139680;
    // load playerid
    if (!_) {} // goto 0x770cc
    // --- line 101 ---
    // _ = 199136576;
    // load var_-4
    // --- line 103 ---
    // stack -4
    // _ = 199136608;
    // load var_-4
    // var_-16 = _;
    // --- line 106 ---
    // _ = 199136608;
    // load var_-4
    // load var_-16
    // --- line 107 ---
    // _ = 199136608;
    // load var_-4
    // --- line 108 ---
    // _ = 199140680;
    // load var_-16
    // stack 4
    // goto 0x77128
    // --- line 110 ---
    // _ = 199136608;
    // load var_-4
    // --- line 112 ---
    // _ = 199138680;
    // load playerid
    // --- line 113 ---
    // _ = 199139680;
    // load playerid
    // --- line 114 ---
    // _ = 199140680;
    // load playerid
    // --- line 115 ---
    // _ = 199136680;
    // load playerid
    // _ = 65535;
    // goto 0x77250
    // --- line 116 ---
    // _ = 199136680;
    // load playerid
    n_veh_DestroyVehicle(4);
    // --- line 117 ---
    // _ = 199136680;
    // load playerid
    // --- line 119 ---
    // _ = 199137680;
    // load playerid
    if (!_) {} // goto 0x772e0
    // --- line 120 ---
    // _ = 199137680;
    // load playerid
    DestroyDynamicRaceCP(4);
    // stack 8
    // --- line 121 ---
    // _ = 199137680;
    // load playerid
    // --- line 123 ---
    // load reason
    if (!_) {} // goto 0x77330
    // --- line 124 ---
    SendClientMessage(12, playerid, -825307393);
    // stack 16
    // stack 8
    // --- line 127 ---
    // stack 4
    return 1;
}


// RESTORED: gamemodes/modules/core/vehicle/auto-race/callbacks.pwn
// Functions: 1

stock __OnServerTimerAutoRace()
{
    PlayerPlaySound(20, L_4, 3201, 0, 0, 0);
    GameTextForPlayer(16, L_4, 199142212, 5000, 3);
    TogglePlayerControllable(8, L_4, 1);
    SendClientMessageToAll(8, -1);
    return 1;
    format(16, -32, 6);
    GameTextForPlayer(16, L_4, -32, 5000, 3);
    SetTimer(12, 199142396, 1000);
    return 1;
}


// RESTORED: gamemodes/modules/core/vehicle/auto-race/callbacks.pwn
// Functions: 0

// AMX 0x75968
stock @__OnServerTimerAutoRace()
{
    // --- line 5 ---
    // --- line 7 ---
    // stack -4
    // var_-8 = _;
    // --- line 11 ---
    // _ = 199136592;
    // load var_-8
    // goto 0x75c54
    // --- line 12 ---
    // stack -4
    // _ = 199136576;
    // load var_-8
    // var_-12 = _;
    // goto 0x75a08
    // load var_-12
    // _ = -1;
    // goto 0x75bd8
    // --- line 13 ---
    // _ = 199136608;
    // load var_-8
    // load var_-12
    // var_-4 = _;
    // --- line 14 ---
    // load var_-4
    // _ = 65535;
    // goto 0x75b18
    // _ = 199138680;
    // load var_-4
    // load var_-8
    // goto 0x75afc
    // _ = 199139680;
    // load var_-4
    if (!_) {} // goto 0x75afc
    // goto 0x75b00
    if (!_) {} // goto 0x75b18
    // goto 0x75b1c
    if (!_) {} // goto 0x75bd0
    // --- line 16 ---
    PlayerPlaySound(20, var_-4, 3201, 0, 0, 0);
    // stack 24
    // --- line 17 ---
    GameTextForPlayer(16, var_-4, 199142212, 5000, 3);
    // stack 20
    // --- line 18 ---
    TogglePlayerControllable(8, var_-4, 1);
    // stack 12
    // goto 0x759fc
    // stack 4
    // --- line 21 ---
    // _ = 199136600;
    // load var_-8
    // --- line 22 ---
    SendClientMessageToAll(8, -1);
    // stack 12
    // --- line 23 ---
    // stack 8
    return 1;
    // --- line 26 ---
    // stack -24
    // --- line 29 ---
    // _ = 199136592;
    // load var_-8
    format(16, -32, 6);
    // stack 20
    // --- line 30 ---
    // stack -4
    // _ = 199136576;
    // load var_-8
    // var_-36 = _;
    // goto 0x75d0c
    // load var_-36
    // _ = -1;
    // goto 0x75e6c
    // --- line 31 ---
    // _ = 199136608;
    // load var_-8
    // load var_-36
    // var_-4 = _;
    // --- line 32 ---
    // load var_-4
    // _ = 65535;
    // goto 0x75e1c
    // _ = 199138680;
    // load var_-4
    // load var_-8
    // goto 0x75e00
    // _ = 199139680;
    // load var_-4
    if (!_) {} // goto 0x75e00
    // goto 0x75e04
    if (!_) {} // goto 0x75e1c
    // goto 0x75e20
    if (!_) {} // goto 0x75e64
    // --- line 34 ---
    GameTextForPlayer(16, var_-4, -32, 5000, 3);
    // stack 20
    // goto 0x75d00
    // stack 4
    // --- line 37 ---
    // _ = 199136600;
    // load var_-8
    SetTimer(12, 199142396, 1000);
    // stack 16
    // --- line 38 ---
    // stack 32
    return 1;
}


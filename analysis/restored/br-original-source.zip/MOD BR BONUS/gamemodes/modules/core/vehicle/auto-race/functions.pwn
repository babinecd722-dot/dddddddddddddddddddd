public OnTimerMinuteOne()
{
    gettime(12, -4, -8);
    switch (_)
    if (_) goto lbl_0x75fdc;
    if (_) goto lbl_0x75fdc;
    if (_) goto lbl_0x75fdc;
    goto lbl_0x75fe4;
    if (!_) goto lbl_0x76014;
    if (!_) goto lbl_0x76014;
    goto lbl_0x76018;
    if (!_) goto lbl_0x760c8;
    if (!_) goto lbl_0x760c8;
    SendClientMessageToAll(-1, 199142496);
    goto lbl_0x76dc0;
    goto lbl_0x76128;
    goto lbl_0x76128;
    goto lbl_0x7612c;
    if (!_) goto lbl_0x761b0;
    SendClientMessageToAll(-1, 199142796);
    goto lbl_0x76dc0;
    goto lbl_0x76210;
    goto lbl_0x76210;
    goto lbl_0x76214;
    if (!_) goto lbl_0x76d94;
    goto lbl_0x765a0;
    goto lbl_0x762f0;
    goto lbl_0x764f8;
    goto lbl_0x763f8;
    goto lbl_0x763dc;
    if (!_) goto lbl_0x763dc;
    goto lbl_0x763e0;
    if (!_) goto lbl_0x763f8;
    goto lbl_0x763fc;
    if (!_) goto lbl_0x764f0;
    goto lbl_0x762e4;
    SendClientMessageToAll(-1, 199143100);
    return 1;
    goto lbl_0x76630;
    goto lbl_0x76d28;
    goto lbl_0x76740;
    goto lbl_0x76724;
    if (!_) goto lbl_0x76724;
    goto lbl_0x76728;
    if (!_) goto lbl_0x76740;
    goto lbl_0x76744;
    if (!_) goto lbl_0x76d20;
    SetPlayerVirtualWorld(8, var_-20);
    random(4, 128, -1, 0, -1, -1);
    random(4, 128);
    n_veh_CreateVehicle(44);
    SetVehicleVirtualWorld(8);
    PutPlayerInVehicle(12, var_-20);
    CreateDynamicRaceCP(56, 0);
    Streamer_Update(8, var_-20, 3);
    TogglePlayerControllable(8, var_-20, 0);
    goto lbl_0x76624;
    SetTimer(199143372, 1000, 0);
    goto lbl_0x76dc0;
    return 1;
}


public OnPlayerDisconnectAndSpawn(playerid, reason)
{
    goto lbl_0x76e5c;
    if (_) goto lbl_0x76e5c;
    goto lbl_0x76e64;
    if (!_) goto lbl_0x77338;
    if (!_) goto lbl_0x770cc;
    goto lbl_0x77128;
    goto lbl_0x77250;
    n_veh_DestroyVehicle(4);
    if (!_) goto lbl_0x772e0;
    DestroyDynamicRaceCP(4);
    if (!_) goto lbl_0x77330;
    SendClientMessage(playerid, -825307393, 199143472);
    return 1;
}


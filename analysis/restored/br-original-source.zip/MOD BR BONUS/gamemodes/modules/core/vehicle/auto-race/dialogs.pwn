stock DC_P_AUTORACE(playerid)
{
    Dialog_Open(28, playerid, 199143592, 0, 199143636, 199143720, 199143964, 199143996);
    return 1;
}


stock DR_P_AUTORACE(playerid, response, listitem)
{
    if (!_) goto lbl_0x773e4;
    return 1;
    if (!_) goto lbl_0x77468;
    SendClientMessage(playerid, -825307393, 199144020);
    return 1;
    if (!_) goto lbl_0x774d0;
    SendClientMessage(playerid, -825307393, 199144100);
    return 1;
    goto lbl_0x77568;
    SendClientMessage(playerid, -825307393, 199144184);
    return 1;
    if (!_) goto lbl_0x775cc;
    if (_) goto lbl_0x775cc;
    goto lbl_0x775d0;
    if (!_) goto lbl_0x7775c;
    SendClientMessage(playerid, -1, 199144284);
    return 1;
}


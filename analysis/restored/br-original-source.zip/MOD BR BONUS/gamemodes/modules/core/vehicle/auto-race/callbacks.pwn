// RESTORED: gamemodes/modules/core/vehicle/auto-race/callbacks.pwn
// Functions: 0

// AMX 0x75968-0x75ee8
stock @__OnServerTimerAutoRace()
{
    // --- line 5 ---
    // --- line 7 ---
    // stack -4
    // var_-8 = _;
    // --- line 11 ---
    // _ = 199136592;
    // load var_-8
    if (_) goto lbl_0x75c54; // jnz
    // --- line 12 ---
    // stack -4
    // _ = 199136576;
    // load var_-8
    // var_-12 = _;
    goto lbl_0x75a08; // jump 0x75a08
    // load var_-12
    // _ = -1;
    goto lbl_0x75bd8; // jeq 0x75bd8
    // --- line 13 ---
    // _ = 199136608;
    // load var_-8
    // load var_-12
    // var_-4 = _;
    // --- line 14 ---
    // load var_-4
    // _ = 65535;
    goto lbl_0x75b18; // jeq 0x75b18
    // _ = 199138680;
    // load var_-4
    // load var_-8
    goto lbl_0x75afc; // jneq 0x75afc
    // _ = 199139680;
    // load var_-4
    if (!_) goto lbl_0x75afc; // jzer
    goto lbl_0x75b00; // jump 0x75b00
    if (!_) goto lbl_0x75b18; // jzer
    goto lbl_0x75b1c; // jump 0x75b1c
    if (!_) goto lbl_0x75bd0; // jzer
    // --- line 16 ---
    PlayerPlaySound(20, var_-4, 3201, 0, 0, 0);
    // stack 24
    // --- line 17 ---
    GameTextForPlayer(16, var_-4, 199142212, 5000, 3);
    // stack 20
    // --- line 18 ---
    TogglePlayerControllable(8, var_-4, 1);
    // stack 12
    goto lbl_0x759fc; // jump 0x759fc
    // stack 4
    // --- line 21 ---
    // _ = 199136600;
    // load var_-8
    // --- line 22 ---
    SendClientMessageToAll(-1, 199142272);
    // stack 12
    // --- line 23 ---
    // stack 8
    return 1;
    // --- line 26 ---
    // stack -24
    // --- line 29 ---
    // _ = 199136592;
    // load var_-8
    format(-32, 6, 199142372);
    // stack 20
    // --- line 30 ---
    // stack -4
    // _ = 199136576;
    // load var_-8
    // var_-36 = _;
    goto lbl_0x75d0c; // jump 0x75d0c
    // load var_-36
    // _ = -1;
    goto lbl_0x75e6c; // jeq 0x75e6c
    // --- line 31 ---
    // _ = 199136608;
    // load var_-8
    // load var_-36
    // var_-4 = _;
    // --- line 32 ---
    // load var_-4
    // _ = 65535;
    goto lbl_0x75e1c; // jeq 0x75e1c
    // _ = 199138680;
    // load var_-4
    // load var_-8
    goto lbl_0x75e00; // jneq 0x75e00
    // _ = 199139680;
    // load var_-4
    if (!_) goto lbl_0x75e00; // jzer
    goto lbl_0x75e04; // jump 0x75e04
    if (!_) goto lbl_0x75e1c; // jzer
    goto lbl_0x75e20; // jump 0x75e20
    if (!_) goto lbl_0x75e64; // jzer
    // --- line 34 ---
    GameTextForPlayer(16, var_-4, -32, 5000, 3);
    // stack 20
    goto lbl_0x75d00; // jump 0x75d00
    // stack 4
    // --- line 37 ---
    // _ = 199136600;
    // load var_-8
    SetTimer(199142396, 1000, 0);
    // stack 16
    // --- line 38 ---
    // stack 32
    return 1;
}


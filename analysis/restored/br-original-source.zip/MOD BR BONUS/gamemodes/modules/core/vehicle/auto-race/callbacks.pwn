stock @__OnServerTimerAutoRace()
{
    if (_) goto lbl_0x75c54;
    goto lbl_0x75a08;
    goto lbl_0x75bd8;
    goto lbl_0x75b18;
    goto lbl_0x75afc;
    if (!_) goto lbl_0x75afc;
    goto lbl_0x75b00;
    if (!_) goto lbl_0x75b18;
    goto lbl_0x75b1c;
    if (!_) goto lbl_0x75bd0;
    PlayerPlaySound(20, var_-4, 3201, 0, 0, 0);
    GameTextForPlayer(16, var_-4, 199142212, 5000, 3);
    TogglePlayerControllable(8, var_-4, 1);
    goto lbl_0x759fc;
    SendClientMessageToAll(-1, 199142272);
    return 1;
    format(-32, 6, 199142372);
    goto lbl_0x75d0c;
    goto lbl_0x75e6c;
    goto lbl_0x75e1c;
    goto lbl_0x75e00;
    if (!_) goto lbl_0x75e00;
    goto lbl_0x75e04;
    if (!_) goto lbl_0x75e1c;
    goto lbl_0x75e20;
    if (!_) goto lbl_0x75e64;
    GameTextForPlayer(16, var_-4, -32, 5000, 3);
    goto lbl_0x75d00;
    SetTimer(199142396, 1000, 0);
    return 1;
}


stock CREATE_ACCOUNTS_TABLE_WP()
{
    mysql_query(166387936, 199011120);
    mysql_errno(1);
    if (!_) goto lbl_0x63d34;
    mysql_query(166387936, 199011352);
    mysql_errno(1);
    if (!_) goto lbl_0x63d34;
    print(199011992);
    return 1;
}


stock LoadWeeklyPrizes(playerid)
{
    mysql_format(166387936, -336, 84, 199012212);
    mysql_query(166387936, -336);
    mysql_errno(1);
    if (!_) goto lbl_0x63f7c;
    cache_get_row(20, 0, 0, -532, 1, 48);
    sscanf(12, -532, 199012456);
    cache_get_row_int(12, 0, 1, 1);
    cache_delete(8, var_-340, 1);
    return 1;
}


stock UnLoadWeeklyPrizes(playerid)
{
    format(-192, 48, 199012508);
    mysql_format(166387936, -928, 184, 199012592);
    mysql_query(166387936, -928);
    return 1;
}


stock ch_OnPlayerConnect(playerid)
{
    SetTimerEx(199012872, 2000, 0, 199012940);
    weekly_OnPlayerConnect(4, playerid);
    return 1;
}


stock name_OnPlayerDisconnect(playerid, reason)
{
    UnLoadWeeklyPrizes(4, playerid);
    weekly_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock ch_OnGameModeInit()
{
    SetTimer(199012948, 3000, 0);
    SetTimer(199013048, 5000, 1);
    print(199013120);
    weekly_OnGameModeInit(0);
    return 1;
}


stock CheckWeeklyPrizes()
{
    getdate(12, -4, -8, -12);
    gettime(12, -16, -20);
    GetDayOfWeek(12, var_-4, var_-8, var_-12);
    if (!_) goto lbl_0x6453c;
    if (!_) goto lbl_0x6453c;
    if (!_) goto lbl_0x6453c;
    goto lbl_0x64540;
    if (!_) goto lbl_0x6457c;
    mysql_query(166387936, 199013336);
    if (!_) goto lbl_0x645b8;
    if (!_) goto lbl_0x645b8;
    goto lbl_0x645bc;
    if (!_) goto lbl_0x645f8;
    mysql_query(166387936, 199013544);
    goto lbl_0x6461c;
    goto lbl_0x6492c;
    if (!_) goto lbl_0x6469c;
    goto lbl_0x64618;
    goto lbl_0x646d0;
    goto lbl_0x6475c;
    if (!_) goto lbl_0x64754;
    goto lbl_0x646c4;
    if (!_) goto lbl_0x6478c;
    goto lbl_0x64618;
    if (!_) goto lbl_0x64824;
    goto lbl_0x64824;
    goto lbl_0x64828;
    if (!_) goto lbl_0x64924;
    SendClientMessage(var_-32, -1, 199013684);
    UnLoadWeeklyPrizes(4, var_-32);
    goto lbl_0x64618;
    return 1;
}


stock pc_cmd_everyprize(playerid)
{
    goto lbl_0x649cc;
    goto lbl_0x64bdc;
    switch (_)
    format(-1508, 28, 199014056);
    goto lbl_0x64b10;
    format(-1508, 28, 199014164);
    goto lbl_0x64b10;
    format(-1508, 28, 199014264);
    goto lbl_0x64b10;
    format(-1844, 84, 199014336);
    strcat(-1392, -1844);
    goto lbl_0x649c0;
    fg_ShowPlayerDialog(28, playerid, 3882, 2, 199014388, -1392, 199014472, 199014508);
    return 1;
}


stock skin_OnDialogResponse(playerid, dialogid, response, listitem)
{
    if (!_) goto lbl_0x657cc;
    if (!_) goto lbl_0x657cc;
    if (!_) goto lbl_0x64d7c;
    if (!_) goto lbl_0x64d7c;
    if (!_) goto lbl_0x64d7c;
    goto lbl_0x64d80;
    if (!_) goto lbl_0x64dc8;
    SendClientMessage(playerid, -1, 199014532);
    return 1;
    if (!_) goto lbl_0x64ea0;
    if (!_) goto lbl_0x64ea0;
    if (!_) goto lbl_0x64ea0;
    goto lbl_0x64ea4;
    if (!_) goto lbl_0x64eec;
    SendClientMessage(playerid, -1, 199014864);
    return 1;
    if (!_) goto lbl_0x64f88;
    SendClientMessage(playerid, -1, 199015320);
    return 1;
    switch (_)
    SendClientMessage(playerid, -1, 199015600);
    goto lbl_0x657c4;
    switch (_)
    GivePlayerDonateRub(20, playerid);
    goto lbl_0x655e8;
    GivePlayerMoneyEx(20, playerid);
    goto lbl_0x655e8;
    if (!_) goto lbl_0x652ec;
    gettime(12);
    goto lbl_0x65378;
    timestamp_to_date(28);
    UpdatePlayerDatabaseInt(12, playerid, 199015916, 3);
    UpdatePlayerDatabaseInt(12, playerid, 199015948);
    goto lbl_0x655e8;
    UpdatePlayerDatabaseInt(12, playerid, 199016000);
    goto lbl_0x655e8;
    format(-580, 144, 199016040);
    SendClientMessage(playerid, -1, -580);
    UnLoadWeeklyPrizes(4, playerid);
    goto lbl_0x657c4;
    SendClientMessage(playerid, -1, 199016376);
    goto lbl_0x657c4;
    weekly_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


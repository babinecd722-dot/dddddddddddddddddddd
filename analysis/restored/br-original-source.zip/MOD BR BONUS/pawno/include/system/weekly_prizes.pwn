// RESTORED: pawno/include/system/weekly_prizes.pwn
// Functions: 0

// AMX 0x63c44-0x63d44
stock CREATE_ACCOUNTS_TABLE_WP()
{
    // --- line 31 ---
    // --- line 33 ---
    mysql_query(166387936, 199011120);
    // stack 16
    // --- line 35 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x63d34; // jzer
    // --- line 37 ---
    mysql_query(166387936, 199011352);
    // stack 16
    // --- line 39 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x63d34; // jzer
    print(199011992);
    // stack 8
    // --- line 42 ---
    return 1;
}


// AMX 0x63d44-0x63fc0
stock LoadWeeklyPrizes(playerid)
{
    // --- line 45 ---
    // --- line 47 ---
    // stack -336
    // --- line 49 ---
    // _ = 181530104;
    // load playerid
    mysql_format(166387936, -336, 84, 199012212);
    // stack 24
    // --- line 50 ---
    // stack -4
    mysql_query(166387936, -336);
    // stack 16
    // var_-340 = _;
    // --- line 52 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x63f7c; // jzer
    // --- line 54 ---
    // stack -192
    // --- line 56 ---
    cache_get_row(20, 0, 0, -532, 1, 48);
    // stack 24
    // --- line 58 ---
    // _ = 199002120;
    // load playerid
    sscanf(12, -532, 199012456);
    // stack 16
    // --- line 60 ---
    // _ = 199002120;
    // load playerid
    cache_get_row_int(12, 0, 1, 1);
    // stack 16
    // stack 192
    // --- line 65 ---
    cache_delete(8, var_-340, 1);
    // stack 12
    // --- line 67 ---
    // stack 340
    return 1;
}


// AMX 0x63fc0-0x64290
stock UnLoadWeeklyPrizes(playerid)
{
    // --- line 70 ---
    // --- line 72 ---
    // stack -192
    // --- line 74 ---
    // _ = 199002120;
    // load playerid
    // _ = 199002120;
    // load playerid
    // _ = 199002120;
    // load playerid
    // _ = 199002120;
    // load playerid
    // _ = 199002120;
    // load playerid
    // _ = 199002120;
    // load playerid
    // _ = 199002120;
    // load playerid
    format(-192, 48, 199012508);
    // stack 44
    // --- line 83 ---
    // stack -736
    // --- line 85 ---
    // _ = 181530104;
    // load playerid
    // _ = 199002120;
    // load playerid
    mysql_format(166387936, -928, 184, 199012592);
    // stack 32
    // --- line 86 ---
    mysql_query(166387936, -928);
    // stack 16
    // --- line 90 ---
    // stack 928
    return 1;
}


// AMX 0x64290-0x642fc
stock ch_OnPlayerConnect(playerid)
{
    // --- line 95 ---
    // --- line 97 ---
    SetTimerEx(199012872, 2000, 0, 199012940);
    // stack 24
    // --- line 99 ---
    weekly_OnPlayerConnect(4, playerid);
    return 1;
}


// AMX 0x642fc-0x64348
stock name_OnPlayerDisconnect(playerid, reason)
{
    // --- line 114 ---
    // --- line 116 ---
    UnLoadWeeklyPrizes(4, playerid);
    // --- line 118 ---
    weekly_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


// AMX 0x64348-0x643f4
stock ch_OnGameModeInit()
{
    // --- line 133 ---
    // --- line 135 ---
    SetTimer(199012948, 3000, 0);
    // stack 16
    // --- line 136 ---
    SetTimer(199013048, 5000, 1);
    // stack 16
    // --- line 138 ---
    print(199013120);
    // stack 8
    // --- line 141 ---
    weekly_OnGameModeInit(0);
    return 1;
}


// AMX 0x643f4-0x6494c
stock CheckWeeklyPrizes()
{
    // --- line 156 ---
    // --- line 158 ---
    // --- line 160 ---
    getdate(12, -4, -8, -12);
    // stack 16
    // --- line 161 ---
    gettime(12, -16, -20);
    // stack 16
    // --- line 163 ---
    // stack -4
    GetDayOfWeek(12, var_-4, var_-8, var_-12);
    // _ = 1;
    // var_-24 = _;
    // --- line 165 ---
    // load var_-24
    if (!_) goto lbl_0x6453c; // jzer
    // load var_-16
    if (!_) goto lbl_0x6453c; // jzer
    // load var_-20
    if (!_) goto lbl_0x6453c; // jzer
    goto lbl_0x64540; // jump 0x64540
    if (!_) goto lbl_0x6457c; // jzer
    mysql_query(166387936, 199013336);
    // stack 16
    // --- line 167 ---
    // load var_-16
    if (!_) goto lbl_0x645b8; // jzer
    // load var_-20
    if (!_) goto lbl_0x645b8; // jzer
    goto lbl_0x645bc; // jump 0x645bc
    if (!_) goto lbl_0x645f8; // jzer
    mysql_query(166387936, 199013544);
    // stack 16
    // --- line 169 ---
    // --- line 171 ---
    goto lbl_0x6461c; // jump 0x6461c
    // _ = 9816;
    // load var_-32
    // var_-32 = _;
    // _ = 250;
    goto lbl_0x6492c; // jeq 0x6492c
    // --- line 173 ---
    // _ = 199002120;
    // load var_-32
    if (!_) goto lbl_0x6469c; // jzer
    goto lbl_0x64618; // jump 0x64618
    // --- line 175 ---
    // var_-28 = _;
    // --- line 176 ---
    goto lbl_0x646d0; // jump 0x646d0
    // load var_-36
    // _ = 7;
    goto lbl_0x6475c; // jsgeq 0x6475c
    // _ = 199002120;
    // load var_-32
    // load var_-36
    if (!_) goto lbl_0x64754; // jzer
    // load var_-36
    // var_-28 = _;
    goto lbl_0x646c4; // jump 0x646c4
    // stack 4
    // --- line 178 ---
    // load var_-28
    if (!_) goto lbl_0x6478c; // jzer
    goto lbl_0x64618; // jump 0x64618
    // --- line 180 ---
    // _ = 199002120;
    // load var_-32
    if (!_) goto lbl_0x64824; // jzer
    // _ = 181530104;
    // load var_-32
    // _ = 7200;
    goto lbl_0x64824; // jsless 0x64824
    goto lbl_0x64828; // jump 0x64828
    if (!_) goto lbl_0x64924; // jzer
    // --- line 182 ---
    SendClientMessage(var_-32, -1, 199013684);
    // stack 16
    // --- line 183 ---
    // _ = 199002120;
    // load var_-32
    // load var_-28
    // --- line 184 ---
    // _ = 199002120;
    // load var_-32
    // --- line 185 ---
    UnLoadWeeklyPrizes(4, var_-32);
    goto lbl_0x64618; // jump 0x64618
    // stack 4
    // --- line 189 ---
    // stack 28
    return 1;
}


// AMX 0x6494c-0x64c48
stock pc_cmd_everyprize(playerid)
{
    // --- line 192 ---
    // --- line 194 ---
    // stack -1392
    // --- line 196 ---
    // stack -112
    // stack -336
    goto lbl_0x649cc; // jump 0x649cc
    // load var_-1396
    // _ = 7;
    goto lbl_0x64bdc; // jsgeq 0x64bdc
    // --- line 198 ---
    // _ = 199002120;
    // load playerid
    // load var_-1396
    switch (_) // -> 0x64aec
    // --- line 200 ---
    format(-1508, 28, 199014056);
    // stack 16
    goto lbl_0x64b10; // jump 0x64b10
    // --- line 201 ---
    format(-1508, 28, 199014164);
    // stack 16
    goto lbl_0x64b10; // jump 0x64b10
    // --- line 202 ---
    format(-1508, 28, 199014264);
    // stack 16
    goto lbl_0x64b10; // jump 0x64b10
    // casetbl cases=4
    // --- line 206 ---
    // _ = 199001364;
    // load var_-1396
    // load var_-1396
    format(-1844, 84, 199014336);
    // stack 28
    // --- line 207 ---
    strcat(-1392, -1844);
    // stack 16
    goto lbl_0x649c0; // jump 0x649c0
    // stack 452
    // --- line 210 ---
    fg_ShowPlayerDialog(28, playerid, 3882, 2, 199014388, -1392, 199014472, 199014508);
    // --- line 212 ---
    // stack 1392
    return 1;
}


// AMX 0x64c48-0x6580c
stock skin_OnDialogResponse(playerid, dialogid, response, listitem)
{
    // --- line 215 ---
    // --- line 217 ---
    // load dialogid
    if (!_) goto lbl_0x657cc; // jzer
    // --- line 219 ---
    // load response
    if (!_) goto lbl_0x657cc; // jzer
    // --- line 221 ---
    // stack -4
    // load listitem
    // var_-4 = _;
    // --- line 223 ---
    // load var_-4
    if (!_) goto lbl_0x64d7c; // jzer
    // _ = 199002120;
    // load playerid
    // load var_-4
    if (!_) goto lbl_0x64d7c; // jzer
    // _ = 199002120;
    // load playerid
    if (!_) goto lbl_0x64d7c; // jzer
    goto lbl_0x64d80; // jump 0x64d80
    if (!_) goto lbl_0x64dc8; // jzer
    // --- line 224 ---
    SendClientMessage(playerid, -1, 199014532);
    // stack 16
    // stack 4
    return 1;
    // --- line 226 ---
    // load var_-4
    if (!_) goto lbl_0x64ea0; // jzer
    // _ = 199002120;
    // load playerid
    // load var_-4
    if (!_) goto lbl_0x64ea0; // jzer
    // _ = 199002120;
    // load playerid
    if (!_) goto lbl_0x64ea0; // jzer
    goto lbl_0x64ea4; // jump 0x64ea4
    if (!_) goto lbl_0x64eec; // jzer
    // --- line 227 ---
    SendClientMessage(playerid, -1, 199014864);
    // stack 16
    // stack 4
    return 1;
    // --- line 229 ---
    // _ = 199002120;
    // load playerid
    // load var_-4
    if (!_) goto lbl_0x64f88; // jzer
    SendClientMessage(playerid, -1, 199015320);
    // stack 16
    // stack 4
    return 1;
    // --- line 231 ---
    // _ = 199002120;
    // load playerid
    // load var_-4
    switch (_) // -> 0x657a0
    // --- line 233 ---
    SendClientMessage(playerid, -1, 199015600);
    // stack 16
    goto lbl_0x657c4; // jump 0x657c4
    // --- line 236 ---
    // _ = 199001364;
    // load var_-4
    switch (_) // -> 0x655bc
    // --- line 238 ---
    // _ = 199001364;
    // load var_-4
    GivePlayerDonateRub(20, playerid);
    goto lbl_0x655e8; // jump 0x655e8
    // --- line 239 ---
    // _ = 199001364;
    // load var_-4
    GivePlayerMoneyEx(20, playerid);
    goto lbl_0x655e8; // jump 0x655e8
    // --- line 242 ---
    // _ = 181530104;
    // load playerid
    if (!_) goto lbl_0x652ec; // jzer
    // --- line 244 ---
    // _ = 181530104;
    // load playerid
    // --- line 245 ---
    // _ = 181530104;
    // load playerid
    gettime(12);
    // stack 16
    // _ = 199001364;
    // load var_-4
    goto lbl_0x65378; // jump 0x65378
    // --- line 249 ---
    // _ = 181530104;
    // load playerid
    // _ = 199001364;
    // load var_-4
    // --- line 251 ---
    // --- line 255 ---
    // _ = 181530104;
    // load playerid
    timestamp_to_date(28);
    // --- line 257 ---
    UpdatePlayerDatabaseInt(12, playerid, 199015916, 3);
    // --- line 258 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 199015948);
    // stack 12
    goto lbl_0x655e8; // jump 0x655e8
    // --- line 261 ---
    // _ = 181530104;
    // load playerid
    // _ = 199001364;
    // load var_-4
    // --- line 262 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 199016000);
    goto lbl_0x655e8; // jump 0x655e8
    // casetbl cases=5
    // --- line 266 ---
    // stack -576
    // --- line 267 ---
    // _ = 199001364;
    // load var_-4
    format(-580, 144, 199016040);
    // stack 20
    // --- line 268 ---
    SendClientMessage(playerid, -1, -580);
    // stack 16
    // --- line 270 ---
    // _ = 199002120;
    // load playerid
    // load var_-4
    // --- line 271 ---
    // _ = 199002120;
    // load playerid
    // --- line 272 ---
    UnLoadWeeklyPrizes(4, playerid);
    // stack 576
    goto lbl_0x657c4; // jump 0x657c4
    // --- line 275 ---
    SendClientMessage(playerid, -1, 199016376);
    // stack 16
    goto lbl_0x657c4; // jump 0x657c4
    // casetbl cases=4
    // stack 4
    // --- line 280 ---
    weekly_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


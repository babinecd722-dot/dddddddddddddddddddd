stock ClearPlayerCPInfo(playerid)
{
    return 1;
}


stock n_SetPlayerCheckpoint(playerid, size, action_type)
{
    SetPlayerCheckpoint(20, playerid, var_16, var_20, var_24, size);
    return 1;
}


stock n_IsPlayerInCheckpoint(playerid, size)
{
    if (!_) goto lbl_0xd1a0;
    IsPlayerInRangeOfPoint(20, playerid);
    if (!_) goto lbl_0xd1a0;
    return 1;
}


stock n_DisablePlayerCheckpoint(playerid)
{
    if (!_) goto lbl_0xd270;
    DisablePlayerCheckpoint(4, playerid);
    return 1;
}


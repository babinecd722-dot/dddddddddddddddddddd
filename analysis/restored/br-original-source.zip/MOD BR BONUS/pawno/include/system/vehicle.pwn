stock SetVehicleDataAll(vehicleid, modelid, angle, color1, color2, respawn_delay, addsiren, action_type, action_id)
{
    if (!_) goto lbl_0xe738;
    IsABike(4, vehicleid, 0, 0, 0, 0, 0, 0);
    if (!_) goto lbl_0xe710;
    goto lbl_0xe714;
    SetVehicleParamsEx(32, vehicleid);
    return 1;
}


stock n_veh_AddStaticVehicleEx(modelid, angle, color1, color2, respawn_delay, addsiren, action_type, action_id)
{
    Iter_AddStaticVehicleEx(36, modelid, var_16, var_20, var_24, angle, color1, color2, respawn_delay, 0);
    SetVehicleDataAll(48, 1186228, modelid, var_16, var_20, var_24, angle, color1, color2, respawn_delay, addsiren, action_type, action_id);
    return 1;
}


stock n_veh_CreateVehicle(modelid, angle, color1, color2, respawn_delay, addsiren, action_type, action_id)
{
    Iter_CreateVehicle(36, modelid, var_16, var_20, var_24, angle, color1, color2, respawn_delay, 0);
    SetVehicleDataAll(48, 1186232, modelid, var_16, var_20, var_24, angle, color1, color2, respawn_delay, addsiren, action_type, action_id);
    return 1;
}


stock n_veh_DestroyVehicle(vehicleid)
{
    if (!_) goto lbl_0xe9c4;
    DestroyVehicleLabel(4, vehicleid);
    Iter_DestroyVehicle(4, vehicleid);
    return 1;
}


stock n_OnGameModeInit()
{
    goto lbl_0xea0c;
    goto lbl_0xea6c;
    goto lbl_0xea00;
    n_veh_OnGameModeInit(0);
    return 1;
}


stock SetVehicleParamsInit(vehicleid)
{
    GetVehicleParamsEx(32, vehicleid);
    return 1;
}


stock GetVehicleParam(vehicleid, paramid)
{
    SetVehicleParamsInit(4, vehicleid);
    return 1;
}


stock SetVehicleParam(vehicleid, paramid, set_value)
{
    SetVehicleParamsInit(4, vehicleid);
    SetVehicleParamsEx(32, vehicleid);
    return 1;
}


stock CreateVehicleLabel(vehicleid, color, drawdistance, testlos, worldid, interiorid, playerid, streamdistance)
{
    IsValidVehicle(4, vehicleid);
    if (!_) goto lbl_0xefd0;
    CreateDynamic3DTextLabel(60, var_16, color, var_24, var_28, var_32, drawdistance, "	'Ì¹ÏX'", vehicleid, testlos, worldid, interiorid, playerid, streamdistance, -1, 0);
    return 1;
}


stock UpdateVehicleLabel(vehicleid, color)
{
    if (!_) goto lbl_0xf0e0;
    IsValidDynamic3DTextLabel(4);
    if (!_) goto lbl_0xf0e0;
    UpdateDynamic3DTextLabelText(12);
    return 1;
}


stock DestroyVehicleLabel(vehicleid)
{
    if (!_) goto lbl_0xf224;
    IsValidDynamic3DTextLabel(4);
    if (!_) goto lbl_0xf224;
    DestroyDynamic3DTextLabel(4);
    return 1;
}


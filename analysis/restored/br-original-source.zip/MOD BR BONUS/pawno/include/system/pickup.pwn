stock n_CreatePickup(model, type, Virtualworld, action_type, action_id)
{
    CreatePickup(24, model, type, var_20, var_24, var_28, Virtualworld);
    goto lbl_0xdc48;
    CreateDynamicSphere(32, var_20, var_24, var_28, 1068708659, Virtualworld, -1, -1, 0);
    CreateDynamicSphere(32, var_20, var_24, var_28, 1068708659, Virtualworld, -1, -1, 0);
    return 1;
}


stock n_DestroyPickup(pickupid)
{
    if (!_) goto lbl_0xdd34;
    DestroyDynamicArea(4);
    DestroyPickup(4, pickupid);
    return 1;
}


public OnPlayerPickUpPickup(playerid, pickupid)
{
    GetPVarInt(8, playerid, "ù");
    if (!_) goto lbl_0xddb0;
    return 1;
    SetPVarInt(12, playerid, 168116, 1);
    GetTickCount(0);
    goto lbl_0xdf84;
    GetTickCount(0);
    if (!_) goto lbl_0xdf44;
    OnPlayerPickUpPickupEx(16, playerid, pickupid, var_-4, var_-8);
    return 1;
}


stock Iter_OnGameModeInit()
{
    print("\"");
    print(168204);
    print(168360);
    print(168508);
    print("'");
    print("'");
    goto lbl_0xe090;
    goto lbl_0xe0f0;
    goto lbl_0xe084;
    n_OnGameModeInit(0);
    return 1;
}


stock fg_OnPlayerConnect(playerid)
{
    SetPVarInt(12, playerid, "N", 0);
    fixp_OnPlayerConnect(4, playerid);
    return 1;
}


public OnPlayerSpawn(playerid)
{
    SetPVarInt(12, playerid, 168988, 0);
    fixp_OnPlayerSpawn(4, playerid);
    return 1;
}


public OnPlayerLeaveDynamicArea(playerid, areaid)
{
    SetPVarInt(12, playerid, 169068, 0);
    fixp_OnPlayerLeaveDynamicArea(8, playerid, areaid);
    return 1;
}


stock weekly_OnGameModeInit()
{
    printf(4, 199024644);
    HAT_OnGameModeInit(0);
    return 1;
}


stock pc_cmd_spin(playerid)
{
    sscanf(12, var_16, 199024824, -4);
    if (!_) goto lbl_0x658e0;
    SendClientMessage(playerid, -1, 199024832);
    return 1;
    IsPlayerInRangeOfPlayer(12, playerid, var_-4, 1080033280);
    if (!_) goto lbl_0x65958;
    SendClientMessage(playerid, -1, 199025036);
    return 1;
    goto lbl_0x659d8;
    SendClientMessage(playerid, -1, 199025272);
    return 1;
    fg_ShowPlayerDialog(28, playerid, 4374, 1, 199025552, 199025604, 199025948, 199025972);
    return 1;
}


stock pc_cmd_spins(playerid)
{
    if (!_) goto lbl_0x65b00;
    SendClientMessage(playerid, -1, 199025996);
    return 1;
    if (!_) goto lbl_0x65b78;
    SendClientMessage(playerid, -1, 199026204);
    return 1;
    strcmp(var_16, 199026464);
    if (!_) goto lbl_0x65d34;
    goto lbl_0x65c10;
    return 1;
    if (!_) goto lbl_0x65d00;
    StartHAT(8, playerid, var_-4);
    goto lbl_0x65d24;
    StartHAT(8, var_-4, playerid);
    goto lbl_0x65f30;
    strcmp(var_16, 199026480);
    if (!_) goto lbl_0x65efc;
    goto lbl_0x65e14;
    goto lbl_0x65e4c;
    SendClientMessage(var_-4, -1, 199026492);
    SendClientMessage(playerid, -1, 199026740);
    DefaultHAT(4, playerid);
    DefaultHAT(4, var_-4);
    goto lbl_0x65f30;
    SendClientMessage(playerid, -1, 199026980);
    return 1;
}


stock StartHAT(heads, tails)
{
    IsPlayerConnected(heads);
    if (_) goto lbl_0x65fb0;
    IsPlayerConnected(tails);
    if (_) goto lbl_0x65fb0;
    goto lbl_0x65fb8;
    if (!_) goto lbl_0x66070;
    SendClientMessage(heads, -1, 199027176);
    SendClientMessage(tails, -1, 199027388);
    DefaultHAT(4, heads);
    DefaultHAT(4, tails);
    return 1;
    goto lbl_0x66150;
    goto lbl_0x66150;
    goto lbl_0x66158;
    if (!_) goto lbl_0x66218;
    SendClientMessage(heads, -1, 199027600);
    SendClientMessage(tails, -1, 199027792);
    DefaultHAT(4, heads);
    DefaultHAT(4, tails);
    return 1;
    if (!_) goto lbl_0x662e8;
    format(-580, 144, 199027984);
    goto lbl_0x66350;
    format(-580, 144, 199028064);
    SendClientMessage(heads, -577699841, -580);
    SendClientMessage(tails, -577699841, -580);
    format(-580, 144, 199028144);
    format(-580, 144, 199028308);
    SetTimerEx(199028476, 3000, 0, 199028504);
    return 1;
}


stock EndHAT(heads, tails)
{
    IsPlayerConnected(heads);
    if (_) goto lbl_0x665e4;
    IsPlayerConnected(tails);
    if (_) goto lbl_0x665e4;
    goto lbl_0x665ec;
    if (!_) goto lbl_0x666a4;
    SendClientMessage(heads, -1, 199028516);
    SendClientMessage(tails, -1, 199028728);
    DefaultHAT(4, heads);
    DefaultHAT(4, tails);
    return 1;
    random(4, 2);
    if (!_) goto lbl_0x66730;
    goto lbl_0x66758;
    goto lbl_0x66800;
    goto lbl_0x66828;
    goto lbl_0x66858;
    goto lbl_0x66860;
    format(-588, 144, 199028940);
    SendClientMessage(heads, -1, -588);
    SendClientMessage(tails, -1, -588);
    if (!_) goto lbl_0x66a90;
    goto lbl_0x66a28;
    GivePlayerMoneyEx(20, var_-8);
    GivePlayerMoneyEx(20, var_-4, var_-600, 199029208, 1, 1);
    goto lbl_0x66a90;
    SendClientMessage(var_-8, -1, 199029260);
    SendClientMessage(var_-4, -1, 199029436);
    fg_ShowPlayerDialog(28, var_-592, 4377, 2, 199029624, 199029676, 199029888, 199029912);
    return 1;
}


stock DefaultHAT(playerid)
{
    return 1;
}


stock DialogThrowHAT(playerid)
{
    format(-576, 144, 199029936);
    fg_ShowPlayerDialog(28, playerid, 4375, 2, 199030024, -576, 199030076, 199030108);
    return 1;
}


stock DialogRoleHAT(playerid)
{
    format(-576, 144, 199030132);
    fg_ShowPlayerDialog(28, playerid, 4376, 2, 199030300, -576, 199030352, 199030384);
    return 1;
}


stock AcceptHAT(playerid, to_player)
{
    goto lbl_0x670b0;
    SendClientMessage(playerid, -1, 199030408);
    DefaultHAT(4, playerid);
    return 1;
    if (!_) goto lbl_0x67138;
    goto lbl_0x6717c;
    if (!_) goto lbl_0x67210;
    goto lbl_0x67254;
    goto lbl_0x67404;
    format(-748, 42, 199030736);
    format(-580, 144, 199030816);
    SendClientMessage(to_player, -7012097, -580);
    goto lbl_0x67500;
    goto lbl_0x67508;
    format(-580, 144, 199031000);
    SendClientMessage(to_player, -7012097, -580);
    format(-580, 144, 199031068);
    SendClientMessage(playerid, -7012097, -580);
    goto lbl_0x6766c;
    goto lbl_0x67674;
    format(-580, 144, 199031248);
    SendClientMessage(playerid, -7012097, -580);
    SendClientMessage(to_player, -1, 199031316);
    SendClientMessage(playerid, -1, 199031580);
    SendClientMessage(to_player, -1, 199031836);
    SetTimerEx(199032092, 10000, 0, 199032156);
    return 1;
}


stock CancelAcceptHAT(playerid, to_player)
{
    SendClientMessage(to_player, -1, 199032168);
    SendClientMessage(playerid, -1, 199032416);
    DefaultHAT(4, playerid);
    DefaultHAT(4, to_player);
    return 1;
}


stock weekly_OnDialogResponse(playerid, dialogid, response, listitem)
{
    if (!_) goto lbl_0x67c2c;
    if (!_) goto lbl_0x67bc4;
    sscanf(12, var_28, 199032656, -4);
    if (!_) goto lbl_0x679a8;
    SendClientMessage(playerid, -1, 199032664);
    goto lbl_0x67bb4;
    goto lbl_0x67a04;
    SendClientMessage(playerid, -1, 199032904);
    return 1;
    IsPlayerInRangeOfPlayer(12, playerid, var_-8, 1083179008);
    if (!_) goto lbl_0x67ac4;
    SendClientMessage(playerid, -1, 199033240);
    return 1;
    goto lbl_0x67b4c;
    SendClientMessage(playerid, -1, 199033476);
    return 1;
    DialogRoleHAT(4, playerid);
    goto lbl_0x67c2c;
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    if (!_) goto lbl_0x67d9c;
    if (!_) goto lbl_0x67d34;
    if (!_) goto lbl_0x67d00;
    AcceptHAT(8, playerid, var_-4);
    goto lbl_0x67d9c;
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    if (!_) goto lbl_0x67f00;
    if (!_) goto lbl_0x67e98;
    if (!_) goto lbl_0x67e30;
    goto lbl_0x67e74;
    DialogThrowHAT(4, playerid);
    goto lbl_0x67f00;
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    if (!_) goto lbl_0x68030;
    if (!_) goto lbl_0x67fc8;
    if (!_) goto lbl_0x67f6c;
    DialogRoleHAT(4, playerid);
    goto lbl_0x67fc0;
    AcceptHAT(8, playerid);
    goto lbl_0x68030;
    DefaultHAT(4);
    DefaultHAT(4, playerid);
    HAT_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


stock fixp_OnPlayerSpawn(playerid)
{
    DefaultHAT(4, playerid);
    HAT_OnPlayerSpawn(4, playerid);
    return 1;
}


stock AccessoryEdit_DestroyCoordsText(playerid)
{
    GetPVarInt(8, playerid, 199037828);
    if (!_) goto lbl_0x681c4;
    PlayerTextDrawHide(8, playerid);
    PlayerTextDrawDestroy(8, playerid);
    DeletePVar(8, playerid, 199037920);
    return 1;
}


stock AccessoryShop_IsValidIndex(index)
{
    return 1;
}


stock AccessoryShop_GetPriceByIndex(index)
{
    AccessoryShop_IsValidIndex(4, index);
    if (!_) goto lbl_0x68290;
    return 1;
}


stock AccessoryShop_GetModelByIndex(index)
{
    AccessoryShop_IsValidIndex(4, index);
    if (!_) goto lbl_0x68308;
    return 1;
}


stock AccessoryShop_GetInventoryItemB(modelid)
{
    goto lbl_0x68364;
    goto lbl_0x6840c;
    goto lbl_0x68404;
    return 1;
    goto lbl_0x68358;
    Inv11_GetAccItemByModel(4, modelid);
    return 1;
}


stock AccessoryShop_GiveInventoryItem(playerid, index)
{
    AccessoryShop_IsValidIndex(4, index);
    if (!_) goto lbl_0x68470;
    return 1;
    AccessoryShop_GetModelByIndex(4, index);
    AccessoryShop_GetInventoryItemB(4, var_-4);
    goto lbl_0x68534;
    printf(199096528, 12);
    return 1;
    Inventory11_AddItemToDatabase(24, playerid, var_-8, var_-4, 1, 0, 0);
    if (!_) goto lbl_0x685fc;
    printf(199096852, 12);
    return 1;
}


stock CreatePlTDButtonBR(playerid)
{
    CreatePlayerTextDraw(16, playerid, 1134551951, 1136318215, 199097176);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawTextSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    return 1;
}


stock CreateTextDrawButtonBR()
{
    TextDrawCreate(12, 1116340224, 1128923136, 199097220);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1141342208, 1128923136, 199097280);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1131071249, 1136231560, 199097344);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1131442622, 1136656384, 199097428);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1134566510, 1136607445, 199097484);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    return 1;
}


stock HAT_OnPlayerSpawn(playerid)
{
    LoadAccessory(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    name_OnPlayerSpawn(4, playerid);
    return 1;
}


stock AccessoryEditSetMovementLock(playerid, enable)
{
    if (!_) goto lbl_0x696d0;
    GetPlayerPos(playerid, -4);
    SetPVarInt(12, playerid, 199097540, 1);
    SetPVarFloat(12, playerid, 199097604, var_-4);
    SetPVarFloat(12, playerid, 199097664, var_-8);
    SetPVarFloat(12, playerid, 199097724, var_-12);
    SetPlayerVelocity(16, playerid, 0, 0, 0);
    TogglePlayerControllable(8, playerid, 1);
    printf(199097784, 12);
    goto lbl_0x69814;
    DeletePVar(8, playerid, 199098000);
    DeletePVar(8, playerid, 199098064);
    DeletePVar(8, playerid, 199098124);
    DeletePVar(8, playerid, 199098184);
    SetPlayerVelocity(16, playerid, 0, 0, 0);
    TogglePlayerControllable(8, playerid, 1);
    printf(199098244, 12);
    return 1;
}


public OnPlayerUpdate(playerid)
{
    GetPVarInt(8, playerid, 199098380);
    if (!_) goto lbl_0x69b94;
    GetPVarFloat(8, playerid, 199098444);
    GetPVarFloat(8, playerid, 199098504);
    GetPVarFloat(8, playerid, 199098564);
    GetPlayerPos(playerid, -16);
    floatabs(4);
    func_0x2ac(8);
    if (_) goto lbl_0x69b04;
    floatabs(4);
    func_0x2ac(8);
    if (_) goto lbl_0x69b04;
    floatabs(4);
    func_0x2ac(8);
    if (_) goto lbl_0x69b04;
    goto lbl_0x69b0c;
    if (!_) goto lbl_0x69b50;
    SetPlayerPos(playerid, var_-4, var_-8, var_-12);
    SetPlayerVelocity(16, playerid, 0, 0, 0);
    acsedit_OnPlayerUpdate(4, playerid);
    return 1;
}


stock blackjack_OnPlayerClickTextDraw(playerid, clickedid)
{
    goto lbl_0x69db4;
    goto lbl_0x69dac;
    DestroyPlayerObject(8, playerid);
    CreatePlayerObject(36, playerid);
    SetPriceAccesory(8, playerid);
    goto lbl_0x69fb0;
    goto lbl_0x69fa8;
    DestroyPlayerObject(8, playerid);
    CreatePlayerObject(36, playerid);
    SetPriceAccesory(8, playerid);
    goto lbl_0x6a39c;
    DestroyPlayerObject(8, playerid);
    goto lbl_0x6a0a4;
    goto lbl_0x6a108;
    TextDrawHideForPlayer(8, playerid);
    goto lbl_0x6a098;
    PlayerTextDrawHide(8, playerid);
    SetPlayerPosEx(32, playerid, 1130267024, 1146574169, 1095011477, 1094390503, 0, 0, 1);
    DeletePVar(8, playerid, 199098624);
    DeletePVar(8, playerid, 199098696);
    DeletePVar(8, playerid, 199098768);
    DeletePVar(8, playerid, 199098840);
    DeletePVar(8, playerid, 199098912);
    DeletePVar(8, playerid, 199098992);
    CancelSelectTextDraw(4, playerid);
    TogglePlayerControllable(8, playerid, 1);
    ShowHud(4, playerid);
    TogglePlayerHudElement(12, playerid, 0, 1);
    goto lbl_0x6ad1c;
    AccessoryShop_IsValidIndex(4, var_-4);
    if (!_) goto lbl_0x6a470;
    SendClientMessage(playerid, -825307393, 199099068);
    return 1;
    AccessoryShop_GetPriceByIndex(4, var_-4);
    goto lbl_0x6ace0;
    AccessoryShop_GiveInventoryItem(8, playerid, var_-4);
    if (!_) goto lbl_0x6a5c4;
    ShowNotificationNew(28, playerid, 2, 6, 0, 0, 199099180, 199099264);
    return 1;
    random(4, 4);
    goto lbl_0x6a6cc;
    goto lbl_0x6a6cc;
    goto lbl_0x6a6cc;
    goto lbl_0x6a6d0;
    if (!_) goto lbl_0x6a814;
    format(-520, 128, 199099272);
    mysql_query(166387936, -520);
    mysql_errno(1);
    if (!_) goto lbl_0x6acd0;
    goto lbl_0x6a8cc;
    goto lbl_0x6a8cc;
    goto lbl_0x6a8cc;
    goto lbl_0x6a8d0;
    if (!_) goto lbl_0x6a978;
    goto lbl_0x6a9bc;
    goto lbl_0x6a9bc;
    goto lbl_0x6a9c0;
    if (!_) goto lbl_0x6ab94;
    gettime(12);
    mysql_format(166387936, -520, 128, 199099496);
    mysql_query(166387936, -520);
    GivePlayerMoneyEx(20, playerid);
    format(-1044, 128, 199099844);
    ShowNewNotification(28, playerid, 3, 6, 0, 0, -1044, 199099928);
    goto lbl_0x6ad14;
    SendClientMessage(playerid, -1, 199099932);
    goto lbl_0x6b120;
    goto lbl_0x6ad6c;
    goto lbl_0x6add0;
    TextDrawHideForPlayer(8, playerid);
    goto lbl_0x6ad60;
    TogglePlayerHudElement(12, playerid, 0, 1);
    DeletePVar(8, playerid, 199100036);
    DeletePVar(8, playerid, 199100068);
    DeletePVar(8, playerid, 199100132);
    DeletePVar(8, playerid, 199100152);
    DeletePVar(8, playerid, 199100180);
    DeletePVar(8, playerid, 199100200);
    DeletePVar(8, playerid, 199100256);
    DeletePVar(8, playerid, 199100308);
    DeletePVar(8, playerid, 199100376);
    DeletePVar(8, playerid, 199100404);
    DeletePVar(8, playerid, 199100432);
    DeletePVar(8, playerid, 199100460);
    DeletePVar(8, playerid, 199100492);
    DeletePVar(8, playerid, 199100524);
    DeletePVar(8, playerid, 199100556);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CancelSelectTextDraw(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    TogglePlayerAllHudElements(8, playerid, 1);
    goto lbl_0x6d00c;
    goto lbl_0x6b170;
    goto lbl_0x6b1d4;
    TextDrawHideForPlayer(8, playerid);
    goto lbl_0x6b164;
    TogglePlayerHudElement(12, playerid, 0, 1);
    GetPVarInt(8, playerid, 199100600);
    if (!_) goto lbl_0x6b998;
    GetPVarInt(8, playerid, 199100860);
    mysql_format(166387936, -2048, 512, 199100668);
    mysql_query(166387936, -2048);
    GetPVarFloat(8, playerid, 199101672);
    GetPVarFloat(8, playerid, 199101640);
    GetPVarFloat(8, playerid, 199101608);
    GetPVarFloat(8, playerid, 199101576);
    GetPVarFloat(8, playerid, 199101548);
    GetPVarFloat(8, playerid, 199101520);
    GetPVarFloat(8, playerid, 199101492);
    GetPVarInt(8, playerid, 199101472);
    GetPVarInt(8, playerid, 199101420);
    GetPVarInt(8, playerid, 199101400);
    mysql_format(166387936, -2048, 512, 199100880);
    mysql_query(166387936, -2048);
    DeletePVar(8, playerid, 199101716);
    DeletePVar(8, playerid, 199101748);
    DeletePVar(8, playerid, 199101812);
    DeletePVar(8, playerid, 199101832);
    DeletePVar(8, playerid, 199101860);
    DeletePVar(8, playerid, 199101880);
    DeletePVar(8, playerid, 199101936);
    DeletePVar(8, playerid, 199101988);
    DeletePVar(8, playerid, 199102056);
    DeletePVar(8, playerid, 199102084);
    DeletePVar(8, playerid, 199102112);
    DeletePVar(8, playerid, 199102140);
    DeletePVar(8, playerid, 199102172);
    DeletePVar(8, playerid, 199102204);
    DeletePVar(8, playerid, 199102236);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CancelSelectTextDraw(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    TogglePlayerAllHudElements(8, playerid, 1);
    ShowHud(4, playerid);
    SendClientMessage(playerid, -1, 199102280);
    return 1;
    GetPVarInt(8, playerid, 199102392);
    GetPVarFloat(8, playerid, 199103256);
    GetPVarFloat(8, playerid, 199103224);
    GetPVarFloat(8, playerid, 199103192);
    GetPVarFloat(8, playerid, 199103160);
    GetPVarFloat(8, playerid, 199103132);
    GetPVarFloat(8, playerid, 199103104);
    GetPVarFloat(8, playerid, 199103076);
    GetPVarInt(8, playerid, 199103056);
    GetPVarInt(8, playerid, 199103004);
    GetPVarInt(8, playerid, 199102984);
    printf(199102448, 12);
    goto lbl_0x6c0e0;
    GetPVarFloat(8, playerid, 199104256, -2056);
    GetPVarFloat(8, playerid, 199104212);
    GetPVarFloat(8, playerid, 199104168);
    GetPVarFloat(8, playerid, 199104136);
    GetPVarFloat(8, playerid, 199104104);
    GetPVarFloat(8, playerid, 199104072);
    GetPVarFloat(8, playerid, 199104044);
    GetPVarFloat(8, playerid, 199104016);
    GetPVarFloat(8, playerid, 199103988);
    GetPVarInt(8, playerid, 199103968);
    mysql_format(166387936, -2048, 512, 199103300);
    mysql_query(166387936, -2048);
    mysql_errno(1);
    if (!_) goto lbl_0x6c05c;
    mysql_errno(1);
    printf(199104300, 12);
    goto lbl_0x6c0bc;
    printf(199104732, 12);
    LoadPlayerAccessories(4, playerid);
    goto lbl_0x6c57c;
    GetPVarInt(8, playerid, 199105832);
    GetPVarFloat(8, playerid, 199105788);
    GetPVarFloat(8, playerid, 199105756);
    GetPVarFloat(8, playerid, 199105724);
    GetPVarFloat(8, playerid, 199105692);
    GetPVarFloat(8, playerid, 199105664);
    GetPVarFloat(8, playerid, 199105636);
    GetPVarFloat(8, playerid, 199105608);
    GetPVarInt(8, playerid, 199105588);
    GetPVarInt(8, playerid, 199105560);
    format(-2048, 512, 199105040);
    mysql_query(166387936, -2048);
    mysql_errno(1);
    if (!_) goto lbl_0x6c4b8;
    mysql_errno(1);
    GetPVarInt(8, playerid, 199106256);
    printf(199105852, 12);
    goto lbl_0x6c550;
    GetPVarInt(8, playerid, 199106556);
    printf(199106276, 12);
    cache_delete(8, var_-2052, 1);
    GetPVarInt(8, playerid, 199106576);
    goto lbl_0x6c5fc;
    goto lbl_0x6c5fc;
    goto lbl_0x6c604;
    if (!_) goto lbl_0x6c654;
    GetPVarInt(8, playerid, 199106604);
    AccessoryGetIndexByModel(4);
    goto lbl_0x6cc98;
    GetPVarInt(8, playerid, 199106908);
    mysql_format(166387936, -2048, 512, 199106656);
    mysql_query(166387936, -2048);
    mysql_errno(1);
    if (!_) goto lbl_0x6c848;
    mysql_errno(1);
    GetPVarInt(8, playerid, 199107332);
    printf(199106928, 12);
    GetPVarFloat(8, playerid, 199108148);
    GetPVarFloat(8, playerid, 199108116);
    GetPVarFloat(8, playerid, 199108084);
    GetPVarFloat(8, playerid, 199108052);
    GetPVarFloat(8, playerid, 199108024);
    GetPVarFloat(8, playerid, 199107996);
    GetPVarFloat(8, playerid, 199107968);
    GetPVarInt(8, playerid, 199107948, -2060);
    GetPVarInt(8, playerid, 199107928);
    mysql_format(166387936, -2048, 512, 199107352);
    mysql_query(166387936, -2048);
    mysql_errno(1);
    if (!_) goto lbl_0x6cbf8;
    mysql_errno(1);
    GetPVarInt(8, playerid, 199108636, -2060);
    printf(199108192, 12);
    goto lbl_0x6cc98;
    GetPVarInt(8, playerid, 199108972, -2060);
    printf(199108656, 12);
    DeletePVar(8, playerid, 199108992);
    DeletePVar(8, playerid, 199109024);
    DeletePVar(8, playerid, 199109088);
    DeletePVar(8, playerid, 199109108);
    DeletePVar(8, playerid, 199109136);
    DeletePVar(8, playerid, 199109156);
    DeletePVar(8, playerid, 199109212);
    DeletePVar(8, playerid, 199109264);
    DeletePVar(8, playerid, 199109332);
    DeletePVar(8, playerid, 199109360);
    DeletePVar(8, playerid, 199109388);
    DeletePVar(8, playerid, 199109416);
    DeletePVar(8, playerid, 199109448);
    DeletePVar(8, playerid, 199109480);
    DeletePVar(8, playerid, 199109512);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CancelSelectTextDraw(4, playerid);
    AccessoryEditSetMovementLock(8, playerid, 0);
    TogglePlayerAllHudElements(8, playerid, 1);
    SendClientMessage(playerid, -1, 199109556);
    ShowHud(4, playerid);
    goto lbl_0x6d038;
    goto lbl_0x6d0b0;
    goto lbl_0x6d0a8;
    goto lbl_0x6d0b0;
    goto lbl_0x6d02c;
    goto lbl_0x6d6f0;
    GetPVarInt(8, playerid, 199109668);
    goto lbl_0x6d150;
    goto lbl_0x6d150;
    goto lbl_0x6d158;
    if (!_) goto lbl_0x6d174;
    TextDrawHideForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawHideForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    SetPVarInt(12, playerid, 199109732);
    switch (_)
    GetPVarFloat(8, playerid, 199109796);
    goto lbl_0x6d620;
    GetPVarFloat(8, playerid, 199109824);
    goto lbl_0x6d620;
    GetPVarFloat(8, playerid, 199109852);
    goto lbl_0x6d620;
    GetPVarFloat(8, playerid, 199109880);
    goto lbl_0x6d620;
    GetPVarFloat(8, playerid, 199109924);
    goto lbl_0x6d620;
    GetPVarFloat(8, playerid, 199109956);
    goto lbl_0x6d620;
    GetPVarFloat(8, playerid, 199109988);
    goto lbl_0x6d620;
    format(-144, 32, 199110020);
    PlayerTextDrawSetString(12, playerid);
    return 1;
    goto lbl_0x6d758;
    goto lbl_0x6d758;
    goto lbl_0x6d760;
    if (!_) goto lbl_0x6e418;
    goto lbl_0x6d7b0;
    goto lbl_0x6d7b8;
    GetPVarInt(8, playerid, 199110040);
    switch (_)
    GetPVarFloat(8, playerid, 199110132);
    SetPVarFloat(12, playerid, 199110104);
    GetPVarFloat(8, playerid, 199110180);
    format(-140, 32, 199110160);
    goto lbl_0x6e0c8;
    GetPVarFloat(8, playerid, 199110236);
    SetPVarFloat(12, playerid, 199110208);
    GetPVarFloat(8, playerid, 199110284);
    format(-140, 32, 199110264);
    goto lbl_0x6e0c8;
    GetPVarFloat(8, playerid, 199110340);
    SetPVarFloat(12, playerid, 199110312);
    GetPVarFloat(8, playerid, 199110388);
    format(-140, 32, 199110368);
    goto lbl_0x6e0c8;
    GetPVarFloat(8, playerid, 199110460);
    SetPVarFloat(12, playerid, 199110416);
    GetPVarFloat(8, playerid, 199110524);
    format(-140, 32, 199110504);
    goto lbl_0x6e0c8;
    GetPVarFloat(8, playerid, 199110600);
    SetPVarFloat(12, playerid, 199110568);
    GetPVarFloat(8, playerid, 199110652);
    format(-140, 32, 199110632);
    goto lbl_0x6e0c8;
    GetPVarFloat(8, playerid, 199110716);
    SetPVarFloat(12, playerid, 199110684);
    GetPVarFloat(8, playerid, 199110768);
    format(-140, 32, 199110748);
    goto lbl_0x6e0c8;
    GetPVarFloat(8, playerid, 199110832);
    SetPVarFloat(12, playerid, 199110800);
    GetPVarFloat(8, playerid, 199110884);
    format(-140, 32, 199110864);
    goto lbl_0x6e0c8;
    return 1;
    goto lbl_0x6e0c8;
    PlayerTextDrawSetString(12, playerid);
    GetPVarFloat(8, playerid, 199111356, 0, 0);
    GetPVarFloat(8, playerid, 199111312);
    GetPVarFloat(8, playerid, 199111268);
    GetPVarFloat(8, playerid, 199111236);
    GetPVarFloat(8, playerid, 199111204);
    GetPVarFloat(8, playerid, 199111172);
    GetPVarFloat(8, playerid, 199111144);
    GetPVarFloat(8, playerid, 199111116);
    GetPVarFloat(8, playerid, 199111088);
    GetPVarInt(8, playerid, 199111068);
    GetPVarInt(8, playerid, 199110936);
    goto lbl_0x6e35c;
    GetPVarInt(8, playerid, 199110988);
    goto lbl_0x6e3b0;
    GetPVarInt(8, playerid, 199111040);
    GetPVarInt(8, playerid, 199110916);
    SetPlayerAttachedObject(60, playerid);
    return 1;
    btn_OnPlayerClickTextDraw(8, playerid, clickedid);
    return 1;
}


stock HAT_OnGameModeInit()
{
    print(199111400);
    CreateTextDrawButtonBR(0);
    CreateEditAccessoryTD_Accessory(0);
    SetTimer(199111568, "SO", 0);
    acs_OnGameModeInit(0);
    return 1;
}


stock EntryAccessoryMarket(playerid)
{
    GetPlayerPos(playerid, -4);
    GetPlayerFacingAngle(8, playerid, -16);
    SetPVarFloat(12, playerid, 199111668, var_-4);
    SetPVarFloat(12, playerid, 199111740, var_-8);
    SetPVarFloat(12, playerid, 199111812, var_-12);
    SetPVarFloat(12, playerid, 199111884, var_-16);
    GetPlayerInterior(4, playerid);
    SetPVarInt(12, playerid, 199111956);
    GetPlayerVirtualWorld(4, playerid);
    SetPVarInt(12, playerid, 199112036);
    SetPlayerPosEx(32, playerid, 1161103814, 1153106476, 1159476608, 1135706604, 1);
    HideHud(4, playerid);
    TogglePlayerControllable(8, playerid, 0);
    goto lbl_0x6e7e0;
    goto lbl_0x6e834;
    SendClientMessage(playerid, -1, 199112112);
    goto lbl_0x6e7d4;
    TogglePlayerHudElement(12, playerid, 0, 0);
    InterpolateCameraPos(36, playerid, 1161125690, 1153123327, 1159476608, 1161119543, 1153140496, 1159476690, 2000, 1);
    InterpolateCameraLookAt(36, playerid, 1161133012, 1153131819, 1159476608, 1161114030, 1153166428, 1159477504, 2000, 1);
    CreatePlayerObject(36, playerid);
    CreatePlTDButtonBR(4, playerid);
    SetPriceAccesory(8, playerid, 0);
    TogglePlayerControllable(8, playerid, 0);
    SelectTextDraw(8, playerid, -11382017);
    goto lbl_0x6ea88;
    goto lbl_0x6eaec;
    TextDrawShowForPlayer(8, playerid);
    goto lbl_0x6ea7c;
    PlayerTextDrawShow(8, playerid);
    GetPlayerCameraPos(16, playerid, -20, -24, -28);
    TogglePlayerControllable(8, playerid, 0);
    return 1;
}


stock SetPriceAccesory(playerid, acs)
{
    AccessoryShop_IsValidIndex(4, acs);
    if (!_) goto lbl_0x6ec3c;
    return 1;
    AccessoryShop_GetPriceByIndex(4, acs, -156, 15);
    ConvertMoney(12);
    format(-96, 24, 199112116);
    PlayerTextDrawSetString(12, playerid);
    return 1;
}


stock pc_cmd_testacs(playerid)
{
    mysql_format(166387936, -512, 128, 199112140);
    mysql_query(166387936, -512);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x6efbc;
    cache_delete(8, var_-516, 1);
    mysql_format(166387936, -512, 128, 199112444);
    mysql_query(166387936, -512);
    SendClientMessage(playerid, 1724671743, 199112716);
    goto lbl_0x6f01c;
    cache_delete(8, var_-516, 1);
    SendClientMessage(playerid, -825307393, 199112892);
    AccessoryShowInventory(4, playerid);
    return 1;
}


stock pc_cmd_myacs(playerid)
{
    AccessoryShowInventory(4, playerid);
    return 1;
}


stock AccessoryShowInventory(playerid)
{
    mysql_format(166387936, -16384, 4096, 199113068);
    mysql_query(166387936, -16384);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x6f258;
    SendClientMessage(playerid, -1717986817, 199113288);
    ShowNewNotification(28, playerid, 2, 6, 0, 0, 199113388, 199113488);
    cache_delete(8, var_-16388, 1);
    return 1;
    format(-16384, 4096, 199113492);
    goto lbl_0x6f300;
    goto lbl_0x6f650;
    cache_get_field_content_int(var_-17332, 199113552, 1);
    cache_get_field_content_int(var_-17332, 199113564, 1);
    cache_get_field_content_int(var_-17332, 199113592, 1);
    if (!_) goto lbl_0x6f41c;
    goto lbl_0x6f2f4;
    goto lbl_0x6f474;
    format(-17324, 70, 199113608);
    goto lbl_0x6f4a8;
    format(-17324, 70, 199113692);
    format(-17036, 160, 199113780);
    strcat(-16384, -17036);
    format(-17036, 160, 199113884);
    SetPVarInt(12, playerid, -17036, var_-17044);
    goto lbl_0x6f2f4;
    if (!_) goto lbl_0x6f6e8;
    SendClientMessage(playerid, -825307393, 199113920);
    cache_delete(8, var_-16388, 1);
    return 1;
    Dialog(28, playerid, 1190, 5, 199114084, -16384, 199114284, 199114312);
    cache_delete(8, var_-16388, 1);
    return 1;
}


stock HAT_OnDialogResponse(playerid, dialogid, response, listitem)
{
    if (!_) goto lbl_0x6f9e0;
    if (!_) goto lbl_0x6f9e0;
    SetPVarInt(12, playerid, 199114336, var_-4);
    format(-100, 24, 199114380);
    GetPVarInt(8, playerid, -100);
    if (!_) goto lbl_0x6f958;
    Dialog(28, playerid, 1191, 5, 199114416, 199114652, 199115500, 199115532);
    SetPVarInt(12, playerid, 199115564, 0);
    goto lbl_0x6f9d8;
    Dialog(28, playerid, 1191, 5, 199115596, 199115832, 199116412, 199116444);
    SetPVarInt(12, playerid, 199116476, 1);
    if (!_) goto lbl_0x6fbd8;
    if (!_) goto lbl_0x6fbd8;
    GetPVarInt(8, playerid, 199116508);
    GetPVarInt(8, playerid, 199116552);
    if (!_) goto lbl_0x6fb48;
    switch (_)
    UseAccessory(8, playerid, var_-4);
    goto lbl_0x6fb40;
    SellAccessory(8, playerid, var_-4);
    goto lbl_0x6fb40;
    DeleteAccessory(8, playerid, var_-4);
    goto lbl_0x6fb40;
    goto lbl_0x6fbd0;
    switch (_)
    TakeOffAccessory(8, playerid, var_-4);
    goto lbl_0x6fbd0;
    EditAccessory(8, playerid, var_-4);
    goto lbl_0x6fbd0;
    if (!_) goto lbl_0x6fee4;
    if (!_) goto lbl_0x6fee4;
    sscanf(16, var_28, 199116584, -4, -8);
    if (!_) goto lbl_0x6fca0;
    SendClientMessage(playerid, -1, 199116612);
    return 1;
    goto lbl_0x6fd34;
    if (_) goto lbl_0x6fd34;
    IsPlayerConnected(var_-4);
    if (_) goto lbl_0x6fd34;
    goto lbl_0x6fd3c;
    if (!_) goto lbl_0x6fd84;
    SendClientMessage(playerid, -1, 199116732);
    return 1;
    goto lbl_0x6fdc4;
    goto lbl_0x6fdc4;
    goto lbl_0x6fdcc;
    if (!_) goto lbl_0x6fe14;
    SendClientMessage(playerid, -1, 199116852);
    return 1;
    GetPVarInt(8, playerid, 199117108);
    SetPVarInt(12, playerid, 199117024);
    SetPVarInt(12, playerid, 199117152, var_-8);
    SendPlayerOffer(20, playerid, var_-4, 25, 0, 0);
    acs_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


stock UseAccessory(playerid, database)
{
    mysql_format(166387936, -880, 220, 199117228);
    mysql_query(166387936, -880);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x700a8;
    cache_delete(8, var_-884, 1);
    SendClientMessage(playerid, -1, 199117548);
    return 1;
    cache_get_field_content_int(0, 199117664, 1);
    cache_delete(8, var_-884, 1);
    if (!_) goto lbl_0x701a8;
    SendClientMessage(playerid, -1, 199117692);
    return 1;
    switch (_)
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    goto lbl_0x703ec;
    if (!_) goto lbl_0x70454;
    SendClientMessage(playerid, -1, 199117820);
    return 1;
    mysql_format(166387936, -880, 220, 199118020);
    mysql_query(166387936, -880);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x70754;
    cache_get_field_content_int(0, 199118348, 1);
    cache_delete(8, var_-884, 1);
    mysql_format(166387936, -880, 220, 199118376);
    mysql_query(166387936, -880);
    mysql_format(166387936, -880, 220, 199118644);
    mysql_query(166387936, -880);
    IsPlayerAttachedObjectSlotUsed(8, playerid, var_-896);
    if (!_) goto lbl_0x70744;
    RemovePlayerAttachedObject(8, playerid, var_-896);
    goto lbl_0x70780;
    cache_delete(8, var_-884, 1);
    mysql_format(166387936, -880, 220, 199118956);
    mysql_query(166387936, -880);
    mysql_format(166387936, -880, 220, 199119284);
    mysql_query(166387936, -880);
    mysql_format(166387936, -880, 220, 199119532);
    mysql_query(166387936, -880);
    SetPlayerAttachedObject(60, playerid, var_-896);
    SendClientMessage(playerid, -1, 199119760);
    return 1;
}


stock TakeOffAccessory(playerid, database)
{
    mysql_format(166387936, -740, 184, 199119872);
    mysql_query(166387936, -740);
    cache_get_field_content_int(0, 199120064, 1);
    cache_delete(8, var_-744, 1);
    mysql_errno(1);
    if (!_) goto lbl_0x70e98;
    mysql_format(166387936, -740, 184, 199120092);
    mysql_query(166387936, -740);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x70cbc;
    cache_get_row_int(12, 0, 0, 1);
    cache_delete(8, var_-744, 1);
    mysql_format(166387936, -740, 184, 199120388);
    mysql_query(166387936, -740);
    mysql_format(166387936, -740, 184, 199120664);
    mysql_query(166387936, -740);
    goto lbl_0x70e98;
    RemovePlayerAttachedObject(8, playerid, var_-4);
    ShowNewNotification(28, playerid, 3, 6, 0, 0, 199120884, 199120944);
    return 1;
}


stock SellAccessory(playerid, database)
{
    mysql_format(166387936, -496, 124, 199120948);
    mysql_query(166387936, -496);
    cache_get_row_int(12, 0, 0, 1);
    SetPVarInt(12, playerid, 199121160);
    cache_delete(8, var_-500, 1);
    Dialog(28, playerid, 1192, 1, 199121188, 199121280, 199121724, 199121748);
    return 1;
}


stock DeleteAccessory(playerid, database)
{
    mysql_format(166387936, -496, 124, 199121772);
    mysql_query(166387936, -496);
    mysql_errno(1);
    if (!_) goto lbl_0x71164;
    SendClientMessage(playerid, -1, 199121956);
    goto lbl_0x71198;
    SendClientMessage(playerid, -1, 199122028);
    return 1;
}


stock EditAccessory(playerid, database)
{
    goto lbl_0x71208;
    goto lbl_0x7125c;
    SendClientMessage(playerid, -1, 199122144);
    goto lbl_0x711fc;
    TogglePlayerHudElement(12, playerid, 0, 0);
    format(-880, 220, 199122148);
    mysql_query(166387936, -880);
    cache_get_row_int(12, 0, 0, 1);
    cache_delete(8, var_-888, 1);
    format(-880, 220, 199122352);
    mysql_query(166387936, -880);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x72278;
    cache_get_field_content_int(0, 199122620, 1);
    cache_get_field_content_int(0, 199122640, 1);
    cache_get_field_content_float(12, 0, 199122660, 1);
    cache_get_field_content_float(12, 0, 199122668, 1);
    cache_get_field_content_float(12, 0, 199122676, 1);
    cache_get_field_content_float(12, 0, 199122684, 1);
    cache_get_field_content_float(12, 0, 199122696, 1);
    cache_get_field_content_float(12, 0, 199122708, 1);
    cache_get_field_content_float(12, 0, 199122720, 1);
    SetPVarInt(12, playerid, 199122744, var_-900);
    SetPVarInt(12, playerid, 199122764, var_-892);
    DeletePVar(8, playerid, 199122792);
    SetPVarInt(12, playerid, 199122848);
    SetPVarInt(12, playerid, 199122900, var_-896);
    SetPVarFloat(12, playerid, 199122920, var_-908);
    SetPVarFloat(12, playerid, 199122948, var_-912);
    SetPVarFloat(12, playerid, 199122976, var_-904);
    SetPVarFloat(12, playerid, 199123004, var_-916);
    SetPVarFloat(12, playerid, 199123036, var_-920);
    SetPVarFloat(12, playerid, 199123068, var_-924);
    SetPVarFloat(12, playerid, 199123100, var_-928);
    RemovePlayerAttachedObject(8, playerid, var_-900);
    GetPVarFloat(8, playerid, 199123584, 0, 0);
    GetPVarFloat(8, playerid, 199123540);
    GetPVarFloat(8, playerid, 199123496);
    GetPVarFloat(8, playerid, 199123464);
    GetPVarFloat(8, playerid, 199123432);
    GetPVarFloat(8, playerid, 199123400);
    GetPVarFloat(8, playerid, 199123372);
    GetPVarFloat(8, playerid, 199123344);
    GetPVarFloat(8, playerid, 199123316);
    GetPVarInt(8, playerid, 199123296);
    GetPVarInt(8, playerid, 199123164);
    goto lbl_0x71b94;
    GetPVarInt(8, playerid, 199123216);
    goto lbl_0x71be8;
    GetPVarInt(8, playerid, 199123268);
    GetPVarInt(8, playerid, 199123144);
    SetPlayerAttachedObject(60, playerid);
    HideHud(4, playerid);
    SelectTextDraw(8, playerid, -11382017);
    goto lbl_0x71ca0;
    goto lbl_0x71d04;
    TextDrawShowForPlayer(8, playerid);
    goto lbl_0x71c94;
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    TextDrawShowForPlayer(8, playerid);
    GetPVarFloat(8, playerid, 199123640);
    format(-1000, 18, 199123628);
    AccessoryEdit_DestroyCoordsText(4, playerid);
    CreatePlayerTextDraw(16, playerid, 1141004691, 1133671213, -1000);
    PlayerTextDrawLetterSize(16, playerid);
    PlayerTextDrawAlignment(12, playerid);
    PlayerTextDrawColor(12, playerid);
    PlayerTextDrawBackgroundColor(12, playerid);
    PlayerTextDrawFont(12, playerid);
    PlayerTextDrawSetProportional(12, playerid);
    PlayerTextDrawSetShadow(12, playerid);
    PlayerTextDrawShow(8, playerid);
    SetPVarInt(12, playerid, 199123668, 1);
    SetPVarInt(12, playerid, 199123760, 1);
    TogglePlayerAllHudElements(8, playerid, 0);
    AccessoryEditSetMovementLock(8, playerid, 1);
    cache_delete(8, var_-888, 1);
    return 1;
}


stock AccessoryGetIndexByModel(modelid)
{
    goto lbl_0x722dc;
    goto lbl_0x72358;
    goto lbl_0x72350;
    return 1;
    goto lbl_0x722d0;
    return 1;
}


stock LoadAccessory(playerid)
{
    format(-880, 220, 199123824);
    mysql_query(166387936, -880);
    cache_get_row_count(4, 1);
    printf(199124040, 12);
    if (!_) goto lbl_0x72928;
    goto lbl_0x72558;
    goto lbl_0x72918;
    cache_get_field_content_int(var_-932, 199124308, 1);
    cache_get_field_content_int(var_-932, 199124328, 1);
    cache_get_field_content_int(var_-932, 199124356, 1);
    cache_get_field_content_float(12, var_-932, 199124376, 1);
    cache_get_field_content_float(12, var_-932, 199124384, 1);
    cache_get_field_content_float(12, var_-932, 199124392, 1);
    cache_get_field_content_float(12, var_-932, 199124400, 1);
    cache_get_field_content_float(12, var_-932, 199124412, 1);
    cache_get_field_content_float(12, var_-932, 199124424, 1);
    cache_get_field_content_float(12, var_-932, 199124436, 1);
    SetPlayerAttachedObject(60, playerid, var_-892);
    printf(199124460, -932);
    goto lbl_0x7254c;
    cache_delete(8, var_-888, 1);
    return 1;
}


stock CreateEditAccessoryTD_Accessory()
{
    TextDrawCreate(12, 1108082688, 1099956224, 199124964);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1142292480, 1036831949, 199125020);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1138917376, 1135706112, 199125088);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1115815936, 199125144);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1121714176, 199125192);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1125842944, 199125240);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1128792064, 199125288);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1131741184, 199125336);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1133576192, 199125384);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1135050752, 199125432);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1108082688, 1115815936, 199125480);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1121714176, 199125528);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1125842944, 199125576);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1128792064, 199125624);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1131741184, 199125672);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1133576192, 199125720);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1108082688, 1135050752, 199125768);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125816);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125864);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125912);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199125960);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199126008);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199126056);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1138163712, 1120403456, 199126104);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawCreate(12, 1139146752, 1129119744, 199126152);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    TextDrawCreate(12, 1141145600, 1129119744, 199126216);
    TextDrawTextSize(12);
    TextDrawAlignment(8);
    TextDrawColor(8);
    TextDrawBackgroundColor(8);
    TextDrawFont(8);
    TextDrawSetProportional(8);
    TextDrawSetShadow(8);
    TextDrawSetSelectable(8);
    return 1;
}


stock CREATE_TABLIST_ACCESSORY()
{
    mysql_query(166387936, 199126280);
    mysql_errno(1);
    if (!_) goto lbl_0x75870;
    mysql_query(166387936, 199126416);
    mysql_errno(1);
    if (!_) goto lbl_0x75870;
    printf(4, 199128260);
    return 1;
    mysql_query(166387936, 199128416);
    mysql_errno(1);
    if (!_) goto lbl_0x75958;
    mysql_query(166387936, 199128552);
    mysql_errno(1);
    if (!_) goto lbl_0x75958;
    printf(4, 199129276);
    return 1;
}


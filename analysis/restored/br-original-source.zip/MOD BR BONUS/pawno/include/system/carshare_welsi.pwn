stock prom_OnPlayerConnect(playerid)
{
    car_OnPlayerConnect(4, playerid);
    return 1;
}


stock prom_OnPlayerDisconnect(playerid, reason)
{
    goto lbl_0x5b0b0;
    DeleteCarShareVehicle(4, playerid);
    car_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock prom_OnGameModeInit()
{
    print(197989672);
    car_OnGameModeInit(0);
    return 1;
}


stock prom_OnDialogResponse(playerid, dialogid, response, listitem)
{
    if (!_) goto lbl_0x5b1d4;
    if (!_) goto lbl_0x5b1d4;
    switch (_)
    DeleteCarShareVehicle(4, playerid);
    SendClientMessage(playerid, -1, 197989852);
    goto lbl_0x5b1d4;
    if (!_) goto lbl_0x5bb00;
    if (!_) goto lbl_0x5bb00;
    if (_) goto lbl_0x5b244;
    if (_) goto lbl_0x5b244;
    goto lbl_0x5b24c;
    if (!_) goto lbl_0x5b79c;
    if (!_) goto lbl_0x5b2d8;
    GetPVarInt(8, playerid, 197990204);
    SetPVarInt(12, playerid, 197990124);
    goto lbl_0x5b358;
    if (!_) goto lbl_0x5b358;
    GetPVarInt(8, playerid, 197990364);
    SetPVarInt(12, playerid, 197990284);
    GetPVarInt(8, playerid, 197990444);
    goto lbl_0x5b458;
    goto lbl_0x5b698;
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    format(-524, 128, 197990684);
    strcat(-5844, -524);
    goto lbl_0x5b44c;
    goto lbl_0x5b6f0;
    strcat(-5844, 197990856);
    goto lbl_0x5b740;
    strcat(-5844, 197990968);
    DialogCarShare(28, playerid, 2311, 5, 197991084, -5844, 197991124, 197991148);
    goto lbl_0x5bb00;
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    format(-344, 84, 197991172);
    format(-840, 124, 197991252);
    Dialog(28, playerid, 2313, 2, -344, -840, 197991672, 197991696);
    SetPVarInt(12, playerid, 197991720, var_-4);
    if (!_) goto lbl_0x5c5a8;
    if (!_) goto lbl_0x5c5a8;
    switch (_)
    goto lbl_0x5bc18;
    goto lbl_0x5bc18;
    goto lbl_0x5bc18;
    goto lbl_0x5bc18;
    goto lbl_0x5bc18;
    GetPVarInt(8, playerid, 197991760);
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    goto lbl_0x5bf58;
    GivePlayerMoneyEx(20, playerid);
    format(-748, 184, 197991800);
    SendClientMessage(playerid, -1, -748);
    GivePlayerMoneyEx(20, playerid);
    goto lbl_0x5bfa4;
    SendClientMessage(playerid, -1, 197992216);
    return 1;
    SetTimerEx(20, 197992436);
    GetPlayerDistanceFromPoint(16, playerid);
    goto lbl_0x5c0e4;
    goto lbl_0x5c234;
    GetPlayerDistanceFromPoint(16, playerid);
    func_0x358(8);
    if (!_) goto lbl_0x5c22c;
    goto lbl_0x5c0d8;
    n_veh_CreateVehicle(44);
    format(-1276, 124, 197992480);
    CreateVehicleLabel(48);
    EnablePlayerGPS(24, playerid, 1, var_-768, var_-772, var_-776, 197992732);
    if (!_) goto lbl_0x5cb0c;
    if (!_) goto lbl_0x5caf0;
    switch (_)
    goto lbl_0x5c6c0;
    goto lbl_0x5c6c0;
    goto lbl_0x5c6c0;
    goto lbl_0x5c6c0;
    goto lbl_0x5c6c0;
    GetPVarInt(8, playerid, 197992912);
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    goto lbl_0x5c9dc;
    GivePlayerMoneyEx(20, playerid);
    format(-744, 184, 197992952);
    SendClientMessage(playerid, -1, -744);
    GivePlayerMoneyEx(20, playerid);
    goto lbl_0x5ca44;
    SendClientMessage(playerid, -1, 197993368);
    DeleteCarShareVehicle(4, playerid);
    return 1;
    SetTimerEx(20, 197993588);
    goto lbl_0x5cb0c;
    DeleteCarShareVehicle(4, playerid);
    car_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


stock pc_cmd_arendacar(playerid)
{
    goto lbl_0x5cbc0;
    goto lbl_0x5cbc0;
    goto lbl_0x5cbc4;
    if (!_) goto lbl_0x5cc20;
    Dialog(28, playerid, 2310, 2, 197993632, 197993672, 197993788, 197993812);
    goto lbl_0x5cf94;
    goto lbl_0x5cc9c;
    goto lbl_0x5ced0;
    func_0x2c(8);
    func_0x80(8);
    floatround(8);
    format(-516, 128, 197993996);
    strcat(-5836, -516);
    goto lbl_0x5cc90;
    strcat(-5836, 197994164);
    SetPVarInt(12, playerid, 197994276, 1);
    DialogCarShare(28, playerid, 2311, 5, 197994356, -5836, 197994396, 197994420);
    return 1;
}


stock DialogCarShare(playerid, dialogid, style)
{
    if (!_) goto lbl_0x5d00c;
    fg_ShowPlayerDialog(28, playerid, 0, 2, 197994444, 197994460, 197994476, 197994492);
    fg_ShowPlayerDialog(28, playerid, dialogid, style, var_24, var_28, var_32, var_36);
    return 1;
}


stock CarShare(playerid)
{
    if (_) goto lbl_0x5d0d8;
    if (_) goto lbl_0x5d0d8;
    goto lbl_0x5d0e0;
    if (!_) goto lbl_0x5d0f8;
    return 1;
    SendClientMessage(playerid, -1, 197994496);
    Dialog(28, playerid, 2312, 2, 197994688, 197994728, 197995144, 197995168);
    return 1;
}


stock DeleteCarShareVehicle(playerid)
{
    DestroyVehicleLabel(4);
    n_veh_DestroyVehicle(4);
    return 1;
}


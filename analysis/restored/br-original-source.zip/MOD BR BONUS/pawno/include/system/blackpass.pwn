stock BlackPass_LogEvent(playerid, reward_id, reward_type, reward_value, amount, extra)
{
    IsPlayerConnected(playerid);
    if (_) goto lbl_0x3556dc;
    if (_) goto lbl_0x3556dc;
    goto lbl_0x3556e4;
    if (!_) goto lbl_0x3556f8;
    return 1;
    mysql_format(166387936, -2048, 512, 229801760);
    mysql_query(166387936, -2048);
    return 1;
}


stock BlackPass_ResetPlayer(playerid)
{
    goto lbl_0x355a44;
    goto lbl_0x355b0c;
    goto lbl_0x355a38;
    goto lbl_0x355c3c;
    goto lbl_0x356080;
    BlackPass_FindTaskDefIndex(4, var_-8);
    if (!_) goto lbl_0x355e2c;
    goto lbl_0x355e1c;
    goto lbl_0x355e24;
    goto lbl_0x355e60;
    goto lbl_0x355c30;
    return 1;
}


stock BlackPass_GetLevelFromExperienc(experience)
{
    goto lbl_0x356100;
    goto lbl_0x356130;
    return 1;
}


stock BlackPass_GetMaxExperience()
{
    return 1;
}


stock BlackPass_BuildClaimFlagsString(playerid, is_premium, output_len)
{
    goto lbl_0x3561a0;
    goto lbl_0x35631c;
    if (!_) goto lbl_0x356248;
    goto lbl_0x356290;
    if (!_) goto lbl_0x3562a8;
    goto lbl_0x3562b0;
    strcat(var_20, -12);
    goto lbl_0x356194;
    return 1;
}


stock BlackPass_ParseClaimFlagsString(playerid, is_premium)
{
    goto lbl_0x35635c;
    goto lbl_0x3564fc;
    strlen(var_20);
    goto lbl_0x356414;
    if (!_) goto lbl_0x356414;
    goto lbl_0x356418;
    if (!_) goto lbl_0x356494;
    goto lbl_0x3564ec;
    goto lbl_0x356350;
    return 1;
}


stock BlackPass_GetCurrentLevel(playerid)
{
    BlackPass_GetLevelFromExperienc(4);
    return 1;
}


stock BlackPass_GetClientPremiumStatu(status)
{
    switch (_)
    return 1;
    goto lbl_0x356648;
    return 1;
    goto lbl_0x356648;
    return 1;
}


stock BlackPass_GetRewardInventoryIte(level, is_premium)
{
    if (!_) goto lbl_0x356680;
    goto lbl_0x356688;
    return 1;
}


stock BlackPass_GetDeluxeInventoryIte(index)
{
    return 1;
}


stock BlackPass_IsRewardInventoryItem(itemid)
{
    goto lbl_0x356704;
    goto lbl_0x356704;
    goto lbl_0x356708;
    if (!_) goto lbl_0x356720;
    return 1;
    goto lbl_0x356764;
    goto lbl_0x356764;
    goto lbl_0x356768;
    if (!_) goto lbl_0x356780;
    return 1;
    goto lbl_0x3567c4;
    goto lbl_0x3567c4;
    goto lbl_0x3567c8;
    if (!_) goto lbl_0x3567e0;
    return 1;
}


stock BlackPass_GetRewardInventoryDat(itemid, name_len)
{
    goto lbl_0x3568a0;
    goto lbl_0x3568a0;
    goto lbl_0x3568a4;
    if (!_) goto lbl_0x356ad0;
    if (!_) goto lbl_0x356abc;
    format(var_16, name_len, 229802448);
    return 1;
    goto lbl_0x356b14;
    goto lbl_0x356b14;
    goto lbl_0x356b18;
    if (!_) goto lbl_0x356d44;
    if (!_) goto lbl_0x356d30;
    format(var_16, name_len, 229802460);
    return 1;
    goto lbl_0x356d88;
    goto lbl_0x356d88;
    goto lbl_0x356d8c;
    if (!_) goto lbl_0x356fac;
    if (!_) goto lbl_0x356fa4;
    format(var_16, name_len, 229802472);
    return 1;
}


stock BlackPass_HasQueuedReward(playerid, itemid)
{
    goto lbl_0x356fe0;
    goto lbl_0x357128;
    if (!_) goto lbl_0x3570fc;
    goto lbl_0x3570fc;
    goto lbl_0x357100;
    if (!_) goto lbl_0x357120;
    return 1;
    goto lbl_0x356fd4;
    return 1;
}


stock BlackPass_QueueInventoryReward(playerid, itemid)
{
    BlackPass_IsRewardInventoryItem(4, itemid);
    if (!_) goto lbl_0x357178;
    return 1;
    BlackPass_HasQueuedReward(8, playerid, itemid);
    if (!_) goto lbl_0x3571b4;
    return 1;
    goto lbl_0x357224;
    printf(229802484, 12);
    return 1;
    printf(229802744, 12);
    SavePlayerCaseRewardDB(16, playerid, 99, itemid, 0);
    return 1;
}


stock BlackPass_QueueLevelReward(playerid, level, is_premium)
{
    goto lbl_0x357488;
    goto lbl_0x357488;
    goto lbl_0x357490;
    if (!_) goto lbl_0x3574a4;
    return 1;
    BlackPass_GetRewardInventoryIte(8, level, is_premium);
    BlackPass_QueueInventoryReward(8, playerid);
    return 1;
}


stock BlackPass_QueueDeluxeRewards(playerid, skip_level_reward)
{
    goto lbl_0x357510;
    goto lbl_0x3575bc;
    if (!_) goto lbl_0x357564;
    if (!_) goto lbl_0x357564;
    goto lbl_0x357568;
    if (!_) goto lbl_0x35757c;
    goto lbl_0x357504;
    BlackPass_GetDeluxeInventoryIte(4, var_-4);
    BlackPass_QueueInventoryReward(8, playerid);
    goto lbl_0x357504;
    return 1;
}


stock BlackPass_ShowLootNotification(playerid)
{
    ShowClientNotification(24, playerid, 3, 3, 0, 0, var_16);
    return 1;
}


stock BlackPass_SendLayoutPacket(playerid, layout_id)
{
    JSON_Object(0);
    BlackPass_SendMainPacket(12, playerid, var_-4, layout_id);
    JSON_Cleanup(8, var_-4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendStateRefresh(playerid, current_layout, visible_layout)
{
    JSON_Object(0);
    BlackPass_FillBasePacket(8, playerid, var_-4);
    JSON_SetInt(var_-4, 229802924, -1);
    JSON_SetInt(var_-4, 229802932, -1);
    JSON_SetInt(var_-4, 229802944, visible_layout);
    JSON_SetInt(var_-4, 229802956);
    JSON_SetInt(var_-4, 229802968);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(var_-4, 229802980);
    JSON_SetInt(var_-4, 229802988);
    JSON_SetInt(var_-4, 229803000);
    JSON_SetInt(var_-4, 229803008, current_layout);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x357ab0;
    goto lbl_0x357ab8;
    JSON_SetInt(var_-4, 229803020);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x357b54;
    goto lbl_0x357b5c;
    JSON_SetInt(var_-4, 229803032);
    OnPacketIncoming(12, playerid, 22, var_-4);
    JSON_Cleanup(8, var_-4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_AutoClaimRewardsRange(playerid, start_level, end_level, claim_standard, claim_premium)
{
    goto lbl_0x357c5c;
    goto lbl_0x357c8c;
    goto lbl_0x357cb4;
    return 1;
    goto lbl_0x357ce4;
    goto lbl_0x357f14;
    if (!_) goto lbl_0x357d74;
    if (!_) goto lbl_0x357d74;
    goto lbl_0x357d78;
    if (!_) goto lbl_0x357e04;
    BlackPass_QueueLevelReward(12, playerid, var_-4, 0);
    if (!_) goto lbl_0x357e7c;
    if (!_) goto lbl_0x357e7c;
    goto lbl_0x357e80;
    if (!_) goto lbl_0x357f0c;
    BlackPass_QueueLevelReward(12, playerid, var_-4, 1);
    goto lbl_0x357cd8;
    return 1;
}


stock BlackPass_GrantExperience(playerid, experience)
{
    if (!_) goto lbl_0x357fa4;
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x357fa4;
    return 1;
    goto lbl_0x35807c;
    BlackPass_GetMaxExperience(0);
    goto lbl_0x358124;
    BlackPass_GetMaxExperience(0);
    BlackPass_GetLevelFromExperienc(4);
    BlackPass_SavePlayer(4, playerid);
    return 1;
}


stock BlackPass_SetLevelWithReset(playerid, target_level)
{
    if (!_) goto lbl_0x358250;
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x358250;
    return 1;
    goto lbl_0x358280;
    goto lbl_0x3582b0;
    BlackPass_SavePlayer(4, playerid);
    return 1;
}


stock BlackPass_AddLevelsWithReset(playerid, levels_to_add)
{
    goto lbl_0x3583c0;
    BlackPass_GetCurrentLevel(4, playerid);
    return 1;
    BlackPass_GetCurrentLevel(4, playerid);
    goto lbl_0x358444;
    BlackPass_SetLevelWithReset(8, playerid, var_-8);
    BlackPass_GetCurrentLevel(4, playerid);
    return 1;
}


stock BlackPass_SendLevelSyncPacket(playerid, level, exp_value)
{
    JSON_Object(0);
    if (!_) goto lbl_0x358504;
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x358574;
    JSON_SetInt(var_-4, 229803044, -1);
    JSON_SetInt(var_-4, 229803052, 3);
    JSON_SetInt(var_-4, 229803064, -2);
    JSON_SetInt(var_-4, 229803076, exp_value);
    JSON_SetInt(var_-4, 229803084, level);
    OnPacketIncoming(12, playerid, 22, var_-4);
    JSON_Cleanup(8, var_-4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendLevelSyncRange(playerid, old_level, new_level)
{
    goto lbl_0x358768;
    BlackPass_SendLevelSyncPacket(12, playerid, -1, -1);
    return 1;
    goto lbl_0x3587a0;
    goto lbl_0x358854;
    goto lbl_0x358824;
    goto lbl_0x358828;
    BlackPass_SendLevelSyncPacket(12, playerid, var_-4);
    goto lbl_0x358794;
    return 1;
}


stock BlackPass_SavePlayer(playerid)
{
    if (!_) goto lbl_0x3588bc;
    return 1;
    BlackPass_BuildClaimFlagsString(16, playerid, 0, -248, 62);
    BlackPass_BuildClaimFlagsString(16, playerid, 1, -496, 62);
    mysql_format(166387936, -4592, 1024, 229803092);
    mysql_query(166387936, -4592);
    printf(229804096, 12);
    return 1;
}


stock BlackPass_SendRewardClaimPacket(playerid, reward_id, is_premium, layout_id)
{
    JSON_Object(0);
    JSON_SetInt(var_-4, 229804472, -1);
    JSON_SetInt(var_-4, 229804480, 2);
    JSON_SetInt(var_-4, 229804492, layout_id);
    JSON_SetInt(var_-4, 229804504, 1);
    JSON_SetInt(var_-4, 229804512, reward_id);
    if (!_) goto lbl_0x358e8c;
    goto lbl_0x358e90;
    JSON_SetInt(var_-4, 229804524);
    OnPacketIncoming(12, playerid, 22, var_-4);
    JSON_Cleanup(8, var_-4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendClaimPacketsRange(playerid, start_level, end_level, claim_standard, claim_premium, layout_id)
{
    goto lbl_0x358f90;
    goto lbl_0x358fc0;
    goto lbl_0x358fe8;
    return 1;
    goto lbl_0x359018;
    goto lbl_0x3591a0;
    if (!_) goto lbl_0x3590a4;
    if (!_) goto lbl_0x3590a4;
    goto lbl_0x3590a8;
    if (!_) goto lbl_0x3590e4;
    BlackPass_SendRewardClaimPacket(16, playerid, var_-4, 0, layout_id);
    if (!_) goto lbl_0x359158;
    if (!_) goto lbl_0x359158;
    goto lbl_0x35915c;
    if (!_) goto lbl_0x359198;
    BlackPass_SendRewardClaimPacket(16, playerid, var_-4, 1, layout_id);
    goto lbl_0x35900c;
    return 1;
}


stock BlackPass_SendAutoClaimSyncRang(playerid, old_level, new_level, claim_standard, claim_premium, layout_id)
{
    goto lbl_0x3591e8;
    return 1;
    goto lbl_0x359220;
    goto lbl_0x35943c;
    goto lbl_0x3592a4;
    goto lbl_0x3592a8;
    BlackPass_SendLevelSyncPacket(12, playerid, var_-4);
    if (!_) goto lbl_0x359340;
    if (!_) goto lbl_0x359340;
    goto lbl_0x359344;
    if (!_) goto lbl_0x359380;
    BlackPass_SendRewardClaimPacket(16, playerid, var_-4, 0, layout_id);
    if (!_) goto lbl_0x3593f4;
    if (!_) goto lbl_0x3593f4;
    goto lbl_0x3593f8;
    if (!_) goto lbl_0x359434;
    BlackPass_SendRewardClaimPacket(16, playerid, var_-4, 1, layout_id);
    goto lbl_0x359214;
    return 1;
}


stock BlackPass_LoadPlayer(playerid)
{
    BlackPass_ResetPlayer(4, playerid);
    mysql_format(166387936, -1024, 256, 229804532);
    mysql_query(166387936, -1024);
    mysql_errno(1);
    if (!_) goto lbl_0x359668;
    mysql_errno(1);
    printf(229804856, 12);
    cache_delete(8, var_-1028, 1);
    return 1;
    cache_get_row_count(4, 1);
    if (_) goto lbl_0x35984c;
    mysql_format(166387936, -1024, 256, 229805140);
    mysql_query(166387936, -1024);
    cache_delete(8, var_-1028, 1);
    return 1;
    cache_get_field_content_int(0, 229806672, 1);
    cache_get_field_content_int(0, 229806716, 1);
    cache_get_field_content_int(0, 229806740, 1);
    cache_get_field_content_int(0, 229806800, 1);
    cache_get_field_content_int(0, 229806820, 1);
    cache_get_field_content_int(0, 229806884, 1);
    cache_get_field_content(20, 0, 229806976, -1276, 62, 62);
    cache_get_field_content(20, 0, 229807044, -1524, 62, 62);
    BlackPass_ParseClaimFlagsString(12, playerid, 0, -1276);
    BlackPass_ParseClaimFlagsString(12, playerid, 1, -1524);
    goto lbl_0x359cdc;
    BlackPass_GetLevelFromExperienc(4);
    cache_delete(8, var_-1028, 1);
    return 1;
}


stock BlackPass_GetCurrentTaskPeriod(task_group)
{
    switch (_)
    gettime(12);
    return 1;
    goto lbl_0x359ef8;
    gettime(12);
    return 1;
    goto lbl_0x359ef8;
    return 1;
}


stock BlackPass_GetTaskResetTimer()
{
    gettime(12);
    goto lbl_0x359fcc;
    return 1;
}


stock BlackPass_FindTaskDefIndex(task_id)
{
    goto lbl_0x35a00c;
    goto lbl_0x35a088;
    goto lbl_0x35a080;
    return 1;
    goto lbl_0x35a000;
    return 1;
}


stock BlackPass_FindTaskSlot(playerid, task_id)
{
    goto lbl_0x35a0c8;
    goto lbl_0x35a174;
    goto lbl_0x35a16c;
    return 1;
    goto lbl_0x35a0bc;
    return 1;
}


stock BlackPass_GetTaskDefIndexFromSl(playerid, task_index)
{
    if (!_) goto lbl_0x35a1e8;
    return 1;
    goto lbl_0x35a268;
    return 1;
    BlackPass_FindTaskDefIndex(4);
    return 1;
}


stock BlackPass_ClearTaskSlot(playerid, task_index, task_group)
{
    BlackPass_GetCurrentTaskPeriod(4, task_group);
    return 1;
}


stock BlackPass_AssignTaskSlot(playerid, task_index, task_id, row_id)
{
    BlackPass_FindTaskDefIndex(4, task_id);
    if (!_) goto lbl_0x35a6b0;
    return 1;
    BlackPass_GetCurrentTaskPeriod(4);
    return 1;
}


stock BlackPass_GetNextFreeTaskSlot(playerid, task_group)
{
    if (!_) goto lbl_0x35aac0;
    goto lbl_0x35aac4;
    if (!_) goto lbl_0x35ab00;
    goto lbl_0x35ab08;
    goto lbl_0x35ab40;
    goto lbl_0x35abe0;
    if (_) goto lbl_0x35abd8;
    return 1;
    goto lbl_0x35ab34;
    return 1;
}


stock BlackPass_IsTaskActive(playerid, task_id)
{
    BlackPass_FindTaskSlot(8, playerid, task_id);
    return 1;
}


stock BlackPass_GetTaskDescription(task_id, output_len)
{
    switch (_)
    format(var_16, output_len, 229807108);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807168);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807232);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807332);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807400);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807524);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807688);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807860);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229807972);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229808092);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229808200);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229808360);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229808456);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229808652);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229808708);
    goto lbl_0x35b0b4;
    format(var_16, output_len, 229808772);
    goto lbl_0x35b0b4;
    return 1;
}


stock BlackPass_TaskHasAction(playerid, task_index)
{
    if (!_) goto lbl_0x35b11c;
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    if (!_) goto lbl_0x35b180;
    return 1;
    goto lbl_0x35b1e0;
    return 1;
    goto lbl_0x35b240;
    return 1;
}


stock BlackPass_GetStoredTaskStatus(playerid, task_index)
{
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    if (!_) goto lbl_0x35b2c0;
    return 1;
    if (!_) goto lbl_0x35b348;
    return 1;
    goto lbl_0x35b404;
    return 1;
    if (!_) goto lbl_0x35b4a4;
    BlackPass_TaskHasAction(8, playerid, task_index);
    if (!_) goto lbl_0x35b4a4;
    goto lbl_0x35b4a8;
    if (!_) goto lbl_0x35b4c8;
    return 1;
}


stock BlackPass_GetClientTaskStatus(playerid, task_index)
{
    if (!_) goto lbl_0x35b538;
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    if (!_) goto lbl_0x35b5a0;
    return 1;
    goto lbl_0x35b634;
    return 1;
    if (!_) goto lbl_0x35b6c0;
    if (_) goto lbl_0x35b6c0;
    goto lbl_0x35b6c4;
    if (!_) goto lbl_0x35b6e4;
    return 1;
    if (!_) goto lbl_0x35b76c;
    return 1;
    goto lbl_0x35b828;
    return 1;
    if (!_) goto lbl_0x35b8c8;
    BlackPass_TaskHasAction(8, playerid, task_index);
    if (!_) goto lbl_0x35b8c8;
    goto lbl_0x35b8cc;
    if (!_) goto lbl_0x35b8ec;
    return 1;
    BlackPass_TaskHasAction(8, playerid, task_index);
    if (!_) goto lbl_0x35b930;
    return 1;
}


stock BlackPass_EnableTaskGps(playerid, task_id)
{
    switch (_)
    EnablePlayerGPS(24, playerid);
    return 1;
    goto lbl_0x35bf20;
    EnablePlayerGPS(24, playerid);
    return 1;
    goto lbl_0x35bf20;
    EnablePlayerGPS(24, playerid);
    return 1;
    goto lbl_0x35bf20;
    EnablePlayerGPS(24, playerid);
    return 1;
    goto lbl_0x35bf20;
    EnablePlayerGPS(24, playerid);
    return 1;
    goto lbl_0x35bf20;
    EnablePlayerGPS(24, playerid);
    return 1;
    goto lbl_0x35bf20;
    EnablePlayerGPS(24, playerid);
    return 1;
    goto lbl_0x35bf20;
    return 1;
}


stock BlackPass_SaveTaskSlot(playerid, task_index)
{
    if (!_) goto lbl_0x35bf84;
    return 1;
    BlackPass_GetStoredTaskStatus(8, playerid, task_index);
    mysql_format(166387936, -2048, 512, 229808876);
    mysql_query(166387936, -2048);
    return 1;
}


stock BlackPass_InsertTaskSlot(playerid, task_index)
{
    if (!_) goto lbl_0x35c294;
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    if (!_) goto lbl_0x35c2f8;
    return 1;
    mysql_format(166387936, -3076, 768, 229809392);
    mysql_query(166387936, -3076);
    return 1;
}


stock BlackPass_LoadTasks(playerid)
{
    IsPlayerConnected(playerid);
    if (_) goto lbl_0x35c664;
    if (_) goto lbl_0x35c664;
    goto lbl_0x35c66c;
    if (!_) goto lbl_0x35c680;
    return 1;
    BlackPass_GetCurrentTaskPeriod(4, 1);
    BlackPass_GetCurrentTaskPeriod(4, 2);
    if (!_) goto lbl_0x35c770;
    goto lbl_0x35c770;
    goto lbl_0x35c770;
    goto lbl_0x35c774;
    if (!_) goto lbl_0x35c794;
    return 1;
    goto lbl_0x35c7e0;
    goto lbl_0x35c82c;
    BlackPass_ClearTaskSlot(12, playerid, var_-12, 1);
    goto lbl_0x35c7d4;
    goto lbl_0x35c854;
    goto lbl_0x35c8a0;
    BlackPass_ClearTaskSlot(12, playerid, var_-12, 2);
    goto lbl_0x35c848;
    goto lbl_0x35c8c8;
    goto lbl_0x35d608;
    mysql_format(166387936, -1104, 256, 229810608);
    mysql_query(166387936, -1104);
    mysql_errno(1);
    if (!_) goto lbl_0x35cb18;
    mysql_errno(1);
    printf(229811616, 12);
    cache_delete(8, var_-1108, 1);
    return 1;
    goto lbl_0x35cb38;
    cache_get_row_count(4, 1);
    goto lbl_0x35d264;
    cache_get_field_content_int(var_-1112, 229811884, 1);
    cache_get_field_content_int(var_-1112, 229811916, 1);
    BlackPass_FindTaskDefIndex(4, var_-1116);
    cache_get_field_content_int(var_-1112, 229811960, 1);
    if (!_) goto lbl_0x35cc98;
    goto lbl_0x35cb2c;
    goto lbl_0x35ccf8;
    goto lbl_0x35cb2c;
    if (!_) goto lbl_0x35cd34;
    goto lbl_0x35cb2c;
    if (!_) goto lbl_0x35cd94;
    goto lbl_0x35cb2c;
    BlackPass_GetNextFreeTaskSlot(8, playerid, var_-1120);
    if (!_) goto lbl_0x35cdf8;
    goto lbl_0x35cb2c;
    cache_get_field_content_int(var_-1112, 229811988, 1);
    BlackPass_AssignTaskSlot(16, playerid, var_-1132, var_-1116);
    cache_get_field_content_int(var_-1112, 229812000, 1);
    cache_get_field_content_int(var_-1112, 229812044, 1);
    cache_get_field_content_int(var_-1112, 229812080, 1);
    cache_get_field_content_int(var_-1112, 229812108, 1);
    cache_get_field_content_int(var_-1112, 229812140, 1);
    if (!_) goto lbl_0x35d1b0;
    goto lbl_0x35d1bc;
    if (!_) goto lbl_0x35d254;
    goto lbl_0x35cb2c;
    cache_delete(8, var_-1108, 1);
    if (!_) goto lbl_0x35d2c8;
    goto lbl_0x35d608;
    goto lbl_0x35d2f4;
    goto lbl_0x35d5c8;
    BlackPass_FindTaskDefIndex(4, var_-1120);
    if (_) goto lbl_0x35d3b4;
    if (_) goto lbl_0x35d3b4;
    goto lbl_0x35d3bc;
    if (!_) goto lbl_0x35d3d8;
    goto lbl_0x35d2e8;
    if (!_) goto lbl_0x35d464;
    goto lbl_0x35d464;
    goto lbl_0x35d468;
    if (!_) goto lbl_0x35d484;
    goto lbl_0x35d2e8;
    if (!_) goto lbl_0x35d4c8;
    goto lbl_0x35d4c8;
    goto lbl_0x35d4cc;
    if (!_) goto lbl_0x35d4e8;
    goto lbl_0x35d2e8;
    BlackPass_AssignTaskSlot(16, playerid, var_-1116, var_-1120, 0);
    BlackPass_InsertTaskSlot(8, playerid, var_-1116);
    if (!_) goto lbl_0x35d5a0;
    goto lbl_0x35d5ac;
    goto lbl_0x35d2e8;
    if (_) goto lbl_0x35d5f8;
    goto lbl_0x35d608;
    goto lbl_0x35c8bc;
    return 1;
}


stock BlackPass_ShowTaskReadyGui(playerid, task_id)
{
    JSON_Object(0);
    JSON_SetInt(var_-4, 229812212, 1);
    JSON_SetInt(var_-4, 229812220, 2);
    JSON_SetInt(var_-4, 229812228, 6);
    JSON_SetString(16, var_-4, 229812240, 229812248, 28);
    JSON_SetString(16, var_-4, 229812360, 229812368, 91);
    JSON_SetString(16, var_-4, 229812732, 229812740, 9);
    ShowPlayerGUI(12, playerid, 65, var_-4);
    JSON_Cleanup(8, var_-4, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_ShowTrackedTaskGui(playerid, task_id)
{
    BlackPass_GetTaskDescription(12, task_id, -384, 96);
    JSON_Object(0);
    JSON_SetInt(var_-388, 229812776, 1);
    JSON_SetInt(var_-388, 229812784, 5);
    JSON_SetInt(var_-388, 229812792, 4);
    JSON_SetString(16, var_-388, 229812800, -384, 96);
    JSON_SetInt(var_-388, 229812812, 0);
    JSON_SetInt(var_-388, 229812824, 1);
    JSON_SetString(16, var_-388, 229812836, 229812848, 8);
    JSON_Array(0);
    JSON_SetArray(12, var_-388, 229812880);
    JSON_Array(0);
    JSON_SetArray(12, var_-388, 229812892);
    JSON_Array(0);
    JSON_SetArray(12, var_-388, 229812904);
    JSON_Array(0);
    JSON_SetArray(12, var_-388, 229812916);
    JSON_SetInt(var_-388, 229812928, 0);
    ShowPlayerGUI(12, playerid, 39, var_-388);
    JSON_Cleanup(8, var_-388, 0);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_OpenTasksScreen(playerid)
{
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x35dd30;
    return 1;
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x35dd64;
    return 1;
    JSON_Object(0);
    JSON_SetInt(var_-4, 229812936, 1);
    JSON_SetInt(var_-4, 229812944, 0);
    JSON_SetInt(var_-4, 229812952, 3);
    JSON_SetInt(var_-4, 229812964, 0);
    JSON_SetInt(var_-4, 229812972, 1);
    JSON_SetInt(var_-4, 229812984, 0);
    GetPlayerMoney(4, playerid);
    JSON_SetInt(var_-4, 229812996);
    JSON_SetInt(var_-4, 229813004);
    JSON_SetInt(var_-4, 229813012);
    JSON_SetArray(12, var_-4, 229813020);
    strcmp(229813028);
    if (!_) goto lbl_0x35e160;
    JSON_SetString(16, var_-4, 229813048);
    goto lbl_0x35e19c;
    JSON_SetString(16, var_-4, 229813060, 229813072, 2);
    JSON_SetString(16, var_-4, 229813080);
    ShowPlayerGUI(12, playerid, 22, var_-4);
    JSON_Cleanup(8, var_-4, 0);
    JSON_Object(0);
    BlackPass_SendMainPacket(12, playerid, var_-8, 0);
    JSON_Cleanup(8, var_-8, 0);
    JSON_Object(0);
    BlackPass_SendMainPacket(12, playerid, var_-12, 1);
    JSON_Cleanup(8, var_-12, 0);
    func_0xcd48(8);
    func_0xcd48(8);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_AddTaskProgress(playerid, task_id, amount)
{
    goto lbl_0x35e430;
    return 1;
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x35e464;
    return 1;
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x35e498;
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    if (!_) goto lbl_0x35e4fc;
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, var_-4);
    if (!_) goto lbl_0x35e560;
    return 1;
    if (!_) goto lbl_0x35e5e4;
    return 1;
    goto lbl_0x35e7f0;
    goto lbl_0x35e8f0;
    goto lbl_0x35e8f0;
    if (!_) goto lbl_0x35e8f0;
    goto lbl_0x35e8f4;
    if (!_) goto lbl_0x35e98c;
    BlackPass_ShowTaskReadyGui(8, playerid, task_id);
    BlackPass_SaveTaskSlot(8, playerid, var_-4);
    if (!_) goto lbl_0x35ea1c;
    BlackPass_SendLayoutPacket(8, playerid, 1);
    return 1;
}


stock BlackPass_ClaimTaskReward(playerid, task_id)
{
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x35ea70;
    return 1;
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x35eaa4;
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    if (!_) goto lbl_0x35eb08;
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, var_-4);
    if (!_) goto lbl_0x35eb6c;
    return 1;
    if (!_) goto lbl_0x35ebf0;
    return 1;
    goto lbl_0x35eca8;
    return 1;
    BlackPass_GetCurrentLevel(4, playerid);
    goto lbl_0x35ef6c;
    goto lbl_0x35efcc;
    HidePlayerGUI(8, playerid, 39);
    DisablePlayerGPS(4, playerid);
    HidePlayerGUI(8, playerid, 65);
    BlackPass_SaveTaskSlot(8, playerid, var_-4);
    BlackPass_ClearTaskSlot(12, playerid, var_-4, var_-24);
    BlackPass_GrantExperience(8, playerid, var_-16);
    goto lbl_0x35f0fc;
    GivePlayerMoneyEx(20, playerid, var_-20, 229813092, 1, 1);
    BlackPass_LogEvent(28, playerid, 229813180, task_id, 10, var_-16, 1, var_-24);
    format(-408, 96, 229813224);
    ShowNotificationNew(28, playerid, 3, 4, 0, 0, -408, 229813312);
    BlackPass_GetCurrentLevel(4, playerid);
    goto lbl_0x35f288;
    ShowNotificationNew(28, playerid, 3, 3, 0, 0, 229813324, 229813508);
    BlackPass_GetCurrentLevel(4, playerid);
    BlackPass_SendLevelSyncRange(12, playerid, var_-12);
    BlackPass_OpenTasksScreen(4, playerid);
    return 1;
}


stock BlackPass_BeginTrackTask(playerid, task_id)
{
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x35f330;
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    if (!_) goto lbl_0x35f394;
    return 1;
    BlackPass_TaskHasAction(8, playerid, var_-4);
    if (!_) goto lbl_0x35f3d8;
    return 1;
    goto lbl_0x35f3f8;
    goto lbl_0x35f540;
    if (!_) goto lbl_0x35f4a0;
    goto lbl_0x35f4a0;
    goto lbl_0x35f4a4;
    if (!_) goto lbl_0x35f538;
    BlackPass_SaveTaskSlot(8, playerid, var_-8);
    goto lbl_0x35f3ec;
    BlackPass_SaveTaskSlot(8, playerid, var_-4);
    BlackPass_EnableTaskGps(8, playerid, task_id);
    HidePlayerGUI(8, playerid, 22);
    ShowNotificationNew(28, playerid, 3, 3, 0, 0, 229813520, 229813632);
    BlackPass_ShowTrackedTaskGui(8, playerid, task_id);
    return 1;
}


stock BlackPass_StopTrackTask(playerid, task_id)
{
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x35f714;
    return 1;
    BlackPass_FindTaskSlot(8, playerid, task_id);
    if (!_) goto lbl_0x35f778;
    return 1;
    if (!_) goto lbl_0x35f7f8;
    return 1;
    goto lbl_0x35f8c0;
    BlackPass_SaveTaskSlot(8, playerid, var_-4);
    DisablePlayerGPS(4, playerid);
    HidePlayerGUI(8, playerid, 39);
    BlackPass_OpenTasksScreen(4, playerid);
    return 1;
}


stock BlackPass_FindExchangeReplaceme(playerid, task_index)
{
    BlackPass_GetTaskDefIndexFromSl(8, playerid, task_index);
    if (!_) goto lbl_0x35fa70;
    return 1;
    goto lbl_0x35fa90;
    goto lbl_0x35fc28;
    goto lbl_0x35fad0;
    goto lbl_0x35fa84;
    goto lbl_0x35fb58;
    goto lbl_0x35fa84;
    BlackPass_IsTaskActive(8, playerid);
    if (!_) goto lbl_0x35fbb8;
    goto lbl_0x35fa84;
    goto lbl_0x35fc08;
    goto lbl_0x35fa84;
    return 1;
    goto lbl_0x35fa84;
    return 1;
}


stock BlackPass_HandleTaskPress(playerid, json)
{
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x35fcb0;
    func_0xcd48(8);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x35fd10;
    func_0xcd48(8);
    return 1;
    JSON_GetInt(12, json, 229813644, -4);
    BlackPass_FindTaskSlot(8, playerid, var_-4);
    if (!_) goto lbl_0x35fe48;
    BlackPass_SendMainPacket(12, playerid, json, 1);
    func_0xcd48(8);
    return 1;
    BlackPass_GetClientTaskStatus(8, playerid, var_-8);
    switch (_)
    BlackPass_ClaimTaskReward(8, playerid, var_-4);
    func_0xcd48(8);
    return 1;
    goto lbl_0x35ffc4;
    BlackPass_StopTrackTask(8, playerid, var_-4);
    func_0xcd48(8);
    return 1;
    goto lbl_0x35ffc4;
    BlackPass_BeginTrackTask(8, playerid, var_-4);
    func_0xcd48(8);
    return 1;
    goto lbl_0x35ffc4;
    BlackPass_SendMainPacket(12, playerid, json, 1);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleTaskExchange(playerid, json)
{
    JSON_GetInt(12, json, 229813656, -4);
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x360120;
    func_0xcd48(8);
    return 1;
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x36018c;
    func_0xcd48(8);
    return 1;
    BlackPass_FindTaskSlot(8, playerid, var_-4);
    if (!_) goto lbl_0x360220;
    func_0xcd48(8);
    return 1;
    BlackPass_GetTaskDefIndexFromSl(8, playerid, var_-8);
    if (!_) goto lbl_0x3602b4;
    func_0xcd48(8);
    return 1;
    if (!_) goto lbl_0x360368;
    func_0xcd48(8);
    return 1;
    goto lbl_0x360450;
    func_0xcd48(8);
    return 1;
    goto lbl_0x360528;
    ShowNotificationNew(28, playerid, 2, 3, 0, 0, 229813668, 229813736);
    func_0xcd48(8);
    return 1;
    BlackPass_FindExchangeReplaceme(8, playerid, var_-8);
    if (!_) goto lbl_0x360608;
    ShowNotificationNew(28, playerid, 2, 3, 0, 0, 229813748, 229813892);
    func_0xcd48(8);
    return 1;
    if (!_) goto lbl_0x360718;
    DisablePlayerGPS(4, playerid);
    HidePlayerGUI(8, playerid, 39);
    GivePlayerDonateRub(20, playerid, -10, 229813904, 1, 1);
    BlackPass_GetCurrentTaskPeriod(4);
    goto lbl_0x360b98;
    mysql_format(166387936, -3092, 768, 229814000);
    mysql_query(166387936, -3092);
    BlackPass_LogEvent(28, playerid, 229815012, var_-4, 0, 10, 1);
    ShowNotificationNew(28, playerid, 3, 3, 0, 0, 229815068, 229815348);
    BlackPass_OpenTasksScreen(4, playerid);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleExtraGui(playerid, guiid, json)
{
    JSON_GetInt(12, json, 229815360, -4);
    JSON_GetInt(12, json, 229815368, -8);
    switch (_)
    if (_) goto lbl_0x361010;
    if (_) goto lbl_0x361010;
    goto lbl_0x361018;
    if (!_) goto lbl_0x3610b4;
    HidePlayerGUI(8, playerid, 65);
    func_0xcd48(8);
    return 1;
    if (!_) goto lbl_0x3611b8;
    HidePlayerGUI(8, playerid, 65);
    BlackPass_OpenTasksScreen(4, playerid);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3612fc;
    if (!_) goto lbl_0x361244;
    HidePlayerGUI(8, playerid, 39);
    func_0xcd48(8);
    return 1;
    if (!_) goto lbl_0x3612d8;
    HidePlayerGUI(8, playerid, 39);
    BlackPass_OpenTasksScreen(4, playerid);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3612fc;
    func_0xcd48(8);
    return 1;
}


stock BlackPass_OnPlayerLogged(playerid)
{
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x361378;
    return 1;
    BlackPass_LoadTasks(4, playerid);
    if (!_) goto lbl_0x3613ac;
    return 1;
    BlackPass_AddTaskProgress(12, playerid, 254, 1);
    return 1;
}


stock BlackPass_OnPlayedHour(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 52, 1);
    return 1;
}


stock BlackPass_OnScooterRent(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 108, 1);
    return 1;
}


stock BlackPass_OnAdvertSent(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 96, 1);
    return 1;
}


stock BlackPass_OnPlateRegenerated(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 97, 1);
    return 1;
}


stock BlackPass_OnBankDeposit(playerid, amount)
{
    BlackPass_AddTaskProgress(12, playerid, 2, 1);
    BlackPass_AddTaskProgress(12, playerid, 99, amount);
    return 1;
}


stock BlackPass_OnMoneyEarned(playerid, amount)
{
    goto lbl_0x361550;
    return 1;
    strfind(var_20, 229815376, 1);
    goto lbl_0x3615a8;
    return 1;
    BlackPass_AddTaskProgress(12, playerid, 257, amount);
    return 1;
}


stock BlackPass_OnCaseOpened(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 255, 1);
    return 1;
}


stock BlackPass_OnPlayerGreeting(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 143, 1);
    return 1;
}


stock BlackPass_OnTestDriveStarted(playerid)
{
    BlackPass_AddTaskProgress(12, playerid, 104, 1);
    return 1;
}


stock BlackPass_FillBasePacket(playerid, json)
{
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(json, 229815416, -1);
    JSON_SetInt(json, 229815424, -1);
    JSON_SetInt(json, 229815436, 0);
    JSON_SetInt(json, 229815448, var_-4);
    JSON_SetInt(json, 229815460);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(json, 229815472);
    JSON_SetInt(json, 229815480);
    JSON_SetInt(json, 229815492);
    JSON_SetInt(json, 229815500);
    if (!_) goto lbl_0x3619fc;
    goto lbl_0x361a04;
    JSON_SetInt(json, 229815512);
    if (!_) goto lbl_0x361a90;
    goto lbl_0x361a98;
    JSON_SetInt(json, 229815524);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_SendMainPacket(playerid, json, latype)
{
    printf(229815536, 12);
    switch (_)
    JSON_SetInt(json, 229815672, -1);
    JSON_SetInt(json, 229815680, -1);
    JSON_SetInt(json, 229815692, 0);
    JSON_SetString(16, json, 229815704, 229815716, 15);
    JSON_SetString(16, json, 229815776);
    JSON_SetInt(json, 229815788);
    JSON_SetInt(json, 229815800, "y");
    JSON_SetInt(json, 229815812);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(json, 229815824);
    JSON_SetInt(json, 229815832, 0);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x361ec0;
    goto lbl_0x361ec8;
    JSON_SetInt(json, 229815844);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x361f64;
    goto lbl_0x361f6c;
    JSON_SetInt(json, 229815856);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x36314c;
    printf(4, 229815868);
    BlackPass_LoadTasks(4, playerid);
    JSON_SetInt(json, 229815992, -1);
    JSON_SetInt(json, 229816000, 0);
    JSON_SetInt(json, 229816012, 1);
    JSON_SetString(16, json, 229816024, 229816036, 15);
    JSON_SetString(16, json, 229816096);
    JSON_SetInt(json, 229816108);
    JSON_SetInt(json, 229816120);
    JSON_Array(0);
    goto lbl_0x3622ac;
    goto lbl_0x362560;
    goto lbl_0x362340;
    goto lbl_0x3622a0;
    JSON_Object(0);
    JSON_SetInt(var_-12, 229816132);
    JSON_SetInt(var_-12, 229816144);
    BlackPass_GetClientTaskStatus(8, playerid, var_-8);
    JSON_SetInt(var_-12, 229816152);
    JSON_Array(4, -12);
    JSON_Append(8, var_-4);
    func_0xcd48(8);
    goto lbl_0x3622a0;
    JSON_SetArray(12, json, 229816160, var_-4);
    BlackPass_GetTaskResetTimer(0);
    JSON_SetInt(json, 229816172);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    func_0xcd48(8);
    return 1;
    goto lbl_0x36314c;
    JSON_SetInt(json, 229816184, -1);
    JSON_SetInt(json, 229816192, 0);
    JSON_SetInt(json, 229816204, 2);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x36314c;
    printf(4, 229816216);
    JSON_SetInt(json, 229816344, -1);
    JSON_SetInt(json, 229816352, 0);
    JSON_SetInt(json, 229816364, 3);
    mysql_format(166387936, -4096, 1024, 229816376);
    mysql_query(166387936, -4096);
    JSON_Array(0);
    goto lbl_0x362950;
    cache_get_row_count(4, 1);
    goto lbl_0x362b40;
    JSON_Object(0);
    cache_get_field_content(20, var_-4108, 229817764, -4208, 25, 25);
    JSON_SetString(16, var_-4212, 229817784, -4208, 25);
    cache_get_field_content_int(var_-4108, 229817808, 1);
    JSON_SetInt(var_-4212, 229817792);
    JSON_Array(4, -4212);
    JSON_Append(8, var_-4104);
    func_0xcd48(8);
    goto lbl_0x362944;
    cache_delete(8, var_-4100, 1);
    mysql_format(166387936, -4096, 1024, 229817848);
    mysql_query(166387936, -4096);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x362ccc;
    cache_get_field_content_int(0, 229819668, 1);
    cache_delete(8, var_-4108, 1);
    JSON_SetArray(12, json, 229819716, var_-4104);
    JSON_SetInt(json, 229819724, var_-4112);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    func_0xcd48(8);
    return 1;
    goto lbl_0x36314c;
    if (!_) goto lbl_0x362e70;
    JSON_SetInt(json, 229819732, -1);
    JSON_SetInt(json, 229819740, 0);
    JSON_SetInt(json, 229819752, 4);
    JSON_SetInt(json, 229819764, var_-4);
    JSON_SetInt(json, 229819772, var_-8);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(json, 229819784);
    JSON_SetString(16, json, 229819792, 229819832, 19);
    JSON_SetString(16, json, 229819908, 229819952, 20);
    JSON_SetString(16, json, 229820032, 229820068, 14);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x36314c;
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleBuyLevels(playerid, json)
{
    JSON_GetInt(12, json, 229820124, -4);
    goto lbl_0x3631fc;
    BlackPass_GetCurrentLevel(4, playerid);
    goto lbl_0x363384;
    JSON_SetInt(json, 229820132, -1);
    JSON_SetInt(json, 229820140, 1);
    JSON_SetInt(json, 229820152, 0);
    JSON_SetInt(json, 229820164, 0);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3633dc;
    goto lbl_0x3635a8;
    JSON_SetInt(json, 229820172, -1);
    JSON_SetInt(json, 229820180, 1);
    JSON_SetInt(json, 229820192, 0);
    JSON_SetInt(json, 229820204, 0);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    BlackPass_SetLevelWithReset(8, playerid, var_-12);
    BlackPass_GetCurrentLevel(4, playerid);
    goto lbl_0x363694;
    BlackPass_AutoClaimRewardsRange(20, playerid);
    GivePlayerDonateRub(20, playerid);
    BlackPass_SavePlayer(4, playerid);
    BlackPass_LogEvent(28, playerid, 229820316, 0, 10, 0, var_-4, var_-16);
    JSON_SetInt(json, 229820360, -1);
    JSON_SetInt(json, 229820368, 1);
    JSON_SetInt(json, 229820380, 0);
    JSON_SetInt(json, 229820392, 1);
    OnPacketIncoming(12, playerid, 22, json);
    BlackPass_SendAutoClaimSyncRang(24, playerid, var_-8, var_-20, 1);
    BlackPass_SendMainPacket(12, playerid, json, 0);
    BlackPass_SendStateRefresh(12, playerid, 0, -1);
    BlackPass_ShowLootNotification(8, playerid, 229820400);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandlePurchasePremium(playerid, json)
{
    JSON_GetInt(12, json, 229820512, -4);
    if (!_) goto lbl_0x363a10;
    goto lbl_0x363a18;
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x363a78;
    goto lbl_0x363a80;
    if (!_) goto lbl_0x363af8;
    if (!_) goto lbl_0x363af8;
    goto lbl_0x363afc;
    if (!_) goto lbl_0x363b18;
    goto lbl_0x363d4c;
    JSON_SetInt(json, 229820524, -1);
    JSON_SetInt(json, 229820532, 1);
    JSON_SetInt(json, 229820544, 4);
    JSON_SetInt(json, 229820556, 1);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(json, 229820564);
    JSON_SetInt(json, 229820572, "y");
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x363ed4;
    JSON_SetInt(json, 229820584, -1);
    JSON_SetInt(json, 229820592, 1);
    JSON_SetInt(json, 229820604, 4);
    JSON_SetInt(json, 229820616, 0);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    if (!_) goto lbl_0x363f08;
    goto lbl_0x363f10;
    GivePlayerDonateRub(20, playerid);
    if (!_) goto lbl_0x3640fc;
    BlackPass_AddLevelsWithReset(8, playerid, 10);
    BlackPass_GetCurrentLevel(4, playerid, 1, 1);
    BlackPass_AutoClaimRewardsRange(20, playerid, 1);
    if (!_) goto lbl_0x3640f4;
    BlackPass_QueueDeluxeRewards(8, playerid, 1);
    goto lbl_0x36414c;
    BlackPass_GetCurrentLevel(4, playerid, 0, 1);
    BlackPass_AutoClaimRewardsRange(20, playerid, 1);
    BlackPass_SavePlayer(4, playerid);
    BlackPass_LogEvent(28, playerid, 229820828, 0, 0, var_-12, 1, var_-20);
    JSON_SetInt(json, 229820864, -1);
    JSON_SetInt(json, 229820872, 1);
    JSON_SetInt(json, 229820884, 4);
    JSON_SetInt(json, 229820896, 1);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(json, 229820904);
    JSON_SetInt(json, 229820912, "y");
    BlackPass_GetCurrentLevel(4, playerid);
    JSON_SetInt(json, 229820924);
    JSON_SetInt(json, 229820936);
    OnPacketIncoming(12, playerid, 22, json);
    if (!_) goto lbl_0x364560;
    BlackPass_GetCurrentLevel(4, playerid);
    BlackPass_SendAutoClaimSyncRang(24, playerid, var_-16, var_-24, 1);
    BlackPass_SendMainPacket(12, playerid, json, 0);
    BlackPass_SendStateRefresh(12, playerid, 0, -1);
    BlackPass_ShowLootNotification(8, playerid, 229820948);
    goto lbl_0x364634;
    BlackPass_GetCurrentLevel(4, playerid, 0, 1, 0);
    BlackPass_SendClaimPacketsRange(24, playerid, 1);
    BlackPass_SendMainPacket(12, playerid, json, 0);
    BlackPass_SendStateRefresh(12, playerid, 0, -1);
    BlackPass_ShowLootNotification(8, playerid, 229821120);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleGetPrize(playerid, json)
{
    JSON_GetInt(12, json, 229821264, -4);
    JSON_GetInt(12, json, 229821276, -8);
    JSON_GetInt(12, json, 229821284, -12);
    goto lbl_0x364778;
    goto lbl_0x364778;
    goto lbl_0x364780;
    if (!_) goto lbl_0x3647cc;
    func_0xcd48(8);
    return 1;
    BlackPass_GetCurrentLevel(4, playerid);
    goto lbl_0x36483c;
    func_0xcd48(8);
    return 1;
    if (!_) goto lbl_0x36489c;
    if (_) goto lbl_0x36489c;
    goto lbl_0x3648a0;
    if (!_) goto lbl_0x3648ec;
    func_0xcd48(8);
    return 1;
    if (!_) goto lbl_0x364a24;
    if (!_) goto lbl_0x364998;
    func_0xcd48(8);
    return 1;
    BlackPass_QueueLevelReward(12, playerid, var_-4, 1);
    goto lbl_0x364b40;
    if (!_) goto lbl_0x364abc;
    func_0xcd48(8);
    return 1;
    BlackPass_QueueLevelReward(12, playerid, var_-4, 0);
    BlackPass_SavePlayer(4, playerid);
    BlackPass_LogEvent(28, playerid, 229821296, var_-4, 0, 0, 1, var_-8);
    JSON_SetInt(json, 229821348, -1);
    JSON_SetInt(json, 229821356, 2);
    JSON_SetInt(json, 229821368, var_-12);
    JSON_SetInt(json, 229821380, 1);
    JSON_SetInt(json, 229821388, var_-4);
    JSON_SetInt(json, 229821400, var_-8);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandleRefreshRating(playerid, json)
{
    gettime(12);
    goto lbl_0x364f38;
    printf(229821408, 12);
    ShowNotificationNew(28, playerid, 2, 4, 0, 0, 229821596, 229821756);
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 3);
    func_0xcd48(8);
    return 1;
}


stock BlackPass_HandlePacket(playerid, json)
{
    IsPlayerConnected(playerid);
    if (_) goto lbl_0x3650a0;
    if (_) goto lbl_0x3650a0;
    goto lbl_0x3650a8;
    if (!_) goto lbl_0x3650e8;
    func_0xcd48(8);
    return 1;
    BlackPass_LoadPlayer(4, playerid);
    if (!_) goto lbl_0x365148;
    func_0xcd48(8);
    return 1;
    JSON_GetInt(12, json, 229821768, -4);
    JSON_GetInt(12, json, 229821776, -8);
    JSON_GetInt(12, json, 229821788, -12);
    if (!_) goto lbl_0x3652f4;
    JSON_SetInt(json, 229821800, -1);
    JSON_SetInt(json, 229821808, -1);
    JSON_SetInt(json, 229821820, 0);
    switch (_)
    JSON_SetInt(json, 229821832, -1);
    JSON_SetInt(json, 229821840, var_-8);
    JSON_SetInt(json, 229821852, var_-12);
    JSON_SetInt(json, 229821864);
    JSON_SetInt(json, 229821876);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(json, 229821888);
    JSON_SetInt(json, 229821896);
    JSON_SetInt(json, 229821908);
    JSON_SetInt(json, 229821916);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x365690;
    goto lbl_0x365698;
    JSON_SetInt(json, 229821928);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x365734;
    goto lbl_0x36573c;
    JSON_SetInt(json, 229821940);
    switch (_)
    switch (_)
    JSON_SetInt(json, 229821952, -1);
    JSON_SetInt(json, 229821960, -1);
    JSON_SetInt(json, 229821972, 0);
    JSON_SetString(16, json, 229821984, 229821996, 15);
    JSON_SetString(16, json, 229822056);
    JSON_SetInt(json, 229822068);
    JSON_SetInt(json, 229822080, "y");
    JSON_SetInt(json, 229822092);
    BlackPass_GetClientPremiumStatu(4);
    JSON_SetInt(json, 229822104);
    JSON_SetInt(json, 229822112, 0);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x365b38;
    goto lbl_0x365b40;
    JSON_SetInt(json, 229822124);
    BlackPass_GetCurrentLevel(4, playerid);
    if (!_) goto lbl_0x365bdc;
    goto lbl_0x365be4;
    JSON_SetInt(json, 229822136);
    OnPacketIncoming(12, playerid, 22, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x365c9c;
    func_0xcd48(8);
    return 1;
    goto lbl_0x366588;
    switch (_)
    BlackPass_SendMainPacket(12, playerid, json, 0);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3661b8;
    BlackPass_SendMainPacket(12, playerid, json, 0);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3661b8;
    JSON_GetInt(12, json, 229822148, -16);
    goto lbl_0x365f4c;
    BlackPass_HandleTaskPress(8, playerid, json);
    func_0xcd48(8);
    return 1;
    BlackPass_SendMainPacket(12, playerid, json, 1);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3661b8;
    BlackPass_SendMainPacket(12, playerid, json, 2);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3661b8;
    BlackPass_HandleRefreshRating(8, playerid, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3661b8;
    BlackPass_SendMainPacket(12, playerid, json, 4);
    func_0xcd48(8);
    return 1;
    goto lbl_0x3661b8;
    func_0xcd48(8);
    return 1;
    goto lbl_0x366588;
    JSON_SetInt(json, 229822160, -1);
    JSON_SetInt(json, 229822168, 1);
    switch (_)
    BlackPass_HandleBuyLevels(8, playerid, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x366438;
    BlackPass_HandleTaskExchange(8, playerid, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x366438;
    BlackPass_HandleRefreshRating(8, playerid, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x366438;
    BlackPass_HandlePurchasePremium(8, playerid, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x366438;
    func_0xcd48(8);
    return 1;
    goto lbl_0x366588;
    switch (_)
    BlackPass_HandleGetPrize(8, playerid, json);
    func_0xcd48(8);
    return 1;
    goto lbl_0x366510;
    func_0xcd48(8);
    return 1;
    goto lbl_0x366588;
    func_0xcd48(8);
    return 1;
    goto lbl_0x3665e4;
    func_0xcd48(8);
    return 1;
}


stock pc_cmd_blackpass(playerid)
{
    JSON_Object(0);
    JSON_SetInt(var_-4, 229822180, -2);
    BlackPass_HandlePacket(8, playerid, var_-4);
    JSON_Cleanup(8, var_-4, 0);
    func_0xcd48(8);
    return 1;
}


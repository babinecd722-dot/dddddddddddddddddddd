stock rul_OnPlayerDisconnect(playerid, reason)
{
    OrdinaryNewElectric(4, playerid);
    e_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock rul_OnPlayerConnect(playerid)
{
    OrdinaryNewElectric(4, playerid);
    e_OnPlayerConnect(4, playerid);
    return 1;
}


stock name_OnPlayerSpawn(playerid)
{
    OrdinaryNewElectric(4, playerid);
    e_OnPlayerSpawn(4, playerid);
    return 1;
}


stock name_OnDialogResponse(playerid, dialogid, response, listitem)
{
    if (!_) goto lbl_0x8a370;
    if (!_) goto lbl_0x8a370;
    goto lbl_0x8a33c;
    n_veh_CreateVehicle(44, 428, -987716615, -1008575755, 1104731645, 1127426746, 0, 0, 0, 0, -1, -1);
    PutPlayerInVehicle(12, playerid);
    GivePlayerMoneyEx(20, playerid, -1000);
    SendClientMessage(playerid, -1, 199251224);
    goto lbl_0x8a370;
    SendClientMessage(playerid, -1, 199251576);
    if (!_) goto lbl_0x8a504;
    if (!_) goto lbl_0x8a504;
    GetPlayerSkin(4, playerid);
    if (!_) goto lbl_0x8a42c;
    SetPlayerSkinInit(4, playerid);
    SendClientMessage(playerid, -1, 199251744);
    goto lbl_0x8a504;
    SetPlayerSkin(8, playerid, 206);
    SendClientMessage(playerid, -1, 199252000);
    EnablePlayerGPS(24, playerid, 55, -987806217, -1008907781, 1105198962, 199252236);
    SendClientMessage(playerid, -1, 199252240);
    if (!_) goto lbl_0x8a718;
    if (!_) goto lbl_0x8a718;
    if (!_) goto lbl_0x8a644;
    SendClientMessage(playerid, -1, 199252564);
    EnablePlayerGPS(24, playerid, 55, -988144542, 1135638947, 1153147584, 199252808);
    SendClientMessage(playerid, -1, 199252812);
    goto lbl_0x8a718;
    SendClientMessage(playerid, -1, 199253068);
    OrdinaryNewElectric(4, playerid);
    GetPlayerSkin(4, playerid);
    if (!_) goto lbl_0x8a718;
    SetPlayerSkinInit(4, playerid);
    SendClientMessage(playerid, -1, 199253304);
    if (!_) goto lbl_0x8ac98;
    if (!_) goto lbl_0x8ac98;
    GetPVarInt(8, playerid, 199253560);
    if (!_) goto lbl_0x8a8f4;
    GetPVarInt(8, playerid, 199253632);
    switch (_)
    goto lbl_0x8a864;
    goto lbl_0x8a864;
    goto lbl_0x8a864;
    SetPVarInt(12, playerid, 199253860, 1);
    Dialog(28, playerid, 3247, 2, 199253932, 199254044, 199254228, 199254260);
    goto lbl_0x8ac98;
    DeletePVar(8, playerid, 199254264);
    GetPVarInt(8, playerid, 199254336);
    GetPVarInt(8, playerid, 199254380);
    goto lbl_0x8aae0;
    SendClientMessage(playerid, -1, 199254424);
    SendClientMessage(playerid, -1, 199254632);
    goto lbl_0x8aad8;
    SendClientMessage(playerid, -1, 199254916);
    GivePlayerMoneyEx(20, playerid, -2500);
    goto lbl_0x8ac34;
    SendClientMessage(playerid, -1, 199255108);
    SendClientMessage(playerid, -1, 199255300);
    format(-596, 148, 199255584);
    GivePlayerMoneyEx(20, playerid);
    DeletePVar(8, playerid, 199255928);
    e_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


stock blackjack_OnPlayerEnterDynamicA(playerid, areaid)
{
    goto lbl_0x8ad50;
    SetPlayerPosEx(32, playerid, -988096408, 1135649954, 1153147584, 1132745447, 1, 1, 1);
    goto lbl_0x8adc0;
    SetPlayerPosEx(32, playerid, -987833034, -1009503688, 1105351722, 1132822919, 0, 0, 1);
    goto lbl_0x8ae50;
    if (!_) goto lbl_0x8ae50;
    Dialog(28, playerid, 3244, 0, 199255972, 199256124, 199256564, 199256588);
    goto lbl_0x8aee0;
    if (!_) goto lbl_0x8aee0;
    Dialog(28, playerid, 3245, 0, 199256612, 199256700, 199256908, 199256932);
    goto lbl_0x8b04c;
    goto lbl_0x8b018;
    if (!_) goto lbl_0x8afc4;
    Dialog(28, playerid, 3246, 0, 199256956, 199257084, 199257304, 199257328);
    goto lbl_0x8b010;
    Dialog(28, playerid, 3246, 0, 199257352, 199257476, 199257688, 199257712);
    goto lbl_0x8b04c;
    SendClientMessage(playerid, -1, 199257736);
    if (!_) goto lbl_0x8b380;
    if (!_) goto lbl_0x8b380;
    if (!_) goto lbl_0x8b154;
    SendClientMessage(playerid, -1, 199257924);
    return 1;
    IsPlayerInOrdersElectric(4, playerid);
    goto lbl_0x8b210;
    if (_) goto lbl_0x8b210;
    goto lbl_0x8b218;
    if (!_) goto lbl_0x8b344;
    IsPlayerInAnyVehicle(4, playerid);
    if (!_) goto lbl_0x8b28c;
    SendClientMessage(playerid, -1, 199258092);
    return 1;
    ApplyAnimationEx(44, playerid, 199258256, 199258292, 1078355558, 1, 1, 1, 0, 0, 0, -1);
    SetTimerEx(199258336, 5000, 0, 199258408);
    goto lbl_0x8b378;
    SendClientMessage(playerid, -1, 199258416);
    e_OnPlayerEnterDynamicArea(8, playerid, areaid);
    return 1;
}


stock rul_OnGameModeInit()
{
    print(199258560);
    CreateElectric(0);
    e_OnGameModeInit(0);
    return 1;
}


stock CreateElectric()
{
    print(199258716);
    goto lbl_0x8b44c;
    goto lbl_0x8b6e0;
    CreateDynamicSphere(32);
    func_0x1d0(8);
    if (!_) goto lbl_0x8b6d8;
    Create3DTextLabel(32, 199258808, -1);
    goto lbl_0x8b440;
    CreateActorEx(40, 199258908, 199259092, 84, -988096066, 1135921152, 1153147584, 1132745447, 1, 1, 1);
    CreateDynamicSphere(32, -988096066, 1135921152, 1153147584, 1077936128, 1, 1, -1, 0);
    CreateDynamicPickup(44, "pc_cmd_dice", 23, -987806217, -1008907781, 1105198962, 0, 0, -1, 1128792064, -1, 0);
    CreateDynamicSphere(32, -987806217, -1008907781, 1105198962, 1077936128, 0, 0, -1, 0);
    Create3DTextLabel(32, 199259096, -1, -987806217, -1008907781, 1105198962, 1092616192, 0, 0);
    CreateDynamicPickup(44, 1275, 23, -988144542, 1135638947, 1153147584, 1, 1, -1, 1128792064, -1, 0);
    CreateDynamicSphere(32, -988144542, 1135638947, 1153147584, 1077936128, 1, 1, -1, 0);
    Create3DTextLabel(32, 199259312, -1, -988144542, 1135638947, 1153147584, 1092616192, 1, 0);
    CreateDynamicSphere(32, -987828746, -1009493336, 1105346418, 1065353216, 0, 0, -1, 0);
    Create3DTextLabel(32, 199259500, -1, -987828746, -1009493336, 1105346418, 1092616192, 0, 0);
    CreateDynamicSphere(32, -988090365, 1135636158, 1153147584, 1065353216, 1, 1, -1, 0);
    CreateDynamicPickup(44, "cmd_dice", 23, -987828746, -1009493336, 1105346418, 0, 0, -1, 1128792064, -1, 0);
    CreateDynamicPickup(44, "cmd_dice", 23, -988090365, 1135636158, 1153147584, 1, 1, -1, 1128792064, -1, 0);
    return 1;
}


stock pc_cmd_eorders(playerid)
{
    if (!_) goto lbl_0x8bc70;
    return 1;
    goto lbl_0x8bcd8;
    SendClientMessage(playerid, -1, 199259664);
    return 1;
    GetPlayerSkin(4, playerid);
    goto lbl_0x8bd44;
    SendClientMessage(playerid, -1, 199259804);
    return 1;
    if (!_) goto lbl_0x8bdac;
    SendClientMessage(playerid, -1, 199260072);
    return 1;
    GetPlayerVehicleID(4, playerid);
    goto lbl_0x8be34;
    SendClientMessage(playerid, -1, 199260292);
    return 1;
    random(4, 10);
    GetPlayerDistanceFromPoint(16, playerid);
    floatround(8, var_-464, 0);
    func_0x2c(8);
    random(4, 2500);
    func_0x128(8);
    floatround(8, var_-468, 0);
    format(-460, 114, 199260536);
    SendClientMessage(playerid, -1, -460);
    if (!_) goto lbl_0x8c2b0;
    EnablePlayerGPS(24, playerid, 55);
    goto lbl_0x8c384;
    EnablePlayerGPS(24, playerid, 55);
    return 1;
}


stock IsPlayerInOrdersElectric(playerid)
{
    goto lbl_0x8c3c4;
    goto lbl_0x8c468;
    IsPlayerInDynamicArea(12, playerid);
    if (!_) goto lbl_0x8c460;
    return 1;
    goto lbl_0x8c3b8;
    return 1;
}


stock OrdinaryNewElectric(playerid)
{
    goto lbl_0x8c4ec;
    n_veh_DestroyVehicle(4);
    GetPVarInt(8, playerid, 199260960);
    if (!_) goto lbl_0x8c604;
    DeletePVar(8, playerid, 199261004);
    return 1;
}


stock NextStageElectric(playerid)
{
    ClearAnimations(8, playerid, 0);
    random(4, 3);
    switch (_)
    goto lbl_0x8c758;
    goto lbl_0x8c758;
    goto lbl_0x8c758;
    SetPVarInt(12, playerid, 199261232, var_-4);
    format(-804, 184, 199261276);
    Dialog(28, playerid, 3247, 0, 199261580, -804, 199261696, 199261720);
    return 1;
}


stock car_OnGameModeInit()
{
    print(197997332);
    ch_OnGameModeInit(0);
    return 1;
}


stock car_OnPlayerDisconnect(playerid, reason)
{
    goto lbl_0x5d428;
    SendClientMessage(var_-4, -1, 197997512);
    name_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock car_OnPlayerConnect(playerid)
{
    ch_OnPlayerConnect(4, playerid);
    return 1;
}


stock car_OnDialogResponse(playerid, dialogid, response, listitem)
{
    if (!_) goto lbl_0x5d80c;
    if (!_) goto lbl_0x5d780;
    if (!_) goto lbl_0x5d504;
    return 1;
    if (_) goto lbl_0x5d588;
    IsPlayerConnected(var_-4);
    if (_) goto lbl_0x5d588;
    goto lbl_0x5d590;
    if (!_) goto lbl_0x5d5cc;
    DeleteFullPVarExchange(4, playerid);
    return 1;
    GetPVarInt(8, playerid, 197997744);
    if (!_) goto lbl_0x5d63c;
    goto lbl_0x5d644;
    if (!_) goto lbl_0x5d6e0;
    SendClientMessage(var_-4, -1, 197997812);
    ShowNotification(24, playerid, 1, 197998100, 3, 197998204, 197998208);
    goto lbl_0x5d714;
    SendClientMessage(var_-4, -1, 197998212);
    Exchange_ShowVehicleList(16, playerid, var_-12, 0, var_-8);
    if (!_) goto lbl_0x5d770;
    ShowDialogSelectTypeExchange(4, playerid);
    goto lbl_0x5d80c;
    goto lbl_0x5d7e8;
    DeleteFullPVarExchange(4, var_-4);
    DeleteFullPVarExchange(4, playerid);
    if (!_) goto lbl_0x5e134;
    if (!_) goto lbl_0x5e118;
    GetPVarInt(8, playerid, 197998504);
    if (!_) goto lbl_0x5d8c8;
    goto lbl_0x5d8dc;
    if (_) goto lbl_0x5d930;
    IsPlayerConnected(var_-8);
    if (_) goto lbl_0x5d930;
    goto lbl_0x5d938;
    if (!_) goto lbl_0x5d958;
    return 1;
    if (!_) goto lbl_0x5da4c;
    GetPVarInt(8, playerid, 197998572);
    Exchange_ShowVehicleList(16, playerid, var_-8);
    return 1;
    if (!_) goto lbl_0x5dae0;
    GetPVarInt(8, playerid, 197998644);
    Exchange_ShowVehicleList(16, playerid, var_-8);
    return 1;
    goto lbl_0x5db24;
    ShowDialogSelectTypeExchange(4, playerid);
    return 1;
    SetPVarInt(12, var_-8, 197998716, var_-12);
    mysql_format(166387936, 197995192, 285, 197998784);
    mysql_query(166387936, 197995192);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x5dc8c;
    print(197998968);
    cache_delete(8, var_-16, 1);
    ShowDialogSelectTypeExchange(4, playerid);
    return 1;
    cache_get_field_content_int(0, 197999112, 1);
    GetVehicleModelName(12, var_-20, -292, 68);
    strlen(-292);
    if (!_) goto lbl_0x5dd88;
    format(-292, 68, 197999148);
    SetPVarString(12, var_-8, 197999184, -292);
    cache_delete(8, var_-16, 1);
    if (_) goto lbl_0x5de6c;
    IsPlayerConnected(var_-296);
    if (_) goto lbl_0x5de6c;
    goto lbl_0x5de74;
    if (!_) goto lbl_0x5de94;
    return 1;
    if (!_) goto lbl_0x5df44;
    format(-872, 144, 197999244);
    goto lbl_0x5dfb4;
    format(-872, 144, 197999496);
    SendClientMessage(var_-296, -1, -872);
    GetPVarInt(8, playerid, 197999744);
    if (!_) goto lbl_0x5e0bc;
    ShowNotification(24, playerid, 1, 197999812, 3, 197999932, 197999936);
    SetPVarInt(12, playerid, 197999940, 1);
    ShowDialogSelectTypeExchange(4, playerid);
    goto lbl_0x5e108;
    Dialog(28, playerid, 1613, 2, 198000008, 198000160, 198000344, 198000376);
    goto lbl_0x5e134;
    ShowDialogSelectTypeExchange(4, playerid);
    if (!_) goto lbl_0x5e76c;
    if (!_) goto lbl_0x5e750;
    GetPVarInt(8, playerid, 198000404);
    if (!_) goto lbl_0x5e4e4;
    strval(4, var_28);
    if (!_) goto lbl_0x5e250;
    SendClientMessage(playerid, -1, 198000464);
    return 1;
    GetPVarInt(8, playerid, 198000652);
    if (!_) goto lbl_0x5e3b0;
    goto lbl_0x5e32c;
    SetPVarInt(12, playerid, 198000712, var_-4);
    SendExchange(4, var_-8);
    goto lbl_0x5e3a8;
    DeleteFullPVarExchange(4, playerid);
    goto lbl_0x5e4cc;
    goto lbl_0x5e450;
    SetPVarInt(12, playerid, 198000752, var_-4);
    SendExchange(4, var_-8);
    goto lbl_0x5e4cc;
    DeleteFullPVarExchange(4, playerid);
    return 1;
    switch (_)
    format(-512, 128, 198000792);
    SendClientMessage(playerid, -1, -512);
    SendExchange(4);
    goto lbl_0x5e748;
    Dialog(28, playerid, 1613, 1, 198001064, 198001216, 198001452, 198001476);
    SetPVarInt(12, playerid, 198001500, 1);
    goto lbl_0x5e748;
    Dialog(28, playerid, 1613, 1, 198001560, 198001712, 198001948, 198001972);
    SetPVarInt(12, playerid, 198001996, 2);
    goto lbl_0x5e748;
    goto lbl_0x5e76c;
    ShowDialogSelectTypeExchange(4, playerid);
    if (!_) goto lbl_0x5eaa4;
    if (!_) goto lbl_0x5e9d4;
    GetPVarInt(8, playerid, 198002056);
    GetPVarInt(8, var_-4, 198002140);
    GetPVarInt(8, var_-4, 198002224);
    GetPVarInt(8, var_-4, 198002264);
    if (!_) goto lbl_0x5e920;
    GetPVarInt(8, playerid, 198002324);
    if (!_) goto lbl_0x5e970;
    GetPVarInt(8, var_-4, 198002392);
    Exchange(32, var_-8, var_-12, playerid, var_-4, var_-16, var_-20, var_-24, var_-28);
    goto lbl_0x5eaa4;
    SendClientMessage(12);
    SendClientMessage(playerid, -1, 198002640);
    DeleteFullPVarExchange(4, playerid);
    DeleteFullPVarExchange(4);
    ch_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


stock pc_cmd_changeprop(playerid)
{
    sscanf(12, var_16, 198002812, -4);
    if (!_) goto lbl_0x5eb74;
    SendClientMessage(playerid, -1717986817, 198002820);
    return 1;
    IsPlayerConnected(var_-4);
    if (_) goto lbl_0x5ebc8;
    goto lbl_0x5ebc8;
    goto lbl_0x5ebd0;
    if (!_) goto lbl_0x5ec18;
    SendClientMessage(playerid, -1717986817, 198002968);
    return 1;
    IsPlayerInRangeOfPlayer(12, playerid, var_-4, 1086324736);
    if (!_) goto lbl_0x5ec90;
    SendClientMessage(playerid, -1717986817, 198003040);
    return 1;
    goto lbl_0x5ed00;
    SendClientMessage(playerid, -1, 198003164);
    return 1;
    format(-580, 144, 198003448);
    SendClientMessage(playerid, 865730559, -580);
    format(-580, 144, 198003616);
    ShowNotificationNew(28, var_-4, 4, 10, 9201, 0, -580, 198003688);
    SetPVarInt(12, var_-4, 198003700, playerid);
    SetPVarInt(12, playerid, 198003740, var_-4);
    return 1;
}


stock pc_cmd_yeschange(playerid)
{
    GetPVarInt(8, playerid, 198003776);
    if (_) goto lbl_0x5efb8;
    IsPlayerConnected(var_-4);
    if (_) goto lbl_0x5efb8;
    goto lbl_0x5efc0;
    if (!_) goto lbl_0x5f008;
    SendClientMessage(playerid, -1717986817, 198003816);
    return 1;
    GetPVarInt(8, var_-4, 198003944);
    goto lbl_0x5f0a0;
    SendClientMessage(playerid, -1717986817, 198003980);
    return 1;
    goto lbl_0x5f108;
    goto lbl_0x5f108;
    goto lbl_0x5f110;
    if (!_) goto lbl_0x5f158;
    SendClientMessage(playerid, -1717986817, 198004100);
    return 1;
    SendClientMessage(var_-4, -2555649, 198004216);
    SendClientMessage(playerid, -2555649, 198004368);
    ShowDialogSelectTypeExchange(4, var_-4);
    return 1;
}


stock Exchange(type, type_1, player, player_1, surcharge, surcharge_p, vehicle_sql, vehicle_sql_1)
{
    switch (_)
    ExchangeHouse(8, player, player_1);
    goto lbl_0x5f378;
    ExchangeVehicle(8, player_1, vehicle_sql);
    goto lbl_0x5f378;
    ExchangeBusiness(8, player, player_1);
    goto lbl_0x5f378;
    ExchangeFuelStation(8, player, player_1);
    goto lbl_0x5f378;
    print(198004512);
    goto lbl_0x5f378;
    switch (_)
    ExchangeHouse(8, player_1, player);
    goto lbl_0x5f494;
    ExchangeVehicle(8, player, vehicle_sql_1);
    goto lbl_0x5f494;
    ExchangeBusiness(8, player_1, player);
    goto lbl_0x5f494;
    ExchangeFuelStation(8, player_1, player);
    goto lbl_0x5f494;
    print(198004620);
    goto lbl_0x5f494;
    goto lbl_0x5f640;
    if (!_) goto lbl_0x5f50c;
    goto lbl_0x5f580;
    if (!_) goto lbl_0x5f550;
    goto lbl_0x5f580;
    print(198004736);
    return 1;
    GivePlayerMoneyEx(20, var_-4, surcharge);
    GivePlayerMoneyEx(20, var_-8);
    SendClientMessage(player, -1, 198004760);
    SendClientMessage(player, -1, 198005096);
    SendClientMessage(player, -1, 198005320);
    SendClientMessage(player, -1, 198005620);
    SendClientMessage(player_1, -1, 198005840);
    SendClientMessage(player_1, -1, 198006064);
    SendClientMessage(player_1, -1, 198006400);
    SendClientMessage(player_1, -1, 198006700);
    format(-512, 128, 198006920);
    SendClientMessage(player, -1, -512);
    format(-512, 128, 198007168);
    SendClientMessage(player_1, -1, -512);
    DeleteFullPVarExchange(4, player);
    DeleteFullPVarExchange(4, player_1);
    return 1;
}


stock ExchangeVehicle(playerid, sql_id)
{
    goto lbl_0x5fae0;
    goto lbl_0x5fad8;
    UnloadPlayerOwnableCar(8);
    mysql_format(166387936, 197995192, 285, 198007416);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x5fbe0;
    print(198007608);
    return 1;
}


stock ExchangeFuelStation(playerid, to_player)
{
    GetPlayerFuelStation(4, playerid);
    mysql_format(166387936, 197995192, 285, 198007752);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x5fdc0;
    print(198007924);
    return 1;
    format(197995192, 285, 198008068);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x5fec8;
    print(198008436);
    return 1;
    mysql_errno(1);
    if (!_) goto lbl_0x6058c;
    gettime(12);
    format(16);
    CallLocalFunction(12, 198008588, 198008680, -4);
    SendClientMessage(to_player, 1724645631, 198008688);
    format(197995192, 285, 198008932);
    mysql_query(166387936, 197995192);
    format(197995192, 285, 198009472);
    mysql_query(166387936, 197995192);
    return 1;
}


stock ExchangeBusiness(playerid, to_player)
{
    GetPlayerBusiness(4, playerid);
    mysql_format(166387936, 197995192, 285, 198009724);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x6076c;
    print(198009900);
    return 1;
    mysql_format(166387936, 197995192, 285, 198010044);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x6087c;
    print(198010396);
    return 1;
    printf(198010548, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x6102c;
    gettime(12);
    format(16);
    CallLocalFunction(12, 198010576, 198010656, -4);
    SendClientMessage(to_player, 1724645631, 198010664);
    format(197995192, 285, 198010916);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x60f24;
    print(198011376);
    return 1;
    format(197995192, 285, 198011528);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x61014;
    print(198011760);
    return 1;
}


stock ExchangeHouse(playerid, to_player)
{
    GetPlayerHouse(8, playerid, -1);
    mysql_format(166387936, 197995192, 285, 198011912);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x61258;
    print(198012152);
    return 1;
    format(197995192, 285, 198012304);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x6137c;
    print(198012700);
    return 1;
    printf(198012844, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x61abc;
    gettime(12);
    GetElapsedTime(12);
    goto lbl_0x61708;
    goto lbl_0x617a0;
    CallLocalFunction(12, 198012872, 198012948, -24);
    mysql_errno(1);
    if (!_) goto lbl_0x61824;
    print(198012956);
    return 1;
    format(16);
    cache_delete(8, var_-28, 1);
    UpdateHouse(4, var_-4);
    HouseHealthInit(8, var_-4, -1);
    HouseStoreInit(8, var_-4, -1);
    format(197995192, 285, 198013108);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x61ab4;
    print(198013556);
    return 1;
}


stock Exchange_ShowVehicleList(viewerid, ownerid, page, is_select_other)
{
    if (_) goto lbl_0x61b30;
    IsPlayerConnected(ownerid);
    if (_) goto lbl_0x61b30;
    goto lbl_0x61b38;
    if (!_) goto lbl_0x61b4c;
    return 1;
    mysql_format(166387936, 197995192, 285, 198013708);
    mysql_query(166387936, 197995192);
    mysql_errno(1);
    if (!_) goto lbl_0x61c8c;
    print(198013940);
    cache_delete(8, var_-4, 1);
    return 1;
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x61d70;
    if (!_) goto lbl_0x61cfc;
    goto lbl_0x61d04;
    SendClientMessage(viewerid, -1);
    cache_delete(8, var_-4, 1);
    return 1;
    goto lbl_0x61dd0;
    goto lbl_0x61e00;
    goto lbl_0x61e78;
    format(-16404, 4096, 198014416);
    goto lbl_0x61f20;
    goto lbl_0x621e0;
    cache_get_field_content_int(var_-17052, 198014624, 1);
    cache_get_field_content_int(var_-17052, 198014636, 1);
    GetVehicleModelName(12, var_-17060, -17188, 32);
    strlen(-17188);
    if (!_) goto lbl_0x62078;
    format(-17188, 32, 198014672);
    format(-17044, 160, 198014708);
    strlen(-16404);
    strlen(-17044);
    goto lbl_0x62138;
    goto lbl_0x621e0;
    strcat(-16404, -17044);
    goto lbl_0x61f14;
    goto lbl_0x62330;
    format(-17044, 160, 198014912);
    strlen(-16404);
    strlen(-17044);
    goto lbl_0x62330;
    strcat(-16404, -17044);
    goto lbl_0x62478;
    format(-17044, 160, 198014992);
    strlen(-16404);
    strlen(-17044);
    goto lbl_0x62478;
    strcat(-16404, -17044);
    SetPVarInt(12, viewerid, 198015072, page);
    SetPVarInt(12, ownerid, 198015144, 2);
    Dialog(28, viewerid, 1612, 5, 198015228, -16404, 198015424, 198015456);
    cache_delete(8, var_-4, 1);
    return 1;
}


stock ShowDialogSelectTypeExchange(playerid)
{
    goto lbl_0x625f4;
    Dialog(28, playerid, 1610, 5, 198015484, 198015684, 198016084, 198016116);
    return 1;
}


stock SendExchange(playerid)
{
    GetPVarInt(8, var_-4, 198016144);
    GetPVarString(16, playerid, 198016228, -472, 68);
    GetPVarString(16, var_-4, 198016288, -744, 68);
    strlen(-472);
    if (!_) goto lbl_0x627c8;
    format(-472, 68, 198016348);
    strlen(-744);
    if (!_) goto lbl_0x6282c;
    format(-744, 68, 198016392);
    goto lbl_0x62920;
    GetPVarInt(8, var_-4, 198016436);
    switch (_)
    format(-200, 48, 198016496);
    goto lbl_0x62920;
    format(-200, 48, 198016600);
    goto lbl_0x62920;
    format(197995192, 285, 198016712);
    Dialog(28, playerid, 1614, 0, 198017308, 197995192, 198017440, 198017464);
    return 1;
}


stock DeleteFullPVarExchange(playerid)
{
    DeletePVar(8, playerid, 198017488);
    DeletePVar(8, playerid, 198017528);
    DeletePVar(8, playerid, 198017568);
    DeletePVar(8, playerid, 198017628);
    DeletePVar(8, playerid, 198017696);
    DeletePVar(8, playerid, 198017756);
    DeletePVar(8, playerid, 198017824);
    DeletePVar(8, playerid, 198017908);
    return 1;
}


stock ClearPlayerRCPInfo(playerid)
{
    return 1;
}


stock n_SetPlayerRaceCheckpoint(playerid, type, nextx, nexty, nextz, size, action_type)
{
    SetPlayerRaceCheckpoint(36, playerid, type, var_20, var_24, var_28, nextx, nexty, nextz, size);
    return 1;
}


stock n_IsPlayerInRaceCheckpoint(playerid)
{
    if (!_) goto lbl_0xd748;
    IsPlayerInRangeOfPoint(20, playerid);
    if (!_) goto lbl_0xd748;
    return 1;
}


stock n_DisablePlayerRaceCheckpoint(playerid)
{
    if (!_) goto lbl_0xd818;
    DisablePlayerRaceCheckpoint(4, playerid);
    return 1;
}


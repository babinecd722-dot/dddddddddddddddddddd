// RESTORED: pawno/include/system/new_promo.pwn
// Functions: 0

// AMX 0x46690-0x4673c
stock blackjack_OnGameModeInit()
{
    // --- line 182 ---
    // --- line 184 ---
    print(197880844);
    // stack 8
    // --- line 185 ---
    SetTimer(197881028, 1500, 0);
    // stack 16
    // --- line 186 ---
    SetTimer(197881132, 3000, 0);
    // stack 16
    // --- line 188 ---
    prom_OnGameModeInit(0);
    return 1;
}


// AMX 0x4673c-0x4757c
public OnPromoTimerTick(playerPromoSQLID)
{
    // --- line 203 ---
    // --- line 205 ---
    // stack -1024
    // --- line 206 ---
    // --- line 207 ---
    // --- line 208 ---
    // --- line 210 ---
    mysql_format(166387936, -1024, 256, 197881240);
    // stack 24
    // --- line 211 ---
    mysql_query(166387936, -1024);
    // stack 16
    // var_-1028 = _;
    // --- line 213 ---
    mysql_errno(1);
    // stack 8
    if (_) goto lbl_0x46880; // jnz
    cache_get_row_count(4, var_-1028);
    // stack 8
    if (!_) goto lbl_0x46880; // jzer
    goto lbl_0x46888; // jump 0x46888
    if (!_) goto lbl_0x46d4c; // jzer
    // --- line 215 ---
    mysql_errno(1);
    // stack 8
    printf(197882108, 12);
    // stack 16
    // --- line 217 ---
    goto lbl_0x46914; // jump 0x46914
    // load var_-1052
    // _ = 250;
    goto lbl_0x46d04; // jsgeq 0x46d04
    // --- line 219 ---
    IsPlayerConnected(var_-1052);
    // stack 8
    if (!_) goto lbl_0x46968; // jzer
    goto lbl_0x46908; // jump 0x46908
    // --- line 220 ---
    goto lbl_0x46988; // jump 0x46988
    // load var_-1056
    // _ = 197879844;
    // load var_-1052
    goto lbl_0x46cf4; // jsleq 0x46cf4
    // --- line 222 ---
    // _ = 197863844;
    // load var_-1052
    // load var_-1056
    // load playerPromoSQLID
    goto lbl_0x46cec; // jneq 0x46cec
    // --- line 224 ---
    // _ = 197863844;
    // load var_-1052
    // load var_-1056
    // KillTimer(/* 1 args — stack lost */);
    // stack 8
    // --- line 225 ---
    // stack -4
    // load var_-1056
    // var_-1060 = _;
    goto lbl_0x46ad4; // jump 0x46ad4
    // load var_-1060
    // _ = 197879844;
    // load var_-1052
    // _ = 1;
    goto lbl_0x46ca4; // jsleq 0x46ca4
    // --- line 227 ---
    // _ = 197863844;
    // load var_-1052
    // load var_-1060
    // _ = 197863844;
    // load var_-1052
    // load var_-1060
    // --- line 228 ---
    // _ = 197863844;
    // load var_-1052
    // load var_-1060
    // _ = 197863844;
    // load var_-1052
    // load var_-1060
    goto lbl_0x46ac8; // jump 0x46ac8
    // stack 4
    // --- line 230 ---
    // _ = 197879844;
    // load var_-1052
    // --- line 231 ---
    goto lbl_0x46cf4; // jump 0x46cf4
    goto lbl_0x4697c; // jump 0x4697c
    // stack 4
    goto lbl_0x46908; // jump 0x46908
    // stack 4
    // --- line 235 ---
    cache_delete(8, var_-1028, 1);
    // stack 12
    // --- line 236 ---
    // stack 1048
    return 1;
    // --- line 239 ---
    cache_get_field_content_int(0, 197882496, 1);
    // stack 16
    // var_-1032 = _;
    // --- line 240 ---
    // stack -4
    cache_get_field_content_int(0, 197882540, 1);
    // stack 16
    // var_-1052 = _;
    // --- line 241 ---
    cache_get_field_content_int(0, 197882584, 1);
    // stack 16
    // var_-1036 = _;
    // --- line 242 ---
    cache_get_field_content_int(0, 197882628, 1);
    // stack 16
    // var_-1040 = _;
    // --- line 243 ---
    // stack -4
    cache_get_field_content_int(0, 197882676, 1);
    // stack 16
    // var_-1056 = _;
    // --- line 244 ---
    cache_get_field_content_int(0, 197882736, 1);
    // stack 16
    // var_-1044 = _;
    // --- line 246 ---
    // stack -4
    // load var_-1056
    gettime(12);
    // stack 16
    // var_-1060 = _;
    // --- line 248 ---
    // load var_-1060
    goto lbl_0x474b8; // jsless 0x474b8
    // --- line 250 ---
    GetPlayerIDFromAccountID(4, var_-1032);
    // var_-1048 = _;
    // --- line 251 ---
    // load var_-1048
    // _ = 65535;
    goto lbl_0x47020; // jeq 0x47020
    // --- line 253 ---
    RevokePromoPrize(16, var_-1032, var_-1036, var_-1040, var_-1044);
    // --- line 254 ---
    SendClientMessage(var_-1048, -1, 197882772);
    // stack 16
    // --- line 257 ---
    mysql_format(166387936, -1024, 256, 197883024);
    // stack 24
    // --- line 258 ---
    mysql_query(166387936, -1024);
    // stack 16
    // --- line 260 ---
    goto lbl_0x470b8; // jump 0x470b8
    // load var_-1064
    // _ = 250;
    goto lbl_0x474a8; // jsgeq 0x474a8
    // --- line 262 ---
    IsPlayerConnected(var_-1064);
    // stack 8
    if (!_) goto lbl_0x4710c; // jzer
    goto lbl_0x470ac; // jump 0x470ac
    // --- line 263 ---
    goto lbl_0x4712c; // jump 0x4712c
    // load var_-1068
    // _ = 197879844;
    // load var_-1064
    goto lbl_0x47498; // jsleq 0x47498
    // --- line 265 ---
    // _ = 197863844;
    // load var_-1064
    // load var_-1068
    // load playerPromoSQLID
    goto lbl_0x47490; // jneq 0x47490
    // --- line 267 ---
    // _ = 197863844;
    // load var_-1064
    // load var_-1068
    // KillTimer(/* 1 args — stack lost */);
    // stack 8
    // --- line 268 ---
    // stack -4
    // load var_-1068
    // var_-1072 = _;
    goto lbl_0x47278; // jump 0x47278
    // load var_-1072
    // _ = 197879844;
    // load var_-1064
    // _ = 1;
    goto lbl_0x47448; // jsleq 0x47448
    // --- line 270 ---
    // _ = 197863844;
    // load var_-1064
    // load var_-1072
    // _ = 197863844;
    // load var_-1064
    // load var_-1072
    // --- line 271 ---
    // _ = 197863844;
    // load var_-1064
    // load var_-1072
    // _ = 197863844;
    // load var_-1064
    // load var_-1072
    goto lbl_0x4726c; // jump 0x4726c
    // stack 4
    // --- line 273 ---
    // _ = 197879844;
    // load var_-1064
    // --- line 274 ---
    goto lbl_0x47498; // jump 0x47498
    goto lbl_0x47120; // jump 0x47120
    // stack 4
    goto lbl_0x470ac; // jump 0x470ac
    // stack 4
    goto lbl_0x47538; // jump 0x47538
    // --- line 281 ---
    mysql_format(166387936, -1024, 256, 197883184);
    // stack 28
    // --- line 284 ---
    mysql_query(166387936, -1024);
    // stack 16
    // --- line 286 ---
    cache_delete(8, var_-1028, 1);
    // stack 12
    // --- line 287 ---
    // stack 1060
    return 1;
}


// AMX 0x4757c-0x48340
stock CheckAndCreatePromoTables()
{
    // --- line 290 ---
    // --- line 292 ---
    // --- line 293 ---
    // stack -2048
    // --- line 295 ---
    mysql_format(166387936, -2052, 512, 197883420);
    // stack 20
    // --- line 296 ---
    mysql_query(166387936, -2052);
    // stack 16
    // var_-4 = _;
    // --- line 297 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x477bc; // jzer
    // --- line 299 ---
    printf(4, 197883552);
    // stack 8
    // --- line 300 ---
    mysql_format(166387936, -2052, 512, 197883852);
    // stack 24
    // --- line 301 ---
    mysql_query(166387936, -2052);
    // stack 16
    // --- line 302 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x47798; // jzer
    // --- line 304 ---
    mysql_errno(1);
    // stack 8
    printf(197885864);
    // stack 12
    goto lbl_0x477bc; // jump 0x477bc
    // --- line 308 ---
    printf(4, 197886104);
    // stack 8
    // --- line 311 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // --- line 313 ---
    mysql_format(166387936, -2052, 512, 197886392);
    // stack 20
    // --- line 314 ---
    mysql_query(166387936, -2052);
    // stack 16
    // var_-4 = _;
    // --- line 316 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x479d4; // jzer
    // --- line 318 ---
    printf(4, 197886556);
    // stack 8
    // --- line 319 ---
    mysql_format(166387936, -2052, 512, 197886880);
    // stack 20
    // --- line 320 ---
    mysql_query(166387936, -2052);
    // stack 16
    // --- line 322 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x479b0; // jzer
    // --- line 324 ---
    mysql_errno(1);
    // stack 8
    printf(197887956);
    // stack 12
    goto lbl_0x479d4; // jump 0x479d4
    // --- line 328 ---
    printf(4, 197888220);
    // stack 8
    // --- line 331 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // --- line 333 ---
    mysql_format(166387936, -2052, 512, 197888456);
    // stack 20
    // --- line 334 ---
    mysql_query(166387936, -2052);
    // stack 16
    // var_-4 = _;
    // --- line 335 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x47bec; // jzer
    // --- line 337 ---
    printf(4, 197888596);
    // stack 8
    // --- line 338 ---
    mysql_format(166387936, -2052, 512, 197888840);
    // stack 20
    // --- line 339 ---
    mysql_query(166387936, -2052);
    // stack 16
    // --- line 340 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x47bc8; // jzer
    // --- line 342 ---
    mysql_errno(1);
    // stack 8
    printf(197890512);
    // stack 12
    goto lbl_0x47bec; // jump 0x47bec
    // --- line 346 ---
    printf(4, 197890760);
    // stack 8
    // --- line 349 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // --- line 351 ---
    mysql_format(166387936, -2052, 512, 197890980);
    // stack 20
    // --- line 352 ---
    mysql_query(166387936, -2052);
    // stack 16
    // var_-4 = _;
    // --- line 354 ---
    mysql_errno(1);
    // stack 8
    if (_) goto lbl_0x47cf8; // jnz
    cache_get_field_count(4, var_-4);
    // stack 8
    // _ = 5;
    goto lbl_0x47cf8; // jneq 0x47cf8
    goto lbl_0x47d00; // jump 0x47d00
    if (!_) goto lbl_0x47ed4; // jzer
    // --- line 356 ---
    printf(4, 197891124);
    // stack 8
    // --- line 358 ---
    mysql_errno(1);
    // stack 8
    if (_) goto lbl_0x47db0; // jnz
    // --- line 359 ---
    mysql_query(166387936, 197891504);
    // stack 16
    // --- line 360 ---
    printf(4, 197891652);
    // stack 8
    // --- line 362 ---
    mysql_format(166387936, -2052, 512, 197891872);
    // stack 20
    // --- line 363 ---
    mysql_query(166387936, -2052);
    // stack 16
    // --- line 364 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x47eb0; // jzer
    // --- line 366 ---
    mysql_errno(1);
    // stack 8
    printf(197893400);
    // stack 12
    goto lbl_0x47ed4; // jump 0x47ed4
    // --- line 370 ---
    printf(4, 197893652);
    // stack 8
    // --- line 373 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // --- line 375 ---
    mysql_format(166387936, -2052, 512, 197893952);
    // stack 20
    // --- line 376 ---
    mysql_query(166387936, -2052);
    // stack 16
    // var_-4 = _;
    // --- line 377 ---
    cache_get_row_count(4, 1);
    // stack 8
    if (_) goto lbl_0x480ec; // jnz
    // --- line 379 ---
    printf(4, 197894148);
    // stack 8
    // --- line 380 ---
    mysql_format(166387936, -2052, 512, 197894448);
    // stack 20
    // --- line 381 ---
    mysql_query(166387936, -2052);
    // stack 16
    // --- line 382 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x480c8; // jzer
    // --- line 384 ---
    mysql_errno(1);
    // stack 8
    printf(197894796);
    // stack 12
    goto lbl_0x480ec; // jump 0x480ec
    // --- line 388 ---
    printf(4, 197895036);
    // stack 8
    // --- line 391 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // --- line 393 ---
    mysql_format(166387936, -2052, 512, 197895244);
    // stack 20
    // --- line 394 ---
    mysql_query(166387936, -2052);
    // stack 16
    // var_-4 = _;
    // --- line 395 ---
    cache_get_row_count(4, 1);
    // stack 8
    if (_) goto lbl_0x48304; // jnz
    // --- line 397 ---
    printf(4, 197895472);
    // stack 8
    // --- line 398 ---
    mysql_format(166387936, -2052, 512, 197895804);
    // stack 20
    // --- line 399 ---
    mysql_query(166387936, -2052);
    // stack 16
    // --- line 400 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x482e0; // jzer
    // --- line 402 ---
    mysql_errno(1);
    // stack 8
    printf(197896200);
    // stack 12
    goto lbl_0x48304; // jump 0x48304
    // --- line 406 ---
    printf(4, 197896472);
    // stack 8
    // --- line 409 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // stack 2052
    return 1;
}


// AMX 0x48340-0x48990
stock LoadPromoCodesFromDatabase()
{
    // --- line 412 ---
    // --- line 414 ---
    printf(4, 197896712);
    // stack 8
    // --- line 415 ---
    // --- line 416 ---
    // stack -512
    // --- line 418 ---
    mysql_format(166387936, -516, 128, 197896912);
    // stack 20
    // --- line 419 ---
    printf(197897180, -516);
    // stack 12
    // --- line 421 ---
    mysql_query(166387936, -516);
    // stack 16
    // var_-4 = _;
    // --- line 422 ---
    mysql_errno(1);
    // stack 8
    printf(197897312);
    // stack 12
    // --- line 424 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x48560; // jzer
    // --- line 425 ---
    mysql_errno(1);
    // stack 8
    printf(197897468);
    // stack 12
    // --- line 426 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // --- line 427 ---
    // stack 516
    return 1;
    // --- line 430 ---
    cache_get_row_count(4, var_-4);
    // stack 8
    // stor.pri 197806840
    // --- line 431 ---
    printf(197897664, 197806840);
    // stack 12
    // --- line 433 ---
    // _ = 100;
    goto lbl_0x48654; // jsleq 0x48654
    // --- line 435 ---
    printf(197897900, 197806840);
    // stack 20
    // --- line 436 ---
    // stor.pri 197806840
    goto lbl_0x4868c; // jump 0x4868c
    // --- line 438 ---
    if (_) goto lbl_0x4868c; // jnz
    // --- line 439 ---
    printf(4, 197898316);
    // stack 8
    // --- line 442 ---
    goto lbl_0x486ac; // jump 0x486ac
    // load var_-520
    goto lbl_0x488f4; // jsgeq 0x488f4
    // --- line 444 ---
    // _ = 197791640;
    // load var_-520
    cache_get_field_content_int(var_-520, 197898548, 1);
    // stack 16
    // --- line 445 ---
    // _ = 197791640;
    // load var_-520
    cache_get_field_content(20, var_-520, 197898560);
    // stack 24
    // --- line 446 ---
    // _ = 197791640;
    // load var_-520
    cache_get_field_content_int(var_-520, 197898580, 1);
    // stack 16
    // --- line 447 ---
    // _ = 197791640;
    // load var_-520
    cache_get_field_content_int(var_-520, 197898624, 1);
    // stack 16
    // --- line 448 ---
    // _ = 197791640;
    // load var_-520
    cache_get_field_content_int(var_-520, 197898664, 1);
    // stack 16
    goto lbl_0x486a0; // jump 0x486a0
    // stack 4
    // --- line 450 ---
    cache_delete(8, var_-4, 1);
    // stack 12
    // --- line 451 ---
    printf(197898708, 197806840);
    // stack 12
    // --- line 452 ---
    printf(4, 197898956);
    // stack 8
    // --- line 453 ---
    // stack 516
    return 1;
}


// AMX 0x48990-0x48b10
stock blackjack_OnPlayerConnect(playerid)
{
    // --- line 456 ---
    // --- line 458 ---
    // _ = 197879844;
    // load playerid
    // --- line 459 ---
    goto lbl_0x489e4; // jump 0x489e4
    // load var_-4
    // _ = 5;
    goto lbl_0x48acc; // jsgeq 0x48acc
    // --- line 461 ---
    // _ = 197863844;
    // load playerid
    // load var_-4
    // --- line 462 ---
    // _ = 197863844;
    // load playerid
    // load var_-4
    goto lbl_0x489d8; // jump 0x489d8
    // stack 4
    // --- line 464 ---
    OnPlayerLogin(4, playerid);
    // --- line 466 ---
    prom_OnPlayerConnect(4, playerid);
    return 1;
}


// AMX 0x48b10-0x4910c
public OnPlayerLogin(playerid)
{
    // --- line 481 ---
    // --- line 483 ---
    // stack -4
    // _ = 181530104;
    // load playerid
    // var_-4 = _;
    // --- line 484 ---
    // --- line 485 ---
    // stack -1024
    // --- line 487 ---
    mysql_format(166387936, -1032, 256, 197899152);
    // stack 24
    // --- line 488 ---
    mysql_query(166387936, -1032);
    // stack 16
    // var_-8 = _;
    // --- line 490 ---
    // stack -4
    cache_get_row_count(4, 1);
    // stack 8
    // var_-1036 = _;
    // --- line 491 ---
    // load var_-1036
    goto lbl_0x490c8; // jsgeq 0x490c8
    // --- line 493 ---
    goto lbl_0x48c74; // jump 0x48c74
    // load var_-1040
    goto lbl_0x490c0; // jsgeq 0x490c0
    // --- line 495 ---
    // stack -4
    cache_get_field_content_int(var_-1040, 197900128, 1);
    // stack 16
    // var_-1044 = _;
    // --- line 496 ---
    // stack -4
    cache_get_field_content_int(var_-1040, 197900140, 1);
    // stack 16
    // var_-1048 = _;
    // --- line 497 ---
    // stack -4
    cache_get_field_content_int(var_-1040, 197900184, 1);
    // stack 16
    // var_-1052 = _;
    // --- line 498 ---
    // stack -4
    cache_get_field_content_int(var_-1040, 197900244, 1);
    // stack 16
    // var_-1056 = _;
    // --- line 499 ---
    // stack -4
    cache_get_field_content_int(var_-1040, 197900304, 1);
    // stack 16
    // var_-1060 = _;
    // --- line 500 ---
    // stack -4
    cache_get_field_content_int(var_-1040, 197900348, 1);
    // stack 16
    // var_-1064 = _;
    // --- line 501 ---
    // stack -4
    cache_get_field_content_int(var_-1040, 197900396, 1);
    // stack 16
    // var_-1068 = _;
    // --- line 503 ---
    // stack -4
    // load var_-1056
    gettime(12);
    // stack 16
    // var_-1072 = _;
    // --- line 505 ---
    // load var_-1072
    goto lbl_0x48fd0; // jsgeq 0x48fd0
    // --- line 507 ---
    mysql_format(166387936, -1032, 256, 197900432);
    // stack 28
    // --- line 508 ---
    mysql_query(166387936, -1032);
    // stack 16
    // --- line 510 ---
    SetPlayerPromoTimer(12, playerid, var_-1044, var_-1056);
    goto lbl_0x490b0; // jump 0x490b0
    // --- line 514 ---
    RevokePromoPrize(16, var_-4, var_-1060, var_-1064, var_-1068);
    // --- line 516 ---
    mysql_format(166387936, -1032, 256, 197900668);
    // stack 24
    // --- line 517 ---
    mysql_query(166387936, -1032);
    // stack 16
    // --- line 518 ---
    SendClientMessage(playerid, -1, 197900828);
    // stack 16
    // stack 32
    goto lbl_0x48c68; // jump 0x48c68
    // stack 4
    // --- line 522 ---
    cache_delete(8, var_-8, 1);
    // stack 12
    // --- line 523 ---
    // stack 1036
    return 1;
}


// AMX 0x4910c-0x49158
stock blackjack_OnPlayerDisconnect(playerid, reason)
{
    // --- line 526 ---
    // --- line 528 ---
    StopPlayerPromoTimer(4, playerid);
    // --- line 530 ---
    prom_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


// AMX 0x49158-0x49258
stock GetPlayerIDFromAccountID(accountId)
{
    // --- line 545 ---
    // --- line 547 ---
    goto lbl_0x49180; // jump 0x49180
    // load var_-4
    // _ = 250;
    goto lbl_0x49240; // jsgeq 0x49240
    // --- line 549 ---
    IsPlayerConnected(var_-4);
    // stack 8
    if (!_) goto lbl_0x49214; // jzer
    // _ = 181530104;
    // load var_-4
    // load accountId
    goto lbl_0x49214; // jneq 0x49214
    goto lbl_0x49218; // jump 0x49218
    if (!_) goto lbl_0x49238; // jzer
    // --- line 551 ---
    // load var_-4
    // stack 4
    return 1;
    goto lbl_0x49174; // jump 0x49174
    // stack 4
    // --- line 554 ---
    return 1;
}


// AMX 0x49258-0x49564
stock SetPlayerPromoTimer(playerid, playerPromoSQLID, durationHours)
{
    // --- line 557 ---
    // --- line 559 ---
    // _ = 197879844;
    // load playerid
    // _ = 5;
    goto lbl_0x49348; // jsless 0x49348
    // --- line 561 ---
    // _ = 181530104;
    // load playerid
    // _ = 181530104;
    // load playerid
    printf(197901080);
    // stack 24
    // --- line 563 ---
    return 1;
    // --- line 566 ---
    // stack -4
    // _ = 197879844;
    // load playerid
    // var_-4 = _;
    // --- line 567 ---
    // _ = 197863844;
    // load playerid
    // load var_-4
    // load playerPromoSQLID
    // --- line 568 ---
    // _ = 197863844;
    // load playerid
    // load var_-4
    SetTimerEx(197901536, "4k", 1, 197901604);
    // stack 24
    // --- line 569 ---
    // _ = 197879844;
    // load playerid
    // --- line 571 ---
    // _ = 181530104;
    // load playerid
    // _ = 181530104;
    // load playerid
    printf(197901612);
    // stack 24
    // --- line 573 ---
    // stack 4
    return 1;
}


// AMX 0x49564-0x49ce4
stock StopPlayerPromoTimer(playerid)
{
    // --- line 576 ---
    // --- line 578 ---
    // stack -1024
    // --- line 579 ---
    // --- line 580 ---
    // stack -4
    // _ = 181530104;
    // load playerid
    // var_-1032 = _;
    // --- line 582 ---
    goto lbl_0x495f8; // jump 0x495f8
    // load var_-1036
    // _ = 197879844;
    // load playerid
    goto lbl_0x49ca0; // jsleq 0x49ca0
    // --- line 584 ---
    // stack -4
    // _ = 197863844;
    // load playerid
    // load var_-1036
    // var_-1040 = _;
    // --- line 585 ---
    // stack -4
    // _ = 197863844;
    // load playerid
    // load var_-1036
    // var_-1044 = _;
    // --- line 587 ---
    KillTimer(var_-1044);
    // stack 8
    // --- line 589 ---
    mysql_format(166387936, -1024, 256, 197902008);
    // stack 24
    // --- line 590 ---
    mysql_query(166387936, -1024);
    // stack 16
    // var_-1028 = _;
    // --- line 592 ---
    mysql_errno(1);
    // stack 8
    if (_) goto lbl_0x49818; // jnz
    cache_get_row_count(4, var_-1028);
    // stack 8
    goto lbl_0x49818; // jsleq 0x49818
    goto lbl_0x4981c; // jump 0x4981c
    if (!_) goto lbl_0x49c64; // jzer
    // --- line 594 ---
    // stack -4
    cache_get_field_content_int(0, 197902276, 1);
    // stack 16
    // var_-1048 = _;
    // --- line 595 ---
    // stack -4
    cache_get_field_content_int(0, 197902320, 1);
    // stack 16
    // var_-1052 = _;
    // --- line 597 ---
    // --- line 598 ---
    // --- line 599 ---
    // stack -512
    // --- line 600 ---
    mysql_format(166387936, -1572, 128, 197902380);
    // stack 24
    // --- line 601 ---
    mysql_query(166387936, -1572);
    // stack 16
    // var_-1060 = _;
    // --- line 602 ---
    mysql_errno(1);
    // stack 8
    if (_) goto lbl_0x499d4; // jnz
    cache_get_row_count(4, var_-1060);
    // stack 8
    goto lbl_0x499d4; // jsleq 0x499d4
    goto lbl_0x499d8; // jump 0x499d8
    if (!_) goto lbl_0x49a1c; // jzer
    // --- line 604 ---
    cache_get_field_content_int(0, 197902864, 1);
    // stack 16
    // var_-1056 = _;
    // --- line 606 ---
    cache_delete(8, var_-1060, 1);
    // stack 12
    // --- line 608 ---
    // stack -4
    // load var_-1056
    gettime(12);
    // stack 16
    // var_-1576 = _;
    // --- line 609 ---
    // load var_-1576
    goto lbl_0x49b08; // jsleq 0x49b08
    // --- line 611 ---
    // stack -4
    min(8, var_-1052, var_-1576);
    // stack 12
    // var_-1580 = _;
    // --- line 612 ---
    // load var_-1580
    goto lbl_0x49b6c; // jsleq 0x49b6c
    // --- line 614 ---
    mysql_format(166387936, -1024, 256, 197902924);
    // stack 28
    // --- line 617 ---
    mysql_query(166387936, -1024);
    // stack 16
    // --- line 618 ---
    // _ = 181530104;
    // load playerid
    printf(197903160, -1040);
    // stack 24
    // stack 536
    // --- line 621 ---
    cache_delete(8, var_-1028, 1);
    // stack 12
    // stack 8
    goto lbl_0x495ec; // jump 0x495ec
    // stack 4
    // --- line 623 ---
    // _ = 197879844;
    // load playerid
    // stack 1032
    return 1;
}


// AMX 0x49ce4-0x4a69c
stock RevokePromoPrize(accountId, prizeType, prizeValue, promoIdForCarRevoke)
{
    // --- line 626 ---
    // --- line 628 ---
    // stack -4
    GetPlayerIDFromAccountID(4, accountId);
    // var_-4 = _;
    // --- line 629 ---
    // load var_-4
    if (!_) goto lbl_0x49d48; // jzer
    // stack 4
    return 1;
    // --- line 631 ---
    // stack -1024
    // --- line 632 ---
    // --- line 634 ---
    // load prizeType
    switch (_) // -> 0x4a5e8
    // --- line 638 ---
    // stack -4
    // _ = 181530104;
    // load var_-4
    // var_-1036 = _;
    // --- line 639 ---
    // stack -4
    // load prizeValue
    // var_-1040 = _;
    // --- line 641 ---
    // load var_-1040
    goto lbl_0x49ec0; // jsleq 0x49ec0
    // --- line 643 ---
    // _ = 181530104;
    // load var_-4
    // --- line 644 ---
    UpdatePlayerDatabaseInt(12, var_-4, 197903660, 0);
    // --- line 645 ---
    SendClientMessage(var_-4, -1, 197903684);
    // stack 20
    goto lbl_0x49f58; // jump 0x49f58
    // --- line 649 ---
    // load prizeValue
    GivePlayerMoneyEx(20, var_-4);
    // --- line 650 ---
    SendClientMessage(var_-4, -1, 197904192);
    // stack 20
    // stack 8
    goto lbl_0x4a614; // jump 0x4a614
    // --- line 655 ---
    // stack -4
    // _ = 181530104;
    // load var_-4
    // var_-1036 = _;
    // --- line 656 ---
    // stack -4
    // load prizeValue
    // var_-1040 = _;
    // --- line 658 ---
    // load var_-1040
    goto lbl_0x4a0c0; // jsleq 0x4a0c0
    // --- line 660 ---
    // _ = 181530104;
    // load var_-4
    GivePlayerDonateRub(20, var_-4);
    // --- line 661 ---
    SendClientMessage(var_-4, -1, 197904584);
    // stack 20
    goto lbl_0x4a158; // jump 0x4a158
    // --- line 665 ---
    // load prizeValue
    GivePlayerDonateRub(20, var_-4);
    // --- line 666 ---
    SendClientMessage(var_-4, -1, 197905120);
    // stack 20
    // stack 8
    goto lbl_0x4a614; // jump 0x4a614
    // --- line 671 ---
    mysql_format(166387936, -1028, 256, 197905516);
    // stack 32
    // --- line 674 ---
    mysql_query(166387936, -1028);
    // stack 16
    // var_-1032 = _;
    // --- line 676 ---
    // stack -4
    cache_get_row_count(4, 1);
    // stack 8
    // var_-1036 = _;
    // --- line 677 ---
    // load var_-1036
    goto lbl_0x4a58c; // jsgeq 0x4a58c
    // --- line 679 ---
    // stack -4
    cache_get_field_content_int(0, 197906000, 1);
    // stack 16
    // var_-1040 = _;
    // --- line 680 ---
    // stack -4
    cache_get_field_content_int(0, 197906012, 1);
    // stack 16
    // var_-1044 = _;
    // --- line 682 ---
    mysql_format(166387936, -1028, 256, 197906056);
    // stack 24
    // --- line 683 ---
    mysql_query(166387936, -1028);
    // stack 16
    // --- line 685 ---
    IsValidVehicle(4, var_-1044);
    // stack 8
    if (!_) goto lbl_0x4a398; // jzer
    // --- line 687 ---
    n_veh_DestroyVehicle(4, var_-1044);
    goto lbl_0x4a4e0; // jump 0x4a4e0
    // --- line 692 ---
    goto lbl_0x4a3b8; // jump 0x4a3b8
    // load var_-1048
    // _ = 15000;
    goto lbl_0x4a4d8; // jsgeq 0x4a4d8
    // --- line 694 ---
    // _ = 182230856;
    // load var_-1048
    // load var_-1040
    goto lbl_0x4a474; // jneq 0x4a474
    // _ = 182230856;
    // load var_-1048
    IsValidVehicle(4);
    // stack 8
    if (!_) goto lbl_0x4a474; // jzer
    goto lbl_0x4a478; // jump 0x4a478
    if (!_) goto lbl_0x4a4d0; // jzer
    // --- line 696 ---
    // _ = 182230856;
    // load var_-1048
    n_veh_DestroyVehicle(4);
    // --- line 697 ---
    goto lbl_0x4a4d8; // jump 0x4a4d8
    goto lbl_0x4a3ac; // jump 0x4a3ac
    // stack 4
    // --- line 702 ---
    SendClientMessage(var_-4, -1, 197906212);
    // stack 16
    // --- line 703 ---
    // _ = 181530104;
    // load var_-4
    printf(197906500, -1040);
    // stack 24
    // stack 8
    // --- line 706 ---
    cache_delete(8, var_-1032, 1);
    // stack 12
    // stack 4
    goto lbl_0x4a614; // jump 0x4a614
    // --- line 710 ---
    // stack 1032
    return 1;
    goto lbl_0x4a614; // jump 0x4a614
    // casetbl cases=5
    // --- line 713 ---
    // _ = 181530104;
    // load var_-4
    printf(197906968, 16);
    // stack 24
    // --- line 714 ---
    // stack 1032
    return 1;
}


// AMX 0x4a69c-0x4a93c
stock GetPromoCodeDataByString()
{
    // --- line 734 ---
    // --- line 736 ---
    goto lbl_0x4a6c4; // jump 0x4a6c4
    // load var_-4
    goto lbl_0x4a928; // jsgeq 0x4a928
    // --- line 738 ---
    // _ = 197791640;
    // load var_-4
    strcmp(16);
    // stack 20
    if (_) goto lbl_0x4a920; // jnz
    // --- line 740 ---
    // load var_16
    // _ = 197791640;
    // load var_-4
    // --- line 741 ---
    // _ = 197791640;
    // load var_-4
    // load var_16
    strmid(20);
    // stack 24
    // --- line 742 ---
    // load var_16
    // _ = 197791640;
    // load var_-4
    // --- line 743 ---
    // load var_16
    // _ = 197791640;
    // load var_-4
    // --- line 744 ---
    // load var_16
    // _ = 197791640;
    // load var_-4
    // --- line 745 ---
    // stack 4
    return 1;
    goto lbl_0x4a6b8; // jump 0x4a6b8
    // stack 4
    // --- line 748 ---
    return 1;
}


// AMX 0x4a93c-0x4aa24
stock GetPromoCodeIndexByString()
{
    // --- line 751 ---
    // --- line 753 ---
    goto lbl_0x4a964; // jump 0x4a964
    // load var_-4
    goto lbl_0x4aa0c; // jsgeq 0x4aa0c
    // --- line 755 ---
    // _ = 197791640;
    // load var_-4
    strcmp(16);
    // stack 20
    if (_) goto lbl_0x4aa04; // jnz
    // --- line 757 ---
    // load var_-4
    // stack 4
    return 1;
    goto lbl_0x4a958; // jump 0x4a958
    // stack 4
    // --- line 760 ---
    return 1;
}


// AMX 0x4aa24-0x4ad0c
stock GivePromoCar(playerid, modelid, promoSqlId)
{
    // --- line 763 ---
    // --- line 765 ---
    // --- line 766 ---
    // stack -12
    // --- line 767 ---
    GetPlayerPos(playerid, -20);
    // stack 20
    // --- line 768 ---
    // stack -4
    // var_-24 = _;
    // --- line 769 ---
    // stack -4
    // var_-28 = _;
    // --- line 770 ---
    // stack -4
    // var_-32 = _;
    // --- line 771 ---
    // --- line 772 ---
    // stack -1024
    // --- line 807 ---
    gettime(12);
    // stack 16
    // _ = 181530104;
    // load playerid
    format(-1060, 256, 197907244);
    // stack 60
    // --- line 810 ---
    mysql_query(166387936, -1060);
    // stack 16
    // var_-1064 = _;
    // --- line 812 ---
    cache_delete(8, var_-1064, 1);
    // stack 12
    // --- line 813 ---
    // stack 1068
    return 1;
}


// AMX 0x4ad0c-0x4b528
stock ShowPromoCreationConfirmation(playerid)
{
    // --- line 816 ---
    // --- line 818 ---
    // stack -4096
    // --- line 819 ---
    // stack -1024
    // --- line 820 ---
    // stack -128
    // --- line 821 ---
    // _ = 197806844;
    // load playerid
    strmid(20, -5248);
    // stack 24
    // --- line 822 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-5252 = _;
    // --- line 823 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-5256 = _;
    // --- line 825 ---
    format(-4096, 1024, 197907992);
    // stack 16
    // --- line 826 ---
    format(-5120, 256, 197908256);
    // stack 20
    // --- line 827 ---
    strcat(-4096, -5120);
    // stack 16
    // --- line 829 ---
    // stack -128
    // --- line 830 ---
    // load var_-5256
    if (_) goto lbl_0x4af80; // jnz
    // --- line 831 ---
    format(-5384, 32, 197908376);
    // stack 16
    goto lbl_0x4afbc; // jump 0x4afbc
    // --- line 833 ---
    format(-5384, 32, 197908420);
    // stack 20
    // --- line 835 ---
    format(-5120, 256, 197908432);
    // stack 20
    // --- line 837 ---
    strcat(-4096, -5120);
    // stack 16
    // --- line 839 ---
    strcat(-4096, 197908600);
    // stack 16
    // --- line 840 ---
    goto lbl_0x4b080; // jump 0x4b080
    // load var_-5388
    goto lbl_0x4b4c4; // jsgeq 0x4b4c4
    // --- line 842 ---
    // stack -4
    // _ = 197842844;
    // load playerid
    // load var_-5388
    // var_-5392 = _;
    // --- line 843 ---
    // stack -4
    // _ = 197842844;
    // load playerid
    // load var_-5388
    // var_-5396 = _;
    // --- line 844 ---
    // stack -4
    // _ = 197842844;
    // load playerid
    // load var_-5388
    // var_-5400 = _;
    // --- line 846 ---
    // stack -512
    // --- line 847 ---
    // stack -256
    // --- line 849 ---
    // load var_-5400
    if (_) goto lbl_0x4b270; // jnz
    // --- line 851 ---
    format(-6168, 64, 197908712);
    // stack 16
    goto lbl_0x4b2ac; // jump 0x4b2ac
    // --- line 855 ---
    format(-6168, 64, 197908748);
    // stack 20
    // --- line 858 ---
    // load var_-5392
    switch (_) // -> 0x4b45c
    // --- line 862 ---
    // load var_-5388
    format(-5912, 128, 197908784);
    // stack 28
    goto lbl_0x4b480; // jump 0x4b480
    // --- line 866 ---
    // load var_-5388
    format(-5912, 128, 197908984);
    // stack 28
    goto lbl_0x4b480; // jump 0x4b480
    // --- line 870 ---
    // load var_-5388
    format(-5912, 128, 197909188);
    // stack 32
    goto lbl_0x4b480; // jump 0x4b480
    // casetbl cases=4
    // --- line 873 ---
    strcat(-4096, -5912);
    // stack 16
    // stack 780
    goto lbl_0x4b074; // jump 0x4b074
    // stack 4
    // --- line 876 ---
    fg_ShowPlayerDialog(28, playerid, "usesRenters", 0, 197909448, -4096, 197909700, 197909732);
    // stack 5384
    return 1;
}


// AMX 0x4b528-0x4be6c
stock CreatePromoCodeInDatabase(playerid)
{
    // --- line 881 ---
    // --- line 883 ---
    // stack -4096
    // --- line 884 ---
    // stack -128
    // --- line 885 ---
    // _ = 197806844;
    // load playerid
    strmid(20, -4224);
    // stack 24
    // --- line 886 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-4228 = _;
    // --- line 887 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-4232 = _;
    // --- line 888 ---
    // --- line 889 ---
    // --- line 890 ---
    // stack -1024
    // --- line 892 ---
    mysql_format(166387936, -4096, 1024, 197909760);
    // stack 36
    // --- line 896 ---
    mysql_query(166387936, -4096);
    // stack 16
    // var_-4240 = _;
    // --- line 897 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x4b8a0; // jzer
    // --- line 899 ---
    mysql_errno(1);
    // stack 8
    format(-5264, 256, 197910164);
    // stack 20
    // --- line 900 ---
    SendClientMessage(playerid, -1, -5264);
    // stack 16
    // --- line 901 ---
    mysql_errno(1);
    // stack 8
    printf(197910444);
    // stack 12
    // --- line 902 ---
    cache_delete(8, var_-4240, 1);
    // stack 12
    // --- line 903 ---
    // stack 5264
    return 1;
    // --- line 905 ---
    cache_insert_id(4, var_-4240);
    // stack 8
    // var_-4236 = _;
    // --- line 906 ---
    cache_delete(8, var_-4240, 1);
    // stack 12
    // --- line 908 ---
    // load var_-4236
    if (_) goto lbl_0x4b980; // jnz
    // --- line 910 ---
    SendClientMessage(playerid, -1, 197910700);
    // stack 16
    // --- line 911 ---
    printf(197910968, -4224);
    // stack 12
    // --- line 912 ---
    // stack 5264
    return 1;
    // --- line 915 ---
    goto lbl_0x4b9a0; // jump 0x4b9a0
    // load var_-5268
    goto lbl_0x4bd00; // jsgeq 0x4bd00
    // --- line 917 ---
    // stack -4
    // _ = 197842844;
    // load playerid
    // load var_-5268
    // var_-5272 = _;
    // --- line 918 ---
    // stack -4
    // _ = 197842844;
    // load playerid
    // load var_-5268
    // var_-5276 = _;
    // --- line 919 ---
    // stack -4
    // _ = 197842844;
    // load playerid
    // load var_-5268
    // var_-5280 = _;
    // --- line 921 ---
    mysql_format(166387936, -4096, 1024, 197911240);
    // stack 40
    // --- line 925 ---
    mysql_query(166387936, -4096);
    // stack 16
    // --- line 926 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x4bcf0; // jzer
    // --- line 928 ---
    mysql_errno(1);
    // stack 8
    // load var_-5268
    format(-5264, 256, 197911760);
    // stack 24
    // --- line 929 ---
    SendClientMessage(playerid, -1, -5264);
    // stack 16
    // --- line 930 ---
    mysql_errno(1);
    // stack 8
    printf(197912028, -4236);
    // stack 20
    // stack 12
    goto lbl_0x4b994; // jump 0x4b994
    // stack 4
    // --- line 934 ---
    format(-5264, 256, 197912400);
    // stack 24
    // --- line 935 ---
    SendClientMessage(playerid, -1, -5264);
    // stack 16
    // --- line 936 ---
    LoadPromoCodesFromDatabase(0);
    // --- line 938 ---
    // _ = 197806844;
    // load playerid
    // --- line 939 ---
    // _ = 197806844;
    // load playerid
    // --- line 940 ---
    // _ = 197806844;
    // load playerid
    // --- line 942 ---
    // stack 5264
    return 1;
}


// AMX 0x4be6c-0x57dc0
stock blackjack_OnDialogResponse(playerid, dialogid, response, listitem)
{
    // --- line 945 ---
    // --- line 947 ---
    // load dialogid
    switch (_) // -> 0x57cfc
    // --- line 951 ---
    // load response
    if (!_) goto lbl_0x4c2a8; // jzer
    // --- line 953 ---
    // load listitem
    switch (_) // -> 0x4c27c
    // --- line 957 ---
    pc_cmd_mypromo(8, playerid, 197912644);
    goto lbl_0x4c2a8; // jump 0x4c2a8
    // --- line 994 ---
    // stack -4096
    // --- line 995 ---
    // stack -4
    GetPromoLevelForOwner(4, playerid);
    // var_-4100 = _;
    // --- line 996 ---
    // stack -128
    // --- line 997 ---
    // stack -1320
    // --- line 1002 ---
    // --- line 1004 ---
    goto lbl_0x4bfb4; // jump 0x4bfb4
    // load var_-5552
    // _ = 10;
    goto lbl_0x4c10c; // jsgeq 0x4c10c
    // --- line 1006 ---
    // load var_-5552
    goto lbl_0x4c038; // jsless 0x4c038
    // --- line 1008 ---
    format(-4228, 32, 197913900);
    // stack 16
    goto lbl_0x4c06c; // jump 0x4c06c
    // --- line 1012 ---
    format(-4228, 32, 197913960);
    // stack 16
    // --- line 1014 ---
    // load var_-5552
    // load var_-5552
    format(-4096, 1024, 197914020);
    // stack 32
    goto lbl_0x4bfa8; // jump 0x4bfa8
    // stack 4
    // --- line 1017 ---
    strlen(-4096);
    // stack 8
    goto lbl_0x4c1a0; // jsgeq 0x4c1a0
    // --- line 1019 ---
    strlen(-4096);
    // stack 8
    // _ = 1;
    // --- line 1022 ---
    fg_ShowPlayerDialog(28, playerid, "ers", 2, 197914156, -4096, 197914220, 197914256);
    // stack 5548
    goto lbl_0x4c2a8; // jump 0x4c2a8
    // --- line 1026 ---
    fg_ShowPlayerDialog(28, playerid, "enters", 0, 197914280, 197914352, 197916492, 197916516);
    goto lbl_0x4c2a8; // jump 0x4c2a8
    // --- line 1034 ---
    pc_cmd_mypromo(8, playerid, 197916520);
    goto lbl_0x4c2a8; // jump 0x4c2a8
    // casetbl cases=5
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1041 ---
    // load response
    if (!_) goto lbl_0x4ca4c; // jzer
    // --- line 1043 ---
    // stack -4
    // load listitem
    // var_-4 = _;
    // --- line 1044 ---
    // stack -4
    GetPromoLevelForOwner(4, playerid);
    // var_-8 = _;
    // --- line 1045 ---
    // --- line 1046 ---
    // stack -1024
    // --- line 1048 ---
    // _ = 181530104;
    // load playerid
    mysql_format(166387936, -1044, 256, 197916524);
    // stack 24
    // --- line 1049 ---
    // stack -4
    mysql_query(166387936, -1044);
    // stack 16
    // var_-1048 = _;
    // --- line 1050 ---
    cache_get_row_count(4, var_-1048);
    // stack 8
    if (_) goto lbl_0x4c4a0; // jnz
    // --- line 1052 ---
    SendClientMessage(playerid, -1, 197916932);
    // stack 16
    // --- line 1053 ---
    cache_delete(8, var_-1048, 1);
    // stack 12
    // --- line 1054 ---
    // stack 1048
    return 1;
    // --- line 1056 ---
    cache_get_field_content_int(0, 197917084, 1);
    // stack 16
    // var_-20 = _;
    // --- line 1057 ---
    cache_get_field_content_int(0, 197917096, 1);
    // stack 16
    // var_-12 = _;
    // --- line 1058 ---
    cache_get_field_content_int(0, 197917144, 1);
    // stack 16
    // var_-16 = _;
    // --- line 1059 ---
    cache_delete(8, var_-1048, 1);
    // stack 12
    // --- line 1061 ---
    // load var_-4
    // load var_-8
    goto lbl_0x4c61c; // jsgeq 0x4c61c
    // --- line 1063 ---
    SendClientMessage(playerid, -1, 197917200);
    // stack 16
    // --- line 1064 ---
    pc_cmd_mypromo(8, playerid, 197917488);
    // --- line 1065 ---
    // stack 1048
    return 1;
    // --- line 1068 ---
    // load var_-4
    // _ = 10;
    goto lbl_0x4c6a8; // jsleq 0x4c6a8
    // --- line 1070 ---
    SendClientMessage(playerid, -1, 197917492);
    // stack 16
    // --- line 1071 ---
    pc_cmd_mypromo(8, playerid, 197917716);
    // --- line 1072 ---
    // stack 1048
    return 1;
    // --- line 1075 ---
    // stack -4
    // _ = 197789848;
    // load var_-4
    // var_-1052 = _;
    // --- line 1076 ---
    // stack -4
    // _ = 197789848;
    // load var_-4
    // var_-1056 = _;
    // --- line 1077 ---
    // stack -4
    // _ = 197789848;
    // load var_-4
    // var_-1060 = _;
    // --- line 1078 ---
    // stack -2048
    // --- line 1080 ---
    // load var_-12
    goto lbl_0x4c878; // jsless 0x4c878
    // --- line 1082 ---
    // load var_-4
    if (!_) goto lbl_0x4c7ec; // jzer
    goto lbl_0x4c820; // jump 0x4c820
    // _ = 197789848;
    // load var_-4
    format(-3108, 512, 197917720);
    // stack 28
    goto lbl_0x4c9c0; // jump 0x4c9c0
    // --- line 1084 ---
    // load var_-16
    goto lbl_0x4c950; // jsless 0x4c950
    // --- line 1086 ---
    // load var_-4
    if (!_) goto lbl_0x4c8c4; // jzer
    goto lbl_0x4c8f8; // jump 0x4c8f8
    // _ = 197789848;
    // load var_-4
    format(-3108, 512, 197918652);
    // stack 28
    goto lbl_0x4c9c0; // jump 0x4c9c0
    // --- line 1090 ---
    SendClientMessage(playerid, -1, 197919572);
    // stack 16
    // --- line 1091 ---
    pc_cmd_mypromo(8, playerid, 197919884);
    // --- line 1092 ---
    // stack 3108
    return 1;
    // --- line 1095 ---
    fg_ShowPlayerDialog(28, playerid, "rs", 0, 197919888, -3108, 197920032, 197920056);
    // --- line 1096 ---
    // _ = 197790640;
    // load playerid
    // load var_-4
    // stack 3108
    goto lbl_0x4ca70; // jump 0x4ca70
    // --- line 1100 ---
    pc_cmd_mypromo(8, playerid, 197920080);
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1105 ---
    // load response
    if (!_) goto lbl_0x4d030; // jzer
    // --- line 1107 ---
    // stack -4
    // _ = 197790640;
    // load playerid
    // var_-4 = _;
    // --- line 1108 ---
    // --- line 1109 ---
    // stack -1024
    // --- line 1111 ---
    // _ = 181530104;
    // load playerid
    mysql_format(166387936, -1040, 256, 197920084);
    // stack 24
    // --- line 1112 ---
    // stack -4
    mysql_query(166387936, -1040);
    // stack 16
    // var_-1044 = _;
    // --- line 1113 ---
    cache_get_row_count(4, var_-1044);
    // stack 8
    if (_) goto lbl_0x4cc48; // jnz
    // --- line 1115 ---
    SendClientMessage(playerid, -1, 197920492);
    // stack 16
    // --- line 1116 ---
    cache_delete(8, var_-1044, 1);
    // stack 12
    // --- line 1117 ---
    // stack 1044
    return 1;
    // --- line 1119 ---
    cache_get_field_content_int(0, 197920644, 1);
    // stack 16
    // var_-16 = _;
    // --- line 1120 ---
    cache_get_field_content_int(0, 197920656, 1);
    // stack 16
    // var_-8 = _;
    // --- line 1121 ---
    cache_get_field_content_int(0, 197920704, 1);
    // stack 16
    // var_-12 = _;
    // --- line 1122 ---
    cache_delete(8, var_-1044, 1);
    // stack 12
    // --- line 1124 ---
    // stack -4
    // _ = 197789848;
    // load var_-4
    // var_-1048 = _;
    // --- line 1125 ---
    // stack -4
    // _ = 197789848;
    // load var_-4
    // var_-1052 = _;
    // --- line 1127 ---
    // load var_-8
    goto lbl_0x4cebc; // jsless 0x4cebc
    // --- line 1129 ---
    mysql_format(166387936, -1040, 256, 197920760);
    // stack 28
    // --- line 1130 ---
    mysql_query(166387936, -1040);
    // stack 16
    // --- line 1131 ---
    SavePromoLevelPrizes(12, playerid, var_-16, var_-4);
    // --- line 1132 ---
    SendClientMessage(playerid, -1, 197920996);
    // stack 16
    goto lbl_0x4cffc; // jump 0x4cffc
    // --- line 1134 ---
    // load var_-12
    goto lbl_0x4cfc8; // jsless 0x4cfc8
    // --- line 1136 ---
    mysql_format(166387936, -1040, 256, 197921276);
    // stack 32
    // --- line 1137 ---
    mysql_query(166387936, -1040);
    // stack 16
    // --- line 1138 ---
    SavePromoLevelPrizes(12, playerid, var_-16, var_-4);
    // --- line 1139 ---
    SendClientMessage(playerid, -1, 197921672);
    // stack 16
    goto lbl_0x4cffc; // jump 0x4cffc
    // --- line 1143 ---
    SendClientMessage(playerid, -1, 197921936);
    // stack 16
    // --- line 1145 ---
    pc_cmd_mypromo(8, playerid, 197922248);
    // stack 1052
    goto lbl_0x4d054; // jump 0x4d054
    // --- line 1149 ---
    pc_cmd_mypromo(8, playerid, 197922252);
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1154 ---
    // load response
    if (!_) goto lbl_0x4d094; // jzer
    // --- line 1156 ---
    pc_cmd_mypromo(8, playerid, 197922256);
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1161 ---
    // load response
    if (!_) goto lbl_0x4d0f8; // jzer
    // --- line 1163 ---
    SendClientMessage(playerid, -1, 197922260);
    // stack 16
    // --- line 1164 ---
    return 1;
    // --- line 1167 ---
    // load listitem
    switch (_) // -> 0x4d650
    // --- line 1171 ---
    pc_cmd_bcode(8, playerid, 197922448);
    goto lbl_0x4d67c; // jump 0x4d67c
    // --- line 1175 ---
    SendClientMessage(playerid, -1, 197922452);
    // stack 16
    // --- line 1176 ---
    pc_cmd_promo(8, playerid, 197922652);
    goto lbl_0x4d67c; // jump 0x4d67c
    // --- line 1180 ---
    HasPlayerCreatedPromo(4, playerid);
    if (!_) goto lbl_0x4d1e8; // jzer
    // --- line 1182 ---
    pc_cmd_mypromo(8, playerid, 197922656);
    goto lbl_0x4d234; // jump 0x4d234
    // --- line 1186 ---
    fg_ShowPlayerDialog(28, playerid, "esRenters", 1, 197922660, 197922768, 197925608, 197925632);
    goto lbl_0x4d67c; // jump 0x4d67c
    // --- line 1207 ---
    // stack -1024
    // --- line 1208 ---
    // --- line 1209 ---
    // stack -4096
    // --- line 1210 ---
    // stack -4
    // _ = 181530104;
    // load playerid
    // var_-5128 = _;
    // --- line 1211 ---
    // --- line 1213 ---
    mysql_format(166387936, -1024, 256, 197925660);
    // stack 24
    // --- line 1217 ---
    mysql_query(166387936, -1024);
    // stack 16
    // var_-1028 = _;
    // --- line 1219 ---
    cache_get_row_count(4, var_-1028);
    // stack 8
    goto lbl_0x4d538; // jsgeq 0x4d538
    // --- line 1221 ---
    cache_get_row_count(4, var_-1028);
    // stack 8
    // var_-5132 = _;
    // --- line 1222 ---
    cache_get_field_content(20, 0, 197926416, 1, 1);
    // stack 24
    format(-5124, 1024, 197926304);
    // stack 20
    // --- line 1223 ---
    goto lbl_0x4d458; // jump 0x4d458
    // load var_-5136
    goto lbl_0x4d528; // jsgeq 0x4d528
    // --- line 1225 ---
    // stack -128
    // --- line 1226 ---
    cache_get_field_content(20, var_-5136, 197926436, -5264, 32, 32);
    // stack 24
    // --- line 1227 ---
    format(-5124, 1024, 197926456);
    // stack 24
    // stack 128
    goto lbl_0x4d44c; // jump 0x4d44c
    // stack 4
    goto lbl_0x4d56c; // jump 0x4d56c
    // --- line 1232 ---
    format(-5124, 1024, 197926580);
    // stack 16
    // --- line 1234 ---
    cache_delete(8, var_-1028, 1);
    // stack 12
    // --- line 1236 ---
    // stack -512
    // --- line 1237 ---
    format(-5644, 128, 197926780);
    // stack 20
    // --- line 1238 ---
    fg_ShowPlayerDialog(28, playerid, "Renters", 2, -5644, -5124, 197926920, 197926932);
    // stack 5644
    goto lbl_0x4d67c; // jump 0x4d67c
    // casetbl cases=5
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1244 ---
    // load response
    if (!_) goto lbl_0x4d6e0; // jzer
    // --- line 1246 ---
    SendClientMessage(playerid, -1, 197926936);
    // stack 16
    // --- line 1247 ---
    return 1;
    // --- line 1250 ---
    strlen(var_28);
    // stack 8
    if (_) goto lbl_0x4d79c; // jnz
    // --- line 1252 ---
    SendClientMessage(playerid, -1, 197927124);
    // stack 16
    // --- line 1254 ---
    fg_ShowPlayerDialog(28, playerid, "esRenters", 1, 197927404, 197927512, 197930352, 197930376);
    // --- line 1271 ---
    return 1;
    // --- line 1274 ---
    // stack -4
    strlen(var_28);
    // stack 8
    // var_-4 = _;
    // --- line 1275 ---
    // load var_28
    // _ = 64;
    goto lbl_0x4d860; // jeq 0x4d860
    // --- line 1277 ---
    SendClientMessage(playerid, -1, 197930404);
    // stack 16
    // --- line 1278 ---
    pc_cmd_promo(8, playerid, 197930676);
    // --- line 1279 ---
    // stack 4
    return 1;
    // --- line 1282 ---
    // load var_-4
    // _ = 3;
    goto lbl_0x4d8ec; // jsgeq 0x4d8ec
    // --- line 1284 ---
    SendClientMessage(playerid, -1, 197930680);
    // stack 16
    // --- line 1285 ---
    pc_cmd_promo(8, playerid, 197930964);
    // --- line 1286 ---
    // stack 4
    return 1;
    // --- line 1290 ---
    goto lbl_0x4d90c; // jump 0x4d90c
    // load var_-8
    goto lbl_0x4db88; // jsgeq 0x4db88
    // --- line 1292 ---
    // stack -4
    // load var_-8
    // var_-12 = _;
    // --- line 1294 ---
    // load var_-12
    // _ = 97;
    goto lbl_0x4d994; // jsless 0x4d994
    // load var_-12
    // _ = 122;
    goto lbl_0x4d994; // jsgrtr 0x4d994
    goto lbl_0x4d998; // jump 0x4d998
    if (_) goto lbl_0x4daf4; // jnz
    // load var_-12
    // _ = 65;
    goto lbl_0x4d9e0; // jsless 0x4d9e0
    // load var_-12
    // _ = 90;
    goto lbl_0x4d9e0; // jsgrtr 0x4d9e0
    goto lbl_0x4d9e4; // jump 0x4d9e4
    if (_) goto lbl_0x4daf4; // jnz
    // load var_-12
    // _ = 1040;
    goto lbl_0x4da2c; // jsless 0x4da2c
    // load var_-12
    // _ = 1103;
    goto lbl_0x4da2c; // jsgrtr 0x4da2c
    goto lbl_0x4da30; // jump 0x4da30
    if (_) goto lbl_0x4daf4; // jnz
    // load var_-12
    // _ = 1024;
    goto lbl_0x4da78; // jsless 0x4da78
    // load var_-12
    // _ = 1039;
    goto lbl_0x4da78; // jsgrtr 0x4da78
    goto lbl_0x4da7c; // jump 0x4da7c
    if (_) goto lbl_0x4daf4; // jnz
    // load var_-12
    // _ = 48;
    goto lbl_0x4dac4; // jsless 0x4dac4
    // load var_-12
    // _ = 57;
    goto lbl_0x4dac4; // jsgrtr 0x4dac4
    goto lbl_0x4dac8; // jump 0x4dac8
    if (_) goto lbl_0x4daf4; // jnz
    // load var_-12
    if (_) goto lbl_0x4daf4; // jnz
    goto lbl_0x4dafc; // jump 0x4dafc
    if (!_) goto lbl_0x4db78; // jzer
    // --- line 1302 ---
    SendClientMessage(playerid, -1, 197930968);
    // stack 16
    // --- line 1303 ---
    pc_cmd_promo(8, playerid, 197931408);
    // --- line 1304 ---
    // stack 12
    return 1;
    // stack 4
    goto lbl_0x4d900; // jump 0x4d900
    // stack 4
    // --- line 1307 ---
    OnPromoCodeCheckComplete(8, playerid, var_28);
    // --- line 1308 ---
    // stack 4
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1312 ---
    // load response
    if (!_) goto lbl_0x4dc30; // jzer
    // --- line 1314 ---
    SendClientMessage(playerid, -1, 197931412);
    // stack 16
    // --- line 1315 ---
    return 1;
    // --- line 1317 ---
    strlen(var_28);
    // stack 8
    if (_) goto lbl_0x4dcc4; // jnz
    // --- line 1319 ---
    SendClientMessage(playerid, -1, 197931600);
    // stack 16
    // --- line 1320 ---
    pc_cmd_addcpromo(8, playerid, 197931836);
    // --- line 1321 ---
    return 1;
    // --- line 1323 ---
    strfind(var_28, 197931840, 1);
    // stack 20
    // _ = -1;
    goto lbl_0x4dd78; // jeq 0x4dd78
    // --- line 1325 ---
    SendClientMessage(playerid, -1, 197931848);
    // stack 16
    // --- line 1326 ---
    pc_cmd_addcpromo(8, playerid, 197932116);
    // --- line 1327 ---
    return 1;
    // --- line 1329 ---
    strlen(var_28);
    // stack 8
    // _ = 32;
    goto lbl_0x4de90; // jsleq 0x4de90
    // --- line 1331 ---
    // stack -512
    // --- line 1332 ---
    format(-512, 128, 197932120);
    // stack 20
    // --- line 1333 ---
    SendClientMessage(playerid, -1, -512);
    // stack 16
    // --- line 1334 ---
    pc_cmd_addcpromo(8, playerid, 197932416);
    // --- line 1335 ---
    // stack 512
    return 1;
    // --- line 1338 ---
    GetPromoCodeIndexByString(4, var_28);
    // _ = -1;
    goto lbl_0x4df24; // jeq 0x4df24
    // --- line 1340 ---
    SendClientMessage(playerid, -1, 197932420);
    // stack 16
    // --- line 1341 ---
    pc_cmd_addcpromo(8, playerid, 197932664);
    // --- line 1342 ---
    return 1;
    // --- line 1345 ---
    // _ = 197806844;
    // load playerid
    strmid(20);
    // stack 24
    // --- line 1346 ---
    // _ = 197806844;
    // load playerid
    // --- line 1348 ---
    fg_ShowPlayerDialog(28, playerid, "LoadHousesRenters", 1, 197932668, 197932864, 197932996, 197933020);
    // --- line 1349 ---
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1353 ---
    // load response
    if (!_) goto lbl_0x4e08c; // jzer
    // --- line 1355 ---
    SendClientMessage(playerid, -1, 197933048);
    // stack 16
    // --- line 1356 ---
    return 1;
    // --- line 1358 ---
    // stack -4
    strval(4, var_28);
    // stack 8
    // var_-4 = _;
    // --- line 1359 ---
    // load var_-4
    // _ = 1;
    goto lbl_0x4e100; // jsless 0x4e100
    // load var_-4
    // _ = 5;
    goto lbl_0x4e100; // jsgrtr 0x4e100
    goto lbl_0x4e108; // jump 0x4e108
    if (!_) goto lbl_0x4e1a8; // jzer
    // --- line 1361 ---
    SendClientMessage(playerid, -1, 197933236);
    // stack 16
    // --- line 1362 ---
    fg_ShowPlayerDialog(28, playerid, "LoadHousesRenters", 1, 197933472, 197933668, 197933800, 197933824);
    // --- line 1363 ---
    // stack 4
    return 1;
    // --- line 1365 ---
    // _ = 197806844;
    // load playerid
    // load var_-4
    // --- line 1367 ---
    fg_ShowPlayerDialog(28, playerid, 12347, 1, 197933852, 197934048, 197934272, 197934296);
    // --- line 1368 ---
    // stack 4
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1373 ---
    // load response
    if (!_) goto lbl_0x4e2b4; // jzer
    // --- line 1375 ---
    SendClientMessage(playerid, -1, 197934324);
    // stack 16
    // --- line 1376 ---
    return 1;
    // --- line 1378 ---
    // stack -4
    strval(4, var_28);
    // stack 8
    // var_-4 = _;
    // --- line 1379 ---
    // load var_-4
    goto lbl_0x4e39c; // jsleq 0x4e39c
    // --- line 1381 ---
    SendClientMessage(playerid, -1, 197934512);
    // stack 16
    // --- line 1382 ---
    fg_ShowPlayerDialog(28, playerid, 12347, 1, 197934780, 197934976, 197935200, 197935224);
    // --- line 1383 ---
    // stack 4
    return 1;
    // --- line 1385 ---
    // _ = 197806844;
    // load playerid
    // load var_-4
    // --- line 1387 ---
    // stack -512
    // --- line 1388 ---
    // _ = 197806844;
    // load playerid
    // _ = 197806844;
    // load playerid
    format(-516, 128, 197935252);
    // stack 24
    // --- line 1392 ---
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -516, 197935484, 197935772, 197935804);
    // --- line 1397 ---
    // stack 516
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1402 ---
    // load response
    if (!_) goto lbl_0x4e584; // jzer
    // --- line 1404 ---
    SendClientMessage(playerid, -1, 197935832);
    // stack 16
    // --- line 1405 ---
    return 1;
    // --- line 1407 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-4 = _;
    // --- line 1408 ---
    // _ = 197842844;
    // load playerid
    // load var_-4
    // load listitem
    // --- line 1410 ---
    // stack -1024
    // --- line 1411 ---
    // load listitem
    switch (_) // -> 0x4e754
    // --- line 1413 ---
    format(-1028, 256, 197936020);
    // stack 16
    goto lbl_0x4e780; // jump 0x4e780
    // --- line 1414 ---
    format(-1028, 256, 197936124);
    // stack 16
    goto lbl_0x4e780; // jump 0x4e780
    // --- line 1415 ---
    format(-1028, 256, 197936232);
    // stack 16
    goto lbl_0x4e780; // jump 0x4e780
    // --- line 1416 ---
    format(-1028, 256, 197936464);
    // stack 16
    goto lbl_0x4e780; // jump 0x4e780
    // casetbl cases=5
    // --- line 1419 ---
    // stack -512
    // --- line 1420 ---
    // _ = 197806844;
    // load playerid
    // load var_-4
    format(-1540, 128, 197936560);
    // stack 24
    // --- line 1424 ---
    fg_ShowPlayerDialog(28, playerid, "adHousesRenters", 1, -1540, -1028, 197936768, 197936792);
    // --- line 1428 ---
    // stack 1540
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1433 ---
    // load response
    if (!_) goto lbl_0x4e8f8; // jzer
    // --- line 1435 ---
    SendClientMessage(playerid, -1, 197936820);
    // stack 16
    // --- line 1436 ---
    return 1;
    // --- line 1438 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-4 = _;
    // --- line 1439 ---
    // stack -4
    strval(4, var_28);
    // stack 8
    // var_-8 = _;
    // --- line 1440 ---
    // stack -4
    // _ = 197842844;
    // load playerid
    // load var_-4
    // var_-12 = _;
    // --- line 1442 ---
    // stack -512
    // --- line 1443 ---
    // _ = 197806844;
    // load playerid
    // load var_-4
    format(-524, 128, 197937008);
    // stack 24
    // --- line 1447 ---
    // load var_-8
    goto lbl_0x4ec90; // jsless 0x4ec90
    // --- line 1449 ---
    SendClientMessage(playerid, -1, 197937292);
    // stack 16
    // --- line 1450 ---
    // stack -1024
    // --- line 1451 ---
    // load var_-12
    switch (_) // -> 0x4ec00
    // --- line 1453 ---
    format(-1548, 256, 197937560);
    // stack 16
    goto lbl_0x4ec2c; // jump 0x4ec2c
    // --- line 1454 ---
    format(-1548, 256, 197937664);
    // stack 16
    goto lbl_0x4ec2c; // jump 0x4ec2c
    // --- line 1455 ---
    format(-1548, 256, 197937772);
    // stack 16
    goto lbl_0x4ec2c; // jump 0x4ec2c
    // --- line 1456 ---
    format(-1548, 256, 197938004);
    // stack 16
    goto lbl_0x4ec2c; // jump 0x4ec2c
    // casetbl cases=5
    // --- line 1458 ---
    fg_ShowPlayerDialog(28, playerid, "adHousesRenters", 1, -524, -1548, 197938100, 197938124);
    // --- line 1462 ---
    // stack 1548
    return 1;
    // --- line 1465 ---
    // _ = 197842844;
    // load playerid
    // load var_-4
    // load var_-8
    // --- line 1467 ---
    // load var_-12
    if (!_) goto lbl_0x4ef88; // jzer
    // --- line 1469 ---
    // _ = 197842844;
    // load playerid
    // load var_-4
    // --- line 1470 ---
    // _ = 197806844;
    // load playerid
    // --- line 1472 ---
    // _ = 197806844;
    // load playerid
    // _ = 197806844;
    // load playerid
    goto lbl_0x4ef54; // jsleq 0x4ef54
    // --- line 1474 ---
    // _ = 197806844;
    // load playerid
    // _ = 197806844;
    // load playerid
    format(-524, 128, 197938152);
    // stack 24
    // --- line 1477 ---
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -524, 197938384, 197938672, 197938704);
    goto lbl_0x4ef70; // jump 0x4ef70
    // --- line 1485 ---
    ShowPromoCreationConfirmation(4, playerid);
    // --- line 1487 ---
    // stack 524
    return 1;
    // --- line 1490 ---
    fg_ShowPlayerDialog(28, playerid, "dHousesRenters", 2, -524, 197938732, 197939008, 197939040);
    // --- line 1495 ---
    // stack 524
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1500 ---
    // load response
    if (!_) goto lbl_0x4f050; // jzer
    // --- line 1502 ---
    SendClientMessage(playerid, -1, 197939068);
    // stack 16
    // --- line 1503 ---
    return 1;
    // --- line 1505 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-4 = _;
    // --- line 1506 ---
    // stack -4
    // load listitem
    // var_-8 = _;
    // --- line 1508 ---
    // stack -512
    // --- line 1510 ---
    // load var_-8
    if (_) goto lbl_0x4f1dc; // jnz
    // --- line 1512 ---
    // _ = 197806844;
    // load playerid
    // load var_-4
    format(-520, 128, 197939256);
    // stack 24
    // --- line 1516 ---
    fg_ShowPlayerDialog(28, playerid, "HousesRenters", 1, -520, 197939524, 197939668, 197939692);
    // --- line 1520 ---
    // stack 520
    return 1;
    // --- line 1524 ---
    // _ = 197842844;
    // load playerid
    // load var_-4
    // --- line 1526 ---
    // _ = 197806844;
    // load playerid
    // --- line 1527 ---
    // _ = 197806844;
    // load playerid
    // _ = 197806844;
    // load playerid
    goto lbl_0x4f418; // jsleq 0x4f418
    // --- line 1529 ---
    // _ = 197806844;
    // load playerid
    // _ = 197806844;
    // load playerid
    format(-520, 128, 197939720);
    // stack 24
    // --- line 1533 ---
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -520, 197939952, 197940240, 197940272);
    goto lbl_0x4f434; // jump 0x4f434
    // --- line 1541 ---
    ShowPromoCreationConfirmation(4, playerid);
    // --- line 1543 ---
    // stack 520
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1549 ---
    // load response
    if (!_) goto lbl_0x4f4b0; // jzer
    // --- line 1551 ---
    SendClientMessage(playerid, -1, 197940300);
    // stack 16
    // --- line 1552 ---
    return 1;
    // --- line 1554 ---
    // stack -4
    // _ = 197806844;
    // load playerid
    // var_-4 = _;
    // --- line 1555 ---
    // stack -4
    strval(4, var_28);
    // stack 8
    // var_-8 = _;
    // --- line 1557 ---
    // stack -512
    // --- line 1559 ---
    // load var_-8
    goto lbl_0x4f690; // jsless 0x4f690
    // --- line 1561 ---
    SendClientMessage(playerid, -1, 197940488);
    // stack 16
    // --- line 1563 ---
    // _ = 197806844;
    // load playerid
    // load var_-4
    format(-520, 128, 197940780);
    // stack 24
    // --- line 1567 ---
    fg_ShowPlayerDialog(28, playerid, "HousesRenters", 1, -520, 197941048, 197941192, 197941216);
    // --- line 1571 ---
    // stack 520
    return 1;
    // --- line 1573 ---
    // _ = 197842844;
    // load playerid
    // load var_-4
    // load var_-8
    // --- line 1575 ---
    // _ = 197806844;
    // load playerid
    // --- line 1576 ---
    // _ = 197806844;
    // load playerid
    // _ = 197806844;
    // load playerid
    goto lbl_0x4f8d0; // jsleq 0x4f8d0
    // --- line 1578 ---
    // _ = 197806844;
    // load playerid
    // _ = 197806844;
    // load playerid
    format(-520, 128, 197941244);
    // stack 24
    // --- line 1582 ---
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -520, 197941452, 197941740, 197941772);
    goto lbl_0x4f8ec; // jump 0x4f8ec
    // --- line 1590 ---
    ShowPromoCreationConfirmation(4, playerid);
    // --- line 1592 ---
    // stack 520
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1597 ---
    // load response
    if (!_) goto lbl_0x4f944; // jzer
    // --- line 1599 ---
    CreatePromoCodeInDatabase(4, playerid);
    goto lbl_0x4f978; // jump 0x4f978
    // --- line 1603 ---
    SendClientMessage(playerid, -1, 197941800);
    // stack 16
    // --- line 1605 ---
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // --- line 1610 ---
    // load response
    if (!_) goto lbl_0x4f9ec; // jzer
    // --- line 1612 ---
    SendClientMessage(playerid, -1, 197941988);
    // stack 16
    // --- line 1613 ---
    return 1;
    // --- line 1615 ---
    strlen(var_28);
    // stack 8
    if (_) goto lbl_0x4fa80; // jnz
    // --- line 1617 ---
    SendClientMessage(playerid, -1, 197942172);
    // stack 16
    // --- line 1618 ---
    pc_cmd_bcode(8, playerid, 197942452);
    // --- line 1619 ---
    return 1;
    // --- line 1621 ---
    // stack -144
    // --- line 1623 ---
    // stack -4
    // _ = 181530104;
    // load playerid
    // var_-148 = _;
    // --- line 1625 ---
    // stack -1144
    // --- line 1626 ---
    // --- line 1628 ---
    mysql_format(166387936, -1292, 286, 197942456);
    // stack 24
    // --- line 1629 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-1296 = _;
    // --- line 1631 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x4fc04; // jzer
    // --- line 1633 ---
    SendClientMessage(playerid, -1, 197942676);
    // stack 16
    // --- line 1634 ---
    // stack 1296
    return 1;
    // --- line 1637 ---
    cache_get_row_count(4, var_-1296);
    // stack 8
    if (_) goto lbl_0x4fcb4; // jnz
    // --- line 1639 ---
    SendClientMessage(playerid, -1, 197942828);
    // stack 16
    // --- line 1640 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1641 ---
    pc_cmd_bcode(8, playerid, 197943012);
    // --- line 1644 ---
    // stack -4
    cache_get_field_content_int(0, 197943016, 1);
    // stack 16
    // var_-1300 = _;
    // --- line 1645 ---
    // stack -4
    cache_get_field_content_int(0, 197943028, 1);
    // stack 16
    // var_-1304 = _;
    // --- line 1646 ---
    // stack -4
    cache_get_field_content_int(0, 197943104, 1);
    // stack 16
    // var_-1308 = _;
    // --- line 1647 ---
    // stack -4
    cache_get_field_content_int(0, 197943152, 1);
    // stack 16
    // var_-1312 = _;
    // --- line 1648 ---
    // stack -4
    cache_get_field_content_int(0, 197943200, 1);
    // stack 16
    // var_-1316 = _;
    // --- line 1650 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1652 ---
    // load var_-1308
    if (_) goto lbl_0x4fe94; // jnz
    // --- line 1654 ---
    SendClientMessage(playerid, -1, 197943256);
    // stack 16
    // --- line 1655 ---
    // stack 1316
    return 1;
    // --- line 1658 ---
    // load var_-148
    goto lbl_0x4ff20; // jneq 0x4ff20
    // --- line 1660 ---
    SendClientMessage(playerid, -1, 197943660);
    // stack 16
    // --- line 1661 ---
    pc_cmd_bcode(8, playerid, 197943896);
    // --- line 1662 ---
    // stack 1316
    return 1;
    // --- line 1665 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1667 ---
    GetPromoCodeDataByString(8, var_28, -144);
    if (!_) goto lbl_0x57ca8; // jzer
    // --- line 1669 ---
    goto lbl_0x4ffcc; // jsgrtr 0x4ffcc
    if (!_) goto lbl_0x4ffcc; // jzer
    goto lbl_0x4ffd4; // jump 0x4ffd4
    if (!_) goto lbl_0x57c5c; // jzer
    // --- line 1671 ---
    mysql_format(166387936, -1292, 286, 197943900);
    // stack 28
    // --- line 1672 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-1296 = _;
    // --- line 1674 ---
    cache_get_row_count(4, var_-1296);
    // stack 8
    goto lbl_0x50110; // jsgeq 0x50110
    // --- line 1676 ---
    SendClientMessage(playerid, -1, 197944468);
    // stack 16
    // --- line 1677 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1678 ---
    // stack 1316
    return 1;
    // --- line 1680 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1683 ---
    mysql_format(166387936, -1292, 286, 197944680);
    // stack 28
    // --- line 1684 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-1296 = _;
    // --- line 1686 ---
    cache_get_row_count(4, var_-1296);
    // stack 8
    goto lbl_0x50270; // jsgeq 0x50270
    // --- line 1688 ---
    SendClientMessage(playerid, -1, 197945020);
    // stack 16
    // --- line 1689 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1690 ---
    // stack 1316
    return 1;
    // --- line 1692 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1694 ---
    // stack -4096
    // --- line 1695 ---
    format(-5412, 1024, 197945232);
    // stack 20
    // --- line 1696 ---
    strcat(-5412, 197945508);
    // stack 16
    // --- line 1698 ---
    mysql_format(166387936, -1292, 286, 197945596);
    // stack 24
    // --- line 1699 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-1296 = _;
    // --- line 1701 ---
    mysql_errno(1);
    // stack 8
    if (_) goto lbl_0x5040c; // jnz
    cache_get_row_count(4, var_-1296);
    // stack 8
    if (!_) goto lbl_0x5040c; // jzer
    goto lbl_0x50414; // jump 0x50414
    if (!_) goto lbl_0x504f8; // jzer
    // --- line 1703 ---
    SendClientMessage(playerid, -1, 197946052);
    // stack 16
    // --- line 1704 ---
    mysql_errno(1);
    // stack 8
    printf(197946444, -1300);
    // stack 16
    // --- line 1705 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 1706 ---
    // stack 5412
    return 1;
    // --- line 1709 ---
    // stack -4
    cache_get_row_count(4, var_-1296);
    // stack 8
    // var_-5416 = _;
    // --- line 1710 ---
    // stack -256
    // --- line 1712 ---
    // --- line 1713 ---
    // --- line 1714 ---
    // --- line 1715 ---
    // --- line 1717 ---
    // --- line 1718 ---
    // --- line 1719 ---
    // --- line 1720 ---
    // --- line 1722 ---
    // --- line 1723 ---
    // --- line 1724 ---
    // --- line 1725 ---
    // --- line 1727 ---
    // --- line 1728 ---
    // --- line 1729 ---
    // --- line 1730 ---
    // --- line 1732 ---
    // --- line 1733 ---
    // --- line 1734 ---
    // --- line 1735 ---
    // --- line 1737 ---
    // load var_-5416
    if (!_) goto lbl_0x50e00; // jzer
    // --- line 1739 ---
    cache_get_field_content_int(0, 197946692, 1);
    // stack 16
    // var_-5676 = _;
    // --- line 1740 ---
    cache_get_field_content_int(0, 197946704, 1);
    // stack 16
    // var_-5680 = _;
    // --- line 1741 ---
    cache_get_field_content_int(0, 197946748, 1);
    // stack 16
    // var_-5684 = _;
    // --- line 1742 ---
    cache_get_field_content_int(0, 197946796, 1);
    // stack 16
    // var_-5688 = _;
    // --- line 1744 ---
    // stack -1024
    // --- line 1745 ---
    // stack -256
    // --- line 1747 ---
    // load var_-5688
    if (_) goto lbl_0x507d8; // jnz
    // --- line 1748 ---
    format(-5672, 64, 197946856);
    // stack 16
    goto lbl_0x50814; // jump 0x50814
    // --- line 1750 ---
    format(-5672, 64, 197946904);
    // stack 20
    // --- line 1753 ---
    // load var_-5680
    switch (_) // -> 0x50b18
    // --- line 1757 ---
    GivePlayerMoneyEx(20, playerid, var_-5684);
    // --- line 1758 ---
    format(-6776, 256, 197947040);
    // stack 24
    goto lbl_0x50b44; // jump 0x50b44
    // --- line 1762 ---
    GivePlayerDonateRub(20, playerid, var_-5684);
    // --- line 1763 ---
    format(-6776, 256, 197947156);
    // stack 24
    goto lbl_0x50b44; // jump 0x50b44
    // --- line 1767 ---
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    // --- line 1768 ---
    format(-6776, 256, 197947280);
    // stack 28
    goto lbl_0x50b44; // jump 0x50b44
    // --- line 1772 ---
    // _ = 181530104;
    // load playerid
    // --- line 1773 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197947488);
    // --- line 1774 ---
    format(-6776, 256, 197947504);
    // stack 20
    goto lbl_0x50b44; // jump 0x50b44
    // casetbl cases=5
    // --- line 1777 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 1779 ---
    // --- line 1780 ---
    // load var_-5688
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197947608);
    // stack 36
    // --- line 1783 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-7036 = _;
    // --- line 1784 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x50d40; // jzer
    // --- line 1786 ---
    mysql_errno(1);
    // stack 8
    printf(197948092, -5676);
    // stack 20
    goto lbl_0x50dc4; // jump 0x50dc4
    // --- line 1790 ---
    // stack -4
    cache_insert_id(4, var_-7036);
    // stack 8
    // var_-7040 = _;
    // --- line 1792 ---
    // load var_-5688
    goto lbl_0x50dbc; // jsgeq 0x50dbc
    // --- line 1794 ---
    SetPlayerPromoTimer(12, playerid, var_-7040, var_-5688);
    // stack 4
    // --- line 1797 ---
    cache_delete(8, var_-7036, 1);
    // stack 12
    // stack 1284
    goto lbl_0x57850; // jump 0x57850
    // --- line 1799 ---
    // load var_-5416
    if (!_) goto lbl_0x51cf0; // jzer
    // --- line 1801 ---
    cache_get_field_content_int(0, 197948356, 1);
    // stack 16
    // var_-5676 = _;
    // --- line 1802 ---
    cache_get_field_content_int(0, 197948368, 1);
    // stack 16
    // var_-5680 = _;
    // --- line 1803 ---
    cache_get_field_content_int(0, 197948412, 1);
    // stack 16
    // var_-5684 = _;
    // --- line 1804 ---
    cache_get_field_content_int(0, 197948460, 1);
    // stack 16
    // var_-5688 = _;
    // --- line 1806 ---
    cache_get_field_content_int(1, 197948520, 1);
    // stack 16
    // var_-5692 = _;
    // --- line 1807 ---
    cache_get_field_content_int(1, 197948532, 1);
    // stack 16
    // var_-5696 = _;
    // --- line 1808 ---
    cache_get_field_content_int(1, 197948576, 1);
    // stack 16
    // var_-5700 = _;
    // --- line 1809 ---
    cache_get_field_content_int(1, 197948624, 1);
    // stack 16
    // var_-5704 = _;
    // --- line 1811 ---
    // stack -1024
    // --- line 1813 ---
    // load var_-5688
    if (_) goto lbl_0x5106c; // jnz
    // --- line 1814 ---
    format(-5672, 64, 197948684);
    // stack 16
    goto lbl_0x510a8; // jump 0x510a8
    // --- line 1816 ---
    format(-5672, 64, 197948732);
    // stack 20
    // --- line 1819 ---
    // load var_-5680
    switch (_) // -> 0x513ac
    // --- line 1823 ---
    GivePlayerMoneyEx(20, playerid, var_-5684);
    // --- line 1824 ---
    format(-6776, 256, 197948868);
    // stack 24
    goto lbl_0x513d8; // jump 0x513d8
    // --- line 1828 ---
    GivePlayerDonateRub(20, playerid, var_-5684);
    // --- line 1829 ---
    format(-6776, 256, 197948984);
    // stack 24
    goto lbl_0x513d8; // jump 0x513d8
    // --- line 1833 ---
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    // --- line 1834 ---
    format(-6776, 256, 197949108);
    // stack 28
    goto lbl_0x513d8; // jump 0x513d8
    // --- line 1838 ---
    // _ = 181530104;
    // load playerid
    // --- line 1839 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197949316);
    // --- line 1840 ---
    format(-6776, 256, 197949332);
    // stack 20
    goto lbl_0x513d8; // jump 0x513d8
    // casetbl cases=5
    // --- line 1843 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 1845 ---
    // --- line 1846 ---
    // load var_-5688
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197949436);
    // stack 36
    // --- line 1849 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 1850 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x515d4; // jzer
    // --- line 1852 ---
    mysql_errno(1);
    // stack 8
    printf(197949920, -5676);
    // stack 20
    goto lbl_0x51658; // jump 0x51658
    // --- line 1856 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 1857 ---
    // load var_-5688
    goto lbl_0x51650; // jsgeq 0x51650
    // --- line 1859 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    // stack 4
    // --- line 1862 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 1865 ---
    // load var_-5704
    if (_) goto lbl_0x516d4; // jnz
    // --- line 1866 ---
    format(-5672, 64, 197950184);
    // stack 16
    goto lbl_0x51710; // jump 0x51710
    // --- line 1868 ---
    format(-5672, 64, 197950232);
    // stack 20
    // --- line 1871 ---
    // load var_-5696
    switch (_) // -> 0x51a14
    // --- line 1875 ---
    GivePlayerMoneyEx(20, playerid, var_-5700);
    // --- line 1876 ---
    format(-6776, 256, 197950368);
    // stack 24
    goto lbl_0x51a40; // jump 0x51a40
    // --- line 1880 ---
    GivePlayerDonateRub(20, playerid, var_-5700);
    // --- line 1881 ---
    format(-6776, 256, 197950484);
    // stack 24
    goto lbl_0x51a40; // jump 0x51a40
    // --- line 1885 ---
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    // --- line 1886 ---
    format(-6776, 256, 197950608);
    // stack 28
    goto lbl_0x51a40; // jump 0x51a40
    // --- line 1890 ---
    // _ = 181530104;
    // load playerid
    // --- line 1891 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197950816);
    // --- line 1892 ---
    format(-6776, 256, 197950832);
    // stack 20
    goto lbl_0x51a40; // jump 0x51a40
    // casetbl cases=5
    // --- line 1895 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 1897 ---
    // load var_-5704
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197950936);
    // stack 36
    // --- line 1900 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 1901 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x51c30; // jzer
    // --- line 1903 ---
    mysql_errno(1);
    // stack 8
    printf(197951420, -5692);
    // stack 20
    goto lbl_0x51cb4; // jump 0x51cb4
    // --- line 1907 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 1908 ---
    // load var_-5704
    goto lbl_0x51cac; // jsgeq 0x51cac
    // --- line 1910 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    // stack 4
    // --- line 1913 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // stack 1028
    goto lbl_0x57850; // jump 0x57850
    // --- line 1915 ---
    // load var_-5416
    if (!_) goto lbl_0x5332c; // jzer
    // --- line 1917 ---
    cache_get_field_content_int(0, 197951684, 1);
    // stack 16
    // var_-5676 = _;
    // --- line 1918 ---
    cache_get_field_content_int(0, 197951696, 1);
    // stack 16
    // var_-5680 = _;
    // --- line 1919 ---
    cache_get_field_content_int(0, 197951740, 1);
    // stack 16
    // var_-5684 = _;
    // --- line 1920 ---
    cache_get_field_content_int(0, 197951788, 1);
    // stack 16
    // var_-5688 = _;
    // --- line 1922 ---
    cache_get_field_content_int(1, 197951848, 1);
    // stack 16
    // var_-5692 = _;
    // --- line 1923 ---
    cache_get_field_content_int(1, 197951860, 1);
    // stack 16
    // var_-5696 = _;
    // --- line 1924 ---
    cache_get_field_content_int(1, 197951904, 1);
    // stack 16
    // var_-5700 = _;
    // --- line 1925 ---
    cache_get_field_content_int(1, 197951952, 1);
    // stack 16
    // var_-5704 = _;
    // --- line 1927 ---
    cache_get_field_content_int(2, 197952012, 1);
    // stack 16
    // var_-5708 = _;
    // --- line 1928 ---
    cache_get_field_content_int(2, 197952024, 1);
    // stack 16
    // var_-5712 = _;
    // --- line 1929 ---
    cache_get_field_content_int(2, 197952068, 1);
    // stack 16
    // var_-5716 = _;
    // --- line 1930 ---
    cache_get_field_content_int(2, 197952116, 1);
    // stack 16
    // var_-5720 = _;
    // --- line 1932 ---
    // stack -1024
    // --- line 1934 ---
    // load var_-5688
    if (_) goto lbl_0x5204c; // jnz
    // --- line 1935 ---
    format(-5672, 64, 197952176);
    // stack 16
    goto lbl_0x52088; // jump 0x52088
    // --- line 1937 ---
    format(-5672, 64, 197952224);
    // stack 20
    // --- line 1940 ---
    // load var_-5680
    switch (_) // -> 0x5238c
    // --- line 1944 ---
    GivePlayerMoneyEx(20, playerid, var_-5684);
    // --- line 1945 ---
    format(-6776, 256, 197952360);
    // stack 24
    goto lbl_0x523b8; // jump 0x523b8
    // --- line 1949 ---
    GivePlayerDonateRub(20, playerid, var_-5684);
    // --- line 1950 ---
    format(-6776, 256, 197952476);
    // stack 24
    goto lbl_0x523b8; // jump 0x523b8
    // --- line 1954 ---
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    // --- line 1955 ---
    format(-6776, 256, 197952600);
    // stack 28
    goto lbl_0x523b8; // jump 0x523b8
    // --- line 1959 ---
    // _ = 181530104;
    // load playerid
    // --- line 1960 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197952808);
    // --- line 1961 ---
    format(-6776, 256, 197952824);
    // stack 20
    goto lbl_0x523b8; // jump 0x523b8
    // casetbl cases=5
    // --- line 1964 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 1966 ---
    // --- line 1967 ---
    // load var_-5688
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197952928);
    // stack 36
    // --- line 1970 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 1971 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x525b4; // jzer
    // --- line 1973 ---
    mysql_errno(1);
    // stack 8
    printf(197953412, -5676);
    // stack 20
    goto lbl_0x52638; // jump 0x52638
    // --- line 1977 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 1978 ---
    // load var_-5688
    goto lbl_0x52630; // jsgeq 0x52630
    // --- line 1980 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    // stack 4
    // --- line 1983 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 1986 ---
    // load var_-5704
    if (_) goto lbl_0x526b4; // jnz
    // --- line 1987 ---
    format(-5672, 64, 197953676);
    // stack 16
    goto lbl_0x526f0; // jump 0x526f0
    // --- line 1989 ---
    format(-5672, 64, 197953724);
    // stack 20
    // --- line 1992 ---
    // load var_-5696
    switch (_) // -> 0x529f4
    // --- line 1996 ---
    GivePlayerMoneyEx(20, playerid, var_-5700);
    // --- line 1997 ---
    format(-6776, 256, 197953860);
    // stack 24
    goto lbl_0x52a20; // jump 0x52a20
    // --- line 2001 ---
    GivePlayerDonateRub(20, playerid, var_-5700);
    // --- line 2002 ---
    format(-6776, 256, 197953976);
    // stack 24
    goto lbl_0x52a20; // jump 0x52a20
    // --- line 2006 ---
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    // --- line 2007 ---
    format(-6776, 256, 197954100);
    // stack 28
    goto lbl_0x52a20; // jump 0x52a20
    // --- line 2011 ---
    // _ = 181530104;
    // load playerid
    // --- line 2012 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197954308);
    // --- line 2013 ---
    format(-6776, 256, 197954324);
    // stack 20
    goto lbl_0x52a20; // jump 0x52a20
    // casetbl cases=5
    // --- line 2016 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2018 ---
    // load var_-5704
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197954428);
    // stack 36
    // --- line 2021 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2022 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x52c10; // jzer
    // --- line 2024 ---
    mysql_errno(1);
    // stack 8
    printf(197954912, -5692);
    // stack 20
    goto lbl_0x52c94; // jump 0x52c94
    // --- line 2028 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2029 ---
    // load var_-5704
    goto lbl_0x52c8c; // jsgeq 0x52c8c
    // --- line 2031 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    // stack 4
    // --- line 2034 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2038 ---
    // load var_-5720
    if (_) goto lbl_0x52d10; // jnz
    // --- line 2039 ---
    format(-5672, 64, 197955176);
    // stack 16
    goto lbl_0x52d4c; // jump 0x52d4c
    // --- line 2041 ---
    format(-5672, 64, 197955224);
    // stack 20
    // --- line 2044 ---
    // load var_-5712
    switch (_) // -> 0x53050
    // --- line 2048 ---
    GivePlayerMoneyEx(20, playerid, var_-5716);
    // --- line 2049 ---
    format(-6776, 256, 197955360);
    // stack 24
    goto lbl_0x5307c; // jump 0x5307c
    // --- line 2053 ---
    GivePlayerDonateRub(20, playerid, var_-5716);
    // --- line 2054 ---
    format(-6776, 256, 197955476);
    // stack 24
    goto lbl_0x5307c; // jump 0x5307c
    // --- line 2058 ---
    GivePromoCar(12, playerid, var_-5716, var_-1300);
    // --- line 2059 ---
    format(-6776, 256, 197955600);
    // stack 28
    goto lbl_0x5307c; // jump 0x5307c
    // --- line 2063 ---
    // _ = 181530104;
    // load playerid
    // --- line 2064 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197955808);
    // --- line 2065 ---
    format(-6776, 256, 197955824);
    // stack 20
    goto lbl_0x5307c; // jump 0x5307c
    // casetbl cases=5
    // --- line 2068 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2070 ---
    // load var_-5720
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197955928);
    // stack 36
    // --- line 2073 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2074 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x5326c; // jzer
    // --- line 2076 ---
    mysql_errno(1);
    // stack 8
    printf(197956412, -5708);
    // stack 20
    goto lbl_0x532f0; // jump 0x532f0
    // --- line 2080 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2081 ---
    // load var_-5720
    goto lbl_0x532e8; // jsgeq 0x532e8
    // --- line 2083 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5720);
    // stack 4
    // --- line 2086 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // stack 1028
    goto lbl_0x57850; // jump 0x57850
    // --- line 2088 ---
    // load var_-5416
    if (!_) goto lbl_0x55384; // jzer
    // --- line 2090 ---
    cache_get_field_content_int(0, 197956676, 1);
    // stack 16
    // var_-5676 = _;
    // --- line 2091 ---
    cache_get_field_content_int(0, 197956688, 1);
    // stack 16
    // var_-5680 = _;
    // --- line 2092 ---
    cache_get_field_content_int(0, 197956732, 1);
    // stack 16
    // var_-5684 = _;
    // --- line 2093 ---
    cache_get_field_content_int(0, 197956780, 1);
    // stack 16
    // var_-5688 = _;
    // --- line 2095 ---
    cache_get_field_content_int(1, 197956840, 1);
    // stack 16
    // var_-5692 = _;
    // --- line 2096 ---
    cache_get_field_content_int(1, 197956852, 1);
    // stack 16
    // var_-5696 = _;
    // --- line 2097 ---
    cache_get_field_content_int(1, 197956896, 1);
    // stack 16
    // var_-5700 = _;
    // --- line 2098 ---
    cache_get_field_content_int(1, 197956944, 1);
    // stack 16
    // var_-5704 = _;
    // --- line 2100 ---
    cache_get_field_content_int(2, 197957004, 1);
    // stack 16
    // var_-5708 = _;
    // --- line 2101 ---
    cache_get_field_content_int(2, 197957016, 1);
    // stack 16
    // var_-5712 = _;
    // --- line 2102 ---
    cache_get_field_content_int(2, 197957060, 1);
    // stack 16
    // var_-5716 = _;
    // --- line 2103 ---
    cache_get_field_content_int(2, 197957108, 1);
    // stack 16
    // var_-5720 = _;
    // --- line 2105 ---
    cache_get_field_content_int(3, 197957168, 1);
    // stack 16
    // var_-5724 = _;
    // --- line 2106 ---
    cache_get_field_content_int(3, 197957180, 1);
    // stack 16
    // var_-5728 = _;
    // --- line 2107 ---
    cache_get_field_content_int(3, 197957224, 1);
    // stack 16
    // var_-5732 = _;
    // --- line 2108 ---
    cache_get_field_content_int(3, 197957272, 1);
    // stack 16
    // var_-5736 = _;
    // --- line 2110 ---
    cache_get_field_content_int(0, 197957332, 1);
    // stack 16
    // var_-5676 = _;
    // --- line 2111 ---
    cache_get_field_content_int(0, 197957344, 1);
    // stack 16
    // var_-5680 = _;
    // --- line 2112 ---
    cache_get_field_content_int(0, 197957388, 1);
    // stack 16
    // var_-5684 = _;
    // --- line 2113 ---
    cache_get_field_content_int(0, 197957436, 1);
    // stack 16
    // var_-5688 = _;
    // --- line 2115 ---
    cache_get_field_content_int(1, 197957496, 1);
    // stack 16
    // var_-5692 = _;
    // --- line 2116 ---
    cache_get_field_content_int(1, 197957508, 1);
    // stack 16
    // var_-5696 = _;
    // --- line 2117 ---
    cache_get_field_content_int(1, 197957552, 1);
    // stack 16
    // var_-5700 = _;
    // --- line 2118 ---
    cache_get_field_content_int(1, 197957600, 1);
    // stack 16
    // var_-5704 = _;
    // --- line 2120 ---
    cache_get_field_content_int(2, 197957660, 1);
    // stack 16
    // var_-5708 = _;
    // --- line 2121 ---
    cache_get_field_content_int(2, 197957672, 1);
    // stack 16
    // var_-5712 = _;
    // --- line 2122 ---
    cache_get_field_content_int(2, 197957716, 1);
    // stack 16
    // var_-5716 = _;
    // --- line 2123 ---
    cache_get_field_content_int(2, 197957764, 1);
    // stack 16
    // var_-5720 = _;
    // --- line 2125 ---
    // stack -1024
    // --- line 2127 ---
    // load var_-5688
    if (_) goto lbl_0x53a48; // jnz
    // --- line 2128 ---
    format(-5672, 64, 197957824);
    // stack 16
    goto lbl_0x53a84; // jump 0x53a84
    // --- line 2130 ---
    format(-5672, 64, 197957872);
    // stack 20
    // --- line 2133 ---
    // load var_-5680
    switch (_) // -> 0x53d88
    // --- line 2137 ---
    GivePlayerMoneyEx(20, playerid, var_-5684);
    // --- line 2138 ---
    format(-6776, 256, 197958008);
    // stack 24
    goto lbl_0x53db4; // jump 0x53db4
    // --- line 2142 ---
    GivePlayerDonateRub(20, playerid, var_-5684);
    // --- line 2143 ---
    format(-6776, 256, 197958124);
    // stack 24
    goto lbl_0x53db4; // jump 0x53db4
    // --- line 2147 ---
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    // --- line 2148 ---
    format(-6776, 256, 197958248);
    // stack 28
    goto lbl_0x53db4; // jump 0x53db4
    // --- line 2152 ---
    // _ = 181530104;
    // load playerid
    // --- line 2153 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197958456);
    // --- line 2154 ---
    format(-6776, 256, 197958472);
    // stack 20
    goto lbl_0x53db4; // jump 0x53db4
    // casetbl cases=5
    // --- line 2157 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2159 ---
    // --- line 2160 ---
    // load var_-5688
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197958576);
    // stack 36
    // --- line 2163 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2164 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x53fb0; // jzer
    // --- line 2166 ---
    mysql_errno(1);
    // stack 8
    printf(197959060, -5676);
    // stack 20
    goto lbl_0x54034; // jump 0x54034
    // --- line 2170 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2171 ---
    // load var_-5688
    goto lbl_0x5402c; // jsgeq 0x5402c
    // --- line 2173 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    // stack 4
    // --- line 2176 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2179 ---
    // load var_-5704
    if (_) goto lbl_0x540b0; // jnz
    // --- line 2180 ---
    format(-5672, 64, 197959324);
    // stack 16
    goto lbl_0x540ec; // jump 0x540ec
    // --- line 2182 ---
    format(-5672, 64, 197959372);
    // stack 20
    // --- line 2185 ---
    // load var_-5696
    switch (_) // -> 0x543f0
    // --- line 2189 ---
    GivePlayerMoneyEx(20, playerid, var_-5700);
    // --- line 2190 ---
    format(-6776, 256, 197959508);
    // stack 24
    goto lbl_0x5441c; // jump 0x5441c
    // --- line 2194 ---
    GivePlayerDonateRub(20, playerid, var_-5700);
    // --- line 2195 ---
    format(-6776, 256, 197959624);
    // stack 24
    goto lbl_0x5441c; // jump 0x5441c
    // --- line 2199 ---
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    // --- line 2200 ---
    format(-6776, 256, 197959748);
    // stack 28
    goto lbl_0x5441c; // jump 0x5441c
    // --- line 2204 ---
    // _ = 181530104;
    // load playerid
    // --- line 2205 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197959956);
    // --- line 2206 ---
    format(-6776, 256, 197959972);
    // stack 20
    goto lbl_0x5441c; // jump 0x5441c
    // casetbl cases=5
    // --- line 2209 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2211 ---
    // load var_-5704
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197960076);
    // stack 36
    // --- line 2214 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2215 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x5460c; // jzer
    // --- line 2217 ---
    mysql_errno(1);
    // stack 8
    printf(197960560, -5692);
    // stack 20
    goto lbl_0x54690; // jump 0x54690
    // --- line 2221 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2222 ---
    // load var_-5704
    goto lbl_0x54688; // jsgeq 0x54688
    // --- line 2224 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    // stack 4
    // --- line 2227 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2231 ---
    // load var_-5720
    if (_) goto lbl_0x5470c; // jnz
    // --- line 2232 ---
    format(-5672, 64, 197960824);
    // stack 16
    goto lbl_0x54748; // jump 0x54748
    // --- line 2234 ---
    format(-5672, 64, 197960872);
    // stack 20
    // --- line 2237 ---
    // load var_-5712
    switch (_) // -> 0x54a4c
    // --- line 2241 ---
    GivePlayerMoneyEx(20, playerid, var_-5716);
    // --- line 2242 ---
    format(-6776, 256, 197961008);
    // stack 24
    goto lbl_0x54a78; // jump 0x54a78
    // --- line 2246 ---
    GivePlayerDonateRub(20, playerid, var_-5716);
    // --- line 2247 ---
    format(-6776, 256, 197961124);
    // stack 24
    goto lbl_0x54a78; // jump 0x54a78
    // --- line 2251 ---
    GivePromoCar(12, playerid, var_-5716, var_-1300);
    // --- line 2252 ---
    format(-6776, 256, 197961248);
    // stack 28
    goto lbl_0x54a78; // jump 0x54a78
    // --- line 2256 ---
    // _ = 181530104;
    // load playerid
    // --- line 2257 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197961456);
    // --- line 2258 ---
    format(-6776, 256, 197961472);
    // stack 20
    goto lbl_0x54a78; // jump 0x54a78
    // casetbl cases=5
    // --- line 2261 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2263 ---
    // load var_-5720
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197961576);
    // stack 36
    // --- line 2266 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2267 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x54c68; // jzer
    // --- line 2269 ---
    mysql_errno(1);
    // stack 8
    printf(197962060, -5708);
    // stack 20
    goto lbl_0x54cec; // jump 0x54cec
    // --- line 2273 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2274 ---
    // load var_-5720
    goto lbl_0x54ce4; // jsgeq 0x54ce4
    // --- line 2276 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5720);
    // stack 4
    // --- line 2279 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2283 ---
    // load var_-5736
    if (_) goto lbl_0x54d68; // jnz
    // --- line 2284 ---
    format(-5672, 64, 197962324);
    // stack 16
    goto lbl_0x54da4; // jump 0x54da4
    // --- line 2286 ---
    format(-5672, 64, 197962372);
    // stack 20
    // --- line 2289 ---
    // load var_-5728
    switch (_) // -> 0x550a8
    // --- line 2293 ---
    GivePlayerMoneyEx(20, playerid, var_-5732);
    // --- line 2294 ---
    format(-6776, 256, 197962508);
    // stack 24
    goto lbl_0x550d4; // jump 0x550d4
    // --- line 2298 ---
    GivePlayerDonateRub(20, playerid, var_-5732);
    // --- line 2299 ---
    format(-6776, 256, 197962624);
    // stack 24
    goto lbl_0x550d4; // jump 0x550d4
    // --- line 2303 ---
    GivePromoCar(12, playerid, var_-5732, var_-1300);
    // --- line 2304 ---
    format(-6776, 256, 197962748);
    // stack 28
    goto lbl_0x550d4; // jump 0x550d4
    // --- line 2308 ---
    // _ = 181530104;
    // load playerid
    // --- line 2309 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197962956);
    // --- line 2310 ---
    format(-6776, 256, 197962972);
    // stack 20
    goto lbl_0x550d4; // jump 0x550d4
    // casetbl cases=5
    // --- line 2313 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2315 ---
    // load var_-5736
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197963076);
    // stack 36
    // --- line 2318 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2319 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x552c4; // jzer
    // --- line 2321 ---
    mysql_errno(1);
    // stack 8
    printf(197963560, -5724);
    // stack 20
    goto lbl_0x55348; // jump 0x55348
    // --- line 2325 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2326 ---
    // load var_-5736
    goto lbl_0x55340; // jsgeq 0x55340
    // --- line 2328 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5736);
    // stack 4
    // --- line 2331 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // stack 1028
    goto lbl_0x57850; // jump 0x57850
    // --- line 2333 ---
    // load var_-5416
    if (!_) goto lbl_0x57850; // jzer
    // --- line 2335 ---
    cache_get_field_content_int(0, 197963824, 1);
    // stack 16
    // var_-5676 = _;
    // --- line 2336 ---
    cache_get_field_content_int(0, 197963836, 1);
    // stack 16
    // var_-5680 = _;
    // --- line 2337 ---
    cache_get_field_content_int(0, 197963880, 1);
    // stack 16
    // var_-5684 = _;
    // --- line 2338 ---
    cache_get_field_content_int(0, 197963928, 1);
    // stack 16
    // var_-5688 = _;
    // --- line 2340 ---
    cache_get_field_content_int(1, 197963988, 1);
    // stack 16
    // var_-5692 = _;
    // --- line 2341 ---
    cache_get_field_content_int(1, 197964000, 1);
    // stack 16
    // var_-5696 = _;
    // --- line 2342 ---
    cache_get_field_content_int(1, 197964044, 1);
    // stack 16
    // var_-5700 = _;
    // --- line 2343 ---
    cache_get_field_content_int(1, 197964092, 1);
    // stack 16
    // var_-5704 = _;
    // --- line 2345 ---
    cache_get_field_content_int(2, 197964152, 1);
    // stack 16
    // var_-5708 = _;
    // --- line 2346 ---
    cache_get_field_content_int(2, 197964164, 1);
    // stack 16
    // var_-5712 = _;
    // --- line 2347 ---
    cache_get_field_content_int(2, 197964208, 1);
    // stack 16
    // var_-5716 = _;
    // --- line 2348 ---
    cache_get_field_content_int(2, 197964256, 1);
    // stack 16
    // var_-5720 = _;
    // --- line 2350 ---
    cache_get_field_content_int(3, 197964316, 1);
    // stack 16
    // var_-5724 = _;
    // --- line 2351 ---
    cache_get_field_content_int(3, 197964328, 1);
    // stack 16
    // var_-5728 = _;
    // --- line 2352 ---
    cache_get_field_content_int(3, 197964372, 1);
    // stack 16
    // var_-5732 = _;
    // --- line 2353 ---
    cache_get_field_content_int(3, 197964420, 1);
    // stack 16
    // var_-5736 = _;
    // --- line 2355 ---
    cache_get_field_content_int(4, 197964480, 1);
    // stack 16
    // var_-5740 = _;
    // --- line 2356 ---
    cache_get_field_content_int(4, 197964492, 1);
    // stack 16
    // var_-5744 = _;
    // --- line 2357 ---
    cache_get_field_content_int(4, 197964536, 1);
    // stack 16
    // var_-5748 = _;
    // --- line 2358 ---
    cache_get_field_content_int(4, 197964584, 1);
    // stack 16
    // var_-5752 = _;
    // --- line 2360 ---
    // stack -1024
    // --- line 2362 ---
    // load var_-5688
    if (_) goto lbl_0x558c0; // jnz
    // --- line 2363 ---
    format(-5672, 64, 197964644);
    // stack 16
    goto lbl_0x558fc; // jump 0x558fc
    // --- line 2365 ---
    format(-5672, 64, 197964692);
    // stack 20
    // --- line 2368 ---
    // load var_-5680
    switch (_) // -> 0x55c00
    // --- line 2372 ---
    GivePlayerMoneyEx(20, playerid, var_-5684);
    // --- line 2373 ---
    format(-6776, 256, 197964828);
    // stack 24
    goto lbl_0x55c2c; // jump 0x55c2c
    // --- line 2377 ---
    GivePlayerDonateRub(20, playerid, var_-5684);
    // --- line 2378 ---
    format(-6776, 256, 197964944);
    // stack 24
    goto lbl_0x55c2c; // jump 0x55c2c
    // --- line 2382 ---
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    // --- line 2383 ---
    format(-6776, 256, 197965068);
    // stack 28
    goto lbl_0x55c2c; // jump 0x55c2c
    // --- line 2387 ---
    // _ = 181530104;
    // load playerid
    // --- line 2388 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197965276);
    // --- line 2389 ---
    format(-6776, 256, 197965292);
    // stack 20
    goto lbl_0x55c2c; // jump 0x55c2c
    // casetbl cases=5
    // --- line 2392 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2394 ---
    // --- line 2395 ---
    // load var_-5688
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197965396);
    // stack 36
    // --- line 2398 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2399 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x55e28; // jzer
    // --- line 2401 ---
    mysql_errno(1);
    // stack 8
    printf(197965880, -5676);
    // stack 20
    goto lbl_0x55eac; // jump 0x55eac
    // --- line 2405 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2406 ---
    // load var_-5688
    goto lbl_0x55ea4; // jsgeq 0x55ea4
    // --- line 2408 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    // stack 4
    // --- line 2411 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2414 ---
    // load var_-5704
    if (_) goto lbl_0x55f28; // jnz
    // --- line 2415 ---
    format(-5672, 64, 197966144);
    // stack 16
    goto lbl_0x55f64; // jump 0x55f64
    // --- line 2417 ---
    format(-5672, 64, 197966192);
    // stack 20
    // --- line 2420 ---
    // load var_-5696
    switch (_) // -> 0x56268
    // --- line 2424 ---
    GivePlayerMoneyEx(20, playerid, var_-5700);
    // --- line 2425 ---
    format(-6776, 256, 197966328);
    // stack 24
    goto lbl_0x56294; // jump 0x56294
    // --- line 2429 ---
    GivePlayerDonateRub(20, playerid, var_-5700);
    // --- line 2430 ---
    format(-6776, 256, 197966444);
    // stack 24
    goto lbl_0x56294; // jump 0x56294
    // --- line 2434 ---
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    // --- line 2435 ---
    format(-6776, 256, 197966568);
    // stack 28
    goto lbl_0x56294; // jump 0x56294
    // --- line 2439 ---
    // _ = 181530104;
    // load playerid
    // --- line 2440 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197966776);
    // --- line 2441 ---
    format(-6776, 256, 197966792);
    // stack 20
    goto lbl_0x56294; // jump 0x56294
    // casetbl cases=5
    // --- line 2444 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2446 ---
    // load var_-5704
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197966896);
    // stack 36
    // --- line 2449 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2450 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x56484; // jzer
    // --- line 2452 ---
    mysql_errno(1);
    // stack 8
    printf(197967380, -5692);
    // stack 20
    goto lbl_0x56508; // jump 0x56508
    // --- line 2456 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2457 ---
    // load var_-5704
    goto lbl_0x56500; // jsgeq 0x56500
    // --- line 2459 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    // stack 4
    // --- line 2462 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2466 ---
    // load var_-5720
    if (_) goto lbl_0x56584; // jnz
    // --- line 2467 ---
    format(-5672, 64, 197967644);
    // stack 16
    goto lbl_0x565c0; // jump 0x565c0
    // --- line 2469 ---
    format(-5672, 64, 197967692);
    // stack 20
    // --- line 2472 ---
    // load var_-5712
    switch (_) // -> 0x568c4
    // --- line 2476 ---
    GivePlayerMoneyEx(20, playerid, var_-5716);
    // --- line 2477 ---
    format(-6776, 256, 197967828);
    // stack 24
    goto lbl_0x568f0; // jump 0x568f0
    // --- line 2481 ---
    GivePlayerDonateRub(20, playerid, var_-5716);
    // --- line 2482 ---
    format(-6776, 256, 197967944);
    // stack 24
    goto lbl_0x568f0; // jump 0x568f0
    // --- line 2486 ---
    GivePromoCar(12, playerid, var_-5716, var_-1300);
    // --- line 2487 ---
    format(-6776, 256, 197968068);
    // stack 28
    goto lbl_0x568f0; // jump 0x568f0
    // --- line 2491 ---
    // _ = 181530104;
    // load playerid
    // --- line 2492 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197968276);
    // --- line 2493 ---
    format(-6776, 256, 197968292);
    // stack 20
    goto lbl_0x568f0; // jump 0x568f0
    // casetbl cases=5
    // --- line 2496 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2498 ---
    // load var_-5720
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197968396);
    // stack 36
    // --- line 2501 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2502 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x56ae0; // jzer
    // --- line 2504 ---
    mysql_errno(1);
    // stack 8
    printf(197968880, -5708);
    // stack 20
    goto lbl_0x56b64; // jump 0x56b64
    // --- line 2508 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2509 ---
    // load var_-5720
    goto lbl_0x56b5c; // jsgeq 0x56b5c
    // --- line 2511 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5720);
    // stack 4
    // --- line 2514 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2518 ---
    // load var_-5736
    if (_) goto lbl_0x56be0; // jnz
    // --- line 2519 ---
    format(-5672, 64, 197969144);
    // stack 16
    goto lbl_0x56c1c; // jump 0x56c1c
    // --- line 2521 ---
    format(-5672, 64, 197969192);
    // stack 20
    // --- line 2524 ---
    // load var_-5728
    switch (_) // -> 0x56f20
    // --- line 2528 ---
    GivePlayerMoneyEx(20, playerid, var_-5732);
    // --- line 2529 ---
    format(-6776, 256, 197969328);
    // stack 24
    goto lbl_0x56f4c; // jump 0x56f4c
    // --- line 2533 ---
    GivePlayerDonateRub(20, playerid, var_-5732);
    // --- line 2534 ---
    format(-6776, 256, 197969444);
    // stack 24
    goto lbl_0x56f4c; // jump 0x56f4c
    // --- line 2538 ---
    GivePromoCar(12, playerid, var_-5732, var_-1300);
    // --- line 2539 ---
    format(-6776, 256, 197969568);
    // stack 28
    goto lbl_0x56f4c; // jump 0x56f4c
    // --- line 2543 ---
    // _ = 181530104;
    // load playerid
    // --- line 2544 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197969776);
    // --- line 2545 ---
    format(-6776, 256, 197969792);
    // stack 20
    goto lbl_0x56f4c; // jump 0x56f4c
    // casetbl cases=5
    // --- line 2548 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2550 ---
    // load var_-5736
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197969896);
    // stack 36
    // --- line 2553 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2554 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x5713c; // jzer
    // --- line 2556 ---
    mysql_errno(1);
    // stack 8
    printf(197970380, -5724);
    // stack 20
    goto lbl_0x571c0; // jump 0x571c0
    // --- line 2560 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2561 ---
    // load var_-5736
    goto lbl_0x571b8; // jsgeq 0x571b8
    // --- line 2563 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5736);
    // stack 4
    // --- line 2566 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // --- line 2570 ---
    // load var_-5736
    if (_) goto lbl_0x5723c; // jnz
    // --- line 2571 ---
    format(-5672, 64, 197970644);
    // stack 16
    goto lbl_0x57278; // jump 0x57278
    // --- line 2573 ---
    format(-5672, 64, 197970692);
    // stack 20
    // --- line 2576 ---
    // load var_-5744
    switch (_) // -> 0x5757c
    // --- line 2580 ---
    GivePlayerMoneyEx(20, playerid, var_-5748);
    // --- line 2581 ---
    format(-6776, 256, 197970828);
    // stack 24
    goto lbl_0x575a8; // jump 0x575a8
    // --- line 2585 ---
    GivePlayerDonateRub(20, playerid, var_-5748);
    // --- line 2586 ---
    format(-6776, 256, 197970944);
    // stack 24
    goto lbl_0x575a8; // jump 0x575a8
    // --- line 2590 ---
    GivePromoCar(12, playerid, var_-5748, var_-1300);
    // --- line 2591 ---
    format(-6776, 256, 197971068);
    // stack 28
    goto lbl_0x575a8; // jump 0x575a8
    // --- line 2595 ---
    // _ = 181530104;
    // load playerid
    // --- line 2596 ---
    // _ = 181530104;
    // load playerid
    UpdatePlayerDatabaseInt(12, playerid, 197971276);
    // --- line 2597 ---
    format(-6776, 256, 197971292);
    // stack 20
    goto lbl_0x575a8; // jump 0x575a8
    // casetbl cases=5
    // --- line 2600 ---
    strcat(-5412, -6776);
    // stack 16
    // --- line 2602 ---
    // load var_-5752
    gettime(12);
    // stack 16
    mysql_format(166387936, -1292, 286, 197971396);
    // stack 36
    // --- line 2605 ---
    mysql_query(166387936, -1292);
    // stack 16
    // var_-6780 = _;
    // --- line 2606 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x57798; // jzer
    // --- line 2608 ---
    mysql_errno(1);
    // stack 8
    printf(197971880, -5740);
    // stack 20
    goto lbl_0x5781c; // jump 0x5781c
    // --- line 2612 ---
    // stack -4
    cache_insert_id(4, var_-6780);
    // stack 8
    // var_-6784 = _;
    // --- line 2613 ---
    // load var_-5752
    goto lbl_0x57814; // jsgeq 0x57814
    // --- line 2615 ---
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5752);
    // stack 4
    // --- line 2618 ---
    cache_delete(8, var_-6780, 1);
    // stack 12
    // stack 1028
    // --- line 2620 ---
    cache_delete(8, var_-1296, 1);
    // stack 12
    // --- line 2622 ---
    if (!_) goto lbl_0x579ac; // jzer
    // --- line 2624 ---
    mysql_format(166387936, -1292, 286, 197972144);
    // stack 24
    // --- line 2625 ---
    mysql_query(166387936, -1292);
    // stack 16
    // --- line 2627 ---
    // stack -4
    GetPromoCodeIndexByString(4, var_28);
    // var_-5756 = _;
    // --- line 2628 ---
    // load var_-5756
    // _ = -1;
    goto lbl_0x579a4; // jeq 0x579a4
    // --- line 2630 ---
    // _ = 197791640;
    // load var_-5756
    // stack 4
    // --- line 2634 ---
    // --- line 2636 ---
    // load var_-1308
    goto lbl_0x57a00; // jsless 0x57a00
    // load var_-1308
    // _ = 10;
    goto lbl_0x57a00; // jsgrtr 0x57a00
    goto lbl_0x57a04; // jump 0x57a04
    if (!_) goto lbl_0x57a4c; // jzer
    // --- line 2638 ---
    // _ = 197789848;
    // load var_-1308
    // var_-5756 = _;
    // --- line 2641 ---
    mysql_format(166387936, -1292, 286, 197972392);
    // stack 28
    // --- line 2642 ---
    mysql_query(166387936, -1292);
    // stack 16
    // --- line 2644 ---
    // stack -4
    GetPlayerIDFromAccountID(4, var_-1304);
    // var_-5760 = _;
    // --- line 2646 ---
    // load var_-5760
    // _ = -1;
    goto lbl_0x57bac; // jeq 0x57bac
    // --- line 2648 ---
    // stack -1024
    // --- line 2649 ---
    format(-6784, 256, 197972848);
    // stack 20
    // --- line 2650 ---
    SendClientMessage(var_-5760, -1, -6784);
    // stack 16
    // stack 1024
    // --- line 2653 ---
    fg_ShowPlayerDialog(28, playerid, "ew", 0, 197973252, -5412, 197973452, 197973464);
    // --- line 2654 ---
    // _ = 181530104;
    // load playerid
    AddPlayerActivatedPromo(8);
    // --- line 2655 ---
    // stack 5760
    return 1;
    // --- line 2659 ---
    SendClientMessage(playerid, -1, 197973468);
    // stack 16
    // --- line 2660 ---
    // stack 1316
    return 1;
    // --- line 2665 ---
    SendClientMessage(playerid, -1, 197973748);
    // stack 16
    // --- line 2666 ---
    // stack 1316
    return 1;
    goto lbl_0x57d80; // jump 0x57d80
    // casetbl cases=16
    // --- line 2671 ---
    prom_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


// AMX 0x57dc0-0x57f64
stock CheckUsePromoCode(playerid, accountId, promoSqlId)
{
    // --- line 2687 ---
    // --- line 2689 ---
    // stack -624
    // --- line 2691 ---
    mysql_format(166387936, -624, 156, 197973896);
    // stack 28
    // --- line 2692 ---
    // stack -4
    mysql_query(166387936, -624);
    // stack 16
    // var_-628 = _;
    // --- line 2694 ---
    cache_get_row_count(4, var_-628);
    // stack 8
    goto lbl_0x57f20; // jsgeq 0x57f20
    // --- line 2696 ---
    SendClientMessage(playerid, -1, 197974464);
    // stack 16
    // --- line 2697 ---
    cache_delete(8, var_-628, 1);
    // stack 12
    // --- line 2698 ---
    // stack 628
    return 1;
    // --- line 2700 ---
    cache_delete(8, var_-628, 1);
    // stack 12
    // --- line 2701 ---
    // stack 628
    return 1;
}


// AMX 0x57f64-0x58aa8
public OnPromoCodeCheckComplete(playerid)
{
    // --- line 2704 ---
    // --- line 2706 ---
    IsPlayerConnected(playerid);
    // stack 8
    if (!_) goto lbl_0x57fa8; // jzer
    // --- line 2708 ---
    return 1;
    // --- line 2711 ---
    // stack -1032
    // --- line 2712 ---
    // stack -4
    // _ = 181530104;
    // load playerid
    // var_-1036 = _;
    // --- line 2713 ---
    // stack -4
    // _ = 181530104;
    // load playerid
    // var_-1040 = _;
    // --- line 2714 ---
    // stack -128
    // --- line 2715 ---
    // stack -1024
    // --- line 2716 ---
    // --- line 2718 ---
    mysql_format(166387936, -1032, 258, 197974676);
    // stack 24
    // --- line 2719 ---
    mysql_query(166387936, -1032);
    // stack 16
    // var_-2196 = _;
    // --- line 2721 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x581e4; // jzer
    // --- line 2723 ---
    SendClientMessage(playerid, -1, 197974880);
    // stack 16
    // --- line 2724 ---
    pc_cmd_promo(8, playerid, 197975196);
    // --- line 2725 ---
    cache_delete(8, var_-2196, 1);
    // stack 12
    // --- line 2726 ---
    // stack 2196
    return 1;
    // --- line 2729 ---
    cache_get_row_count(4, var_-2196);
    // stack 8
    goto lbl_0x582b4; // jsgeq 0x582b4
    // --- line 2731 ---
    SendClientMessage(playerid, -1, 197975200);
    // stack 16
    // --- line 2732 ---
    pc_cmd_promo(8, playerid, 197975544);
    // --- line 2733 ---
    cache_delete(8, var_-2196, 1);
    // stack 12
    // --- line 2734 ---
    // stack 2196
    return 1;
    // --- line 2736 ---
    cache_delete(8, var_-2196, 1);
    // stack 12
    // --- line 2738 ---
    // stack -4
    strlen(var_16);
    // stack 8
    // var_-2200 = _;
    // --- line 2739 ---
    // --- line 2740 ---
    // --- line 2742 ---
    // load var_-2200
    // _ = 3;
    goto lbl_0x58370; // jsless 0x58370
    // load var_-2200
    // _ = 4;
    goto lbl_0x58370; // jsgrtr 0x58370
    goto lbl_0x58374; // jump 0x58374
    if (!_) goto lbl_0x583ac; // jzer
    // --- line 2744 ---
    // var_-2204 = _;
    // --- line 2745 ---
    // var_-2208 = _;
    goto lbl_0x58448; // jump 0x58448
    // --- line 2747 ---
    // load var_-2200
    // _ = 5;
    goto lbl_0x583f0; // jsless 0x583f0
    // load var_-2200
    // _ = 7;
    goto lbl_0x583f0; // jsgrtr 0x583f0
    goto lbl_0x583f4; // jump 0x583f4
    if (!_) goto lbl_0x58418; // jzer
    // --- line 2749 ---
    // var_-2204 = _;
    goto lbl_0x58448; // jump 0x58448
    // --- line 2751 ---
    // load var_-2200
    // _ = 8;
    goto lbl_0x58448; // jsless 0x58448
    // --- line 2753 ---
    // var_-2204 = _;
    // --- line 2756 ---
    // --- line 2757 ---
    // load var_-2212
    // _ = 31;
    goto lbl_0x584a4; // jsgeq 0x584a4
    // load var_-2212
    if (!_) goto lbl_0x584a4; // jzer
    goto lbl_0x584a8; // jump 0x584a8
    if (!_) goto lbl_0x58508; // jzer
    // --- line 2759 ---
    // load var_-2212
    // load var_-2212
    // --- line 2760 ---
    goto lbl_0x58458; // jump 0x58458
    // --- line 2762 ---
    // load var_-2212
    // --- line 2764 ---
    // stack -256
    // --- line 2765 ---
    // load var_-2208
    goto lbl_0x585bc; // jsgeq 0x585bc
    // --- line 2766 ---
    format(-2468, 64, 197975548);
    // stack 24
    goto lbl_0x585f8; // jump 0x585f8
    // --- line 2768 ---
    format(-2468, 64, 197975628);
    // stack 20
    // --- line 2773 ---
    mysql_format(166387936, -1032, 258, 197975668);
    // stack 32
    // --- line 2774 ---
    mysql_query(166387936, -1032);
    // stack 16
    // var_-2196 = _;
    // --- line 2776 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x58750; // jzer
    // --- line 2778 ---
    SendClientMessage(playerid, -1, 197976232);
    // stack 16
    // --- line 2779 ---
    pc_cmd_promo(8, playerid, 197976576);
    // --- line 2780 ---
    cache_delete(8, var_-2196, 1);
    // stack 12
    // --- line 2781 ---
    // stack 2468
    return 1;
    // --- line 2783 ---
    cache_delete(8, var_-2196, 1);
    // stack 12
    // --- line 2785 ---
    // load var_-1040
    goto lbl_0x58980; // jsgeq 0x58980
    // --- line 2787 ---
    // load var_-1040
    goto lbl_0x58868; // jsgeq 0x58868
    // --- line 2789 ---
    format(-2192, 256, 197976580);
    // stack 24
    // --- line 2790 ---
    SendClientMessage(playerid, -1, -2192);
    // stack 16
    // --- line 2791 ---
    pc_cmd_promo(8, playerid, 197976928);
    // --- line 2792 ---
    // stack 2468
    return 1;
    // --- line 2796 ---
    // load var_-2208
    GivePlayerDonateRub(20, playerid);
    // --- line 2797 ---
    format(-2192, 256, 197976932);
    // stack 24
    // --- line 2798 ---
    SendClientMessage(playerid, -1, -2192);
    // stack 16
    // --- line 2799 ---
    pc_cmd_mypromo(8, playerid, 197977384);
    // --- line 2800 ---
    LoadPromoCodesFromDatabase(0);
    goto lbl_0x58a90; // jump 0x58a90
    // --- line 2805 ---
    // load var_-2204
    GivePlayerMoneyEx(20, playerid);
    // --- line 2806 ---
    format(-2192, 256, 197977388);
    // stack 24
    // --- line 2807 ---
    SendClientMessage(playerid, -1, -2192);
    // stack 16
    // --- line 2808 ---
    pc_cmd_mypromo(8, playerid, 197977828);
    // --- line 2809 ---
    LoadPromoCodesFromDatabase(0);
    // --- line 2812 ---
    // stack 2468
    return 1;
}


// AMX 0x58aa8-0x58c04
stock HasPlayerCreatedPromo(playerid)
{
    // --- line 2815 ---
    // --- line 2817 ---
    // stack -512
    // --- line 2818 ---
    // _ = 181530104;
    // load playerid
    mysql_format(166387936, -512, 128, 197977832);
    // stack 24
    // --- line 2819 ---
    // stack -4
    mysql_query(166387936, -512);
    // stack 16
    // var_-516 = _;
    // --- line 2820 ---
    // stack -4
    cache_get_row_count(4, var_-516);
    // stack 8
    // var_-520 = _;
    // --- line 2821 ---
    cache_delete(8, var_-516, 1);
    // stack 12
    // --- line 2822 ---
    // load var_-520
    // stack 520
    return 1;
}


// AMX 0x58c04-0x58cbc
stock AddPlayerActivatedPromo(account_id, promo_id)
{
    // --- line 2825 ---
    // --- line 2827 ---
    // stack -1024
    // --- line 2828 ---
    mysql_format(166387936, -1024, 256, 197978112);
    // stack 28
    // --- line 2829 ---
    mysql_query(166387936, -1024);
    // stack 16
    // stack 1024
    return 1;
}


// AMX 0x58cbc-0x5a0c8
stock SavePromoLevelPrizes(promoId, level)
{
    // --- line 2832 ---
    // --- line 2834 ---
    // --- line 2835 ---
    // stack -1024
    // --- line 2837 ---
    // stack -80
    // --- line 2839 ---
    mysql_format(166387936, -1028, 256, 197978520);
    // stack 24
    // --- line 2840 ---
    mysql_query(166387936, -1028);
    // stack 16
    // --- line 2842 ---
    // _ = 197789848;
    // load level
    // var_-4 = _;
    // --- line 2844 ---
    // load level
    switch (_) // -> 0x59e0c
    // --- line 2848 ---
    goto lbl_0x58e14; // jump 0x58e14
    // load var_-1112
    goto lbl_0x58f80; // jsgeq 0x58f80
    // --- line 2849 ---
    // load var_-1112
    // _ = 197790112;
    // load var_-1112
    // --- line 2850 ---
    // load var_-1112
    // _ = 197790112;
    // load var_-1112
    // --- line 2851 ---
    // load var_-1112
    // _ = 197790112;
    // load var_-1112
    goto lbl_0x58e08; // jump 0x58e08
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2856 ---
    goto lbl_0x58fb0; // jump 0x58fb0
    // load var_-1112
    goto lbl_0x5911c; // jsgeq 0x5911c
    // --- line 2857 ---
    // load var_-1112
    // _ = 197790128;
    // load var_-1112
    // --- line 2858 ---
    // load var_-1112
    // _ = 197790128;
    // load var_-1112
    // --- line 2859 ---
    // load var_-1112
    // _ = 197790128;
    // load var_-1112
    goto lbl_0x58fa4; // jump 0x58fa4
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2864 ---
    goto lbl_0x5914c; // jump 0x5914c
    // load var_-1112
    goto lbl_0x592b8; // jsgeq 0x592b8
    // --- line 2865 ---
    // load var_-1112
    // _ = 197790160;
    // load var_-1112
    // --- line 2866 ---
    // load var_-1112
    // _ = 197790160;
    // load var_-1112
    // --- line 2867 ---
    // load var_-1112
    // _ = 197790160;
    // load var_-1112
    goto lbl_0x59140; // jump 0x59140
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2872 ---
    goto lbl_0x592e8; // jump 0x592e8
    // load var_-1112
    goto lbl_0x59454; // jsgeq 0x59454
    // --- line 2873 ---
    // load var_-1112
    // _ = 197790208;
    // load var_-1112
    // --- line 2874 ---
    // load var_-1112
    // _ = 197790208;
    // load var_-1112
    // --- line 2875 ---
    // load var_-1112
    // _ = 197790208;
    // load var_-1112
    goto lbl_0x592dc; // jump 0x592dc
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2880 ---
    goto lbl_0x59484; // jump 0x59484
    // load var_-1112
    goto lbl_0x595f0; // jsgeq 0x595f0
    // --- line 2881 ---
    // load var_-1112
    // _ = 197790256;
    // load var_-1112
    // --- line 2882 ---
    // load var_-1112
    // _ = 197790256;
    // load var_-1112
    // --- line 2883 ---
    // load var_-1112
    // _ = 197790256;
    // load var_-1112
    goto lbl_0x59478; // jump 0x59478
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2888 ---
    goto lbl_0x59620; // jump 0x59620
    // load var_-1112
    goto lbl_0x5978c; // jsgeq 0x5978c
    // --- line 2889 ---
    // load var_-1112
    // _ = 197790304;
    // load var_-1112
    // --- line 2890 ---
    // load var_-1112
    // _ = 197790304;
    // load var_-1112
    // --- line 2891 ---
    // load var_-1112
    // _ = 197790304;
    // load var_-1112
    goto lbl_0x59614; // jump 0x59614
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2896 ---
    goto lbl_0x597bc; // jump 0x597bc
    // load var_-1112
    goto lbl_0x59928; // jsgeq 0x59928
    // --- line 2897 ---
    // load var_-1112
    // _ = 197790352;
    // load var_-1112
    // --- line 2898 ---
    // load var_-1112
    // _ = 197790352;
    // load var_-1112
    // --- line 2899 ---
    // load var_-1112
    // _ = 197790352;
    // load var_-1112
    goto lbl_0x597b0; // jump 0x597b0
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2904 ---
    goto lbl_0x59958; // jump 0x59958
    // load var_-1112
    goto lbl_0x59ac4; // jsgeq 0x59ac4
    // --- line 2905 ---
    // load var_-1112
    // _ = 197790416;
    // load var_-1112
    // --- line 2906 ---
    // load var_-1112
    // _ = 197790416;
    // load var_-1112
    // --- line 2907 ---
    // load var_-1112
    // _ = 197790416;
    // load var_-1112
    goto lbl_0x5994c; // jump 0x5994c
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2912 ---
    goto lbl_0x59af4; // jump 0x59af4
    // load var_-1112
    goto lbl_0x59c60; // jsgeq 0x59c60
    // --- line 2913 ---
    // load var_-1112
    // _ = 197790480;
    // load var_-1112
    // --- line 2914 ---
    // load var_-1112
    // _ = 197790480;
    // load var_-1112
    // --- line 2915 ---
    // load var_-1112
    // _ = 197790480;
    // load var_-1112
    goto lbl_0x59ae8; // jump 0x59ae8
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // --- line 2920 ---
    goto lbl_0x59c90; // jump 0x59c90
    // load var_-1112
    goto lbl_0x59dfc; // jsgeq 0x59dfc
    // --- line 2921 ---
    // load var_-1112
    // _ = 197790560;
    // load var_-1112
    // --- line 2922 ---
    // load var_-1112
    // _ = 197790560;
    // load var_-1112
    // --- line 2923 ---
    // load var_-1112
    // _ = 197790560;
    // load var_-1112
    goto lbl_0x59c84; // jump 0x59c84
    // stack 4
    goto lbl_0x59e68; // jump 0x59e68
    // casetbl cases=11
    // --- line 2928 ---
    goto lbl_0x59e88; // jump 0x59e88
    // load var_-1112
    goto lbl_0x5a0b0; // jsgeq 0x5a0b0
    // --- line 2930 ---
    // stack -4
    // load var_-1112
    // var_-1116 = _;
    // --- line 2931 ---
    // stack -4
    // load var_-1112
    // var_-1120 = _;
    // --- line 2932 ---
    // stack -4
    // load var_-1112
    // var_-1124 = _;
    // --- line 2934 ---
    mysql_format(166387936, -1028, 256, 197978716);
    // stack 40
    // --- line 2938 ---
    mysql_query(166387936, -1028);
    // stack 16
    // --- line 2940 ---
    mysql_errno(1);
    // stack 8
    if (!_) goto lbl_0x5a0a0; // jzer
    // --- line 2942 ---
    mysql_errno(1);
    // stack 8
    printf(197979236, 16);
    // stack 20
    // stack 12
    goto lbl_0x59e7c; // jump 0x59e7c
    // stack 4
    // stack 1108
    return 1;
}


// AMX 0x5a0c8-0x5a25c
stock GetPromoLevelForOwner(playerid)
{
    // --- line 2964 ---
    // --- line 2966 ---
    // stack -512
    // --- line 2967 ---
    // --- line 2969 ---
    // _ = 181530104;
    // load playerid
    mysql_format(166387936, -512, 128, 197979608);
    // stack 24
    // --- line 2970 ---
    // stack -4
    mysql_query(166387936, -512);
    // stack 16
    // var_-520 = _;
    // --- line 2972 ---
    cache_get_row_count(4, var_-520);
    // stack 8
    goto lbl_0x5a218; // jsgeq 0x5a218
    // --- line 2974 ---
    cache_get_field_content_int(0, 197979924, 1);
    // stack 16
    // var_-516 = _;
    // --- line 2977 ---
    cache_delete(8, var_-520, 1);
    // stack 12
    // --- line 2978 ---
    // load var_-516
    // stack 520
    return 1;
}


// AMX 0x5a25c-0x5a290
stock pc_cmd_createpromo(playerid)
{
    // --- line 2981 ---
    // --- line 2983 ---
    pc_cmd_addcpromo(8, playerid, 197979972);
    return 1;
}


// AMX 0x5a290-0x5a2c4
stock pc_cmd_createytpromo(playerid)
{
    // --- line 2986 ---
    // --- line 2988 ---
    pc_cmd_addcpromo(8, playerid, 197979976);
    return 1;
}


// AMX 0x5a2c4-0x5a3a8
stock pc_cmd_addcpromo(playerid)
{
    // --- line 2992 ---
    // --- line 2994 ---
    // _ = 181530104;
    // load playerid
    // _ = 13;
    goto lbl_0x5a34c; // jsgeq 0x5a34c
    SendClientMessage(playerid, -1, 197979980);
    // stack 16
    return 1;
    // --- line 2996 ---
    fg_ShowPlayerDialog(28, playerid, "w", 1, 197980276, 197980472, 197980644, 197980668);
    // --- line 2997 ---
    return 1;
}


// AMX 0x5a3a8-0x5a524
stock pc_cmd_promo(playerid)
{
    // --- line 3000 ---
    // --- line 3002 ---
    // stack -2048
    // --- line 3003 ---
    // stack -256
    // --- line 3005 ---
    HasPlayerCreatedPromo(4, playerid);
    if (!_) goto lbl_0x5a450; // jzer
    // --- line 3007 ---
    format(-2304, 64, 197980696);
    // stack 16
    goto lbl_0x5a484; // jump 0x5a484
    // --- line 3011 ---
    format(-2304, 64, 197981040);
    // stack 16
    // --- line 3014 ---
    format(-2048, 512, 197981364);
    // stack 20
    // --- line 3016 ---
    fg_ShowPlayerDialog(28, playerid, "sesRenters", 2, 197982340, -2048, 197982412, 197982436);
    // --- line 3021 ---
    // stack 2304
    return 1;
}


// AMX 0x5a524-0x5a560
stock pc_alias_promo()
{
    // --- line 3023 ---
    PC_RegAlias(8, 197982460, 197982484);
    // stack 12
    return 1;
}


// AMX 0x5a560-0x5a98c
stock pc_cmd_mypromo(playerid)
{
    // --- line 3025 ---
    // --- line 3027 ---
    // stack -1024
    // --- line 3028 ---
    // stack -2048
    // --- line 3029 ---
    // stack -128
    // --- line 3030 ---
    // --- line 3032 ---
    // _ = 181530104;
    // load playerid
    mysql_format(166387936, -1024, 256, 197982524);
    // stack 24
    // --- line 3033 ---
    // stack -4
    mysql_query(166387936, -1024);
    // stack 16
    // var_-3216 = _;
    // --- line 3035 ---
    cache_get_row_count(4, var_-3216);
    // stack 8
    if (_) goto lbl_0x5a734; // jnz
    // --- line 3037 ---
    SendClientMessage(playerid, -1, 197982932);
    // stack 16
    // --- line 3038 ---
    cache_delete(8, var_-3216, 1);
    // stack 12
    // --- line 3039 ---
    // stack 3216
    return 1;
    // --- line 3042 ---
    cache_get_field_content(20, 0, 197983120, -3200, 32, 32);
    // stack 24
    // --- line 3043 ---
    cache_get_field_content_int(0, 197983140, 1);
    // stack 16
    // var_-3204 = _;
    // --- line 3044 ---
    cache_get_field_content_int(0, 197983188, 1);
    // stack 16
    // var_-3208 = _;
    // --- line 3046 ---
    // load var_-3204
    goto lbl_0x5a838; // jsless 0x5a838
    // load var_-3204
    // _ = 11;
    goto lbl_0x5a838; // jsgeq 0x5a838
    goto lbl_0x5a83c; // jump 0x5a83c
    if (!_) goto lbl_0x5a89c; // jzer
    // --- line 3048 ---
    // load var_-3204
    // var_-3212 = _;
    goto lbl_0x5a8a8; // jump 0x5a8a8
    // --- line 3052 ---
    // --- line 3055 ---
    format(-3072, 512, 197983236);
    // stack 32
    // --- line 3057 ---
    fg_ShowPlayerDialog(28, playerid, "nters", 2, 197984156, -3072, 197984228, 197984252);
    // --- line 3063 ---
    cache_delete(8, var_-3216, 1);
    // stack 12
    // --- line 3064 ---
    // stack 3216
    return 1;
}


// AMX 0x5a98c-0x5a9c8
stock pc_alias_mypromo()
{
    // --- line 3066 ---
    PC_RegAlias(8, 197984276, 197984308);
    // stack 12
    return 1;
}


// AMX 0x5a9c8-0x5af70
stock pc_cmd_checkpromo(playerid)
{
    // --- line 3068 ---
    // --- line 3070 ---
    // stack -1024
    // --- line 3071 ---
    // stack -2048
    // --- line 3072 ---
    // stack -608
    // --- line 3073 ---
    // --- line 3075 ---
    // _ = 181530104;
    // load playerid
    mysql_format(166387936, -1024, 256, 197984356);
    // stack 24
    // --- line 3076 ---
    mysql_query(166387936, -1024);
    // stack 16
    // var_-3684 = _;
    // --- line 3078 ---
    cache_get_row_count(4, var_-3684);
    // stack 8
    if (_) goto lbl_0x5ab84; // jnz
    // --- line 3080 ---
    SendClientMessage(playerid, -1, 197984856);
    // stack 16
    // --- line 3081 ---
    cache_delete(8, var_-3684, 1);
    // stack 12
    // --- line 3082 ---
    // stack 3684
    return 1;
    // --- line 3085 ---
    // stack -128
    // --- line 3086 ---
    // --- line 3088 ---
    cache_get_field_content_int(0, 197985044, 1);
    // stack 16
    // var_-3828 = _;
    // --- line 3089 ---
    cache_get_field_content(20, 0, 197985056, -3812, 32, 32);
    // stack 24
    // --- line 3090 ---
    cache_get_field_content_int(0, 197985076, 1);
    // stack 16
    // var_-3816 = _;
    // --- line 3091 ---
    cache_get_field_content_int(0, 197985124, 1);
    // stack 16
    // var_-3820 = _;
    // --- line 3092 ---
    cache_get_field_content_int(0, 197985172, 1);
    // stack 16
    // var_-3824 = _;
    // --- line 3093 ---
    cache_delete(8, var_-3684, 1);
    // stack 12
    // --- line 3095 ---
    // load var_-3816
    if (_) goto lbl_0x5ad88; // jnz
    // --- line 3097 ---
    SendClientMessage(playerid, -1, 197985228);
    // stack 16
    // --- line 3098 ---
    // stack 3828
    return 1;
    // --- line 3101 ---
    format(-3680, 152, 197985568);
    // stack 20
    // --- line 3103 ---
    format(-3072, 512, 197985616);
    // stack 28
    // --- line 3105 ---
    fg_ShowPlayerDialog(28, playerid, "s", 0, -3680, -3072, 197986116, 197986140);
    // --- line 3107 ---
    // load var_-3824
    if (_) goto lbl_0x5ae88; // jnz
    // stack 3828
    return 1;
    // --- line 3109 ---
    GivePlayerMoneyEx(20, playerid, var_-3824);
    // --- line 3111 ---
    mysql_format(166387936, -1024, 256, 197986144);
    // stack 24
    // --- line 3112 ---
    mysql_query(166387936, -1024);
    // stack 16
    // --- line 3114 ---
    // stack 3828
    return 1;
}


// AMX 0x5af70-0x5afd4
stock pc_cmd_bcode(playerid)
{
    // --- line 3117 ---
    // --- line 3119 ---
    fg_ShowPlayerDialog(28, playerid, "ousesRenters", 1, 197986384, 197986452, 197986640, 197986668);
    // --- line 3120 ---
    return 1;
}


stock blackjack_OnGameModeInit()
{
    print(197880844);
    SetTimer(197881028, 1500, 0);
    SetTimer(197881132, 3000, 0);
    prom_OnGameModeInit(0);
    return 1;
}


public OnPromoTimerTick(playerPromoSQLID)
{
    mysql_format(166387936, -1024, 256, 197881240);
    mysql_query(166387936, -1024);
    mysql_errno(1);
    if (_) goto lbl_0x46880;
    cache_get_row_count(4, var_-1028);
    if (!_) goto lbl_0x46880;
    goto lbl_0x46888;
    if (!_) goto lbl_0x46d4c;
    mysql_errno(1);
    printf(197882108, 12);
    goto lbl_0x46914;
    goto lbl_0x46d04;
    IsPlayerConnected(var_-1052);
    if (!_) goto lbl_0x46968;
    goto lbl_0x46908;
    goto lbl_0x46988;
    goto lbl_0x46cf4;
    goto lbl_0x46cec;
    goto lbl_0x46ad4;
    goto lbl_0x46ca4;
    goto lbl_0x46ac8;
    goto lbl_0x46cf4;
    goto lbl_0x4697c;
    goto lbl_0x46908;
    cache_delete(8, var_-1028, 1);
    return 1;
    cache_get_field_content_int(0, 197882496, 1);
    cache_get_field_content_int(0, 197882540, 1);
    cache_get_field_content_int(0, 197882584, 1);
    cache_get_field_content_int(0, 197882628, 1);
    cache_get_field_content_int(0, 197882676, 1);
    cache_get_field_content_int(0, 197882736, 1);
    gettime(12);
    goto lbl_0x474b8;
    GetPlayerIDFromAccountID(4, var_-1032);
    goto lbl_0x47020;
    RevokePromoPrize(16, var_-1032, var_-1036, var_-1040, var_-1044);
    SendClientMessage(var_-1048, -1, 197882772);
    mysql_format(166387936, -1024, 256, 197883024);
    mysql_query(166387936, -1024);
    goto lbl_0x470b8;
    goto lbl_0x474a8;
    IsPlayerConnected(var_-1064);
    if (!_) goto lbl_0x4710c;
    goto lbl_0x470ac;
    goto lbl_0x4712c;
    goto lbl_0x47498;
    goto lbl_0x47490;
    goto lbl_0x47278;
    goto lbl_0x47448;
    goto lbl_0x4726c;
    goto lbl_0x47498;
    goto lbl_0x47120;
    goto lbl_0x470ac;
    goto lbl_0x47538;
    mysql_format(166387936, -1024, 256, 197883184);
    mysql_query(166387936, -1024);
    cache_delete(8, var_-1028, 1);
    return 1;
}


stock CheckAndCreatePromoTables()
{
    mysql_format(166387936, -2052, 512, 197883420);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x477bc;
    printf(4, 197883552);
    mysql_format(166387936, -2052, 512, 197883852);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x47798;
    mysql_errno(1);
    printf(197885864);
    goto lbl_0x477bc;
    printf(4, 197886104);
    cache_delete(8, var_-4, 1);
    mysql_format(166387936, -2052, 512, 197886392);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x479d4;
    printf(4, 197886556);
    mysql_format(166387936, -2052, 512, 197886880);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x479b0;
    mysql_errno(1);
    printf(197887956);
    goto lbl_0x479d4;
    printf(4, 197888220);
    cache_delete(8, var_-4, 1);
    mysql_format(166387936, -2052, 512, 197888456);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x47bec;
    printf(4, 197888596);
    mysql_format(166387936, -2052, 512, 197888840);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x47bc8;
    mysql_errno(1);
    printf(197890512);
    goto lbl_0x47bec;
    printf(4, 197890760);
    cache_delete(8, var_-4, 1);
    mysql_format(166387936, -2052, 512, 197890980);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (_) goto lbl_0x47cf8;
    cache_get_field_count(4, var_-4);
    goto lbl_0x47cf8;
    goto lbl_0x47d00;
    if (!_) goto lbl_0x47ed4;
    printf(4, 197891124);
    mysql_errno(1);
    if (_) goto lbl_0x47db0;
    mysql_query(166387936, 197891504);
    printf(4, 197891652);
    mysql_format(166387936, -2052, 512, 197891872);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x47eb0;
    mysql_errno(1);
    printf(197893400);
    goto lbl_0x47ed4;
    printf(4, 197893652);
    cache_delete(8, var_-4, 1);
    mysql_format(166387936, -2052, 512, 197893952);
    mysql_query(166387936, -2052);
    cache_get_row_count(4, 1);
    if (_) goto lbl_0x480ec;
    printf(4, 197894148);
    mysql_format(166387936, -2052, 512, 197894448);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x480c8;
    mysql_errno(1);
    printf(197894796);
    goto lbl_0x480ec;
    printf(4, 197895036);
    cache_delete(8, var_-4, 1);
    mysql_format(166387936, -2052, 512, 197895244);
    mysql_query(166387936, -2052);
    cache_get_row_count(4, 1);
    if (_) goto lbl_0x48304;
    printf(4, 197895472);
    mysql_format(166387936, -2052, 512, 197895804);
    mysql_query(166387936, -2052);
    mysql_errno(1);
    if (!_) goto lbl_0x482e0;
    mysql_errno(1);
    printf(197896200);
    goto lbl_0x48304;
    printf(4, 197896472);
    cache_delete(8, var_-4, 1);
    return 1;
}


stock LoadPromoCodesFromDatabase()
{
    printf(4, 197896712);
    mysql_format(166387936, -516, 128, 197896912);
    printf(197897180, -516);
    mysql_query(166387936, -516);
    mysql_errno(1);
    printf(197897312);
    mysql_errno(1);
    if (!_) goto lbl_0x48560;
    mysql_errno(1);
    printf(197897468);
    cache_delete(8, var_-4, 1);
    return 1;
    cache_get_row_count(4, var_-4);
    printf(197897664, 197806840);
    goto lbl_0x48654;
    printf(197897900, 197806840);
    goto lbl_0x4868c;
    if (_) goto lbl_0x4868c;
    printf(4, 197898316);
    goto lbl_0x486ac;
    goto lbl_0x488f4;
    cache_get_field_content_int(var_-520, 197898548, 1);
    cache_get_field_content(20, var_-520, 197898560);
    cache_get_field_content_int(var_-520, 197898580, 1);
    cache_get_field_content_int(var_-520, 197898624, 1);
    cache_get_field_content_int(var_-520, 197898664, 1);
    goto lbl_0x486a0;
    cache_delete(8, var_-4, 1);
    printf(197898708, 197806840);
    printf(4, 197898956);
    return 1;
}


stock blackjack_OnPlayerConnect(playerid)
{
    goto lbl_0x489e4;
    goto lbl_0x48acc;
    goto lbl_0x489d8;
    OnPlayerLogin(4, playerid);
    prom_OnPlayerConnect(4, playerid);
    return 1;
}


public OnPlayerLogin(playerid)
{
    mysql_format(166387936, -1032, 256, 197899152);
    mysql_query(166387936, -1032);
    cache_get_row_count(4, 1);
    goto lbl_0x490c8;
    goto lbl_0x48c74;
    goto lbl_0x490c0;
    cache_get_field_content_int(var_-1040, 197900128, 1);
    cache_get_field_content_int(var_-1040, 197900140, 1);
    cache_get_field_content_int(var_-1040, 197900184, 1);
    cache_get_field_content_int(var_-1040, 197900244, 1);
    cache_get_field_content_int(var_-1040, 197900304, 1);
    cache_get_field_content_int(var_-1040, 197900348, 1);
    cache_get_field_content_int(var_-1040, 197900396, 1);
    gettime(12);
    goto lbl_0x48fd0;
    mysql_format(166387936, -1032, 256, 197900432);
    mysql_query(166387936, -1032);
    SetPlayerPromoTimer(12, playerid, var_-1044, var_-1056);
    goto lbl_0x490b0;
    RevokePromoPrize(16, var_-4, var_-1060, var_-1064, var_-1068);
    mysql_format(166387936, -1032, 256, 197900668);
    mysql_query(166387936, -1032);
    SendClientMessage(playerid, -1, 197900828);
    goto lbl_0x48c68;
    cache_delete(8, var_-8, 1);
    return 1;
}


stock blackjack_OnPlayerDisconnect(playerid, reason)
{
    StopPlayerPromoTimer(4, playerid);
    prom_OnPlayerDisconnect(8, playerid, reason);
    return 1;
}


stock GetPlayerIDFromAccountID(accountId)
{
    goto lbl_0x49180;
    goto lbl_0x49240;
    IsPlayerConnected(var_-4);
    if (!_) goto lbl_0x49214;
    goto lbl_0x49214;
    goto lbl_0x49218;
    if (!_) goto lbl_0x49238;
    return 1;
    goto lbl_0x49174;
    return 1;
}


stock SetPlayerPromoTimer(playerid, playerPromoSQLID, durationHours)
{
    goto lbl_0x49348;
    printf(197901080);
    return 1;
    SetTimerEx(197901536, "4k", 1, 197901604);
    printf(197901612);
    return 1;
}


stock StopPlayerPromoTimer(playerid)
{
    goto lbl_0x495f8;
    goto lbl_0x49ca0;
    KillTimer(var_-1044);
    mysql_format(166387936, -1024, 256, 197902008);
    mysql_query(166387936, -1024);
    mysql_errno(1);
    if (_) goto lbl_0x49818;
    cache_get_row_count(4, var_-1028);
    goto lbl_0x49818;
    goto lbl_0x4981c;
    if (!_) goto lbl_0x49c64;
    cache_get_field_content_int(0, 197902276, 1);
    cache_get_field_content_int(0, 197902320, 1);
    mysql_format(166387936, -1572, 128, 197902380);
    mysql_query(166387936, -1572);
    mysql_errno(1);
    if (_) goto lbl_0x499d4;
    cache_get_row_count(4, var_-1060);
    goto lbl_0x499d4;
    goto lbl_0x499d8;
    if (!_) goto lbl_0x49a1c;
    cache_get_field_content_int(0, 197902864, 1);
    cache_delete(8, var_-1060, 1);
    gettime(12);
    goto lbl_0x49b08;
    min(8, var_-1052, var_-1576);
    goto lbl_0x49b6c;
    mysql_format(166387936, -1024, 256, 197902924);
    mysql_query(166387936, -1024);
    printf(197903160, -1040);
    cache_delete(8, var_-1028, 1);
    goto lbl_0x495ec;
    return 1;
}


stock RevokePromoPrize(accountId, prizeType, prizeValue, promoIdForCarRevoke)
{
    GetPlayerIDFromAccountID(4, accountId);
    if (!_) goto lbl_0x49d48;
    return 1;
    switch (_)
    goto lbl_0x49ec0;
    UpdatePlayerDatabaseInt(12, var_-4, 197903660, 0);
    SendClientMessage(var_-4, -1, 197903684);
    goto lbl_0x49f58;
    GivePlayerMoneyEx(20, var_-4);
    SendClientMessage(var_-4, -1, 197904192);
    goto lbl_0x4a614;
    goto lbl_0x4a0c0;
    GivePlayerDonateRub(20, var_-4);
    SendClientMessage(var_-4, -1, 197904584);
    goto lbl_0x4a158;
    GivePlayerDonateRub(20, var_-4);
    SendClientMessage(var_-4, -1, 197905120);
    goto lbl_0x4a614;
    mysql_format(166387936, -1028, 256, 197905516);
    mysql_query(166387936, -1028);
    cache_get_row_count(4, 1);
    goto lbl_0x4a58c;
    cache_get_field_content_int(0, 197906000, 1);
    cache_get_field_content_int(0, 197906012, 1);
    mysql_format(166387936, -1028, 256, 197906056);
    mysql_query(166387936, -1028);
    IsValidVehicle(4, var_-1044);
    if (!_) goto lbl_0x4a398;
    n_veh_DestroyVehicle(4, var_-1044);
    goto lbl_0x4a4e0;
    goto lbl_0x4a3b8;
    goto lbl_0x4a4d8;
    goto lbl_0x4a474;
    IsValidVehicle(4);
    if (!_) goto lbl_0x4a474;
    goto lbl_0x4a478;
    if (!_) goto lbl_0x4a4d0;
    n_veh_DestroyVehicle(4);
    goto lbl_0x4a4d8;
    goto lbl_0x4a3ac;
    SendClientMessage(var_-4, -1, 197906212);
    printf(197906500, -1040);
    cache_delete(8, var_-1032, 1);
    goto lbl_0x4a614;
    return 1;
    goto lbl_0x4a614;
    printf(197906968, 16);
    return 1;
}


stock GetPromoCodeDataByString()
{
    goto lbl_0x4a6c4;
    goto lbl_0x4a928;
    strcmp(16);
    if (_) goto lbl_0x4a920;
    strmid(20);
    return 1;
    goto lbl_0x4a6b8;
    return 1;
}


stock GetPromoCodeIndexByString()
{
    goto lbl_0x4a964;
    goto lbl_0x4aa0c;
    strcmp(16);
    if (_) goto lbl_0x4aa04;
    return 1;
    goto lbl_0x4a958;
    return 1;
}


stock GivePromoCar(playerid, modelid, promoSqlId)
{
    GetPlayerPos(playerid, -20);
    gettime(12);
    format(-1060, 256, 197907244);
    mysql_query(166387936, -1060);
    cache_delete(8, var_-1064, 1);
    return 1;
}


stock ShowPromoCreationConfirmation(playerid)
{
    strmid(20, -5248);
    format(-4096, 1024, 197907992);
    format(-5120, 256, 197908256);
    strcat(-4096, -5120);
    if (_) goto lbl_0x4af80;
    format(-5384, 32, 197908376);
    goto lbl_0x4afbc;
    format(-5384, 32, 197908420);
    format(-5120, 256, 197908432);
    strcat(-4096, -5120);
    strcat(-4096, 197908600);
    goto lbl_0x4b080;
    goto lbl_0x4b4c4;
    if (_) goto lbl_0x4b270;
    format(-6168, 64, 197908712);
    goto lbl_0x4b2ac;
    format(-6168, 64, 197908748);
    switch (_)
    format(-5912, 128, 197908784);
    goto lbl_0x4b480;
    format(-5912, 128, 197908984);
    goto lbl_0x4b480;
    format(-5912, 128, 197909188);
    goto lbl_0x4b480;
    strcat(-4096, -5912);
    goto lbl_0x4b074;
    fg_ShowPlayerDialog(28, playerid, "usesRenters", 0, 197909448, -4096, 197909700, 197909732);
    return 1;
}


stock CreatePromoCodeInDatabase(playerid)
{
    strmid(20, -4224);
    mysql_format(166387936, -4096, 1024, 197909760);
    mysql_query(166387936, -4096);
    mysql_errno(1);
    if (!_) goto lbl_0x4b8a0;
    mysql_errno(1);
    format(-5264, 256, 197910164);
    SendClientMessage(playerid, -1, -5264);
    mysql_errno(1);
    printf(197910444);
    cache_delete(8, var_-4240, 1);
    return 1;
    cache_insert_id(4, var_-4240);
    cache_delete(8, var_-4240, 1);
    if (_) goto lbl_0x4b980;
    SendClientMessage(playerid, -1, 197910700);
    printf(197910968, -4224);
    return 1;
    goto lbl_0x4b9a0;
    goto lbl_0x4bd00;
    mysql_format(166387936, -4096, 1024, 197911240);
    mysql_query(166387936, -4096);
    mysql_errno(1);
    if (!_) goto lbl_0x4bcf0;
    mysql_errno(1);
    format(-5264, 256, 197911760);
    SendClientMessage(playerid, -1, -5264);
    mysql_errno(1);
    printf(197912028, -4236);
    goto lbl_0x4b994;
    format(-5264, 256, 197912400);
    SendClientMessage(playerid, -1, -5264);
    LoadPromoCodesFromDatabase(0);
    return 1;
}


stock blackjack_OnDialogResponse(playerid, dialogid, response, listitem)
{
    switch (_)
    if (!_) goto lbl_0x4c2a8;
    switch (_)
    pc_cmd_mypromo(8, playerid, 197912644);
    goto lbl_0x4c2a8;
    GetPromoLevelForOwner(4, playerid);
    goto lbl_0x4bfb4;
    goto lbl_0x4c10c;
    goto lbl_0x4c038;
    format(-4228, 32, 197913900);
    goto lbl_0x4c06c;
    format(-4228, 32, 197913960);
    format(-4096, 1024, 197914020);
    goto lbl_0x4bfa8;
    strlen(-4096);
    goto lbl_0x4c1a0;
    strlen(-4096);
    fg_ShowPlayerDialog(28, playerid, "ers", 2, 197914156, -4096, 197914220, 197914256);
    goto lbl_0x4c2a8;
    fg_ShowPlayerDialog(28, playerid, "enters", 0, 197914280, 197914352, 197916492, 197916516);
    goto lbl_0x4c2a8;
    pc_cmd_mypromo(8, playerid, 197916520);
    goto lbl_0x4c2a8;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4ca4c;
    GetPromoLevelForOwner(4, playerid);
    mysql_format(166387936, -1044, 256, 197916524);
    mysql_query(166387936, -1044);
    cache_get_row_count(4, var_-1048);
    if (_) goto lbl_0x4c4a0;
    SendClientMessage(playerid, -1, 197916932);
    cache_delete(8, var_-1048, 1);
    return 1;
    cache_get_field_content_int(0, 197917084, 1);
    cache_get_field_content_int(0, 197917096, 1);
    cache_get_field_content_int(0, 197917144, 1);
    cache_delete(8, var_-1048, 1);
    goto lbl_0x4c61c;
    SendClientMessage(playerid, -1, 197917200);
    pc_cmd_mypromo(8, playerid, 197917488);
    return 1;
    goto lbl_0x4c6a8;
    SendClientMessage(playerid, -1, 197917492);
    pc_cmd_mypromo(8, playerid, 197917716);
    return 1;
    goto lbl_0x4c878;
    if (!_) goto lbl_0x4c7ec;
    goto lbl_0x4c820;
    format(-3108, 512, 197917720);
    goto lbl_0x4c9c0;
    goto lbl_0x4c950;
    if (!_) goto lbl_0x4c8c4;
    goto lbl_0x4c8f8;
    format(-3108, 512, 197918652);
    goto lbl_0x4c9c0;
    SendClientMessage(playerid, -1, 197919572);
    pc_cmd_mypromo(8, playerid, 197919884);
    return 1;
    fg_ShowPlayerDialog(28, playerid, "rs", 0, 197919888, -3108, 197920032, 197920056);
    goto lbl_0x4ca70;
    pc_cmd_mypromo(8, playerid, 197920080);
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4d030;
    mysql_format(166387936, -1040, 256, 197920084);
    mysql_query(166387936, -1040);
    cache_get_row_count(4, var_-1044);
    if (_) goto lbl_0x4cc48;
    SendClientMessage(playerid, -1, 197920492);
    cache_delete(8, var_-1044, 1);
    return 1;
    cache_get_field_content_int(0, 197920644, 1);
    cache_get_field_content_int(0, 197920656, 1);
    cache_get_field_content_int(0, 197920704, 1);
    cache_delete(8, var_-1044, 1);
    goto lbl_0x4cebc;
    mysql_format(166387936, -1040, 256, 197920760);
    mysql_query(166387936, -1040);
    SavePromoLevelPrizes(12, playerid, var_-16, var_-4);
    SendClientMessage(playerid, -1, 197920996);
    goto lbl_0x4cffc;
    goto lbl_0x4cfc8;
    mysql_format(166387936, -1040, 256, 197921276);
    mysql_query(166387936, -1040);
    SavePromoLevelPrizes(12, playerid, var_-16, var_-4);
    SendClientMessage(playerid, -1, 197921672);
    goto lbl_0x4cffc;
    SendClientMessage(playerid, -1, 197921936);
    pc_cmd_mypromo(8, playerid, 197922248);
    goto lbl_0x4d054;
    pc_cmd_mypromo(8, playerid, 197922252);
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4d094;
    pc_cmd_mypromo(8, playerid, 197922256);
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4d0f8;
    SendClientMessage(playerid, -1, 197922260);
    return 1;
    switch (_)
    pc_cmd_bcode(8, playerid, 197922448);
    goto lbl_0x4d67c;
    SendClientMessage(playerid, -1, 197922452);
    pc_cmd_promo(8, playerid, 197922652);
    goto lbl_0x4d67c;
    HasPlayerCreatedPromo(4, playerid);
    if (!_) goto lbl_0x4d1e8;
    pc_cmd_mypromo(8, playerid, 197922656);
    goto lbl_0x4d234;
    fg_ShowPlayerDialog(28, playerid, "esRenters", 1, 197922660, 197922768, 197925608, 197925632);
    goto lbl_0x4d67c;
    mysql_format(166387936, -1024, 256, 197925660);
    mysql_query(166387936, -1024);
    cache_get_row_count(4, var_-1028);
    goto lbl_0x4d538;
    cache_get_row_count(4, var_-1028);
    cache_get_field_content(20, 0, 197926416, 1, 1);
    format(-5124, 1024, 197926304);
    goto lbl_0x4d458;
    goto lbl_0x4d528;
    cache_get_field_content(20, var_-5136, 197926436, -5264, 32, 32);
    format(-5124, 1024, 197926456);
    goto lbl_0x4d44c;
    goto lbl_0x4d56c;
    format(-5124, 1024, 197926580);
    cache_delete(8, var_-1028, 1);
    format(-5644, 128, 197926780);
    fg_ShowPlayerDialog(28, playerid, "Renters", 2, -5644, -5124, 197926920, 197926932);
    goto lbl_0x4d67c;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4d6e0;
    SendClientMessage(playerid, -1, 197926936);
    return 1;
    strlen(var_28);
    if (_) goto lbl_0x4d79c;
    SendClientMessage(playerid, -1, 197927124);
    fg_ShowPlayerDialog(28, playerid, "esRenters", 1, 197927404, 197927512, 197930352, 197930376);
    return 1;
    strlen(var_28);
    goto lbl_0x4d860;
    SendClientMessage(playerid, -1, 197930404);
    pc_cmd_promo(8, playerid, 197930676);
    return 1;
    goto lbl_0x4d8ec;
    SendClientMessage(playerid, -1, 197930680);
    pc_cmd_promo(8, playerid, 197930964);
    return 1;
    goto lbl_0x4d90c;
    goto lbl_0x4db88;
    goto lbl_0x4d994;
    goto lbl_0x4d994;
    goto lbl_0x4d998;
    if (_) goto lbl_0x4daf4;
    goto lbl_0x4d9e0;
    goto lbl_0x4d9e0;
    goto lbl_0x4d9e4;
    if (_) goto lbl_0x4daf4;
    goto lbl_0x4da2c;
    goto lbl_0x4da2c;
    goto lbl_0x4da30;
    if (_) goto lbl_0x4daf4;
    goto lbl_0x4da78;
    goto lbl_0x4da78;
    goto lbl_0x4da7c;
    if (_) goto lbl_0x4daf4;
    goto lbl_0x4dac4;
    goto lbl_0x4dac4;
    goto lbl_0x4dac8;
    if (_) goto lbl_0x4daf4;
    if (_) goto lbl_0x4daf4;
    goto lbl_0x4dafc;
    if (!_) goto lbl_0x4db78;
    SendClientMessage(playerid, -1, 197930968);
    pc_cmd_promo(8, playerid, 197931408);
    return 1;
    goto lbl_0x4d900;
    OnPromoCodeCheckComplete(8, playerid, var_28);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4dc30;
    SendClientMessage(playerid, -1, 197931412);
    return 1;
    strlen(var_28);
    if (_) goto lbl_0x4dcc4;
    SendClientMessage(playerid, -1, 197931600);
    pc_cmd_addcpromo(8, playerid, 197931836);
    return 1;
    strfind(var_28, 197931840, 1);
    goto lbl_0x4dd78;
    SendClientMessage(playerid, -1, 197931848);
    pc_cmd_addcpromo(8, playerid, 197932116);
    return 1;
    strlen(var_28);
    goto lbl_0x4de90;
    format(-512, 128, 197932120);
    SendClientMessage(playerid, -1, -512);
    pc_cmd_addcpromo(8, playerid, 197932416);
    return 1;
    GetPromoCodeIndexByString(4, var_28);
    goto lbl_0x4df24;
    SendClientMessage(playerid, -1, 197932420);
    pc_cmd_addcpromo(8, playerid, 197932664);
    return 1;
    strmid(20);
    fg_ShowPlayerDialog(28, playerid, "LoadHousesRenters", 1, 197932668, 197932864, 197932996, 197933020);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4e08c;
    SendClientMessage(playerid, -1, 197933048);
    return 1;
    strval(4, var_28);
    goto lbl_0x4e100;
    goto lbl_0x4e100;
    goto lbl_0x4e108;
    if (!_) goto lbl_0x4e1a8;
    SendClientMessage(playerid, -1, 197933236);
    fg_ShowPlayerDialog(28, playerid, "LoadHousesRenters", 1, 197933472, 197933668, 197933800, 197933824);
    return 1;
    fg_ShowPlayerDialog(28, playerid, 12347, 1, 197933852, 197934048, 197934272, 197934296);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4e2b4;
    SendClientMessage(playerid, -1, 197934324);
    return 1;
    strval(4, var_28);
    goto lbl_0x4e39c;
    SendClientMessage(playerid, -1, 197934512);
    fg_ShowPlayerDialog(28, playerid, 12347, 1, 197934780, 197934976, 197935200, 197935224);
    return 1;
    format(-516, 128, 197935252);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -516, 197935484, 197935772, 197935804);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4e584;
    SendClientMessage(playerid, -1, 197935832);
    return 1;
    switch (_)
    format(-1028, 256, 197936020);
    goto lbl_0x4e780;
    format(-1028, 256, 197936124);
    goto lbl_0x4e780;
    format(-1028, 256, 197936232);
    goto lbl_0x4e780;
    format(-1028, 256, 197936464);
    goto lbl_0x4e780;
    format(-1540, 128, 197936560);
    fg_ShowPlayerDialog(28, playerid, "adHousesRenters", 1, -1540, -1028, 197936768, 197936792);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4e8f8;
    SendClientMessage(playerid, -1, 197936820);
    return 1;
    strval(4, var_28);
    format(-524, 128, 197937008);
    goto lbl_0x4ec90;
    SendClientMessage(playerid, -1, 197937292);
    switch (_)
    format(-1548, 256, 197937560);
    goto lbl_0x4ec2c;
    format(-1548, 256, 197937664);
    goto lbl_0x4ec2c;
    format(-1548, 256, 197937772);
    goto lbl_0x4ec2c;
    format(-1548, 256, 197938004);
    goto lbl_0x4ec2c;
    fg_ShowPlayerDialog(28, playerid, "adHousesRenters", 1, -524, -1548, 197938100, 197938124);
    return 1;
    if (!_) goto lbl_0x4ef88;
    goto lbl_0x4ef54;
    format(-524, 128, 197938152);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -524, 197938384, 197938672, 197938704);
    goto lbl_0x4ef70;
    ShowPromoCreationConfirmation(4, playerid);
    return 1;
    fg_ShowPlayerDialog(28, playerid, "dHousesRenters", 2, -524, 197938732, 197939008, 197939040);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4f050;
    SendClientMessage(playerid, -1, 197939068);
    return 1;
    if (_) goto lbl_0x4f1dc;
    format(-520, 128, 197939256);
    fg_ShowPlayerDialog(28, playerid, "HousesRenters", 1, -520, 197939524, 197939668, 197939692);
    return 1;
    goto lbl_0x4f418;
    format(-520, 128, 197939720);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -520, 197939952, 197940240, 197940272);
    goto lbl_0x4f434;
    ShowPromoCreationConfirmation(4, playerid);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4f4b0;
    SendClientMessage(playerid, -1, 197940300);
    return 1;
    strval(4, var_28);
    goto lbl_0x4f690;
    SendClientMessage(playerid, -1, 197940488);
    format(-520, 128, 197940780);
    fg_ShowPlayerDialog(28, playerid, "HousesRenters", 1, -520, 197941048, 197941192, 197941216);
    return 1;
    goto lbl_0x4f8d0;
    format(-520, 128, 197941244);
    fg_ShowPlayerDialog(28, playerid, "oadHousesRenters", 2, -520, 197941452, 197941740, 197941772);
    goto lbl_0x4f8ec;
    ShowPromoCreationConfirmation(4, playerid);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4f944;
    CreatePromoCodeInDatabase(4, playerid);
    goto lbl_0x4f978;
    SendClientMessage(playerid, -1, 197941800);
    return 1;
    goto lbl_0x57d80;
    if (!_) goto lbl_0x4f9ec;
    SendClientMessage(playerid, -1, 197941988);
    return 1;
    strlen(var_28);
    if (_) goto lbl_0x4fa80;
    SendClientMessage(playerid, -1, 197942172);
    pc_cmd_bcode(8, playerid, 197942452);
    return 1;
    mysql_format(166387936, -1292, 286, 197942456);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x4fc04;
    SendClientMessage(playerid, -1, 197942676);
    return 1;
    cache_get_row_count(4, var_-1296);
    if (_) goto lbl_0x4fcb4;
    SendClientMessage(playerid, -1, 197942828);
    cache_delete(8, var_-1296, 1);
    pc_cmd_bcode(8, playerid, 197943012);
    cache_get_field_content_int(0, 197943016, 1);
    cache_get_field_content_int(0, 197943028, 1);
    cache_get_field_content_int(0, 197943104, 1);
    cache_get_field_content_int(0, 197943152, 1);
    cache_get_field_content_int(0, 197943200, 1);
    cache_delete(8, var_-1296, 1);
    if (_) goto lbl_0x4fe94;
    SendClientMessage(playerid, -1, 197943256);
    return 1;
    goto lbl_0x4ff20;
    SendClientMessage(playerid, -1, 197943660);
    pc_cmd_bcode(8, playerid, 197943896);
    return 1;
    cache_delete(8, var_-1296, 1);
    GetPromoCodeDataByString(8, var_28, -144);
    if (!_) goto lbl_0x57ca8;
    goto lbl_0x4ffcc;
    if (!_) goto lbl_0x4ffcc;
    goto lbl_0x4ffd4;
    if (!_) goto lbl_0x57c5c;
    mysql_format(166387936, -1292, 286, 197943900);
    mysql_query(166387936, -1292);
    cache_get_row_count(4, var_-1296);
    goto lbl_0x50110;
    SendClientMessage(playerid, -1, 197944468);
    cache_delete(8, var_-1296, 1);
    return 1;
    cache_delete(8, var_-1296, 1);
    mysql_format(166387936, -1292, 286, 197944680);
    mysql_query(166387936, -1292);
    cache_get_row_count(4, var_-1296);
    goto lbl_0x50270;
    SendClientMessage(playerid, -1, 197945020);
    cache_delete(8, var_-1296, 1);
    return 1;
    cache_delete(8, var_-1296, 1);
    format(-5412, 1024, 197945232);
    strcat(-5412, 197945508);
    mysql_format(166387936, -1292, 286, 197945596);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (_) goto lbl_0x5040c;
    cache_get_row_count(4, var_-1296);
    if (!_) goto lbl_0x5040c;
    goto lbl_0x50414;
    if (!_) goto lbl_0x504f8;
    SendClientMessage(playerid, -1, 197946052);
    mysql_errno(1);
    printf(197946444, -1300);
    cache_delete(8, var_-1296, 1);
    return 1;
    cache_get_row_count(4, var_-1296);
    if (!_) goto lbl_0x50e00;
    cache_get_field_content_int(0, 197946692, 1);
    cache_get_field_content_int(0, 197946704, 1);
    cache_get_field_content_int(0, 197946748, 1);
    cache_get_field_content_int(0, 197946796, 1);
    if (_) goto lbl_0x507d8;
    format(-5672, 64, 197946856);
    goto lbl_0x50814;
    format(-5672, 64, 197946904);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5684);
    format(-6776, 256, 197947040);
    goto lbl_0x50b44;
    GivePlayerDonateRub(20, playerid, var_-5684);
    format(-6776, 256, 197947156);
    goto lbl_0x50b44;
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    format(-6776, 256, 197947280);
    goto lbl_0x50b44;
    UpdatePlayerDatabaseInt(12, playerid, 197947488);
    format(-6776, 256, 197947504);
    goto lbl_0x50b44;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197947608);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x50d40;
    mysql_errno(1);
    printf(197948092, -5676);
    goto lbl_0x50dc4;
    cache_insert_id(4, var_-7036);
    goto lbl_0x50dbc;
    SetPlayerPromoTimer(12, playerid, var_-7040, var_-5688);
    cache_delete(8, var_-7036, 1);
    goto lbl_0x57850;
    if (!_) goto lbl_0x51cf0;
    cache_get_field_content_int(0, 197948356, 1);
    cache_get_field_content_int(0, 197948368, 1);
    cache_get_field_content_int(0, 197948412, 1);
    cache_get_field_content_int(0, 197948460, 1);
    cache_get_field_content_int(1, 197948520, 1);
    cache_get_field_content_int(1, 197948532, 1);
    cache_get_field_content_int(1, 197948576, 1);
    cache_get_field_content_int(1, 197948624, 1);
    if (_) goto lbl_0x5106c;
    format(-5672, 64, 197948684);
    goto lbl_0x510a8;
    format(-5672, 64, 197948732);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5684);
    format(-6776, 256, 197948868);
    goto lbl_0x513d8;
    GivePlayerDonateRub(20, playerid, var_-5684);
    format(-6776, 256, 197948984);
    goto lbl_0x513d8;
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    format(-6776, 256, 197949108);
    goto lbl_0x513d8;
    UpdatePlayerDatabaseInt(12, playerid, 197949316);
    format(-6776, 256, 197949332);
    goto lbl_0x513d8;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197949436);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x515d4;
    mysql_errno(1);
    printf(197949920, -5676);
    goto lbl_0x51658;
    cache_insert_id(4, var_-6780);
    goto lbl_0x51650;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x516d4;
    format(-5672, 64, 197950184);
    goto lbl_0x51710;
    format(-5672, 64, 197950232);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5700);
    format(-6776, 256, 197950368);
    goto lbl_0x51a40;
    GivePlayerDonateRub(20, playerid, var_-5700);
    format(-6776, 256, 197950484);
    goto lbl_0x51a40;
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    format(-6776, 256, 197950608);
    goto lbl_0x51a40;
    UpdatePlayerDatabaseInt(12, playerid, 197950816);
    format(-6776, 256, 197950832);
    goto lbl_0x51a40;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197950936);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x51c30;
    mysql_errno(1);
    printf(197951420, -5692);
    goto lbl_0x51cb4;
    cache_insert_id(4, var_-6780);
    goto lbl_0x51cac;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    cache_delete(8, var_-6780, 1);
    goto lbl_0x57850;
    if (!_) goto lbl_0x5332c;
    cache_get_field_content_int(0, 197951684, 1);
    cache_get_field_content_int(0, 197951696, 1);
    cache_get_field_content_int(0, 197951740, 1);
    cache_get_field_content_int(0, 197951788, 1);
    cache_get_field_content_int(1, 197951848, 1);
    cache_get_field_content_int(1, 197951860, 1);
    cache_get_field_content_int(1, 197951904, 1);
    cache_get_field_content_int(1, 197951952, 1);
    cache_get_field_content_int(2, 197952012, 1);
    cache_get_field_content_int(2, 197952024, 1);
    cache_get_field_content_int(2, 197952068, 1);
    cache_get_field_content_int(2, 197952116, 1);
    if (_) goto lbl_0x5204c;
    format(-5672, 64, 197952176);
    goto lbl_0x52088;
    format(-5672, 64, 197952224);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5684);
    format(-6776, 256, 197952360);
    goto lbl_0x523b8;
    GivePlayerDonateRub(20, playerid, var_-5684);
    format(-6776, 256, 197952476);
    goto lbl_0x523b8;
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    format(-6776, 256, 197952600);
    goto lbl_0x523b8;
    UpdatePlayerDatabaseInt(12, playerid, 197952808);
    format(-6776, 256, 197952824);
    goto lbl_0x523b8;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197952928);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x525b4;
    mysql_errno(1);
    printf(197953412, -5676);
    goto lbl_0x52638;
    cache_insert_id(4, var_-6780);
    goto lbl_0x52630;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x526b4;
    format(-5672, 64, 197953676);
    goto lbl_0x526f0;
    format(-5672, 64, 197953724);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5700);
    format(-6776, 256, 197953860);
    goto lbl_0x52a20;
    GivePlayerDonateRub(20, playerid, var_-5700);
    format(-6776, 256, 197953976);
    goto lbl_0x52a20;
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    format(-6776, 256, 197954100);
    goto lbl_0x52a20;
    UpdatePlayerDatabaseInt(12, playerid, 197954308);
    format(-6776, 256, 197954324);
    goto lbl_0x52a20;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197954428);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x52c10;
    mysql_errno(1);
    printf(197954912, -5692);
    goto lbl_0x52c94;
    cache_insert_id(4, var_-6780);
    goto lbl_0x52c8c;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x52d10;
    format(-5672, 64, 197955176);
    goto lbl_0x52d4c;
    format(-5672, 64, 197955224);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5716);
    format(-6776, 256, 197955360);
    goto lbl_0x5307c;
    GivePlayerDonateRub(20, playerid, var_-5716);
    format(-6776, 256, 197955476);
    goto lbl_0x5307c;
    GivePromoCar(12, playerid, var_-5716, var_-1300);
    format(-6776, 256, 197955600);
    goto lbl_0x5307c;
    UpdatePlayerDatabaseInt(12, playerid, 197955808);
    format(-6776, 256, 197955824);
    goto lbl_0x5307c;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197955928);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x5326c;
    mysql_errno(1);
    printf(197956412, -5708);
    goto lbl_0x532f0;
    cache_insert_id(4, var_-6780);
    goto lbl_0x532e8;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5720);
    cache_delete(8, var_-6780, 1);
    goto lbl_0x57850;
    if (!_) goto lbl_0x55384;
    cache_get_field_content_int(0, 197956676, 1);
    cache_get_field_content_int(0, 197956688, 1);
    cache_get_field_content_int(0, 197956732, 1);
    cache_get_field_content_int(0, 197956780, 1);
    cache_get_field_content_int(1, 197956840, 1);
    cache_get_field_content_int(1, 197956852, 1);
    cache_get_field_content_int(1, 197956896, 1);
    cache_get_field_content_int(1, 197956944, 1);
    cache_get_field_content_int(2, 197957004, 1);
    cache_get_field_content_int(2, 197957016, 1);
    cache_get_field_content_int(2, 197957060, 1);
    cache_get_field_content_int(2, 197957108, 1);
    cache_get_field_content_int(3, 197957168, 1);
    cache_get_field_content_int(3, 197957180, 1);
    cache_get_field_content_int(3, 197957224, 1);
    cache_get_field_content_int(3, 197957272, 1);
    cache_get_field_content_int(0, 197957332, 1);
    cache_get_field_content_int(0, 197957344, 1);
    cache_get_field_content_int(0, 197957388, 1);
    cache_get_field_content_int(0, 197957436, 1);
    cache_get_field_content_int(1, 197957496, 1);
    cache_get_field_content_int(1, 197957508, 1);
    cache_get_field_content_int(1, 197957552, 1);
    cache_get_field_content_int(1, 197957600, 1);
    cache_get_field_content_int(2, 197957660, 1);
    cache_get_field_content_int(2, 197957672, 1);
    cache_get_field_content_int(2, 197957716, 1);
    cache_get_field_content_int(2, 197957764, 1);
    if (_) goto lbl_0x53a48;
    format(-5672, 64, 197957824);
    goto lbl_0x53a84;
    format(-5672, 64, 197957872);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5684);
    format(-6776, 256, 197958008);
    goto lbl_0x53db4;
    GivePlayerDonateRub(20, playerid, var_-5684);
    format(-6776, 256, 197958124);
    goto lbl_0x53db4;
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    format(-6776, 256, 197958248);
    goto lbl_0x53db4;
    UpdatePlayerDatabaseInt(12, playerid, 197958456);
    format(-6776, 256, 197958472);
    goto lbl_0x53db4;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197958576);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x53fb0;
    mysql_errno(1);
    printf(197959060, -5676);
    goto lbl_0x54034;
    cache_insert_id(4, var_-6780);
    goto lbl_0x5402c;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x540b0;
    format(-5672, 64, 197959324);
    goto lbl_0x540ec;
    format(-5672, 64, 197959372);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5700);
    format(-6776, 256, 197959508);
    goto lbl_0x5441c;
    GivePlayerDonateRub(20, playerid, var_-5700);
    format(-6776, 256, 197959624);
    goto lbl_0x5441c;
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    format(-6776, 256, 197959748);
    goto lbl_0x5441c;
    UpdatePlayerDatabaseInt(12, playerid, 197959956);
    format(-6776, 256, 197959972);
    goto lbl_0x5441c;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197960076);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x5460c;
    mysql_errno(1);
    printf(197960560, -5692);
    goto lbl_0x54690;
    cache_insert_id(4, var_-6780);
    goto lbl_0x54688;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x5470c;
    format(-5672, 64, 197960824);
    goto lbl_0x54748;
    format(-5672, 64, 197960872);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5716);
    format(-6776, 256, 197961008);
    goto lbl_0x54a78;
    GivePlayerDonateRub(20, playerid, var_-5716);
    format(-6776, 256, 197961124);
    goto lbl_0x54a78;
    GivePromoCar(12, playerid, var_-5716, var_-1300);
    format(-6776, 256, 197961248);
    goto lbl_0x54a78;
    UpdatePlayerDatabaseInt(12, playerid, 197961456);
    format(-6776, 256, 197961472);
    goto lbl_0x54a78;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197961576);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x54c68;
    mysql_errno(1);
    printf(197962060, -5708);
    goto lbl_0x54cec;
    cache_insert_id(4, var_-6780);
    goto lbl_0x54ce4;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5720);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x54d68;
    format(-5672, 64, 197962324);
    goto lbl_0x54da4;
    format(-5672, 64, 197962372);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5732);
    format(-6776, 256, 197962508);
    goto lbl_0x550d4;
    GivePlayerDonateRub(20, playerid, var_-5732);
    format(-6776, 256, 197962624);
    goto lbl_0x550d4;
    GivePromoCar(12, playerid, var_-5732, var_-1300);
    format(-6776, 256, 197962748);
    goto lbl_0x550d4;
    UpdatePlayerDatabaseInt(12, playerid, 197962956);
    format(-6776, 256, 197962972);
    goto lbl_0x550d4;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197963076);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x552c4;
    mysql_errno(1);
    printf(197963560, -5724);
    goto lbl_0x55348;
    cache_insert_id(4, var_-6780);
    goto lbl_0x55340;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5736);
    cache_delete(8, var_-6780, 1);
    goto lbl_0x57850;
    if (!_) goto lbl_0x57850;
    cache_get_field_content_int(0, 197963824, 1);
    cache_get_field_content_int(0, 197963836, 1);
    cache_get_field_content_int(0, 197963880, 1);
    cache_get_field_content_int(0, 197963928, 1);
    cache_get_field_content_int(1, 197963988, 1);
    cache_get_field_content_int(1, 197964000, 1);
    cache_get_field_content_int(1, 197964044, 1);
    cache_get_field_content_int(1, 197964092, 1);
    cache_get_field_content_int(2, 197964152, 1);
    cache_get_field_content_int(2, 197964164, 1);
    cache_get_field_content_int(2, 197964208, 1);
    cache_get_field_content_int(2, 197964256, 1);
    cache_get_field_content_int(3, 197964316, 1);
    cache_get_field_content_int(3, 197964328, 1);
    cache_get_field_content_int(3, 197964372, 1);
    cache_get_field_content_int(3, 197964420, 1);
    cache_get_field_content_int(4, 197964480, 1);
    cache_get_field_content_int(4, 197964492, 1);
    cache_get_field_content_int(4, 197964536, 1);
    cache_get_field_content_int(4, 197964584, 1);
    if (_) goto lbl_0x558c0;
    format(-5672, 64, 197964644);
    goto lbl_0x558fc;
    format(-5672, 64, 197964692);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5684);
    format(-6776, 256, 197964828);
    goto lbl_0x55c2c;
    GivePlayerDonateRub(20, playerid, var_-5684);
    format(-6776, 256, 197964944);
    goto lbl_0x55c2c;
    GivePromoCar(12, playerid, var_-5684, var_-1300);
    format(-6776, 256, 197965068);
    goto lbl_0x55c2c;
    UpdatePlayerDatabaseInt(12, playerid, 197965276);
    format(-6776, 256, 197965292);
    goto lbl_0x55c2c;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197965396);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x55e28;
    mysql_errno(1);
    printf(197965880, -5676);
    goto lbl_0x55eac;
    cache_insert_id(4, var_-6780);
    goto lbl_0x55ea4;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5688);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x55f28;
    format(-5672, 64, 197966144);
    goto lbl_0x55f64;
    format(-5672, 64, 197966192);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5700);
    format(-6776, 256, 197966328);
    goto lbl_0x56294;
    GivePlayerDonateRub(20, playerid, var_-5700);
    format(-6776, 256, 197966444);
    goto lbl_0x56294;
    GivePromoCar(12, playerid, var_-5700, var_-1300);
    format(-6776, 256, 197966568);
    goto lbl_0x56294;
    UpdatePlayerDatabaseInt(12, playerid, 197966776);
    format(-6776, 256, 197966792);
    goto lbl_0x56294;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197966896);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x56484;
    mysql_errno(1);
    printf(197967380, -5692);
    goto lbl_0x56508;
    cache_insert_id(4, var_-6780);
    goto lbl_0x56500;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5704);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x56584;
    format(-5672, 64, 197967644);
    goto lbl_0x565c0;
    format(-5672, 64, 197967692);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5716);
    format(-6776, 256, 197967828);
    goto lbl_0x568f0;
    GivePlayerDonateRub(20, playerid, var_-5716);
    format(-6776, 256, 197967944);
    goto lbl_0x568f0;
    GivePromoCar(12, playerid, var_-5716, var_-1300);
    format(-6776, 256, 197968068);
    goto lbl_0x568f0;
    UpdatePlayerDatabaseInt(12, playerid, 197968276);
    format(-6776, 256, 197968292);
    goto lbl_0x568f0;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197968396);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x56ae0;
    mysql_errno(1);
    printf(197968880, -5708);
    goto lbl_0x56b64;
    cache_insert_id(4, var_-6780);
    goto lbl_0x56b5c;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5720);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x56be0;
    format(-5672, 64, 197969144);
    goto lbl_0x56c1c;
    format(-5672, 64, 197969192);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5732);
    format(-6776, 256, 197969328);
    goto lbl_0x56f4c;
    GivePlayerDonateRub(20, playerid, var_-5732);
    format(-6776, 256, 197969444);
    goto lbl_0x56f4c;
    GivePromoCar(12, playerid, var_-5732, var_-1300);
    format(-6776, 256, 197969568);
    goto lbl_0x56f4c;
    UpdatePlayerDatabaseInt(12, playerid, 197969776);
    format(-6776, 256, 197969792);
    goto lbl_0x56f4c;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197969896);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x5713c;
    mysql_errno(1);
    printf(197970380, -5724);
    goto lbl_0x571c0;
    cache_insert_id(4, var_-6780);
    goto lbl_0x571b8;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5736);
    cache_delete(8, var_-6780, 1);
    if (_) goto lbl_0x5723c;
    format(-5672, 64, 197970644);
    goto lbl_0x57278;
    format(-5672, 64, 197970692);
    switch (_)
    GivePlayerMoneyEx(20, playerid, var_-5748);
    format(-6776, 256, 197970828);
    goto lbl_0x575a8;
    GivePlayerDonateRub(20, playerid, var_-5748);
    format(-6776, 256, 197970944);
    goto lbl_0x575a8;
    GivePromoCar(12, playerid, var_-5748, var_-1300);
    format(-6776, 256, 197971068);
    goto lbl_0x575a8;
    UpdatePlayerDatabaseInt(12, playerid, 197971276);
    format(-6776, 256, 197971292);
    goto lbl_0x575a8;
    strcat(-5412, -6776);
    gettime(12);
    mysql_format(166387936, -1292, 286, 197971396);
    mysql_query(166387936, -1292);
    mysql_errno(1);
    if (!_) goto lbl_0x57798;
    mysql_errno(1);
    printf(197971880, -5740);
    goto lbl_0x5781c;
    cache_insert_id(4, var_-6780);
    goto lbl_0x57814;
    SetPlayerPromoTimer(12, playerid, var_-6784, var_-5752);
    cache_delete(8, var_-6780, 1);
    cache_delete(8, var_-1296, 1);
    if (!_) goto lbl_0x579ac;
    mysql_format(166387936, -1292, 286, 197972144);
    mysql_query(166387936, -1292);
    GetPromoCodeIndexByString(4, var_28);
    goto lbl_0x579a4;
    goto lbl_0x57a00;
    goto lbl_0x57a00;
    goto lbl_0x57a04;
    if (!_) goto lbl_0x57a4c;
    mysql_format(166387936, -1292, 286, 197972392);
    mysql_query(166387936, -1292);
    GetPlayerIDFromAccountID(4, var_-1304);
    goto lbl_0x57bac;
    format(-6784, 256, 197972848);
    SendClientMessage(var_-5760, -1, -6784);
    fg_ShowPlayerDialog(28, playerid, "ew", 0, 197973252, -5412, 197973452, 197973464);
    AddPlayerActivatedPromo(8);
    return 1;
    SendClientMessage(playerid, -1, 197973468);
    return 1;
    SendClientMessage(playerid, -1, 197973748);
    return 1;
    goto lbl_0x57d80;
    prom_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


stock CheckUsePromoCode(playerid, accountId, promoSqlId)
{
    mysql_format(166387936, -624, 156, 197973896);
    mysql_query(166387936, -624);
    cache_get_row_count(4, var_-628);
    goto lbl_0x57f20;
    SendClientMessage(playerid, -1, 197974464);
    cache_delete(8, var_-628, 1);
    return 1;
    cache_delete(8, var_-628, 1);
    return 1;
}


public OnPromoCodeCheckComplete(playerid)
{
    IsPlayerConnected(playerid);
    if (!_) goto lbl_0x57fa8;
    return 1;
    mysql_format(166387936, -1032, 258, 197974676);
    mysql_query(166387936, -1032);
    mysql_errno(1);
    if (!_) goto lbl_0x581e4;
    SendClientMessage(playerid, -1, 197974880);
    pc_cmd_promo(8, playerid, 197975196);
    cache_delete(8, var_-2196, 1);
    return 1;
    cache_get_row_count(4, var_-2196);
    goto lbl_0x582b4;
    SendClientMessage(playerid, -1, 197975200);
    pc_cmd_promo(8, playerid, 197975544);
    cache_delete(8, var_-2196, 1);
    return 1;
    cache_delete(8, var_-2196, 1);
    strlen(var_16);
    goto lbl_0x58370;
    goto lbl_0x58370;
    goto lbl_0x58374;
    if (!_) goto lbl_0x583ac;
    goto lbl_0x58448;
    goto lbl_0x583f0;
    goto lbl_0x583f0;
    goto lbl_0x583f4;
    if (!_) goto lbl_0x58418;
    goto lbl_0x58448;
    goto lbl_0x58448;
    goto lbl_0x584a4;
    if (!_) goto lbl_0x584a4;
    goto lbl_0x584a8;
    if (!_) goto lbl_0x58508;
    goto lbl_0x58458;
    goto lbl_0x585bc;
    format(-2468, 64, 197975548);
    goto lbl_0x585f8;
    format(-2468, 64, 197975628);
    mysql_format(166387936, -1032, 258, 197975668);
    mysql_query(166387936, -1032);
    mysql_errno(1);
    if (!_) goto lbl_0x58750;
    SendClientMessage(playerid, -1, 197976232);
    pc_cmd_promo(8, playerid, 197976576);
    cache_delete(8, var_-2196, 1);
    return 1;
    cache_delete(8, var_-2196, 1);
    goto lbl_0x58980;
    goto lbl_0x58868;
    format(-2192, 256, 197976580);
    SendClientMessage(playerid, -1, -2192);
    pc_cmd_promo(8, playerid, 197976928);
    return 1;
    GivePlayerDonateRub(20, playerid);
    format(-2192, 256, 197976932);
    SendClientMessage(playerid, -1, -2192);
    pc_cmd_mypromo(8, playerid, 197977384);
    LoadPromoCodesFromDatabase(0);
    goto lbl_0x58a90;
    GivePlayerMoneyEx(20, playerid);
    format(-2192, 256, 197977388);
    SendClientMessage(playerid, -1, -2192);
    pc_cmd_mypromo(8, playerid, 197977828);
    LoadPromoCodesFromDatabase(0);
    return 1;
}


stock HasPlayerCreatedPromo(playerid)
{
    mysql_format(166387936, -512, 128, 197977832);
    mysql_query(166387936, -512);
    cache_get_row_count(4, var_-516);
    cache_delete(8, var_-516, 1);
    return 1;
}


stock AddPlayerActivatedPromo(account_id, promo_id)
{
    mysql_format(166387936, -1024, 256, 197978112);
    mysql_query(166387936, -1024);
    return 1;
}


stock SavePromoLevelPrizes(promoId, level)
{
    mysql_format(166387936, -1028, 256, 197978520);
    mysql_query(166387936, -1028);
    switch (_)
    goto lbl_0x58e14;
    goto lbl_0x58f80;
    goto lbl_0x58e08;
    goto lbl_0x59e68;
    goto lbl_0x58fb0;
    goto lbl_0x5911c;
    goto lbl_0x58fa4;
    goto lbl_0x59e68;
    goto lbl_0x5914c;
    goto lbl_0x592b8;
    goto lbl_0x59140;
    goto lbl_0x59e68;
    goto lbl_0x592e8;
    goto lbl_0x59454;
    goto lbl_0x592dc;
    goto lbl_0x59e68;
    goto lbl_0x59484;
    goto lbl_0x595f0;
    goto lbl_0x59478;
    goto lbl_0x59e68;
    goto lbl_0x59620;
    goto lbl_0x5978c;
    goto lbl_0x59614;
    goto lbl_0x59e68;
    goto lbl_0x597bc;
    goto lbl_0x59928;
    goto lbl_0x597b0;
    goto lbl_0x59e68;
    goto lbl_0x59958;
    goto lbl_0x59ac4;
    goto lbl_0x5994c;
    goto lbl_0x59e68;
    goto lbl_0x59af4;
    goto lbl_0x59c60;
    goto lbl_0x59ae8;
    goto lbl_0x59e68;
    goto lbl_0x59c90;
    goto lbl_0x59dfc;
    goto lbl_0x59c84;
    goto lbl_0x59e68;
    goto lbl_0x59e88;
    goto lbl_0x5a0b0;
    mysql_format(166387936, -1028, 256, 197978716);
    mysql_query(166387936, -1028);
    mysql_errno(1);
    if (!_) goto lbl_0x5a0a0;
    mysql_errno(1);
    printf(197979236, 16);
    goto lbl_0x59e7c;
    return 1;
}


stock GetPromoLevelForOwner(playerid)
{
    mysql_format(166387936, -512, 128, 197979608);
    mysql_query(166387936, -512);
    cache_get_row_count(4, var_-520);
    goto lbl_0x5a218;
    cache_get_field_content_int(0, 197979924, 1);
    cache_delete(8, var_-520, 1);
    return 1;
}


stock pc_cmd_createpromo(playerid)
{
    pc_cmd_addcpromo(8, playerid, 197979972);
    return 1;
}


stock pc_cmd_createytpromo(playerid)
{
    pc_cmd_addcpromo(8, playerid, 197979976);
    return 1;
}


stock pc_cmd_addcpromo(playerid)
{
    goto lbl_0x5a34c;
    SendClientMessage(playerid, -1, 197979980);
    return 1;
    fg_ShowPlayerDialog(28, playerid, "w", 1, 197980276, 197980472, 197980644, 197980668);
    return 1;
}


stock pc_cmd_promo(playerid)
{
    HasPlayerCreatedPromo(4, playerid);
    if (!_) goto lbl_0x5a450;
    format(-2304, 64, 197980696);
    goto lbl_0x5a484;
    format(-2304, 64, 197981040);
    format(-2048, 512, 197981364);
    fg_ShowPlayerDialog(28, playerid, "sesRenters", 2, 197982340, -2048, 197982412, 197982436);
    return 1;
}


stock pc_alias_promo()
{
    PC_RegAlias(8, 197982460, 197982484);
    return 1;
}


stock pc_cmd_mypromo(playerid)
{
    mysql_format(166387936, -1024, 256, 197982524);
    mysql_query(166387936, -1024);
    cache_get_row_count(4, var_-3216);
    if (_) goto lbl_0x5a734;
    SendClientMessage(playerid, -1, 197982932);
    cache_delete(8, var_-3216, 1);
    return 1;
    cache_get_field_content(20, 0, 197983120, -3200, 32, 32);
    cache_get_field_content_int(0, 197983140, 1);
    cache_get_field_content_int(0, 197983188, 1);
    goto lbl_0x5a838;
    goto lbl_0x5a838;
    goto lbl_0x5a83c;
    if (!_) goto lbl_0x5a89c;
    goto lbl_0x5a8a8;
    format(-3072, 512, 197983236);
    fg_ShowPlayerDialog(28, playerid, "nters", 2, 197984156, -3072, 197984228, 197984252);
    cache_delete(8, var_-3216, 1);
    return 1;
}


stock pc_alias_mypromo()
{
    PC_RegAlias(8, 197984276, 197984308);
    return 1;
}


stock pc_cmd_checkpromo(playerid)
{
    mysql_format(166387936, -1024, 256, 197984356);
    mysql_query(166387936, -1024);
    cache_get_row_count(4, var_-3684);
    if (_) goto lbl_0x5ab84;
    SendClientMessage(playerid, -1, 197984856);
    cache_delete(8, var_-3684, 1);
    return 1;
    cache_get_field_content_int(0, 197985044, 1);
    cache_get_field_content(20, 0, 197985056, -3812, 32, 32);
    cache_get_field_content_int(0, 197985076, 1);
    cache_get_field_content_int(0, 197985124, 1);
    cache_get_field_content_int(0, 197985172, 1);
    cache_delete(8, var_-3684, 1);
    if (_) goto lbl_0x5ad88;
    SendClientMessage(playerid, -1, 197985228);
    return 1;
    format(-3680, 152, 197985568);
    format(-3072, 512, 197985616);
    fg_ShowPlayerDialog(28, playerid, "s", 0, -3680, -3072, 197986116, 197986140);
    if (_) goto lbl_0x5ae88;
    return 1;
    GivePlayerMoneyEx(20, playerid, var_-3824);
    mysql_format(166387936, -1024, 256, 197986144);
    mysql_query(166387936, -1024);
    return 1;
}


stock pc_cmd_bcode(playerid)
{
    fg_ShowPlayerDialog(28, playerid, "ousesRenters", 1, 197986384, 197986452, 197986640, 197986668);
    return 1;
}


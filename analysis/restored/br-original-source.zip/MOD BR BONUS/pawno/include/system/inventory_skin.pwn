stock pc_cmd_myskinsz(playerid)
{
    mysql_format(166387936, -2560, 640, 198097180);
    mysql_query(166387936, -2560);
    cache_get_row_count(4, 1);
    if (!_) goto lbl_0x62d2c;
    SendClientMessage(playerid, -1717986817, 198097388);
    CheckSkinPlayer(4, playerid);
    goto lbl_0x63074;
    format(-2560, 640, 198097484);
    goto lbl_0x62dcc;
    goto lbl_0x63018;
    cache_get_field_content_int(var_-2920, 198097488, 1);
    cache_get_field_content_int(var_-2920, 198097500, 1);
    cache_get_field_content_int(var_-2920, 198097532, 1);
    goto lbl_0x62ed8;
    goto lbl_0x62ef4;
    format(-2812, 60, 198097664);
    strcat(-2560, -2812);
    goto lbl_0x62dc0;
    Dialog(28, playerid, 1789, 2, 198097740, -2560, 198097828, 198097860);
    cache_delete(8, var_-2564, 1);
    return 1;
}


stock CheckSkinPlayer(playerid)
{
    mysql_format(166387936, -576, 144, 198097892);
    mysql_query(166387936, -576);
    cache_get_row_count(4, 1);
    cache_delete(8, var_-580, 1);
    if (!_) goto lbl_0x63388;
    GetPlayerSkinEx(4, playerid);
    mysql_format(166387936, -576, 144, 198098100);
    mysql_query(166387936, -576);
    mysql_errno(1);
    if (!_) goto lbl_0x6333c;
    SendClientMessage(playerid, -1, 198098400);
    return 1;
    SendClientMessage(playerid, -1, 198098520);
    return 1;
}


stock ShowOwnableSkinLoadDialog(playerid, id)
{
    SetPVarInt(12, playerid, 198098708, id);
    Dialog(28, playerid, 1790, 2, 198098768, 198098904, 198099044, 198099076);
    return 1;
}


stock ch_OnDialogResponse(playerid, dialogid, response, listitem)
{
    if (!_) goto lbl_0x634ec;
    if (!_) goto lbl_0x634ec;
    ShowOwnableSkinLoadDialog(8, playerid, var_-4);
    if (!_) goto lbl_0x63b0c;
    if (!_) goto lbl_0x63afc;
    GetPVarInt(8, playerid, 198099108);
    mysql_format(166387936, -660, 164, 198099168);
    mysql_query(166387936, -660);
    cache_get_row_int(12, 0, 0, 1);
    cache_get_row_int(12, 0, 1, 1);
    cache_delete(8, var_-676, 1);
    mysql_format(166387936, -660, 164, 198099412);
    mysql_query(166387936, -660);
    cache_get_row_int(12, 0, 0, 1);
    cache_delete(8, var_-676, 1);
    switch (_)
    if (!_) goto lbl_0x63818;
    SendClientMessage(playerid, -1717986817, 198099652);
    return 1;
    UpdatePlayerDatabaseInt(12, playerid, 198099736, var_-664);
    mysql_format(166387936, -660, 164, 198099756);
    mysql_query(166387936, -660);
    mysql_format(166387936, -660, 164, 198099988);
    mysql_query(166387936, -660);
    SetPlayerSkinInit(4, playerid);
    SendClientMessage(playerid, 1724658687, 198100220);
    goto lbl_0x63af4;
    if (!_) goto lbl_0x63a58;
    SendClientMessage(playerid, -1717986817, 198100368);
    return 1;
    mysql_format(166387936, -660, 164, 198100616);
    mysql_query(166387936, -660);
    goto lbl_0x63af4;
    return 1;
    skin_OnDialogResponse(20, playerid, dialogid, response, listitem, var_28);
    return 1;
}


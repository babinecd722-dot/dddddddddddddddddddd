// system_cp_race.pwn — 4 functions

// stock ClearPlayerRCPInfo(); // 0xd27c
// stock n_SetPlayerRaceCheckpoint(); // 0xd2cc
// stock n_IsPlayerInRaceCheckpoint(); // 0xd5dc
// stock n_DisablePlayerRaceCheckpoint(); // 0xd754
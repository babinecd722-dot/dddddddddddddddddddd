// system_carshare_welsi.pwn — 8 functions

// stock prom_OnPlayerConnect(); // 0x5afd4
// stock prom_OnPlayerDisconnect(); // 0x5b05c
// stock prom_OnGameModeInit(); // 0x5b0d8
// stock prom_OnDialogResponse(); // 0x5b11c
// stock pc_cmd_arendacar(); // 0x5cb4c
// stock DialogCarShare(); // 0x5cf9c
// stock CarShare(); // 0x5d068
// stock DeleteCarShareVehicle(); // 0x5d1c4
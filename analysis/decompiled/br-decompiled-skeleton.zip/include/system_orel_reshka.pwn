// system_orel_reshka.pwn — 12 functions

// stock weekly_OnGameModeInit(); // 0x6580c
// stock pc_cmd_spin(); // 0x65850
// stock pc_cmd_spins(); // 0x65a80
// stock StartHAT(); // 0x65f40
// stock EndHAT(); // 0x66574
// stock DefaultHAT(); // 0x66bf0
// stock DialogThrowHAT(); // 0x66d40
// stock DialogRoleHAT(); // 0x66e9c
// stock AcceptHAT(); // 0x67008
// stock CancelAcceptHAT(); // 0x67804
// stock weekly_OnDialogResponse(); // 0x678ec
// stock fixp_OnPlayerSpawn(); // 0x68070
// system_weekly_prizes.pwn — 9 functions

// stock CREATE_ACCOUNTS_TABLE_WP(); // 0x63c44
// stock LoadWeeklyPrizes(); // 0x63d44
// stock UnLoadWeeklyPrizes(); // 0x63fc0
// stock ch_OnPlayerConnect(); // 0x64290
// stock name_OnPlayerDisconnect(); // 0x642fc
// stock ch_OnGameModeInit(); // 0x64348
// stock CheckWeeklyPrizes(); // 0x643f4
// stock pc_cmd_everyprize(); // 0x6494c
// stock skin_OnDialogResponse(); // 0x64c48
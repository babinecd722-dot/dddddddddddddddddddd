// system_electric_job.pwn — 11 functions

// stock rul_OnPlayerDisconnect(); // 0x8a074
// stock rul_OnPlayerConnect(); // 0x8a0c0
// stock name_OnPlayerSpawn(); // 0x8a104
// stock name_OnDialogResponse(); // 0x8a148
// stock blackjack_OnPlayerEnterDynamicA(); // 0x8acd8
// stock rul_OnGameModeInit(); // 0x8b3a8
// stock CreateElectric(); // 0x8b400
// stock pc_cmd_eorders(); // 0x8bc2c
// stock IsPlayerInOrdersElectric(); // 0x8c39c
// stock OrdinaryNewElectric(); // 0x8c480
// stock NextStageElectric(); // 0x8c614
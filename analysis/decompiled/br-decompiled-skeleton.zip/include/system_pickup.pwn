// system_pickup.pwn — 7 functions

// stock n_CreatePickup(); // 0xd824
// stock n_DestroyPickup(); // 0xdc58
// stock OnPlayerPickUpPickup(); // 0xdd5c
// stock Iter_OnGameModeInit(); // 0xdf90
// stock fg_OnPlayerConnect(); // 0xe11c
// stock OnPlayerSpawn(); // 0xe178
// stock OnPlayerLeaveDynamicArea(); // 0xe1d4
// system_inventory_skin.pwn — 4 functions

// stock pc_cmd_myskinsz(); // 0x62bac
// stock CheckSkinPlayer(); // 0x630b8
// stock ShowOwnableSkinLoadDialog(); // 0x6339c
// stock ch_OnDialogResponse(); // 0x6342c
// system_cp.pwn — 4 functions

// stock ClearPlayerCPInfo(); // 0xcde0
// stock n_SetPlayerCheckpoint(); // 0xce30
// stock n_IsPlayerInCheckpoint(); // 0xd010
// stock n_DisablePlayerCheckpoint(); // 0xd1ac
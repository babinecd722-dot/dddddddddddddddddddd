// system_vehicle.pwn — 11 functions

// stock SetVehicleDataAll(); // 0xe238
// stock n_veh_AddStaticVehicleEx(); // 0xe740
// stock n_veh_CreateVehicle(); // 0xe834
// stock n_veh_DestroyVehicle(); // 0xe928
// stock n_OnGameModeInit(); // 0xe9e4
// stock SetVehicleParamsInit(); // 0xea98
// stock GetVehicleParam(); // 0xec30
// stock SetVehicleParam(); // 0xeca4
// stock CreateVehicleLabel(); // 0xeecc
// stock UpdateVehicleLabel(); // 0xefe0
// stock DestroyVehicleLabel(); // 0xf0f0
// system_exchange_welsi.pwn — 15 functions

// stock car_OnGameModeInit(); // 0x5d2e0
// stock car_OnPlayerDisconnect(); // 0x5d324
// stock car_OnPlayerConnect(); // 0x5d450
// stock car_OnDialogResponse(); // 0x5d4a8
// stock pc_cmd_changeprop(); // 0x5eae4
// stock pc_cmd_yeschange(); // 0x5ef20
// stock Exchange(); // 0x5f254
// stock ExchangeVehicle(); // 0x5f988
// stock ExchangeFuelStation(); // 0x5fbf8
// stock ExchangeBusiness(); // 0x605a4
// stock ExchangeHouse(); // 0x61044
// stock Exchange_ShowVehicleList(); // 0x61ad4
// stock ShowDialogSelectTypeExchange(); // 0x62570
// stock SendExchange(); // 0x62604
// stock DeleteFullPVarExchange(); // 0x62a04
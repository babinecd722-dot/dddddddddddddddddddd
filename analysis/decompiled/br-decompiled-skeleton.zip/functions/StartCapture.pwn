// StartCapture @ 0x29be1c-0x29c528 (1804 bytes)
// Source: test.pwn

stock StartCapture()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0029be1c: op235          
// 0x0029be1d: op0            
// 0x0029be1e: eq.alt         -2125428590
// 0x0029be23: push.s         
// 0x0029be24: op166          
// 0x0029be25: sctrl          1891865217
// 0x0029be2a: eq.alt         -2126454382
// 0x0029be2f: push.s         
// 0x0029be30: op255          
// 0x0029be31: stor.alt       1620874113
// 0x0029be36: eq.alt         -2127512941
// 0x0029be3b: pop.pri        
// 0x0029be3c: op216          
// 0x0029be3d: op0            
// 0x0029be3e: eq.alt         -2125400685
// 0x0029be43: pop.alt        
// 0x0029be44: pop.pri        
// 0x0029be45: sctrl          1890620545
// 0x0029be4a: eq.alt         -2126459244
// 0x0029be4f: pop.alt        
// 0x0029be50: op236          
// 0x0029be51: stor.alt       1619629441
// 0x0029be56: eq.alt         -2127517803
// 0x0029be5b: stack          
// 0x0029be5c: op197          
// 0x0029be5d: op0            
// 0x0029be5e: eq.alt         -2125405547
// 0x0029be63: heap           
// 0x0029be64: eq.pri         
// 0x0029be65: sctrl          1889375873
// 0x0029be6a: eq.alt         -2126464106
// 0x0029be6f: heap           
// 0x0029be70: op217          
// 0x0029be71: stor.alt       1626773121
// 0x0029be76: eq.alt         -2127522665
// 0x0029be7b: proc           
// 0x0029be7c: op178          
// 0x0029be7d: op0            
// 0x0029be7e: eq.alt         -2125410409
// 0x0029be83: proc           
// 0x0029be84: op237          
// 0x0029be85: sctrl          1888131201
// 0x0029be8a: eq.alt         -2126468968
// 0x0029be8f: ret            
// 0x0029be90: op198          
// 0x0029be91: stor.alt       1625528449
// 0x0029be96: eq.alt         -2127527527
// 0x0029be9b: retn           
// 0x0029be9c: swap.pri       
// 0x0029be9d: op0            
// 0x0029be9e: eq.alt         -2125415271
// 0x0029bea3: retn           
// 0x0029bea4: op218          
// 0x0029bea5: sctrl          1895274881
// 0x0029beaa: eq.alt         -2126473830
// 0x0029beaf: call           
// 0x0029beb0: op179          
// 0x0029beb1: stor.alt       1624283777
// 0x0029beb6: eq.alt         -2127499622
// 0x0029bebb: call.pri       
// 0x0029bebc: bounds.p       
// 0x0029bebd: op0            
// 0x0029bebe: eq.alt         -2125420133
// 0x0029bec3: call.pri       
// 0x0029bec4: op199          
// 0x0029bec5: sctrl          1894030209
// 0x0029beca: eq.alt         -2126478692
// 0x0029becf: jump           
// 0x0029bed0: swap.alt       
// 0x0029bed1: stor.alt       1623039105
// 0x0029bed6: eq.alt         -2127504484
// 0x0029bedb: jump           
// 0x0029bedc: op249          
// 0x0029bedd: op0            
// 0x0029bede: eq.alt         -2125424995
// 0x0029bee3: switch         
// 0x0029bee4: op180          
// 0x0029bee5: sctrl          1892785537
// 0x0029beea: eq.alt         -2126450787
// 0x0029beef: casetbl        
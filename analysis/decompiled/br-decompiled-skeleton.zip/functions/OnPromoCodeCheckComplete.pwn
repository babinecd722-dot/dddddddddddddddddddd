// OnPromoCodeCheckComplete @ 0x57f64-0x58aa8 (2884 bytes)
// Source: system_new_promo.pwn

public OnPromoCodeCheckComplete()
{
    // const.alt 204022793
    // stack 894730252
    // branch jrel -> -2144925311
    // const.alt 1635810176
    // stack 159461392
    // stack -2122837752
    // stack 655108476
    // stack -2123099896
    // stor.alt 2558337
    // stack 688488716
    // stack -843631864
    // const.alt -607660416
    // const.alt -2122575607
    // const.alt -2115974272
    // stack 654934284
    // stack 654934284
    // const.pri 806104065
    // load.alt 1289533237
    // branch jnz -> 0x-48cae7d4
    // const.alt 204022793
    // stack 894730252
    // const.alt 1635810176
    // stack 159461392
    // stack -2122837752
    // stack 655108476
    // stack -2123099896
    // stack 688488716
    // stack -692636920
    // stack 201949444
    // const.alt -2122575607
    // const.alt -2115974272
    // stack 654934284
    // stack 654934284
    // const.pri 806104065
    // load.alt 1558558517
    // branch jnz -> 0x-48cae7d4
    // const.alt 204022793
    // stack 894730252
    // const.alt 1635810176
    // stack 159461392
    // stack -2122837752
    // stack 655108476
    // stack -2123099896
    // branch jneq -> 0x74290981
    return 1;
    return 1;
    // stack 654934284
    // stack 201949444
    // const.alt -2122575607
    // const.alt -2115974272
    // stack 654934284
    // stack 654934284
    // const.pri 806104065
    // load.alt 1827583797
    // const.alt -1449098201
    // branch jnz -> 0x-48cae7d4
    // const.alt 204022793
    // stack 894730252
    // const.alt 1635810176
    // stack 159461392
    // stack -2122837752
    // stack 655108476
    // stack -2123099896
    // stack -357092084
    return 1;
    // stack 654934284
    // stack 201949444
    // const.alt -2122575607
    // const.alt -2115974272
    // stack 654934284
    // stack 654934284
    // const.pri 806104065
    // load.alt 2096609077
    // const.alt -2138471385
    // branch jnz -> 0x-48cae7d4
    // const.alt 204022793
    // stack 894730252
    // stack 159461392
    // stack -2122837752
    // stack 655108476
    // stack -2123099896
    // stack -206097140
    return 1;
    // stack 654934284
    // stack 201949444
    // const.alt -2122575607
    // const.alt -2115974272
    // stack 654934284
    // stack 654934284
    // const.pri 806104065
    // load.alt 209827893
    // branch jeq -> 0x-565f7bd9
    // branch jrel -> -2138471385
    // branch jnz -> 0x-47cae7d4
    // const.alt 204022793
    // stack 894730252
    // stack 204046119
    // stack 159461392
    // stack -2122837752
    // stack 655108476
    // stack -2123099896
    // stack -55102196
    return 1;
    // stack 654934284
    // const.alt 159450156
    // const.alt -607660416
    // const.alt -2122575607
    // const.alt -2115974272
    // stack 654934284
    // stack 654934284
    // const.pri 806104065
    // load.alt 478853173
    // branch jnz -> 0x-47cae7d4
    // const.alt 204022793
    // stack 894730252
    // stack 159461392
    // stack -2122837752
    // stack 655108476
    // stack -2123099896
    // stack -2051525364
    return 1;
    // stack 654934284
    // const.alt -607660416
    // const.alt -2122575607
    // const.alt -2115974272
    // stack 654934284
}

// --- disasm (first 80) ---
// 0x00057f64: eq.pri         
// 0x00057f65: op214          
// 0x00057f66: op199          
// 0x00057f67: op219          
// 0x00057f68: sysreq.pri     
// 0x00057f69: load.s.pri     -2122743796
// 0x00057f6e: sysreq.c       
// 0x00057f6f: idxaddr        
// 0x00057f70: move.alt       
// 0x00057f71: load.i         
// 0x00057f72: eq.pri         
// 0x00057f73: neg            
// 0x00057f74: eq.pri         
// 0x00057f75: mul.c          
// 0x00057f76: cmps.i         
// 0x00057f77: const.alt      204022793
// 0x00057f7c: push.c         0x-7e847ff8 ""
// 0x00057f81: inc            
// 0x00057f82: stack          894730252
// 0x00057f87: op183          
// 0x00057f88: op204          
// 0x00057f89: jrel           -2144925311
// 0x00057f8e: op236          
// 0x00057f8f: pop.pri        
// 0x00057f90: op225          
// 0x00057f91: zero.pri       
// 0x00057f92: push.c         0x270c297f ""
// 0x00057f97: const.alt      1635810176
// 0x00057f9c: stack          159461392
// 0x00057fa1: push.c         0x2c098100 ""
// 0x00057fa6: zero.pri       
// 0x00057fa7: push.c         0x-7ffbd8f8 ""
// 0x00057fac: emit           
// 0x00057fad: eq.pri         
// 0x00057fae: neq            
// 0x00057faf: stack          -2122837752
// 0x00057fb4: load.i         
// 0x00057fb5: stack          655108476
// 0x00057fba: load.s.alt     92371840
// 0x00057fbf: stack          -2123099896
// 0x00057fc4: load.i         
// 0x00057fc5: push.c         0x-3248cd00 ""
// 0x00057fca: shr.alt        
// 0x00057fcb: eq.alt         1886289929
// 0x00057fd0: load.s.pri     2055277680
// 0x00057fd5: eq.pri         
// 0x00057fd6: jsgeq          
// 0x00057fd7: op183          
// 0x00057fd8: op207          
// 0x00057fd9: strb.i         1948846465
// 0x00057fde: push.s         -2146949264
// 0x00057fe3: emit           
// 0x00057fe4: eq.alt         889990257
// 0x00057fe9: op183          
// 0x00057fea: op207          
// 0x00057feb: stor.alt       2558337
// 0x00057ff0: push.s         -2146949264
// 0x00057ff5: emit           
// 0x00057ff6: eq.alt         -2129908688
// 0x00057ffb: load.i         
// 0x00057ffc: push.c         0x27702900 ""
// 0x00058001: lref.s.alt     159480704
// 0x00058006: stack          688488716
// 0x0005800b: eq.c.alt       
// 0x0005800c: push.c         0x-7e847ffc ""
// 0x00058011: neq            
// 0x00058012: stack          -843631864
// 0x00058017: jgeq           0x981042c
// 0x0005801c: const.alt      -607660416
// 0x00058021: sysreq.pri     
// 0x00058022: load.s.pri     -2122743796
// 0x00058027: sysreq.c       
// 0x00058028: idxaddr        
// 0x00058029: move.alt       
// 0x0005802a: load.i         
// 0x0005802b: eq.pri         
// 0x0005802c: neg            
// 0x0005802d: eq.pri         
// 0x0005802e: mul.c          
// 0x0005802f: cmps.i         
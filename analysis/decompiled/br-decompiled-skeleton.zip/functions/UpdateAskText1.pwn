// UpdateAskText1 @ 0x153b4-0x15564 (432 bytes)
// Source: test.pwn

stock UpdateAskText1()
{
    // const.alt 2038434819
    // stack -24300784
    // branch jrel -> 159450156
    // const.alt 2038434819
    // stack -7523568
    // stack 654934276
    // branch jump -> -2129100402
}

// --- disasm (first 80) ---
// 0x000153b4: op255          
// 0x000153b5: shl.pri        
// 0x000153b6: eq.alt         -696244471
// 0x000153bb: op239          
// 0x000153bc: op234          
// 0x000153bd: op0            
// 0x000153be: push.c         0x-297ff381 ""
// 0x000153c3: op238          
// 0x000153c4: nop            
// 0x000153c5: const.alt      2038434819
// 0x000153ca: lref.pri       -2146885093
// 0x000153cf: neg            
// 0x000153d0: eq.pri         
// 0x000153d1: mul.c          
// 0x000153d2: sctrl          203891721
// 0x000153d7: eq.pri         
// 0x000153d8: emit           
// 0x000153d9: eq.pri         
// 0x000153da: xor            
// 0x000153db: stack          -24300784
// 0x000153e0: jrel           159450156
// 0x000153e5: push.c         0x-72cd00 ""
// 0x000153ea: sleq           
// 0x000153eb: eq.alt         2020507657
// 0x000153f0: load.s.pri     -2146694024
// 0x000153f5: jsgeq          
// 0x000153f6: push.alt       
// 0x000153f7: eq.pri         
// 0x000153f8: eq.c.alt       
// 0x000153f9: eq.alt         -696244471
// 0x000153fe: op239          
// 0x000153ff: op234          
// 0x00015400: load.s.alt     -2146664665
// 0x00015405: op214          
// 0x00015406: op238          
// 0x00015407: nop            
// 0x00015408: const.alt      2038434819
// 0x0001540d: lref.pri       -2146885093
// 0x00015412: neg            
// 0x00015413: eq.pri         
// 0x00015414: mul.c          
// 0x00015415: push.pri       
// 0x00015416: load.i         
// 0x00015417: push.pri       
// 0x00015418: push.c         0x-7f847ff4 ""
// 0x0001541d: xor            
// 0x0001541e: stack          -7523568
// 0x00015423: or             
// 0x00015424: stack          654934276
// 0x00015429: op0            
// 0x0001542a: jump           -2129100402
// 0x0001542f: load.i         
// 0x00015430: eq.pri         
// 0x00015431: sgeq           
// 0x00015432: sysreq.pri     
// 0x00015433: load.s.pri     -2146694024
// 0x00015438: jsgeq          
// 0x00015439: push.alt       
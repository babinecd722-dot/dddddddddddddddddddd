// UpdateMedBed @ 0xcc4ac-0xcc594 (232 bytes)
// Source: test.pwn

stock UpdateMedBed()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000cc4ac: cmps           
// 0x000cc4ad: eq.alt         192687113
// 0x000cc4b2: const.alt      1249934340
// 0x000cc4b7: const.pri      290095109
// 0x000cc4bc: eq.c.alt       
// 0x000cc4bd: eq.alt         50407177
// 0x000cc4c2: sysreq.pri     
// 0x000cc4c3: eq.pri         
// 0x000cc4c4: mul.c          
// 0x000cc4c5: load.pri       1216436352
// 0x000cc4ca: push.pri       
// 0x000cc4cb: load.s.pri     -2024308620
// 0x000cc4d0: leq            
// 0x000cc4d1: pop.alt        
// 0x000cc4d2: eq.pri         
// 0x000cc4d3: neg            
// 0x000cc4d4: push.pri       
// 0x000cc4d5: push.s         -1719392396
// 0x000cc4da: op208          
// 0x000cc4db: eq.pri         
// 0x000cc4dc: op0            
// 0x000cc4dd: const.alt      -521741184
// 0x000cc4e2: strb.i         2038460419
// 0x000cc4e7: load.alt       -2146885093
// 0x000cc4ec: neg            
// 0x000cc4ed: eq.pri         
// 0x000cc4ee: mul.c          
// 0x000cc4ef: lref.s.alt     -2146687991
// 0x000cc4f4: op220          
// 0x000cc4f5: op230          
// 0x000cc4f6: op224          
// 0x000cc4f7: strb.i         2038460419
// 0x000cc4fc: load.alt       -2146885093
// 0x000cc501: neg            
// 0x000cc502: eq.pri         
// 0x000cc503: mul.c          
// 0x000cc504: load.s.alt     -2146687991
// 0x000cc509: op220          
// 0x000cc50a: op230          
// 0x000cc50b: op224          
// 0x000cc50c: strb.i         2038460419
// 0x000cc511: load.alt       -2146885093
// 0x000cc516: neg            
// 0x000cc517: load.i         
// 0x000cc518: push.pri       
// 0x000cc519: push.s         824190732
// 0x000cc51e: eq.alt         -2129593212
// 0x000cc523: load.i         
// 0x000cc524: const.alt      -607660416
// 0x000cc529: sysreq.pri     
// 0x000cc52a: load.s.pri     -2122743796
// 0x000cc52f: sysreq.c       
// 0x000cc530: idxaddr        
// 0x000cc531: move.alt       
// 0x000cc532: load.i         
// 0x000cc533: eq.pri         
// 0x000cc534: neg            
// 0x000cc535: eq.pri         
// 0x000cc536: mul.c          
// 0x000cc537: movs.i         
// 0x000cc538: sleq           
// 0x000cc539: move.alt       
// 0x000cc53a: const.pri      137107327
// 0x000cc53f: stack          -2147210236
// 0x000cc544: mod.c          
// 0x000cc545: retn           
// 0x000cc546: proc           
// 0x000cc547: eq.alt         201949449
// 0x000cc54c: eq.pri         
// 0x000cc54d: op214          
// 0x000cc54e: op199          
// 0x000cc54f: op219          
// 0x000cc550: sysreq.pri     
// 0x000cc551: load.s.pri     -2122743796
// 0x000cc556: sysreq.c       
// 0x000cc557: idxaddr        
// 0x000cc558: move.alt       
// 0x000cc559: load.i         
// 0x000cc55a: eq.pri         
// 0x000cc55b: neg            
// pc_cmd_spin @ 0x65850-0x65a80 (560 bytes)
// Source: system_orel_reshka.pwn

stock pc_cmd_spin()
{
    // stor.alt -1916764109
    // const.alt -2127491033
    return 1;
    // const.alt -607660416
    // branch jrel -> -2123921625
    // stack 654934296
    // branch jump -> 
    // stack 654934288
    // load.pri -422803161
    // const.alt -2071101135
    // branch jrel -> 92342657
    // const.alt 1635810176
    // stack -1065340144
    // const.alt -2127491033
    return 1;
    // const.alt -607660416
    // stack 654934296
    // branch jump -> 
    // stack 654934288
    // load.pri -422803161
    // const.alt -2071101135
    // branch jrel -> 92342657
    // const.alt 1635810176
    // stack -1065340144
    // const.alt -2127491033
    return 1;
    // const.alt -607660416
    // stack 654934296
    // branch jump -> 
    // stack 654934288
    // load.pri -422803161
    // const.alt -2071101135
    // branch jrel -> 92342657
    // const.alt 1635810176
    // stack -1065340144
    // const.alt -2127491033
    return 1;
    // const.alt -607660416
    // stack 654934296
    // branch jump -> 
    // stack 654934288
    // load.pri -422803161
    // const.alt -2071101135
    // branch jrel -> 92342657
    // const.alt 1635810176
    // stack -1065340144
    // const.alt -2127491033
    return 1;
    // const.alt -607660416
}

// --- disasm (first 80) ---
// 0x00065850: stor.alt       -1916764109
// 0x00065855: sctrl          19335553
// 0x0006585a: push.c         0x2903270a ""
// 0x0006585f: const.alt      -2127491033
// 0x00065864: push.alt       
// 0x00065865: retn           
// 0x00065866: sysreq.pri     
// 0x00065867: eq.alt         201687305
// 0x0006586c: const.alt      -607660416
// 0x00065871: sysreq.pri     
// 0x00065872: load.s.pri     -2122743796
// 0x00065877: sysreq.c       
// 0x00065878: idxaddr        
// 0x00065879: move.alt       
// 0x0006587a: load.i         
// 0x0006587b: eq.pri         
// 0x0006587c: neg            
// 0x0006587d: eq.pri         
// 0x0006587e: mul.c          
// 0x0006587f: cmps.i         
// 0x00065880: mod            
// 0x00065881: push.pri       
// 0x00065882: push.c         0x-25631380 ""
// 0x00065887: jrel           -2123921625
// 0x0006588c: lref.pri       338118849
// 0x00065891: eq.pri         
// 0x00065892: emit           
// 0x00065893: push.alt       
// 0x00065894: stack          654934296
// 0x00065899: eq.pri         
// 0x0006589a: op236          
// 0x0006589b: jump           
// 0x0006589c: op219          
// 0x0006589d: cmps           
// 0x0006589e: push.c         0x5816787 ""
// 0x000658a3: op224          
// 0x000658a4: sshr           
// 0x000658a5: push.c         0x257b800c ""
// 0x000658aa: stack          654934288
// 0x000658af: load.pri       -422803161
// 0x000658b4: op179          
// 0x000658b5: sign.alt       
// 0x000658b6: eq.alt         659079429
// 0x000658bb: const.alt      -2071101135
// 0x000658c0: jrel           92342657
// 0x000658c5: op224          
// 0x000658c6: sshr           
// 0x000658c7: push.c         0x270c297f ""
// 0x000658cc: const.alt      1635810176
// 0x000658d1: stack          -1065340144
// 0x000658d6: push.pri       
// 0x000658d7: sctrl          19335553
// 0x000658dc: push.c         0x2904270a ""
// 0x000658e1: const.alt      -2127491033
// 0x000658e6: push.alt       
// 0x000658e7: retn           
// 0x000658e8: sysreq.pri     
// 0x000658e9: eq.alt         201687305
// 0x000658ee: const.alt      -607660416
// 0x000658f3: sysreq.pri     
// 0x000658f4: load.s.pri     -2122743796
// 0x000658f9: sysreq.c       
// 0x000658fa: idxaddr        
// 0x000658fb: move.alt       
// 0x000658fc: load.i         
// 0x000658fd: eq.pri         
// 0x000658fe: neg            
// 0x000658ff: eq.pri         
// 0x00065900: mul.c          
// 0x00065901: cmps.i         
// 0x00065902: mod            
// 0x00065903: push.pri       
// 0x00065904: push.c         0x-22631380 ""
// 0x00065909: leq            
// 0x0006590a: push.c         0x5816787 ""
// 0x0006590f: op193          
// 0x00065910: shr.alt        
// 0x00065911: push.c         0x257b8014 ""
// 0x00065916: stack          654934296
// 0x0006591b: eq.pri         
// FamilySpawnIsNewHouse @ 0x38b0c0-0x38b0e4 (36 bytes)
// Source: test.pwn

stock FamilySpawnIsNewHouse()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0038b0c0: op0            
// 0x0038b0c1: op0            
// 0x0038b0c2: op0            
// 0x0038b0c3: op0            
// 0x0038b0c4: op0            
// 0x0038b0c5: op0            
// 0x0038b0c6: op0            
// 0x0038b0c7: op0            
// 0x0038b0c8: op0            
// 0x0038b0c9: op0            
// 0x0038b0ca: op0            
// 0x0038b0cb: op0            
// 0x0038b0cc: op0            
// 0x0038b0cd: op0            
// 0x0038b0ce: op0            
// 0x0038b0cf: op0            
// 0x0038b0d0: op0            
// 0x0038b0d1: op0            
// 0x0038b0d2: op0            
// 0x0038b0d3: op0            
// 0x0038b0d4: op0            
// 0x0038b0d5: op0            
// 0x0038b0d6: op0            
// 0x0038b0d7: op0            
// 0x0038b0d8: op0            
// 0x0038b0d9: op0            
// 0x0038b0da: op0            
// 0x0038b0db: op0            
// 0x0038b0dc: op0            
// 0x0038b0dd: op0            
// 0x0038b0de: op0            
// 0x0038b0df: op0            
// 0x0038b0e0: op0            
// 0x0038b0e1: op0            
// 0x0038b0e2: op0            
// 0x0038b0e3: op0            
// LoadPrizeRuletka @ 0x87904-0x87aac (424 bytes)
// Source: system_roulette.pwn

stock LoadPrizeRuletka()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00087904: eq.pri         
// 0x00087905: op214          
// 0x00087906: op242          
// 0x00087907: op190          
// 0x00087908: shr.alt        
// 0x00087909: load.s.pri     2038456568
// 0x0008790e: eq.pri         
// 0x0008790f: op245          
// 0x00087910: stor.i         
// 0x00087911: idxaddr        
// 0x00087912: move.alt       
// 0x00087913: load.i         
// 0x00087914: eq.pri         
// 0x00087915: neg            
// 0x00087916: eq.pri         
// 0x00087917: mul.c          
// 0x00087918: eq.alt         1879253604
// 0x0008791d: stor.i         
// 0x0008791e: eq.alt         -696251383
// 0x00087923: op242          
// 0x00087924: op190          
// 0x00087925: shr.alt        
// 0x00087926: load.s.pri     2038456568
// 0x0008792b: eq.pri         
// 0x0008792c: op245          
// 0x0008792d: stor.i         
// 0x0008792e: idxaddr        
// 0x0008792f: move.alt       
// 0x00087930: load.i         
// 0x00087931: eq.pri         
// 0x00087932: neg            
// 0x00087933: eq.pri         
// 0x00087934: mul.c          
// 0x00087935: eq.alt         1812144744
// 0x0008793a: stor.i         
// 0x0008793b: eq.alt         -696251383
// 0x00087940: op242          
// 0x00087941: op190          
// 0x00087942: shr.alt        
// 0x00087943: load.s.pri     2038456568
// 0x00087948: eq.pri         
// 0x00087949: op245          
// 0x0008794a: stor.i         
// 0x0008794b: idxaddr        
// 0x0008794c: move.alt       
// 0x0008794d: load.i         
// 0x0008794e: eq.pri         
// 0x0008794f: neg            
// 0x00087950: eq.pri         
// 0x00087951: mul.c          
// 0x00087952: eq.alt         1745035884
// 0x00087957: stor.i         
// 0x00087958: eq.alt         -696251383
// 0x0008795d: op242          
// 0x0008795e: op190          
// 0x0008795f: shr.alt        
// 0x00087960: load.s.pri     2038456568
// 0x00087965: eq.pri         
// 0x00087966: op245          
// 0x00087967: stor.i         
// 0x00087968: idxaddr        
// 0x00087969: move.alt       
// 0x0008796a: load.i         
// 0x0008796b: eq.pri         
// 0x0008796c: neg            
// 0x0008796d: eq.pri         
// 0x0008796e: mul.c          
// 0x0008796f: eq.alt         1677927024
// 0x00087974: stor.i         
// 0x00087975: eq.alt         -696251383
// 0x0008797a: op242          
// 0x0008797b: op190          
// 0x0008797c: shr.alt        
// 0x0008797d: load.s.pri     2038456568
// 0x00087982: eq.pri         
// 0x00087983: op245          
// 0x00087984: stor.i         
// 0x00087985: idxaddr        
// 0x00087986: move.alt       
// 0x00087987: load.i         
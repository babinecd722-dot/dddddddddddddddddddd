// Iter_OPDCInternal @ 0x6c3c-0x6d58 (284 bytes)
// Source: foreach.inc

stock Iter_OPDCInternal()
{
    // stack -2122568432
    // stack 386149640
    // const.pri 386149633
    // stack -2122830576
    // stack -2122568432
    // stack 386149640
    // const.pri 386149633
    // stack -2122830576
    // stack -2122568432
    // const.alt 271023145
    // stack -2130083564
    // stack 185172232
    // load.pri 774898732
    // stack 
    // branch jrel -> -523534297
    // const.alt -2077156313
    // stack -2122575612
    // const.pri 70089601
    // const.pri 386149635
    // stack -2122830576
    // const.pri 386149682
    // const.pri 386149637
    // stack -2122830576
}

// --- disasm (first 80) ---
// 0x00006c3c: push.s         -2146687108
// 0x00006c41: emit           
// 0x00006c42: eq.pri         
// 0x00006c43: xor            
// 0x00006c44: stack          -2122568432
// 0x00006c49: load.i         
// 0x00006c4a: push.s         -2147211484
// 0x00006c4f: emit           
// 0x00006c50: xchg           
// 0x00006c51: stack          386149640
// 0x00006c56: push.alt       
// 0x00006c57: const.pri      386149633
// 0x00006c5c: push.alt       
// 0x00006c5d: push.s         -2146687108
// 0x00006c62: emit           
// 0x00006c63: eq.pri         
// 0x00006c64: xor            
// 0x00006c65: stack          -2122830576
// 0x00006c6a: load.i         
// 0x00006c6b: push.s         755501860
// 0x00006c70: load.s.alt     2083071255
// 0x00006c75: push.c         0x-7f847ff4 ""
// 0x00006c7a: xor            
// 0x00006c7b: stack          -2122568432
// 0x00006c80: load.i         
// 0x00006c81: push.s         -2147211488
// 0x00006c86: emit           
// 0x00006c87: xchg           
// 0x00006c88: stack          386149640
// 0x00006c8d: push.alt       
// 0x00006c8e: const.pri      386149633
// 0x00006c93: push.alt       
// 0x00006c94: push.s         -2146687108
// 0x00006c99: emit           
// 0x00006c9a: eq.pri         
// 0x00006c9b: xor            
// 0x00006c9c: stack          -2122830576
// 0x00006ca1: load.i         
// 0x00006ca2: push.s         755501856
// 0x00006ca7: load.s.alt     2083071255
// 0x00006cac: push.c         0x-7f847ff4 ""
// 0x00006cb1: xor            
// 0x00006cb2: stack          -2122568432
// 0x00006cb7: load.i         
// 0x00006cb8: push.c         0x29012708 ""
// 0x00006cbd: const.alt      271023145
// 0x00006cc2: eq.pri         
// 0x00006cc3: emit           
// 0x00006cc4: eq.pri         
// 0x00006cc5: not            
// 0x00006cc6: stack          -2130083564
// 0x00006ccb: lref.pri       -2147211396
// 0x00006cd0: emit           
// 0x00006cd1: eq.pri         
// 0x00006cd2: neg            
// 0x00006cd3: stack          185172232
// 0x00006cd8: load.pri       774898732
// 0x00006cdd: eq.alt         654934281
// 0x00006ce2: eq.pri         
// 0x00006ce3: op203          
// 0x00006ce4: op224          
// 0x00006ce5: stack          
// 0x00006ce6: jrel           -523534297
// 0x00006ceb: pop.alt        
// 0x00006cec: sref.alt       19333415
// 0x00006cf1: push.c         0x2904270a ""
// 0x00006cf6: const.alt      -2077156313
// 0x00006cfb: op186          
// 0x00006cfc: strb.i         774920576
// 0x00006d01: eq.alt         738820361
// 0x00006d06: zero.pri       
// 0x00006d07: push.c         0x-7f848000 ""
// 0x00006d0c: or             
// 0x00006d0d: stack          -2122575612
// 0x00006d12: load.i         
// 0x00006d13: const.pri      70089601
// 0x00006d18: stor.i         
// 0x00006d19: push.alt       
// 0x00006d1a: const.pri      386149635
// 0x00006d1f: push.alt       
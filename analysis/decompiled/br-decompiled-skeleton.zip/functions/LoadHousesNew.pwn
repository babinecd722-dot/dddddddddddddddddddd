// LoadHousesNew @ 0x3ad0b8-0x3ad0d0 (24 bytes)
// Source: test.pwn

stock LoadHousesNew()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x003ad0b8: op0            
// 0x003ad0b9: op0            
// 0x003ad0ba: op0            
// 0x003ad0bb: op0            
// 0x003ad0bc: op0            
// 0x003ad0bd: op0            
// 0x003ad0be: op0            
// 0x003ad0bf: op0            
// 0x003ad0c0: op0            
// 0x003ad0c1: op0            
// 0x003ad0c2: op0            
// 0x003ad0c3: op0            
// 0x003ad0c4: op0            
// 0x003ad0c5: op0            
// 0x003ad0c6: op0            
// 0x003ad0c7: op0            
// 0x003ad0c8: op0            
// 0x003ad0c9: op0            
// 0x003ad0ca: op0            
// 0x003ad0cb: op0            
// 0x003ad0cc: op0            
// 0x003ad0cd: op0            
// 0x003ad0ce: op0            
// 0x003ad0cf: op0            
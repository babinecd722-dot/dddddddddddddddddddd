// SetVehicleVinyls @ 0x1436c-0x144e0 (372 bytes)
// Source: customtune.inc

stock SetVehicleVinyls()
{
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 203891721
    // stack 185172240
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 136782857
    // stack 654934284
    // const.alt -689187200
    // const.alt 136782857
    // stack -1249037556
    // branch jneq -> 0x-12297ff5
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 203891721
    // stack 185172240
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 136782857
    // stack 654934284
    // load.pri -2146762457
    // const.alt 2038434819
    // stack -2122743799
}

// --- disasm (first 80) ---
// 0x0001436c: neg            
// 0x0001436d: eq.pri         
// 0x0001436e: mul.c          
// 0x0001436f: jgeq           0x40802b09
// 0x00014374: push.pri       
// 0x00014375: op174          
// 0x00014376: leq            
// 0x00014377: eq.alt         -696244471
// 0x0001437c: op239          
// 0x0001437d: op226          
// 0x0001437e: sref.alt       -304709621
// 0x00014383: op225          
// 0x00014384: jsgeq          
// 0x00014385: push.pri       
// 0x00014386: const.alt      -1561405824
// 0x0001438b: const.alt      2038434819
// 0x00014390: lref.pri       -2146885093
// 0x00014395: neg            
// 0x00014396: eq.pri         
// 0x00014397: mul.c          
// 0x00014398: stack          -2122743799
// 0x0001439d: sysreq.c       
// 0x0001439e: pop.alt        
// 0x0001439f: idxaddr        
// 0x000143a0: load.i         
// 0x000143a1: push.pri       
// 0x000143a2: const.alt      -1561405824
// 0x000143a7: const.alt      2038434819
// 0x000143ac: lref.pri       -2146885093
// 0x000143b1: neg            
// 0x000143b2: eq.pri         
// 0x000143b3: mul.c          
// 0x000143b4: stack          203891721
// 0x000143b9: eq.pri         
// 0x000143ba: emit           
// 0x000143bb: eq.pri         
// 0x000143bc: eq             
// 0x000143bd: stack          185172240
// 0x000143c2: eq.pri         
// 0x000143c3: op214          
// 0x000143c4: op237          
// 0x000143c5: op225          
// 0x000143c6: jsgeq          
// 0x000143c7: push.pri       
// 0x000143c8: const.alt      -1561405824
// 0x000143cd: const.alt      2038434819
// 0x000143d2: lref.pri       -2146885093
// 0x000143d7: neg            
// 0x000143d8: eq.pri         
// 0x000143d9: mul.c          
// 0x000143da: stack          -2122743799
// 0x000143df: sysreq.c       
// 0x000143e0: pop.alt        
// 0x000143e1: idxaddr        
// 0x000143e2: load.i         
// 0x000143e3: push.pri       
// 0x000143e4: const.alt      -1561405824
// 0x000143e9: const.alt      2038434819
// 0x000143ee: lref.pri       -2146885093
// 0x000143f3: neg            
// 0x000143f4: eq.pri         
// 0x000143f5: mul.c          
// 0x000143f6: stack          136782857
// 0x000143fb: eq.pri         
// 0x000143fc: emit           
// 0x000143fd: eq.pri         
// 0x000143fe: grtr           
// 0x000143ff: stack          654934284
// 0x00014404: eq.pri         
// 0x00014405: op214          
// 0x00014406: op239          
// 0x00014407: op226          
// 0x00014408: sleq           
// 0x00014409: const.alt      -689187200
// 0x0001440e: sysreq.pri     
// 0x0001440f: load.s.pri     91848716
// 0x00014414: idxaddr        
// 0x00014415: move.alt       
// 0x00014416: load.i         
// 0x00014417: eq.pri         
// pc_cmd_blackjack @ 0x44820-0x45140 (2336 bytes)
// Source: system_blackjack_full.pwn

stock pc_cmd_blackjack()
{
    // const.alt 740129664
    // stor.alt 1551894913
    // branch jump -> -2130383701
    // load.pri 622265389
    // const.alt 740129664
    // stor.alt 1853884801
    // branch jump -> -2122781781
    // stack 744062992
    // const.alt -55058560
    // load.pri 147357740
    return 1;
    // proc @0x4491b
    // stor.alt 593068066
    // stor.alt 1082131468
    // branch jump -> 190902443
    // load.pri 619817781
    // stack 811171856
    return 1;
    // branch jzer -> 0x-7e8b0e55
    return 1;
    // branch jzer -> 0x-7ea70d55
    // stack 811171856
    // stack 654934296
    // const.alt -1193312217
    // const.alt -189276288
    // stor.alt 185172247
    // load.pri 805343276
    // proc @0x44a31
    // const.alt -189276288
    // const.alt -1421836284
    // const.pri -156551935
    // stack 744062992
    return 1;
    // branch jzer -> 0x-7eb70855
    // stack 159461380
    // branch jzer -> 0x-7ecb0755
    // stack 744062992
    // const.alt -659038336
    // stack -2122254297
    // stack 744062992
    // branch jneq -> 0x-7f87fbf7
    // stack -2130083564
    // const.alt 1635810176
    // stack 744062992
    // const.alt -607660416
    // branch jneq -> 0x-7f87fbf7
    // stack 654934288
    // load.pri 2071987239
    // stack -22334200
}

// --- disasm (first 80) ---
// 0x00044820: const.alt      740129664
// 0x00044825: stor.alt       1551894913
// 0x0004482a: op255          
// 0x0004482b: op183          
// 0x0004482c: sysreq.pri     
// 0x0004482d: jump           -2130383701
// 0x00044832: load.i         
// 0x00044833: eq.pri         
// 0x00044834: sgeq           
// 0x00044835: op255          
// 0x00044836: op183          
// 0x00044837: sysreq.pri     
// 0x00044838: load.s.pri     209238015
// 0x0004483d: load.s.alt     -290766720
// 0x00044842: sctrl          -2146694783
// 0x00044847: op223          
// 0x00044848: op183          
// 0x00044849: op216          
// 0x0004484a: idxaddr.b      2025324291
// 0x0004484f: eq.pri         
// 0x00044850: sysreq.c       
// 0x00044851: load.s.pri     -2146885093
// 0x00044856: neg            
// 0x00044857: eq.pri         
// 0x00044858: mul.c          
// 0x00044859: eq.alt         -2146688000
// 0x0004485e: op223          
// 0x0004485f: op183          
// 0x00044860: op216          
// 0x00044861: idxaddr.b      2025324291
// 0x00044866: eq.pri         
// 0x00044867: sysreq.c       
// 0x00044868: load.s.pri     -2146885093
// 0x0004486d: neg            
// 0x0004486e: push.pri       
// 0x0004486f: load.s.pri     -2139572225
// 0x00044874: mul.c          
// 0x00044875: load.pri       622265389
// 0x0004487a: push.c         0x-e472080 ""
// 0x0004487f: sref.alt       -2130673113
// 0x00044884: lref.pri       662484991
// 0x00044889: strb.i         740653952
// 0x0004488e: idxaddr.b      159480877
// 0x00044893: push.c         0x5810090 ""
// 0x00044898: op255          
// 0x00044899: op183          
// 0x0004489a: zero.pri       
// 0x0004489b: eq.alt         654360581
// 0x000448a0: const.alt      740129664
// 0x000448a5: stor.alt       1853884801
// 0x000448aa: op255          
// 0x000448ab: op191          
// 0x000448ac: zero.pri       
// 0x000448ad: jump           -2122781781
// 0x000448b2: load.i         
// 0x000448b3: load.s.pri     914145279
// 0x000448b8: op171          
// 0x000448b9: op238          
// 0x000448ba: sysreq.pri     
// 0x000448bb: eq.alt         -545249527
// 0x000448c0: op184          
// 0x000448c1: op243          
// 0x000448c2: jsgeq          
// 0x000448c3: push.c         0x7f8180f8 ""
// 0x000448c8: push.s         -2146687220
// 0x000448cd: emit           
// 0x000448ce: eq.pri         
// 0x000448cf: xor            
// 0x000448d0: stack          744062992
// 0x000448d5: eq.pri         
// 0x000448d6: op200          
// 0x000448d7: lref.s.alt     654934320
// 0x000448dc: eq.pri         
// 0x000448dd: op223          
// 0x000448de: op184          
// 0x000448df: op245          
// 0x000448e0: zero.pri       
// 0x000448e1: push.c         0x-a472080 ""
// 0x000448e6: or             
// 0x000448e7: eq.alt         654360581
// OnGameModeInit @ 0x588-0x5d0 (72 bytes)
// Source: Pawn.CMD.inc

public OnGameModeInit()
{
    // branch jzer -> 0x98130a1
    // const.pri 159461387
    // branch jzer -> 0x98108a2
    // const.pri 159461388
}

// --- disasm (first 80) ---
// 0x00000588: div.c          
// 0x00000589: eq.alt         805964553
// 0x0000058e: eq.alt         -7919863
// 0x00000593: op255          
// 0x00000594: op255          
// 0x00000595: sign.alt       
// 0x00000596: push.c         0x48832701 ""
// 0x0000059b: push.s         -2146425076
// 0x000005a0: emit           
// 0x000005a1: stor.s.pri     1417679916
// 0x000005a6: jzer           0x98130a1
// 0x000005ab: const.pri      159461387
// 0x000005b0: push.c         0x-79 ""
// 0x000005b5: sign.alt       
// 0x000005b6: push.c         0x78832701 ""
// 0x000005bb: push.s         -2146425076
// 0x000005c0: emit           
// 0x000005c1: stor.s.pri     1417679916
// 0x000005c6: jzer           0x98108a2
// 0x000005cb: const.pri      159461388
// BJSetPlayerCleanChat @ 0x17ec8-0x18020 (344 bytes)
// Source: system_blackjack_full.pwn

stock BJSetPlayerCleanChat()
{
    // stack 654934288
    // load.pri -338264052
    // stack 654934288
    // branch jump -> -338264052
    // stack 654934288
    // load.pri -338264052
    // const.alt -403974528
    // stor.alt -1432452057
    // stack -2129188076
    // const.alt -403974528
    // stack 654934292
    // load.alt -338264052
    // stack 654934288
    // const.alt -403974528
    // stack 654934288
    // const.alt -403974528
    // stack 654934288
    // load.pri -338264052
    // stack 654934288
    // branch jump -> -338264052
}

// --- disasm (first 80) ---
// 0x00017ec8: push.c         0x-297ff400 ""
// 0x00017ecd: op235          
// 0x00017ece: op223          
// 0x00017ecf: div.c          
// 0x00017ed0: load.s.pri     -2122743796
// 0x00017ed5: sysreq.c       
// 0x00017ed6: lidx           
// 0x00017ed7: push.pri       
// 0x00017ed8: push.s         -2146687220
// 0x00017edd: emit           
// 0x00017ede: eq.pri         
// 0x00017edf: zero.alt       
// 0x00017ee0: stack          654934288
// 0x00017ee5: load.pri       -338264052
// 0x00017eea: op223          
// 0x00017eeb: div.c          
// 0x00017eec: load.s.pri     -2122743796
// 0x00017ef1: sysreq.c       
// 0x00017ef2: lidx           
// 0x00017ef3: push.pri       
// 0x00017ef4: push.s         -2146687220
// 0x00017ef9: emit           
// 0x00017efa: eq.pri         
// 0x00017efb: sign.pri       
// 0x00017efc: stack          654934288
// 0x00017f01: jump           -338264052
// 0x00017f06: op223          
// 0x00017f07: div.c          
// 0x00017f08: load.s.pri     -2122743796
// 0x00017f0d: sysreq.c       
// 0x00017f0e: lidx           
// 0x00017f0f: push.pri       
// 0x00017f10: push.s         -2146687220
// 0x00017f15: emit           
// 0x00017f16: eq.pri         
// 0x00017f17: sign.alt       
// 0x00017f18: stack          654934288
// 0x00017f1d: load.pri       -338264052
// 0x00017f22: op223          
// 0x00017f23: div.c          
// 0x00017f24: load.s.pri     -2122743796
// 0x00017f29: sysreq.c       
// 0x00017f2a: lidx           
// 0x00017f2b: push.pri       
// 0x00017f2c: push.s         -2146687220
// 0x00017f31: emit           
// 0x00017f32: eq.alt         -2129646592
// 0x00017f37: load.i         
// 0x00017f38: push.c         0x-297ff3ff ""
// 0x00017f3d: op235          
// 0x00017f3e: op223          
// 0x00017f3f: div.c          
// 0x00017f40: load.s.pri     -2122743796
// 0x00017f45: sysreq.c       
// 0x00017f46: lidx           
// 0x00017f47: push.pri       
// 0x00017f48: push.s         -2146687220
// 0x00017f4d: emit           
// 0x00017f4e: eq.alt         -2129646591
// 0x00017f53: load.i         
// 0x00017f54: const.alt      -403974528
// 0x00017f59: jsgeq          
// 0x00017f5a: load.s.pri     -2122743796
// 0x00017f5f: sysreq.c       
// 0x00017f60: idxaddr        
// 0x00017f61: push.pri       
// 0x00017f62: push.c         0x-7a0f2980 ""
// 0x00017f67: stor.alt       -1432452057
// 0x00017f6c: op240          
// 0x00017f6d: add.c          
// 0x00017f6e: push.c         0x-6604637c ""
// 0x00017f73: shr.alt        
// 0x00017f74: push.s         -2146425076
// 0x00017f79: emit           
// 0x00017f7a: eq.pri         
// 0x00017f7b: sysreq.c       
// 0x00017f7c: stack          -2129188076
// 0x00017f81: load.i         
// 0x00017f82: push.c         0x-510f017d ""
// 0x00017f87: sgeq           
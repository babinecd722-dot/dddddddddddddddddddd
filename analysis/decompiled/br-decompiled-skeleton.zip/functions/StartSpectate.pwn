// StartSpectate @ 0x7a234-0x7a9d0 (1948 bytes)
// Source: test.pwn

stock StartSpectate()
{
    // load.pri 622265389
    // stack -2122568424
    // stack 201949456
    // branch jrel -> -2141132797
    // const.pri 159454986
    // const.alt -2030252416
    // branch jrel -> -2141132797
    call_0x0xca8a981();
    // const.pri -184824192
    // branch jrel -> -696251356
}

// --- disasm (first 80) ---
// 0x0007a234: op250          
// 0x0007a235: sref.alt       -402454143
// 0x0007a23a: or             
// 0x0007a23b: eq.pri         
// 0x0007a23c: mul.c          
// 0x0007a23d: load.pri       622265389
// 0x0007a242: push.c         0x-7d591380 ""
// 0x0007a247: sysreq.pri     
// 0x0007a248: push.c         0x5812c84 ""
// 0x0007a24d: op238          
// 0x0007a24e: shr.alt        
// 0x0007a24f: push           -1045704832
// 0x0007a254: or             
// 0x0007a255: push.c         0x-7f847fec ""
// 0x0007a25a: mod.c          
// 0x0007a25b: stack          -2122568424
// 0x0007a260: load.i         
// 0x0007a261: push.c         0x-11fa7f00 ""
// 0x0007a266: shr.alt        
// 0x0007a267: push           -1045704832
// 0x0007a26c: or             
// 0x0007a26d: push.c         0x-7f847ff4 ""
// 0x0007a272: add            
// 0x0007a273: stack          201949456
// 0x0007a278: eq.pri         
// 0x0007a279: op206          
// 0x0007a27a: op252          
// 0x0007a27b: inc.i          
// 0x0007a27c: jrel           -2141132797
// 0x0007a281: sysreq.c       
// 0x0007a282: eq.alt         153230151
// 0x0007a287: eq.pri         
// 0x0007a288: neg            
// 0x0007a289: eq.pri         
// 0x0007a28a: mul.c          
// 0x0007a28b: bounds.p       
// 0x0007a28c: mod            
// 0x0007a28d: move.alt       
// 0x0007a28e: const.pri      159454986
// 0x0007a293: const.alt      -2030252416
// 0x0007a298: jrel           -2141132797
// 0x0007a29d: sysreq.c       
// 0x0007a29e: eq.alt         153230151
// 0x0007a2a3: eq.pri         
// 0x0007a2a4: neg            
// 0x0007a2a5: eq.pri         
// 0x0007a2a6: mul.c          
// 0x0007a2a7: halt.p         native#92349464 args=-696251380
// 0x0007a2b0: op199          
// 0x0007a2b1: op219          
// 0x0007a2b2: sysreq.pri     
// 0x0007a2b3: load.s.pri     -2122743796
// 0x0007a2b8: sysreq.c       
// 0x0007a2b9: idxaddr        
// 0x0007a2ba: move.alt       
// 0x0007a2bb: load.i         
// 0x0007a2bc: eq.pri         
// 0x0007a2bd: neg            
// 0x0007a2be: eq.pri         
// 0x0007a2bf: mul.c          
// 0x0007a2c0: cmps.i         
// 0x0007a2c1: mod            
// 0x0007a2c2: push.pri       
// 0x0007a2c3: heap           690290817
// 0x0007a2c8: op232          
// 0x0007a2c9: mul            
// 0x0007a2ca: push.s         136798440
// 0x0007a2cf: call           0xca8a981
// 0x0007a2d4: pop.pri        
// 0x0007a2d5: push.pri       
// 0x0007a2d6: const.pri      -184824192
// 0x0007a2db: load.s.alt     -830469340
// 0x0007a2e0: op252          
// 0x0007a2e1: inc.i          
// 0x0007a2e2: jrel           -696251356
// 0x0007a2e7: op199          
// 0x0007a2e8: op219          
// 0x0007a2e9: sysreq.pri     
// 0x0007a2ea: load.s.pri     -2122743796
// 0x0007a2ef: sysreq.c       
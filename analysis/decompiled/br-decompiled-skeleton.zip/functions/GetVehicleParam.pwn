// GetVehicleParam @ 0xec30-0xeca4 (116 bytes)
// Source: system_vehicle.pwn

stock GetVehicleParam()
{
    // stack 654934284
    // const.alt -689187200
    // stack 654934284
    // const.alt -689187200
    // stack 654934284
}

// --- disasm (first 80) ---
// 0x0000ec30: op235          
// 0x0000ec31: op214          
// 0x0000ec32: sysreq.pri     
// 0x0000ec33: load.s.pri     91848716
// 0x0000ec38: idxaddr        
// 0x0000ec39: move.alt       
// 0x0000ec3a: load.i         
// 0x0000ec3b: eq.pri         
// 0x0000ec3c: neg            
// 0x0000ec3d: eq.pri         
// 0x0000ec3e: mul.c          
// 0x0000ec3f: lref.s.alt     136782857
// 0x0000ec44: eq.pri         
// 0x0000ec45: emit           
// 0x0000ec46: eq.pri         
// 0x0000ec47: shr            
// 0x0000ec48: stack          654934284
// 0x0000ec4d: op0            
// 0x0000ec4e: const.alt      -689187200
// 0x0000ec53: sysreq.pri     
// 0x0000ec54: load.s.pri     91848716
// 0x0000ec59: idxaddr        
// 0x0000ec5a: move.alt       
// 0x0000ec5b: load.i         
// 0x0000ec5c: eq.pri         
// 0x0000ec5d: neg            
// 0x0000ec5e: eq.pri         
// 0x0000ec5f: mul.c          
// 0x0000ec60: lref.s.alt     136782857
// 0x0000ec65: eq.pri         
// 0x0000ec66: emit           
// 0x0000ec67: eq.pri         
// 0x0000ec68: dec            
// 0x0000ec69: stack          654934284
// 0x0000ec6e: op0            
// 0x0000ec6f: const.alt      -689187200
// 0x0000ec74: sysreq.pri     
// 0x0000ec75: load.s.pri     91848716
// 0x0000ec7a: idxaddr        
// 0x0000ec7b: move.alt       
// 0x0000ec7c: load.i         
// 0x0000ec7d: eq.pri         
// 0x0000ec7e: neg            
// 0x0000ec7f: eq.pri         
// 0x0000ec80: mul.c          
// 0x0000ec81: lref.s.alt     136782857
// 0x0000ec86: eq.pri         
// 0x0000ec87: emit           
// 0x0000ec88: eq.pri         
// 0x0000ec89: movs           
// 0x0000ec8a: stack          654934284
// 0x0000ec8f: load.s.alt     -338264052
// 0x0000ec94: op214          
// 0x0000ec95: sysreq.pri     
// 0x0000ec96: load.s.pri     91848716
// 0x0000ec9b: idxaddr        
// 0x0000ec9c: move.alt       
// 0x0000ec9d: load.i         
// 0x0000ec9e: eq.pri         
// 0x0000ec9f: neg            
// 0x0000eca0: eq.pri         
// 0x0000eca1: mul.c          
// 0x0000eca2: lref.s.alt     136782857
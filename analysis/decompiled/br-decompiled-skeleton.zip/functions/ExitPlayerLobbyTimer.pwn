// ExitPlayerLobbyTimer @ 0x20f30-0x22b10 (7136 bytes)
// Source: system_blackjack_full.pwn

stock ExitPlayerLobbyTimer()
{
    // branch jump -> -2127774315
    // stack 80423292
    // stack 
    // stack 654934276
    // load.pri 654625577
    // stack 50954508
    // branch jneq -> 0x28be9536
    // stack -1097518320
    // branch jneq -> 0x-4d217fd9
    // stack 50954516
    // load.pri -1344372725
    // stack 1971328045
    // stack -980077800
    // branch jrel -> 1971328045
    // stack -980077800
    // const.pri -754708349
    // stack -980077796
    // branch jneq -> 0xc270c29
    call_0x0x448a8581();
    // stack -980077804
    // load.pri 35438741
    // stack 
    // stack 50954512
    // branch jneq -> 0x109c5880
    // const.alt 1484815232
    // stack 762588432
    return 1;
    // stack -2122830556
    // stack 80417040
    // stack -912968440
    // stack 386149640
    // stack 863776020
    // stack 
    // stack 
    // stack 654934276
    // load.pri 654625577
    // stack 50954508
    // stack -879414512
    // stack 50954516
    return 1;
    // load.pri -1344372725
    // stack 1971328045
    // stack -778751208
    // load.pri -1344372725
    // branch jrel -> 1971328045
    // stack -778751208
    // const.pri -754708349
    // stack 2038452352
    // stack -778751204
    call_0x0x448a8581();
    // stack -778751212
    // stack 
    // load.pri 41471125
    // stack 
    // branch jump -> 
    // stor.alt 622265389
    // const.alt 1484815232
    // stack 762588432
    // branch jrel -> 1828586881
    // const.alt -2128707033
    // stack -2122830556
    // stack 80417040
    // stack -711641848
    // stack 386149640
    // stack 863776020
    // stack 
    // stack 
    // stack 654934276
    // load.pri 654625577
    // stack 50954508
    // stack -661310704
    // stack 50954516
    // stack 1971328045
    // stack -560647400
    // load.pri -1344372725
    // branch jrel -> 1971328045
    // stack -560647400
    // const.pri -754708349
    // stack -560647396
    // stack -560647404
    // stack 
    return 1;
    // load.pri 39115157
    // stack 
    // stack 50954512
    // const.alt 1484815232
    // stack 762588432
    // stack -2122830556
    // stack 80417040
    // stack -493538040
    // stack 386149640
    // stack 863776020
    // stack 
    // stack 
    // branch jneq -> 0x-2cd6f67f
    // const.alt -1842279385
    // stack 654934276
    // load.pri 654625577
    // stack 50954508
    // stack 
    // stack -459984112
    // stack 50954516
    // stor.alt -359333503
    // load.pri -1344372725
    // stack 1971328045
    // proc @0x2178d
    // const.alt -2130673113
    // stack -342543592
    // branch jrel -> 1971328045
    return 1;
    // stack -342543592
    // const.pri -754708349
    // const.alt 2038452352
    // stack -342543588
    call_0x();
    // stack -342543596
    // load.pri 36759189
    // stack 
    // stack 50954512
    // const.alt 1484815232
    // stack 762588432
    // stack -2122830556
    // stack 80417040
    // stack -275434232
    // stack 386149640
    // stack 863776020
    // stack 
    // stack 
    // const.alt -1842279385
    // stack 654934276
    // load.pri 654625577
    // stack 76033036
    // stack 218726668
    // stack 92342657
    return 1;
    // stack 654934296
    // stack 738820368
    // branch jeq -> 0x-7edb0c6b
    // const.alt -1616322944
    // const.alt -191545590
    // const.pri -191548671
    // stor.alt 80941321
    ();
    // stack 654934300
    // load.pri 1962214785
    // stack 738820368
    call_0x0x1158a292();
    // const.alt -141215873
    // stack -131331711
    // stack -2130083564
    // stack 8924176
    call_0x0x-7e8f087e();
    // stack -2127560531
    // const.alt 1635810176
    // stack 185172240
    // load.pri 807701036
    // const.alt 1635810176
    // stack 185172240
    // load.pri 807701036
    // branch jump -> -2130642027
    // load.alt 16487695
    // stor.alt -1824333696
    // const.alt -1824268160
    return 1;
    // stack 738820380
    // stor.alt -1412464600
    // stack 217780496
    // stack 1501569544
    // stack 
    // const.alt 1635810176
    // stack 654934288
    // load.pri 655162153
    // stack -2146860788
    // stack -2127530876
    // stack 185172236
    // load.pri 812942380
    // proc @0x21cab
    // const.alt 2071987239
    // branch jzer -> 0x-7ed7006b
    return 1;
    // const.alt -607660416
    // stack -696251268
    // branch jneq -> 0x70f71109
    // stack 654934296
    // stack 1827541264
    // stack -2087308024
    // const.alt 1635810176
    // stack 654934288
    call_0x0x-7ed7386a();
    // stack 185172236
    // load.pri 806654252
    // stack 1501569544
    // branch jrel -> -2144925311
    // stack 654934288
    // stack 185172236
    // load.pri 806654252
    // stack 738820364
    // stack 1760432392
    // const.alt -2036974333
    // load.pri 1954977331
    // branch jzer -> 0x-7ed3786a
    // const.pri 11395716
    // const.pri -300855153
    // branch jump -> -2125952874
    // const.alt -2020196601
    // const.pri -2020199679
    // branch jzer -> 0x-7ee7776a
    // const.pri 1083617666
    // const.alt -2003419896
    // branch jzer -> 0xb248996
    // load.pri 680105523
    // branch jzer -> 0x-7ef7756a
    // branch jump -> -2124904298
}

// --- disasm (first 80) ---
// 0x00020f30: jump           -2127774315
// 0x00020f35: load.i         
// 0x00020f36: stack          80423292
// 0x00020f3b: push.c         0x-7e847ffc ""
// 0x00020f40: sref.pri       -888076244
// 0x00020f45: op0            
// 0x00020f46: eq.alt         1221788425
// 0x00020f4b: move.alt       
// 0x00020f4c: eq.pri         
// 0x00020f4d: mod.c          
// 0x00020f4e: eq.pri         
// 0x00020f4f: jsgeq          
// 0x00020f50: stack          
// 0x00020f51: op189          
// 0x00020f52: push.pri       
// 0x00020f53: eq.alt         1221798153
// 0x00020f58: push.s         204013771
// 0x00020f5d: push.c         0x-5b6dcef4 ""
// 0x00020f62: div.c          
// 0x00020f63: stack          654934276
// 0x00020f68: load.pri       654625577
// 0x00020f6d: lref.s.alt     1551924096
// 0x00020f72: stack          50954508
// 0x00020f77: op211          
// 0x00020f78: jneq           0x28be9536
// 0x00020f7d: eq.alt         -562026743
// 0x00020f82: op178          
// 0x00020f83: op242          
// 0x00020f84: jsgeq          
// 0x00020f85: push.c         0x5814080 ""
// 0x00020f8a: op211          
// 0x00020f8b: div.c          
// 0x00020f8c: push.c         0x257b800c ""
// 0x00020f91: stack          -1097518320
// 0x00020f96: sshr           
// 0x00020f97: eq.alt         -754614007
// 0x00020f9c: jneq           0x-4d217fd9
// 0x00020fa1: op242          
// 0x00020fa2: eq.c.alt       
// 0x00020fa3: push.c         0x5814080 ""
// 0x00020fa8: op211          
// 0x00020fa9: div.c          
// 0x00020faa: push.c         0x257b8010 ""
// 0x00020faf: stack          50954516
// 0x00020fb4: op211          
// 0x00020fb5: jsgeq          
// 0x00020fb6: eq.alt         1757713665
// 0x00020fbb: eq.alt         654386953
// 0x00020fc0: load.pri       -1344372725
// 0x00020fc5: push.alt       
// 0x00020fc6: stack          1971328045
// 0x00020fcb: sref.alt       1020471589
// 0x00020fd0: push.s         823404300
// 0x00020fd5: eq.alt         761317773
// 0x00020fda: sleq           
// 0x00020fdb: eq.alt         -754614007
// 0x00020fe0: div.c          
// 0x00020fe1: eq.alt         658297605
// 0x00020fe6: eq.pri         
// 0x00020fe7: op222          
// 0x00020fe8: op178          
// 0x00020fe9: op243          
// 0x00020fea: sysreq.pri     
// 0x00020feb: push.c         0x5810082 ""
// 0x00020ff0: op203          
// 0x00020ff1: lref.s.alt     2071991335
// 0x00020ff6: push.alt       
// 0x00020ff7: stack          -980077800
// 0x00020ffc: sref.alt       19335553
// 0x00021001: push.c         0x-217ff4ff ""
// 0x00021006: op175          
// 0x00021007: push           
// 0x00021008: jrel           1971328045
// 0x0002100d: sref.alt       1020471589
// 0x00021012: push.s         823404300
// 0x00021017: eq.alt         762632333
// 0x0002101c: sleq           
// 0x0002101d: eq.alt         -754614007
// 0x00021022: div.c          
// 0x00021023: eq.alt         658297605
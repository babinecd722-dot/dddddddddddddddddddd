// LoadZakazTextk @ 0x1c1ac4-0x1c1ea4 (992 bytes)
// Source: test.pwn

stock LoadZakazTextk()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001c1ac4: op0            
// 0x001c1ac5: op0            
// 0x001c1ac6: op0            
// 0x001c1ac7: op0            
// 0x001c1ac8: op0            
// 0x001c1ac9: op0            
// 0x001c1aca: op0            
// 0x001c1acb: op0            
// 0x001c1acc: op0            
// 0x001c1acd: op0            
// 0x001c1ace: op0            
// 0x001c1acf: op0            
// 0x001c1ad0: op0            
// 0x001c1ad1: op0            
// 0x001c1ad2: op0            
// 0x001c1ad3: op0            
// 0x001c1ad4: op0            
// 0x001c1ad5: op0            
// 0x001c1ad6: op0            
// 0x001c1ad7: op0            
// 0x001c1ad8: op0            
// 0x001c1ad9: op0            
// 0x001c1ada: op0            
// 0x001c1adb: op0            
// 0x001c1adc: op0            
// 0x001c1add: op0            
// 0x001c1ade: op0            
// 0x001c1adf: op0            
// 0x001c1ae0: op0            
// 0x001c1ae1: op0            
// 0x001c1ae2: op0            
// 0x001c1ae3: op0            
// 0x001c1ae4: op0            
// 0x001c1ae5: op0            
// 0x001c1ae6: op0            
// 0x001c1ae7: op0            
// 0x001c1ae8: op0            
// 0x001c1ae9: op0            
// 0x001c1aea: op0            
// 0x001c1aeb: op0            
// 0x001c1aec: op0            
// 0x001c1aed: op0            
// 0x001c1aee: op0            
// 0x001c1aef: op0            
// 0x001c1af0: op0            
// 0x001c1af1: op0            
// 0x001c1af2: op0            
// 0x001c1af3: op0            
// 0x001c1af4: op0            
// 0x001c1af5: op0            
// 0x001c1af6: op0            
// 0x001c1af7: op0            
// 0x001c1af8: op0            
// 0x001c1af9: op0            
// 0x001c1afa: op0            
// 0x001c1afb: op0            
// 0x001c1afc: op0            
// 0x001c1afd: op0            
// 0x001c1afe: op0            
// 0x001c1aff: op0            
// 0x001c1b00: op0            
// 0x001c1b01: eq.alt         -2123267724
// 0x001c1b06: leq            
// 0x001c1b07: eq.alt         109
// 0x001c1b0c: op0            
// 0x001c1b0d: op0            
// 0x001c1b0e: op0            
// 0x001c1b0f: op0            
// 0x001c1b10: op0            
// 0x001c1b11: op0            
// 0x001c1b12: op0            
// 0x001c1b13: op0            
// 0x001c1b14: op0            
// 0x001c1b15: op0            
// 0x001c1b16: op0            
// 0x001c1b17: op0            
// 0x001c1b18: op0            
// 0x001c1b19: op0            
// 0x001c1b1a: op0            
// 0x001c1b1b: op0            
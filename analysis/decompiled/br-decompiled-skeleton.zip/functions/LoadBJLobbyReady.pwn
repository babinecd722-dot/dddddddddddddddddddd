// LoadBJLobbyReady @ 0x24728-0x25498 (3440 bytes)
// Source: system_blackjack_full.pwn

stock LoadBJLobbyReady()
{
    // stack 805579792
    // proc @0x2475b
    // branch jump -> 189847447
    // load.pri 416847669
    // stack 805579792
    // const.alt -242384591
    // branch jzer -> 0x-7eef2669
    // stack 805579792
    // stack 2038463491
    // branch jeq -> 0x-7eff2569
    // const.alt 1635810176
    // stack 805579792
    // stack 2038434819
    // stack -2130083564
    // branch jump -> 
    // stack 201949456
    // stack 654934292
    // proc @0x2487a
    return 1;
    // proc @0x2489b
    return 1;
    // const.pri 1149512705
    return 1;
    // proc @0x248c1
    // branch jnz -> 0x2938df97
    // stack 911507464
    // proc @0x248f0
    // branch jneq -> 0x-68cca680
    // const.pri -526961407
    return 1;
    // stack 805579792
    return 1;
    // branch jeq -> 0x-7edf1e69
    // const.alt -422803161
    // stack 805841936
    // stack 2038434819
    // branch jneq -> 0xc08e297
    // stack 2038463491
    // branch jneq -> 0x-7ff71d69
    // branch jump -> 185655959
    // load.pri 1491244853
    // stack 805841936
    // stack 2038463491
    // stack 2038434819
    // stack 654934288
    // stor.alt -2115699161
    // stack 688488720
    // load.pri -2125666665
    // branch jump -> -2122783081
    // branch jump -> -2122783081
    // branch jump -> -2122783081
    // branch jump -> -2122783081
    // stack -426298616
    // load.alt 52225431
    // proc @0x24a77
    // branch jump -> -2129335913
    // branch jump -> -2129335913
    // branch jump -> -2129335913
    // branch jump -> -2129335913
    // const.alt 2071987239
    // stack -375966968
    // load.alt 54060951
    // proc @0x24aea
    // proc @0x24af8
    // branch jzer -> 0x-7ef31569
    // proc @0x24b18
    // proc @0x24b20
    // branch jump -> -2130646121
    // stack 805841928
    // load.pri -1344372725
    // stack 1971328045
    // load.pri -2146762457
    // stack 1971328045
    // stack 654934280
    // stack 654934288
    // const.alt 1635810176
    // stack 654934288
    // const.alt 1635810176
    // stack 654934288
    // const.alt 1635810176
    // stack 654934288
    // const.alt 1635810176
    // stack 654934288
    return 1;
    // const.alt 1635810176
    // stack 654934288
    // const.alt 1635810176
    // stack 654934288
    // stack 405372711
    // stack 738820368
    // stack -2130083564
    // stack 201949456
    // stack -2130083564
    // stack 688488720
    // stack 774897796
    // const.pri -607660416
    // const.alt -558571904
    // stack 2038434819
    // const.alt -2122575607
    // branch jeq -> 0x-7e9f0a69
    // stack -1450570628
    return 1;
    // const.alt -1091381632
    // stack 2038434819
    // stack -2130083580
    // branch jneq -> 0x-54307fd8
    // stack 654934300
    // branch jneq -> 0x-54307fd8
    // stack 654934288
    // load.pri 2071987239
    // stack -141085432
    // branch jneq -> 0x7b800427
    // stack 805579784
    // const.alt -2127494105
    // stack 159480849
    // stack -696251268
    // branch jneq -> 0x-54307fd8
    // stack 654934296
    // branch jneq -> 0x-54307fd8
    // stack 654934288
    // load.pri 2071987239
    // stack -73976568
    // stack 806104072
    // branch jneq -> 0x79807c03
    // branch jneq -> 0x7b801c27
    // stack 654934304
    // branch jneq -> 0x-54307fd8
    // stack 654934288
    // load.pri 2071987239
    // stack -40422136
    // stack 806104072
    // stack 894730248
    return 1;
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // const.alt 1484815232
    // stack 292826384
    // const.pri 67150725
    ();
    // branch jneq -> 0x79807c03
    // const.pri 159455026
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // const.pri 159454979
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // branch jneq -> 0x79807c03
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // branch jneq -> 0x79807c03
    // stack -2122568428
    // const.alt 2071989287
    // stack 201949456
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // const.alt -1046094464
    // branch jneq -> 0x79807c03
    // branch jneq -> 0x7b802827
    // stack 654934316
    // branch jneq -> 0x-54307fd8
    // stack 201949456
    // branch jneq -> 0x79807c03
    // branch jneq -> 0x7b801027
    // stack 654934292
    // branch jneq -> 0x-54307fd8
    // stack 185172240
    // load.pri -2127555540
    // const.pri 806104065
    // proc @0x251a7
    // const.pri 159455103
    // branch jneq -> 0x-54307fd8
    // stack 654934296
    // branch jneq -> 0x-54307fd8
    // stack 654934288
    // load.pri 2071987239
    // stack -1902627576
    // stack 2071987239
    // stack 806104072
    // branch jneq -> 0x-54307fd8
    // stack 654934308
    // branch jneq -> 0x-54307fd8
    // stack 654934288
    // load.pri 2071987239
    // stack -1869073144
    // stack 806104072
    // branch jneq -> 0x-4a217fd9
    // branch jrel -> 2071988263
    // stack 654934284
    // load.pri 2071987239
    // stack 894730248
    return 1;
    // stack -2146694783
    // const.alt -1230971520
    // const.alt -1230971520
    // const.alt 1484815232
    // stack 292826384
    // const.pri 67150725
    ();
    // const.pri 159454996
    // const.alt -1230971520
    // stack -2122568428
}

// --- disasm (first 80) ---
// 0x00024728: op214          
// 0x00024729: cmps           
// 0x0002472a: eq.alt         -562026743
// 0x0002472f: op181          
// 0x00024730: push           
// 0x00024731: load.s.alt     -422803161
// 0x00024736: op179          
// 0x00024737: sign.alt       
// 0x00024738: push.s         -2146687220
// 0x0002473d: emit           
// 0x0002473e: eq.pri         
// 0x0002473f: xor            
// 0x00024740: stack          805579792
// 0x00024745: eq.alt         662448393
// 0x0002474a: load.s.alt     738884480
// 0x0002474f: lref.s.alt     -1758047104
// 0x00024754: op215          
// 0x00024755: shr.alt        
// 0x00024756: load.s.pri     930874380
// 0x0002475b: proc           
// 0x0002475c: op215          
// 0x0002475d: shr.alt        
// 0x0002475e: eq.pri         
// 0x0002475f: mod.c          
// 0x00024760: jump           189847447
// 0x00024765: load.pri       416847669
// 0x0002476a: eq.alt         -562026743
// 0x0002476f: op181          
// 0x00024770: push.s         
// 0x00024771: strb.i         -422803161
// 0x00024776: op179          
// 0x00024777: sign.alt       
// 0x00024778: push.s         -2146687220
// 0x0002477d: emit           
// 0x0002477e: eq.pri         
// 0x0002477f: xor            
// 0x00024780: stack          805579792
// 0x00024785: eq.alt         -2038159607
// 0x0002478a: eq.pri         
// 0x0002478b: eq.pri         
// 0x0002478c: op0            
// 0x0002478d: push.s         655108476
// 0x00024792: const.alt      -242384591
// 0x00024797: add            
// 0x00024798: eq.pri         
// 0x00024799: mod            
// 0x0002479a: jzer           0x-7eef2669
// 0x0002479f: load.i         
// 0x000247a0: push.c         0x-6d4a2180 ""
// 0x000247a5: or             
// 0x000247a6: push.c         0x-4c193377 ""
// 0x000247ab: sign.alt       
// 0x000247ac: push.s         -2146687220
// 0x000247b1: emit           
// 0x000247b2: eq.pri         
// 0x000247b3: xor            
// 0x000247b4: stack          805579792
// 0x000247b9: eq.alt         -562033655
// 0x000247be: op180          
// 0x000247bf: op222          
// 0x000247c0: stack          2038463491
// 0x000247c5: eq.alt         2131499385
// 0x000247ca: jeq            0x-7eff2569
// 0x000247cf: load.i         
// 0x000247d0: push.c         0x-6c4a2180 ""
// 0x000247d5: mul            
// 0x000247d6: push.c         0x270c297f ""
// 0x000247db: const.alt      1635810176
// 0x000247e0: stack          805579792
// 0x000247e5: eq.alt         -562033655
// 0x000247ea: op180          
// 0x000247eb: op222          
// 0x000247ec: stack          2038434819
// 0x000247f1: eq.alt         186784633
// 0x000247f6: sign.alt       
// 0x000247f7: stor.i         
// 0x000247f8: eq.alt         1090202633
// 0x000247fd: eq.pri         
// 0x000247fe: mod.c          
// 0x000247ff: addr.alt       2004892923
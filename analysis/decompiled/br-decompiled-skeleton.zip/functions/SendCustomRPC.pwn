// SendCustomRPC @ 0x12948-0x12b88 (576 bytes)
// Source: customhud.inc

stock SendCustomRPC()
{
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949456
    // const.alt -2146687991
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // const.alt -1450428545
    // branch jneq -> 0x5810981
    // const.pri -403974528
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949456
    // const.alt -2146687991
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // const.pri -403974528
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949456
    // const.alt -2146687991
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack 931073033
    // const.pri -403974528
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 203891721
    // stack 201949456
    // const.alt -2146687991
    // const.alt 2038434819
    // stack 136782857
    // stack 201949452
    // const.alt 2038434819
    // const.alt 58788132
    // stack -108186832
    // branch jneq -> 0x-7ff3f67f
    // const.alt 2038434819
}

// --- disasm (first 80) ---
// 0x00012948: eq.alt         152775545
// 0x0001294d: push.pri       
// 0x0001294e: const.alt      -1561405824
// 0x00012953: const.alt      2038434819
// 0x00012958: lref.pri       -2146885093
// 0x0001295d: neg            
// 0x0001295e: eq.pri         
// 0x0001295f: mul.c          
// 0x00012960: sctrl          203891721
// 0x00012965: eq.pri         
// 0x00012966: emit           
// 0x00012967: eq.pri         
// 0x00012968: eq             
// 0x00012969: stack          201949456
// 0x0001296e: eq.pri         
// 0x0001296f: op214          
// 0x00012970: op235          
// 0x00012971: op214          
// 0x00012972: op0            
// 0x00012973: load.s.pri     91848716
// 0x00012978: idxaddr        
// 0x00012979: move.alt       
// 0x0001297a: load.i         
// 0x0001297b: eq.pri         
// 0x0001297c: neg            
// 0x0001297d: eq.pri         
// 0x0001297e: mul.c          
// 0x0001297f: const.alt      -2146687991
// 0x00012984: op214          
// 0x00012985: op238          
// 0x00012986: nop            
// 0x00012987: const.alt      2038434819
// 0x0001298c: lref.pri       -2146885093
// 0x00012991: neg            
// 0x00012992: eq.pri         
// 0x00012993: mul.c          
// 0x00012994: sctrl          136782857
// 0x00012999: eq.pri         
// 0x0001299a: emit           
// 0x0001299b: eq.pri         
// 0x0001299c: sshr           
// 0x0001299d: stack          201949452
// 0x000129a2: eq.pri         
// 0x000129a3: op214          
// 0x000129a4: op238          
// 0x000129a5: nop            
// 0x000129a6: const.alt      2038434819
// 0x000129ab: lref.pri       -2146885093
// 0x000129b0: neg            
// 0x000129b1: eq.pri         
// 0x000129b2: mul.c          
// 0x000129b3: push.pri       
// 0x000129b4: load.i         
// 0x000129b5: const.alt      -1450428545
// 0x000129ba: jneq           0x5810981
// 0x000129bf: xor            
// 0x000129c0: const.pri      -403974528
// 0x000129c5: jsgeq          
// 0x000129c6: push.pri       
// 0x000129c7: const.alt      -1561405824
// 0x000129cc: const.alt      2038434819
// 0x000129d1: lref.pri       -2146885093
// 0x000129d6: neg            
// 0x000129d7: eq.pri         
// 0x000129d8: mul.c          
// 0x000129d9: push.pri       
// 0x000129da: load.i         
// 0x000129db: eq.pri         
// 0x000129dc: sysreq.c       
// 0x000129dd: eq.alt         152775545
// 0x000129e2: push.pri       
// 0x000129e3: const.alt      -1561405824
// 0x000129e8: const.alt      2038434819
// 0x000129ed: lref.pri       -2146885093
// 0x000129f2: neg            
// 0x000129f3: eq.pri         
// 0x000129f4: mul.c          
// 0x000129f5: push.pri       
// 0x000129f6: load.i         
// 0x000129f7: push.pri       
// Case1SecondSpawnTimer @ 0xbc044-0xbc0c0 (124 bytes)
// Source: test.pwn

stock Case1SecondSpawnTimer()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000bc044: load.pri       285083009
// 0x000bc049: eq.alt         655160837
// 0x000bc04e: const.alt      740129664
// 0x000bc053: stor.alt       -2146694783
// 0x000bc058: op220          
// 0x000bc059: op232          
// 0x000bc05a: op231          
// 0x000bc05b: sysreq.pri     
// 0x000bc05c: load.s.pri     -2022080496
// 0x000bc061: load.s.pri     -2146885093
// 0x000bc066: neg            
// 0x000bc067: eq.pri         
// 0x000bc068: mul.c          
// 0x000bc069: eq.pri         
// 0x000bc06a: sleq           
// 0x000bc06b: load.i         
// 0x000bc06c: const.alt      -209700993
// 0x000bc071: op182          
// 0x000bc072: add            
// 0x000bc073: eq.alt         -327145719
// 0x000bc078: op199          
// 0x000bc079: sym.debug      
// 0x000bc07a: stor.alt       2071987239
// 0x000bc07f: eq.pri         
// 0x000bc080: shl            
// 0x000bc081: stack          201949448
// 0x000bc086: eq.pri         
// 0x000bc087: op220          
// 0x000bc088: op232          
// 0x000bc089: op231          
// 0x000bc08a: sysreq.pri     
// 0x000bc08b: load.s.pri     -2022080496
// 0x000bc090: load.s.pri     -2146885093
// 0x000bc095: neg            
// 0x000bc096: eq.pri         
// 0x000bc097: mul.c          
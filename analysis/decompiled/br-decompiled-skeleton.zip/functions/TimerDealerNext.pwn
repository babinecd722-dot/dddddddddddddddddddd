// TimerDealerNext @ 0x39d60-0x39db4 (84 bytes)
// Source: system_blackjack_full.pwn

stock TimerDealerNext()
{
    // stack 654934292
    // const.alt -1263411328
}

// --- disasm (first 80) ---
// 0x00039d60: eq.pri         
// 0x00039d61: op223          
// 0x00039d62: op177          
// 0x00039d63: op180          
// 0x00039d64: cmps           
// 0x00039d65: load.s.pri     -2122743796
// 0x00039d6a: sysreq.c       
// 0x00039d6b: idxaddr        
// 0x00039d6c: move.alt       
// 0x00039d6d: load.i         
// 0x00039d6e: eq.pri         
// 0x00039d6f: neg            
// 0x00039d70: eq.pri         
// 0x00039d71: mul.c          
// 0x00039d72: eq.pri         
// 0x00039d73: add            
// 0x00039d74: load.i         
// 0x00039d75: push.pri       
// 0x00039d76: push.s         -2146425076
// 0x00039d7b: emit           
// 0x00039d7c: eq.pri         
// 0x00039d7d: file           
// 0x00039d7e: stack          654934292
// 0x00039d83: op0            
// 0x00039d84: push.c         0x-7f4f6b74 ""
// 0x00039d89: op0            
// 0x00039d8a: const.alt      -1263411328
// 0x00039d8f: cmps           
// 0x00039d90: load.s.pri     -2122743796
// 0x00039d95: sysreq.c       
// 0x00039d96: idxaddr        
// 0x00039d97: move.alt       
// 0x00039d98: load.i         
// 0x00039d99: eq.pri         
// 0x00039d9a: neg            
// 0x00039d9b: eq.pri         
// 0x00039d9c: mul.c          
// 0x00039d9d: eq.pri         
// 0x00039d9e: add            
// 0x00039d9f: load.i         
// 0x00039da0: push.pri       
// 0x00039da1: push.s         -2146425076
// 0x00039da6: emit           
// 0x00039da7: eq.alt         -2129384446
// 0x00039dac: load.i         
// 0x00039dad: push.c         0x-207ff3ff ""
// 0x00039db2: op177          
// 0x00039db3: op180          
// ShowPlayerSkills @ 0x77880-0x78098 (2072 bytes)
// Source: test.pwn

stock ShowPlayerSkills()
{
    // branch jeq -> 0x5cb1ca80
    // const.alt 92342657
    // stack -897567984
    // const.alt -2144140244
    // load.pri 622265389
    // stack -2122568424
    // stack 201949456
    // branch jrel -> -2141132797
    // const.pri 159454986
    // const.alt -2030252416
    // branch jrel -> -2141132797
    call_0x0xca8a981();
    // const.pri -184824192
    // branch jrel -> -696251356
}

// --- disasm (first 80) ---
// 0x00077880: op219          
// 0x00077881: sysreq.pri     
// 0x00077882: load.s.pri     -2122743796
// 0x00077887: sysreq.c       
// 0x00077888: idxaddr        
// 0x00077889: move.alt       
// 0x0007788a: load.i         
// 0x0007788b: eq.pri         
// 0x0007788c: neg            
// 0x0007788d: eq.pri         
// 0x0007788e: mul.c          
// 0x0007788f: push.pri       
// 0x00077890: div.c          
// 0x00077891: load.i         
// 0x00077892: pop.alt        
// 0x00077893: jeq            0x5cb1ca80
// 0x00077898: eq.alt         -897567991
// 0x0007789d: op174          
// 0x0007789e: const.alt      92342657
// 0x000778a3: op232          
// 0x000778a4: sshr           
// 0x000778a5: push.c         0x-66184b7a ""
// 0x000778aa: sign.alt       
// 0x000778ab: push.s         203905256
// 0x000778b0: eq.pri         
// 0x000778b1: emit           
// 0x000778b2: eq.pri         
// 0x000778b3: xor            
// 0x000778b4: stack          -897567984
// 0x000778b9: op174          
// 0x000778ba: const.alt      -2144140244
// 0x000778bf: op202          
// 0x000778c0: op188          
// 0x000778c1: idxaddr.b      -402454143
// 0x000778c6: or             
// 0x000778c7: eq.pri         
// 0x000778c8: mul.c          
// 0x000778c9: load.pri       622265389
// 0x000778ce: push.c         0x-4f5a1380 ""
// 0x000778d3: sleq           
// 0x000778d4: push.c         0x5812c84 ""
// 0x000778d9: op238          
// 0x000778da: shr.alt        
// 0x000778db: push           -1045704832
// 0x000778e0: or             
// 0x000778e1: push.c         0x-7f847fec ""
// 0x000778e6: mod.c          
// 0x000778e7: stack          -2122568424
// 0x000778ec: load.i         
// 0x000778ed: push.c         0x-11fa7f00 ""
// 0x000778f2: shr.alt        
// 0x000778f3: push           -1045704832
// 0x000778f8: or             
// 0x000778f9: push.c         0x-7f847ff4 ""
// 0x000778fe: add            
// 0x000778ff: stack          201949456
// 0x00077904: eq.pri         
// 0x00077905: op206          
// 0x00077906: op252          
// 0x00077907: inc.i          
// 0x00077908: jrel           -2141132797
// 0x0007790d: sysreq.c       
// 0x0007790e: eq.alt         153230151
// 0x00077913: eq.pri         
// 0x00077914: neg            
// 0x00077915: eq.pri         
// 0x00077916: mul.c          
// 0x00077917: bounds.p       
// 0x00077918: xor            
// 0x00077919: move.alt       
// 0x0007791a: const.pri      159454986
// 0x0007791f: const.alt      -2030252416
// 0x00077924: jrel           -2141132797
// 0x00077929: sysreq.c       
// 0x0007792a: eq.alt         153230151
// 0x0007792f: eq.pri         
// 0x00077930: neg            
// 0x00077931: eq.pri         
// 0x00077932: mul.c          
// 0x00077933: halt.p         native#92349464 args=-696251380
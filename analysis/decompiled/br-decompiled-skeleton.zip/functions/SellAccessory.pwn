// SellAccessory @ 0x70eb0-0x71050 (416 bytes)
// Source: system_accessory.pwn

stock SellAccessory()
{
    // branch jzer -> 0x50ccc680
    // const.alt -607660416
    // branch jeq -> 0x58cdc680
    // stack -964676848
    return 1;
    // load.pri 622265389
    // stack -2127789017
    // stack -2122568424
    // stack 201949456
    // branch jrel -> -2141132797
    // const.pri 159454985
    // const.alt -2030252416
    // branch jrel -> -2141132797
    // const.alt -607660416
    call_0x0xca8a981();
    // const.pri -184824192
    // branch jrel -> -696251356
}

// --- disasm (first 80) ---
// 0x00070eb0: mul.c          
// 0x00070eb1: movs.i         
// 0x00070eb2: add            
// 0x00070eb3: load.i         
// 0x00070eb4: jzer           0x50ccc680
// 0x00070eb9: eq.alt         -964676855
// 0x00070ebe: op202          
// 0x00070ebf: lref.s.alt     -2146694783
// 0x00070ec4: op214          
// 0x00070ec5: op199          
// 0x00070ec6: op219          
// 0x00070ec7: sysreq.pri     
// 0x00070ec8: load.s.pri     2038454504
// 0x00070ecd: eq.alt         153230201
// 0x00070ed2: eq.pri         
// 0x00070ed3: neg            
// 0x00070ed4: eq.pri         
// 0x00070ed5: mul.c          
// 0x00070ed6: push.pri       
// 0x00070ed7: div.c          
// 0x00070ed8: load.i         
// 0x00070ed9: push.pri       
// 0x00070eda: const.alt      -607660416
// 0x00070edf: sysreq.pri     
// 0x00070ee0: load.s.pri     -2122743796
// 0x00070ee5: sysreq.c       
// 0x00070ee6: idxaddr        
// 0x00070ee7: move.alt       
// 0x00070ee8: load.i         
// 0x00070ee9: eq.pri         
// 0x00070eea: neg            
// 0x00070eeb: eq.pri         
// 0x00070eec: mul.c          
// 0x00070eed: push.pri       
// 0x00070eee: div.c          
// 0x00070eef: load.i         
// 0x00070ef0: pop.alt        
// 0x00070ef1: jeq            0x58cdc680
// 0x00070ef6: eq.alt         -964676855
// 0x00070efb: op202          
// 0x00070efc: lref.s.alt     92342657
// 0x00070f01: op232          
// 0x00070f02: sshr           
// 0x00070f03: push.c         0x-66184b7a ""
// 0x00070f08: sign.alt       
// 0x00070f09: push.s         203905256
// 0x00070f0e: eq.pri         
// 0x00070f0f: emit           
// 0x00070f10: eq.pri         
// 0x00070f11: xor            
// 0x00070f12: stack          -964676848
// 0x00070f17: op202          
// 0x00070f18: lref.s.alt     -2144140244
// 0x00070f1d: op198          
// 0x00070f1e: op225          
// 0x00070f1f: retn           
// 0x00070f20: eq.alt         1625817865
// 0x00070f25: eq.pri         
// 0x00070f26: mul.c          
// 0x00070f27: load.pri       622265389
// 0x00070f2c: push.c         0x-165c1380 ""
// 0x00070f31: stack          -2127789017
// 0x00070f36: lref.pri       -2144843538
// 0x00070f3b: op207          
// 0x00070f3c: op171          
// 0x00070f3d: op193          
// 0x00070f3e: or             
// 0x00070f3f: push.c         0x-7f847fec ""
// 0x00070f44: mod.c          
// 0x00070f45: stack          -2122568424
// 0x00070f4a: load.i         
// 0x00070f4b: push.c         0x-11fa7f00 ""
// 0x00070f50: shr.alt        
// 0x00070f51: push           -1045704832
// 0x00070f56: or             
// 0x00070f57: push.c         0x-7f847ff4 ""
// 0x00070f5c: add            
// 0x00070f5d: stack          201949456
// 0x00070f62: eq.pri         
// 0x00070f63: op206          
// FamilySpawnEncodeNewHouse @ 0x38b09c-0x38b0c0 (36 bytes)
// Source: test.pwn

stock FamilySpawnEncodeNewHouse()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0038b09c: op0            
// 0x0038b09d: op0            
// 0x0038b09e: op0            
// 0x0038b09f: op0            
// 0x0038b0a0: op0            
// 0x0038b0a1: op0            
// 0x0038b0a2: op0            
// 0x0038b0a3: op0            
// 0x0038b0a4: op0            
// 0x0038b0a5: op0            
// 0x0038b0a6: op0            
// 0x0038b0a7: op0            
// 0x0038b0a8: op0            
// 0x0038b0a9: op0            
// 0x0038b0aa: op0            
// 0x0038b0ab: op0            
// 0x0038b0ac: op0            
// 0x0038b0ad: op0            
// 0x0038b0ae: op0            
// 0x0038b0af: op0            
// 0x0038b0b0: op0            
// 0x0038b0b1: op0            
// 0x0038b0b2: op0            
// 0x0038b0b3: op0            
// 0x0038b0b4: op0            
// 0x0038b0b5: op0            
// 0x0038b0b6: op0            
// 0x0038b0b7: op0            
// 0x0038b0b8: op0            
// 0x0038b0b9: op0            
// 0x0038b0ba: op0            
// 0x0038b0bb: op0            
// 0x0038b0bc: op0            
// 0x0038b0bd: op0            
// 0x0038b0be: op0            
// 0x0038b0bf: op0            
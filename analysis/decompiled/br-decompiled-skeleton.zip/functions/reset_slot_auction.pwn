// reset_slot_auction @ 0xa6e64-0xa7244 (992 bytes)
// Source: system_auction.pwn

stock reset_slot_auction()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000a6e64: sref.alt       1619078167
// 0x000a6e69: jump           1624761984
// 0x000a6e6e: stack          654934276
// 0x000a6e73: load.pri       661966377
// 0x000a6e78: lref.s.alt     1551924096
// 0x000a6e7d: stack          654934284
// 0x000a6e82: eq.pri         
// 0x000a6e83: op236          
// 0x000a6e84: op191          
// 0x000a6e85: nop            
// 0x000a6e86: idxaddr.b      -1075019737
// 0x000a6e8b: push.adr       
// 0x000a6e8c: zero.pri       
// 0x000a6e8d: eq.alt         662228485
// 0x000a6e92: eq.pri         
// 0x000a6e93: op236          
// 0x000a6e94: op191          
// 0x000a6e95: push.adr       
// 0x000a6e96: sctrl          -2111372761
// 0x000a6e9b: zero.pri       
// 0x000a6e9c: push.s         823928588
// 0x000a6ea1: eq.alt         860930957
// 0x000a6ea6: eq.pri         
// 0x000a6ea7: op230          
// 0x000a6ea8: op225          
// 0x000a6ea9: jneq           0x-7fd8f67f
// 0x000a6eae: op236          
// 0x000a6eaf: op191          
// 0x000a6eb0: nop            
// 0x000a6eb1: jneq           0x8270c29
// 0x000a6eb6: call           0x58a1b681
// 0x000a6ebb: jump           954328704
// 0x000a6ec0: jump           954328704
// 0x000a6ec5: eq.alt         -327145719
// 0x000a6eca: op191          
// 0x000a6ecb: nop            
// 0x000a6ecc: jgeq           0x8270c29
// 0x000a6ed1: call           0x10f89981
// 0x000a6ed6: jump           954328704
// 0x000a6edb: eq.alt         -327145719
// 0x000a6ee0: op191          
// 0x000a6ee1: nop            
// 0x000a6ee2: add            
// 0x000a6ee3: push.c         0x270c297f ""
// 0x000a6ee8: const.alt      1635810176
// 0x000a6eed: stack          -427805936
// 0x000a6ef2: op225          
// 0x000a6ef3: jneq           0x-7fd8f67f
// 0x000a6ef8: op236          
// 0x000a6ef9: op191          
// 0x000a6efa: sysreq.n       
// 0x000a6efb: add            
// 0x000a6efc: push.s         822617868
// 0x000a6f01: eq.alt         860653722
// 0x000a6f06: eq.pri         
// 0x000a6f07: op230          
// 0x000a6f08: op225          
// 0x000a6f09: jneq           0x-7ff8fd7f
// 0x000a6f0e: op230          
// 0x000a6f0f: op225          
// 0x000a6f10: jneq           0x-32198000
// 0x000a6f15: jrel           -689537023
// 0x000a6f1a: retn           
// 0x000a6f1b: load.alt       752871040
// 0x000a6f20: load.s.pri     1491068544
// 0x000a6f25: load.s.alt     1625286272
// 0x000a6f2a: lref.pri       216065664
// 0x000a6f2f: lref.alt       1222698624
// 0x000a6f34: eq.alt         738265865
// 0x000a6f39: op177          
// 0x000a6f3a: stor.alt       -360697040
// 0x000a6f3f: op245          
// 0x000a6f40: mod            
// 0x000a6f41: eq.alt         -2146172151
// 0x000a6f46: mod            
// 0x000a6f47: jzer           0x8e2e680
// 0x000a6f4c: eq.alt         738265865
// 0x000a6f51: lref.s.alt     738820400
// 0x000a6f56: op252          
// 0x000a6f57: op0            
// InitStaticShop247Businesses @ 0x1d36f4-0x1d49d8 (4836 bytes)
// Source: test.pwn

stock InitStaticShop247Businesses()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001d36f4: op0            
// 0x001d36f5: op0            
// 0x001d36f6: op0            
// 0x001d36f7: op0            
// 0x001d36f8: op0            
// 0x001d36f9: op0            
// 0x001d36fa: op0            
// 0x001d36fb: op0            
// 0x001d36fc: op0            
// 0x001d36fd: op0            
// 0x001d36fe: op0            
// 0x001d36ff: op0            
// 0x001d3700: op0            
// 0x001d3701: op0            
// 0x001d3702: op0            
// 0x001d3703: op0            
// 0x001d3704: op0            
// 0x001d3705: op0            
// 0x001d3706: op0            
// 0x001d3707: op0            
// 0x001d3708: op0            
// 0x001d3709: op0            
// 0x001d370a: op0            
// 0x001d370b: op0            
// 0x001d370c: op0            
// 0x001d370d: op0            
// 0x001d370e: op0            
// 0x001d370f: op0            
// 0x001d3710: op0            
// 0x001d3711: op0            
// 0x001d3712: op0            
// 0x001d3713: op0            
// 0x001d3714: op0            
// 0x001d3715: op0            
// 0x001d3716: op0            
// 0x001d3717: op0            
// 0x001d3718: op0            
// 0x001d3719: op0            
// 0x001d371a: op0            
// 0x001d371b: op0            
// 0x001d371c: op0            
// 0x001d371d: op0            
// 0x001d371e: op0            
// 0x001d371f: op0            
// 0x001d3720: op0            
// 0x001d3721: op0            
// 0x001d3722: op0            
// 0x001d3723: op0            
// 0x001d3724: op0            
// 0x001d3725: op0            
// 0x001d3726: op0            
// 0x001d3727: op0            
// 0x001d3728: op0            
// 0x001d3729: op0            
// 0x001d372a: op0            
// 0x001d372b: op0            
// 0x001d372c: op0            
// 0x001d372d: op0            
// 0x001d372e: op0            
// 0x001d372f: op0            
// 0x001d3730: op0            
// 0x001d3731: op0            
// 0x001d3732: op0            
// 0x001d3733: op0            
// 0x001d3734: op0            
// 0x001d3735: op0            
// 0x001d3736: inc.i          
// 0x001d3737: op226          
// 0x001d3738: op217          
// 0x001d3739: jsgeq          
// 0x001d373a: eq.alt         -2130611072
// 0x001d373f: sgeq           
// 0x001d3740: load.s.pri     1300251264
// 0x001d3745: eq.pri         
// 0x001d3746: mul.c          
// 0x001d3747: sctrl          942884224
// 0x001d374c: sctrl          -2144324297
// 0x001d3751: grtr           
// 0x001d3752: op0            
// 0x001d3753: op0            
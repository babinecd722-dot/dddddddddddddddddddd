// OnGameModeExit @ 0xb7bec-0xb7cac (192 bytes)
// Source: test.pwn

public OnGameModeExit()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000b7bec: move.alt       
// 0x000b7bed: load.i         
// 0x000b7bee: eq.pri         
// 0x000b7bef: neg            
// 0x000b7bf0: eq.pri         
// 0x000b7bf1: mul.c          
// 0x000b7bf2: lref.s.alt     -830469084
// 0x000b7bf7: op251          
// 0x000b7bf8: op217          
// 0x000b7bf9: sshr           
// 0x000b7bfa: load.s.pri     41517180
// 0x000b7bff: idxaddr        
// 0x000b7c00: move.alt       
// 0x000b7c01: load.i         
// 0x000b7c02: eq.pri         
// 0x000b7c03: neg            
// 0x000b7c04: eq.pri         
// 0x000b7c05: mul.c          
// 0x000b7c06: const.alt      -562033884
// 0x000b7c0b: op251          
// 0x000b7c0c: op211          
// 0x000b7c0d: idxaddr.b      -2139356380
// 0x000b7c12: mul.c          
// 0x000b7c13: lref.s.alt     722106752
// 0x000b7c18: idxaddr        
// 0x000b7c19: move.alt       
// 0x000b7c1a: load.i         
// 0x000b7c1b: eq.pri         
// 0x000b7c1c: neg            
// 0x000b7c1d: push.pri       
// 0x000b7c1e: const.alt      -201601408
// 0x000b7c23: cmps           
// 0x000b7c24: load.s.pri     2038450421
// 0x000b7c29: load.s.pri     -2146956263
// 0x000b7c2e: shr            
// 0x000b7c2f: heap           52762372
// 0x000b7c34: op245          
// 0x000b7c35: shr.alt        
// 0x000b7c36: eq.pri         
// 0x000b7c37: mul.c          
// 0x000b7c38: load.pri       822355748
// 0x000b7c3d: eq.pri         
// 0x000b7c3e: op240          
// 0x000b7c3f: op211          
// 0x000b7c40: eq.c.alt       
// 0x000b7c41: heap           656742148
// 0x000b7c46: eq.pri         
// 0x000b7c47: op236          
// 0x000b7c48: op198          
// 0x000b7c49: casetbl        
// 0x000b7c4a: shl.pri        
// 0x000b7c4b: push.c         0x5814a82 ""
// 0x000b7c50: op245          
// 0x000b7c51: xor            
// 0x000b7c52: push.c         0x257b802c ""
// 0x000b7c57: stack          -2122830544
// 0x000b7c5c: load.i         
// 0x000b7c5d: const.alt      -637809024
// 0x000b7c62: sshr           
// 0x000b7c63: load.s.pri     41517180
// 0x000b7c68: idxaddr        
// 0x000b7c69: move.alt       
// 0x000b7c6a: load.i         
// 0x000b7c6b: eq.pri         
// 0x000b7c6c: neg            
// 0x000b7c6d: eq.pri         
// 0x000b7c6e: mul.c          
// 0x000b7c6f: sref.alt       50341668
// 0x000b7c74: zero.pri       
// 0x000b7c75: eq.pri         
// 0x000b7c76: mul.c          
// 0x000b7c77: load.pri       -1987827932
// 0x000b7c7c: eq.pri         
// 0x000b7c7d: eq.pri         
// 0x000b7c7e: op0            
// 0x000b7c7f: const.pri      -738468224
// 0x000b7c84: idxaddr.b      -2139356380
// 0x000b7c89: mul.c          
// 0x000b7c8a: lref.s.alt     722106752
// 0x000b7c8f: idxaddr        
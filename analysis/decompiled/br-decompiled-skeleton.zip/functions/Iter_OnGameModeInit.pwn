// Iter_OnGameModeInit @ 0xdf90-0xe11c (396 bytes)
// Source: system_pickup.pwn

stock Iter_OnGameModeInit()
{
    // const.alt 136782857
    // stack 654934284
    // branch jump -> -338264052
    // const.alt 136782857
    // stack 654934284
    // load.pri -338264052
    // const.alt 136782857
    // stack 654934284
    // load.pri -338264052
    // const.alt 136782857
}

// --- disasm (first 80) ---
// 0x0000df90: push.c         0x-297ff3ff ""
// 0x0000df95: op235          
// 0x0000df96: op210          
// 0x0000df97: mul            
// 0x0000df98: load.s.pri     91848716
// 0x0000df9d: idxaddr        
// 0x0000df9e: move.alt       
// 0x0000df9f: load.i         
// 0x0000dfa0: eq.pri         
// 0x0000dfa1: neg            
// 0x0000dfa2: eq.pri         
// 0x0000dfa3: mul.c          
// 0x0000dfa4: const.alt      136782857
// 0x0000dfa9: eq.pri         
// 0x0000dfaa: emit           
// 0x0000dfab: eq.pri         
// 0x0000dfac: movs           
// 0x0000dfad: stack          654934284
// 0x0000dfb2: jump           -338264052
// 0x0000dfb7: op210          
// 0x0000dfb8: mul            
// 0x0000dfb9: load.s.pri     91848716
// 0x0000dfbe: idxaddr        
// 0x0000dfbf: move.alt       
// 0x0000dfc0: load.i         
// 0x0000dfc1: eq.pri         
// 0x0000dfc2: neg            
// 0x0000dfc3: eq.pri         
// 0x0000dfc4: mul.c          
// 0x0000dfc5: const.alt      136782857
// 0x0000dfca: eq.pri         
// 0x0000dfcb: emit           
// 0x0000dfcc: eq.pri         
// 0x0000dfcd: cmps           
// 0x0000dfce: stack          654934284
// 0x0000dfd3: load.pri       -338264052
// 0x0000dfd8: op210          
// 0x0000dfd9: mul            
// 0x0000dfda: load.s.pri     91848716
// 0x0000dfdf: idxaddr        
// 0x0000dfe0: move.alt       
// 0x0000dfe1: load.i         
// 0x0000dfe2: eq.pri         
// 0x0000dfe3: neg            
// 0x0000dfe4: eq.pri         
// 0x0000dfe5: mul.c          
// 0x0000dfe6: const.alt      136782857
// 0x0000dfeb: eq.pri         
// 0x0000dfec: emit           
// 0x0000dfed: eq.pri         
// 0x0000dfee: fill           
// 0x0000dfef: stack          654934284
// 0x0000dff4: load.pri       -338264052
// 0x0000dff9: op210          
// 0x0000dffa: mul            
// 0x0000dffb: load.s.pri     91848716
// 0x0000e000: idxaddr        
// 0x0000e001: move.alt       
// 0x0000e002: load.i         
// 0x0000e003: eq.pri         
// 0x0000e004: neg            
// 0x0000e005: eq.pri         
// 0x0000e006: mul.c          
// 0x0000e007: const.alt      136782857
// 0x0000e00c: eq.pri         
// 0x0000e00d: emit           
// 0x0000e00e: eq.pri         
// 0x0000e00f: halt           
// 0x0000e010: stack          201949452
// 0x0000e015: eq.pri         
// 0x0000e016: op214          
// 0x0000e017: op235          
// 0x0000e018: op210          
// 0x0000e019: mul            
// 0x0000e01a: load.s.pri     91848716
// 0x0000e01f: idxaddr        
// 0x0000e020: move.alt       
// 0x0000e021: load.i         
// 0x0000e022: eq.pri         
// 0x0000e023: neg            
// n_DisablePlayerRaceCheckpoint @ 0xd754-0xd824 (208 bytes)
// Source: system_cp_race.pwn

stock n_DisablePlayerRaceCheckpoint()
{
    // load.alt 2071989287
    // stack -2129188080
    // branch jzer -> 0x-260a7cd9
    // const.alt -705964416
    // stack 654934288
    // load.alt -338264052
    // stack 654934284
    // const.alt -705964416
    // stack 654934284
    // const.alt -705964416
    // stack 654934284
    // load.pri -338264052
    // stack 654934284
    // branch jump -> -338264052
}

// --- disasm (first 80) ---
// 0x0000d754: push.pri       
// 0x0000d755: push.c         0x-4c102980 ""
// 0x0000d75a: jgeq           0x-1a637bd9
// 0x0000d75f: op225          
// 0x0000d760: move.pri       
// 0x0000d761: push.c         0x-7f1f6b7c ""
// 0x0000d766: load.alt       2071989287
// 0x0000d76b: eq.pri         
// 0x0000d76c: eq.c.pri       
// 0x0000d76d: stack          -2129188080
// 0x0000d772: load.i         
// 0x0000d773: push.c         0x-5a26037d ""
// 0x0000d778: jzer           0x-260a7cd9
// 0x0000d77d: op243          
// 0x0000d77e: pop.alt        
// 0x0000d77f: const.alt      -705964416
// 0x0000d784: lref.s.alt     2038434819
// 0x0000d789: lref.pri       -2146885093
// 0x0000d78e: neg            
// 0x0000d78f: load.i         
// 0x0000d790: push.pri       
// 0x0000d791: push.c         0x-7f847ff4 ""
// 0x0000d796: eq.c.alt       
// 0x0000d797: stack          654934288
// 0x0000d79c: load.alt       -338264052
// 0x0000d7a1: op213          
// 0x0000d7a2: lref.s.alt     2038434819
// 0x0000d7a7: lref.pri       -2146885093
// 0x0000d7ac: neg            
// 0x0000d7ad: load.i         
// 0x0000d7ae: push.pri       
// 0x0000d7af: push.c         0x-7f847ff8 ""
// 0x0000d7b4: inc            
// 0x0000d7b5: stack          654934284
// 0x0000d7ba: sign.alt       
// 0x0000d7bb: const.alt      -705964416
// 0x0000d7c0: lref.s.alt     2038434819
// 0x0000d7c5: lref.pri       -2146885093
// 0x0000d7ca: neg            
// 0x0000d7cb: load.i         
// 0x0000d7cc: push.pri       
// 0x0000d7cd: push.c         0x-7f847ff8 ""
// 0x0000d7d2: shr            
// 0x0000d7d3: stack          654934284
// 0x0000d7d8: op0            
// 0x0000d7d9: const.alt      -705964416
// 0x0000d7de: lref.s.alt     2038434819
// 0x0000d7e3: lref.pri       -2146885093
// 0x0000d7e8: neg            
// 0x0000d7e9: load.i         
// 0x0000d7ea: push.pri       
// 0x0000d7eb: push.c         0x-7f847ff8 ""
// 0x0000d7f0: dec            
// 0x0000d7f1: stack          654934284
// 0x0000d7f6: load.pri       -338264052
// 0x0000d7fb: op213          
// 0x0000d7fc: lref.s.alt     2038434819
// 0x0000d801: lref.pri       -2146885093
// 0x0000d806: neg            
// 0x0000d807: load.i         
// 0x0000d808: push.pri       
// 0x0000d809: push.c         0x-7f847ff8 ""
// 0x0000d80e: movs           
// 0x0000d80f: stack          654934284
// 0x0000d814: jump           -338264052
// 0x0000d819: op213          
// 0x0000d81a: lref.s.alt     2038434819
// 0x0000d81f: lref.pri       -2146885093
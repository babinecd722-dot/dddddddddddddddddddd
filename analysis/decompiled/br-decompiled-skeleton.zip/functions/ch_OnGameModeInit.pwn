// ch_OnGameModeInit @ 0x64348-0x643f4 (172 bytes)
// Source: system_weekly_prizes.pwn

stock ch_OnGameModeInit()
{
    // branch jneq -> 0x-7ec37cd9
    // stack -2130083552
    // stack -2130083560
    // stack 2071991335
    // stack 654934296
    // load.pri -422803161
    // const.alt -2071101135
    // branch jrel -> 92342657
    // stack -2130083568
}

// --- disasm (first 80) ---
// 0x00064348: neg            
// 0x00064349: eq.pri         
// 0x0006434a: mul.c          
// 0x0006434b: cmps.i         
// 0x0006434c: mod            
// 0x0006434d: push.pri       
// 0x0006434e: push.c         0x-d641380 ""
// 0x00064353: jneq           0x-7ec37cd9
// 0x00064358: lref.pri       472328425
// 0x0006435d: eq.pri         
// 0x0006435e: emit           
// 0x0006435f: push.alt       
// 0x00064360: stack          -2130083552
// 0x00064365: lref.pri       -696251272
// 0x0006436a: op199          
// 0x0006436b: op219          
// 0x0006436c: sysreq.pri     
// 0x0006436d: load.s.pri     -2122743688
// 0x00064372: sysreq.c       
// 0x00064373: idxaddr        
// 0x00064374: move.alt       
// 0x00064375: load.i         
// 0x00064376: eq.pri         
// 0x00064377: neg            
// 0x00064378: eq.pri         
// 0x00064379: mul.c          
// 0x0006437a: cmps.i         
// 0x0006437b: mod            
// 0x0006437c: push.pri       
// 0x0006437d: push.c         0x-b641380 ""
// 0x00064382: shl.pri        
// 0x00064383: push.c         0x5810581 ""
// 0x00064388: op247          
// 0x00064389: strb.i         2071991335
// 0x0006438e: push.alt       
// 0x0006438f: stack          -2130083560
// 0x00064394: lref.pri       -696251380
// 0x00064399: op199          
// 0x0006439a: op219          
// 0x0006439b: sysreq.pri     
// 0x0006439c: load.s.pri     -2122743796
// 0x000643a1: sysreq.c       
// 0x000643a2: idxaddr        
// 0x000643a3: move.alt       
// 0x000643a4: load.i         
// 0x000643a5: eq.pri         
// 0x000643a6: neg            
// 0x000643a7: eq.pri         
// 0x000643a8: mul.c          
// 0x000643a9: cmps.i         
// 0x000643aa: mod            
// 0x000643ab: push.pri       
// 0x000643ac: push.c         0x-9641380 ""
// 0x000643b1: mod            
// 0x000643b2: push.c         0x5811381 ""
// 0x000643b7: op251          
// 0x000643b8: stack          2071991335
// 0x000643bd: push.alt       
// 0x000643be: stack          654934296
// 0x000643c3: load.pri       -422803161
// 0x000643c8: op179          
// 0x000643c9: sign.alt       
// 0x000643ca: eq.alt         656992517
// 0x000643cf: const.alt      -2071101135
// 0x000643d4: jrel           92342657
// 0x000643d9: op247          
// 0x000643da: strb.i         204046119
// 0x000643df: push.c         0x-7f847ff4 ""
// 0x000643e4: xor            
// 0x000643e5: stack          -2130083568
// 0x000643ea: lref.pri       2133273851
// 0x000643ef: push.s         -2146687112
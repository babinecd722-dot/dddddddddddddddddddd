// pc_alias_gnews @ 0x28c310-0x28c34c (60 bytes)
// Source: test.pwn

stock pc_alias_gnews()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0028c310: op0            
// 0x0028c311: op0            
// 0x0028c312: op0            
// 0x0028c313: op0            
// 0x0028c314: op0            
// 0x0028c315: op0            
// 0x0028c316: op0            
// 0x0028c317: op0            
// 0x0028c318: op0            
// 0x0028c319: op0            
// 0x0028c31a: op0            
// 0x0028c31b: op0            
// 0x0028c31c: op0            
// 0x0028c31d: op0            
// 0x0028c31e: op0            
// 0x0028c31f: op0            
// 0x0028c320: op0            
// 0x0028c321: op0            
// 0x0028c322: op0            
// 0x0028c323: op0            
// 0x0028c324: op0            
// 0x0028c325: op0            
// 0x0028c326: op0            
// 0x0028c327: op0            
// 0x0028c328: op0            
// 0x0028c329: op0            
// 0x0028c32a: op0            
// 0x0028c32b: op0            
// 0x0028c32c: op0            
// 0x0028c32d: op0            
// 0x0028c32e: op0            
// 0x0028c32f: op0            
// 0x0028c330: op0            
// 0x0028c331: op0            
// 0x0028c332: op0            
// 0x0028c333: op0            
// 0x0028c334: op0            
// 0x0028c335: op0            
// 0x0028c336: op0            
// 0x0028c337: op0            
// 0x0028c338: op0            
// 0x0028c339: op0            
// 0x0028c33a: op0            
// 0x0028c33b: op0            
// 0x0028c33c: op0            
// 0x0028c33d: op0            
// 0x0028c33e: op0            
// 0x0028c33f: op0            
// 0x0028c340: op0            
// 0x0028c341: op0            
// 0x0028c342: op0            
// 0x0028c343: op0            
// 0x0028c344: op0            
// 0x0028c345: op0            
// 0x0028c346: op0            
// 0x0028c347: op0            
// 0x0028c348: op0            
// 0x0028c349: op0            
// 0x0028c34a: op0            
// 0x0028c34b: op0            
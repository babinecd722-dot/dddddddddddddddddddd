// AccessoryEditSetMovementLock @ 0x694d0-0x69824 (852 bytes)
// Source: system_accessory.pwn

stock AccessoryEditSetMovementLock()
{
    // load.pri 622265389
    // branch jrel -> -2146690009
    // stack 863776020
    // branch jump -> 
    // branch jzer -> 0x1c9fc280
    // stack 159461384
    // stack 8457224
    // stack 654934288
    // branch jump -> 2090910336
    ();
    // const.alt -2144925311
    // load.pri -1031784405
    ();
    // stack 688488720
    // stack 688488708
    // const.alt -2127494105
    ();
    call_0x0x78859281();
    // branch jump -> 1425402496
    // branch jzer -> 0x28a4c280
    // stack 745804040
    // load.pri 1824047744
    // stack 1962545416
    // branch jneq -> 0x-7ee07ed9
    // stack 855911444
    // stack 1962545416
    call_0x0x448a8581();
    // branch jrel -> -2128641753
    // stack 855911444
    // stack 1962545416
    call_0x0x448a8581();
    return 1;
    // stack 855911444
    // stack 1962545416
    // load.pri -1611890649
    // const.alt -2127490009
    // branch jneq -> 0x-7ee07ed9
}

// --- disasm (first 80) ---
// 0x000694d0: mul.c          
// 0x000694d1: load.pri       622265389
// 0x000694d6: push.c         0x-63601380 ""
// 0x000694db: jrel           -2146690009
// 0x000694e0: op204          
// 0x000694e1: op185          
// 0x000694e2: op208          
// 0x000694e3: strb.i         2038434819
// 0x000694e8: eq.alt         153230201
// 0x000694ed: eq.pri         
// 0x000694ee: neg            
// 0x000694ef: push.pri       
// 0x000694f0: load.s.pri     326729844
// 0x000694f5: pop.alt        
// 0x000694f6: idxaddr        
// 0x000694f7: move.alt       
// 0x000694f8: load.i         
// 0x000694f9: eq.pri         
// 0x000694fa: neg            
// 0x000694fb: push.pri       
// 0x000694fc: push.c         0x257b8010 ""
// 0x00069501: stack          863776020
// 0x00069506: eq.pri         
// 0x00069507: op194          
// 0x00069508: jump           
// 0x00069509: idxaddr.b      159450156
// 0x0006950e: push.s         822355724
// 0x00069513: eq.alt         -2123071056
// 0x00069518: load.i         
// 0x00069519: load.s.pri     22511640
// 0x0006951e: push.pri       
// 0x0006951f: push.c         0x-62601380 ""
// 0x00069524: sctrl          203885609
// 0x00069529: eq.pri         
// 0x0006952a: emit           
// 0x0006952b: jsgrtr         0x-7fccefd4
// 0x00069530: op234          
// 0x00069531: op245          
// 0x00069532: mod            
// 0x00069533: eq.alt         -2146172151
// 0x00069538: mod            
// 0x00069539: jzer           0x1c9fc280
// 0x0006953e: eq.alt         655108361
// 0x00069543: load.s.alt     -2119139023
// 0x00069548: cmps           
// 0x00069549: stack          159461384
// 0x0006954e: push.s         -2147211492
// 0x00069553: emit           
// 0x00069554: xchg           
// 0x00069555: stack          8457224
// 0x0006955a: jsleq          0x5ca0c280
// 0x0006955f: eq.alt         -327145719
// 0x00069564: swap.pri       
// 0x00069565: switch         
// 0x00069566: jgeq           0xc297f27
// 0x0006956b: push.c         0x-7f847ff4 ""
// 0x00069570: xor            
// 0x00069571: stack          654934288
// 0x00069576: eq.pri         
// 0x00069577: op236          
// 0x00069578: swap.pri       
// 0x00069579: swap.pri       
// 0x0006957a: sleq           
// 0x0006957b: push.c         0x-60601380 ""
// 0x00069580: shl.pri        
// 0x00069581: push.c         0x-60601380 ""
// 0x00069586: jgeq           0x-60137fd9
// 0x0006958b: casetbl        
// 0x0006958c: add            
// 0x0006958d: push.c         0x27b32701 ""
// 0x00069592: push.s         823928588
// 0x00069597: eq.alt         743490445
// 0x0006959c: lref.s.alt     654934320
// 0x000695a1: op0            
// 0x000695a2: jump           2090910336
// 0x000695a7: eq.alt         1953398793
// 0x000695ac: load.s.pri     -2146169740
// 0x000695b1: jsgeq          
// 0x000695b2: eq.pri         
// 0x000695b3: op194          
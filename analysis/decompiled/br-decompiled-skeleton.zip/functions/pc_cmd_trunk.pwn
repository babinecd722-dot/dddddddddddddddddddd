// pc_cmd_trunk @ 0x288e04-0x288e40 (60 bytes)
// Source: test.pwn

stock pc_cmd_trunk()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00288e04: op0            
// 0x00288e05: op0            
// 0x00288e06: op0            
// 0x00288e07: op0            
// 0x00288e08: op0            
// 0x00288e09: op0            
// 0x00288e0a: op0            
// 0x00288e0b: op0            
// 0x00288e0c: op0            
// 0x00288e0d: op0            
// 0x00288e0e: op0            
// 0x00288e0f: op0            
// 0x00288e10: op0            
// 0x00288e11: op0            
// 0x00288e12: op0            
// 0x00288e13: op0            
// 0x00288e14: op0            
// 0x00288e15: op0            
// 0x00288e16: op0            
// 0x00288e17: op0            
// 0x00288e18: op0            
// 0x00288e19: op0            
// 0x00288e1a: op0            
// 0x00288e1b: op0            
// 0x00288e1c: op0            
// 0x00288e1d: op0            
// 0x00288e1e: op0            
// 0x00288e1f: op0            
// 0x00288e20: op0            
// 0x00288e21: op0            
// 0x00288e22: op0            
// 0x00288e23: op0            
// 0x00288e24: op0            
// 0x00288e25: op0            
// 0x00288e26: op0            
// 0x00288e27: op0            
// 0x00288e28: op0            
// 0x00288e29: op0            
// 0x00288e2a: op0            
// 0x00288e2b: op0            
// 0x00288e2c: op0            
// 0x00288e2d: op0            
// 0x00288e2e: op0            
// 0x00288e2f: op0            
// 0x00288e30: op0            
// 0x00288e31: op0            
// 0x00288e32: op0            
// 0x00288e33: op0            
// 0x00288e34: op0            
// 0x00288e35: op0            
// 0x00288e36: op0            
// 0x00288e37: op0            
// 0x00288e38: op0            
// 0x00288e39: op0            
// 0x00288e3a: op0            
// 0x00288e3b: op0            
// 0x00288e3c: op0            
// 0x00288e3d: op0            
// 0x00288e3e: op0            
// 0x00288e3f: op0            
// n_IsPlayerInCheckpoint @ 0xd010-0xd1ac (412 bytes)
// Source: system_cp.pwn

stock n_IsPlayerInCheckpoint()
{
    // stack 201949452
    // stack 201949452
    // const.alt 2015962121
    // stack 855911436
    // stack 201949444
    // stor.alt 2038435843
    // stack 201949452
    // stor.alt 2038435843
    // stack 201949452
    // stor.alt 2038435843
    // stack 201949452
    // stor.alt 2038435843
    // const.alt 204022793
    // stack 688488716
    // const.alt 2071987239
    // stack 654934280
    // stack 654934284
    // load.pri 136776745
    // stack 688488716
    // const.alt -2127494105
    // branch jump -> -2130127480
    // const.alt 56151168
    // const.alt -2009630079
    // stack -712494320
    // const.pri -2127679487
    // stor.alt -83687039
    // load.pri 622265389
    // stack -2122568428
    // const.alt -370289024
}

// --- disasm (first 80) ---
// 0x0000d010: lref.pri       -2146885093
// 0x0000d015: neg            
// 0x0000d016: eq.pri         
// 0x0000d017: mul.c          
// 0x0000d018: load.s.alt     2015962121
// 0x0000d01d: push.c         0x-7f847ff8 ""
// 0x0000d022: geq            
// 0x0000d023: stack          201949452
// 0x0000d028: eq.pri         
// 0x0000d029: op214          
// 0x0000d02a: op235          
// 0x0000d02b: op213          
// 0x0000d02c: lref.s.alt     2038435843
// 0x0000d031: lref.pri       -2146885093
// 0x0000d036: neg            
// 0x0000d037: eq.pri         
// 0x0000d038: mul.c          
// 0x0000d039: lref.s.alt     2015962121
// 0x0000d03e: push.c         0x-7f847ff8 ""
// 0x0000d043: geq            
// 0x0000d044: stack          201949452
// 0x0000d049: eq.pri         
// 0x0000d04a: op214          
// 0x0000d04b: op235          
// 0x0000d04c: op213          
// 0x0000d04d: lref.s.alt     2038435843
// 0x0000d052: lref.pri       -2146885093
// 0x0000d057: neg            
// 0x0000d058: eq.pri         
// 0x0000d059: mul.c          
// 0x0000d05a: const.alt      2015962121
// 0x0000d05f: push.c         0x-7f847ff8 ""
// 0x0000d064: geq            
// 0x0000d065: stack          855911436
// 0x0000d06a: movs.i         
// 0x0000d06b: op186          
// 0x0000d06c: op0            
// 0x0000d06d: stack          201949444
// 0x0000d072: eq.pri         
// 0x0000d073: op214          
// 0x0000d074: op235          
// 0x0000d075: op212          
// 0x0000d076: stor.alt       2038435843
// 0x0000d07b: lref.pri       -2146885093
// 0x0000d080: neg            
// 0x0000d081: load.i         
// 0x0000d082: push.pri       
// 0x0000d083: push.s         -2146949364
// 0x0000d088: emit           
// 0x0000d089: eq.pri         
// 0x0000d08a: geq            
// 0x0000d08b: stack          201949452
// 0x0000d090: eq.pri         
// 0x0000d091: op214          
// 0x0000d092: op235          
// 0x0000d093: op212          
// 0x0000d094: stor.alt       2038435843
// 0x0000d099: lref.pri       -2146885093
// 0x0000d09e: neg            
// 0x0000d09f: eq.pri         
// 0x0000d0a0: mul.c          
// 0x0000d0a1: load.s.alt     204022793
// 0x0000d0a6: push.c         0x-7f847ff8 ""
// 0x0000d0ab: geq            
// 0x0000d0ac: stack          201949452
// 0x0000d0b1: eq.pri         
// 0x0000d0b2: op214          
// 0x0000d0b3: op235          
// 0x0000d0b4: op212          
// 0x0000d0b5: stor.alt       2038435843
// 0x0000d0ba: lref.pri       -2146885093
// 0x0000d0bf: neg            
// 0x0000d0c0: eq.pri         
// 0x0000d0c1: mul.c          
// 0x0000d0c2: lref.s.alt     204022793
// 0x0000d0c7: push.c         0x-7f847ff8 ""
// 0x0000d0cc: geq            
// 0x0000d0cd: stack          201949452
// 0x0000d0d2: eq.pri         
// 0x0000d0d3: op214          
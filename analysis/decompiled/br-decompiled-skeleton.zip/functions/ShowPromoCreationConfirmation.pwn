// ShowPromoCreationConfirmation @ 0x4ad0c-0x4b528 (2076 bytes)
// Source: system_new_promo.pwn

stock ShowPromoCreationConfirmation()
{
    // const.alt 151803776
    // branch jneq -> 0xb4cbaaf
    // load.pri 1354411827
    // branch jzer -> 0x-7ef74451
    // const.pri -2030252416
    // const.alt 605050752
    // branch jump -> -2126988113
    // const.pri -2030252416
    // const.alt 151803776
    // branch jneq -> 0xd04bcaf
    // const.pri -2030252416
    // const.alt 151541632
    // branch jneq -> 0xb04bcaf
    // load.pri 146583347
    // branch jzer -> 0x-7ec74351
    // const.pri -2030252416
    // const.alt 605312896
    // branch jrel -> 1468008740
    // load.pri 159455019
    // const.alt -607660416
    // branch jrel -> -2144918519
    // branch jneq -> 0xc271029
    call_0x0x448a8581();
    // const.alt 1468008740
    // load.pri 159455019
    // const.alt -607660416
    // const.alt -2144918519
    // const.alt -607660416
    // const.alt 510230537
    // branch jzer -> 0x-7ee33c51
    // stack 654934288
    // stack 201949456
    // load.pri 159455019
    // const.alt -607660416
    call_0x0x448a8581();
    // load.pri 159455019
    // const.alt -607660416
    // branch jrel -> 203886633
    call_0x0x448a8581();
    // stack -2130433016
    // const.alt -607660416
    // const.alt -8188919
    // branch jeq -> 0x-7edf3a51
    // const.alt -607660416
    // const.alt 69673993
    call_0x0x-7ed72d7d();
    // const.alt -607660416
    // const.alt -8189150
    // stor.alt -8188919
    // branch jeq -> 0x-7e873851
    // stack -696251268
    // stor.alt 216666377
    // load.pri -1970090112
    // branch jnz -> 0x9221b2b
    // stack 201949448
    // stor.alt -8189150
    // stack 201949444
    // const.alt 391741474
    // branch jrel -> 394201890
    // stack 774926485
    // stor.alt -368158336
    // stor.alt 1888843648
    // branch jeq -> 0x2740caaf
    // const.pri -894487807
    // branch jzer -> 0x-7e872f51
    // stack -545249412
    return 1;
    // const.alt -1969501056
    // const.alt -607660416
    // const.pri 1719673607
    // branch jnz -> 0x-7faf3351
    // branch jump -> 190368943
    // load.pri 1892724533
    // const.alt -114554495
    // stor.alt -485598848
    // stor.alt -545249500
    // stack 654934292
    // stor.alt -2110710745
    // stor.alt 201687332
    // const.alt -607660416
    // stor.alt 2071994407
    // stack 654934308
    // load.pri -405472729
    // const.alt -2071101135
    // branch jrel -> 1501563265
    // stack 741370012
    // branch jzer -> 0x-7ed32e51
    // const.pri 1955933185
    return 1;
    // branch jeq -> 0x2708d2af
    return 1;
    // const.alt -1355458176
    // const.alt -1969501056
    // const.pri 1719673607
    // branch jnz -> 0x-7fe72b51
    // branch jump -> 186700975
    // load.pri 953724725
    // const.alt -114554495
    // stor.alt -485598848
    // stor.alt -545249500
    // stor.alt 2071990311
    // stack 654934292
}

// --- disasm (first 80) ---
// 0x0004ad0c: inc.i          
// 0x0004ad0d: const.alt      151803776
// 0x0004ad12: pop.alt        
// 0x0004ad13: jneq           0xb4cbaaf
// 0x0004ad18: load.pri       1354411827
// 0x0004ad1d: eq.pri         
// 0x0004ad1e: mod.c          
// 0x0004ad1f: jzer           0x-7ef74451
// 0x0004ad24: load.i         
// 0x0004ad25: const.pri      -2030252416
// 0x0004ad2a: const.alt      605050752
// 0x0004ad2f: load.i         
// 0x0004ad30: eq.alt         711950339
// 0x0004ad35: jump           -2126988113
// 0x0004ad3a: load.i         
// 0x0004ad3b: addr.pri       604570858
// 0x0004ad40: const.pri      -2030252416
// 0x0004ad45: const.alt      151803776
// 0x0004ad4a: pop.alt        
// 0x0004ad4b: jneq           0xd04bcaf
// 0x0004ad50: op234          
// 0x0004ad51: load.s.alt     151279488
// 0x0004ad56: push.pri       
// 0x0004ad57: const.pri      -2030252416
// 0x0004ad5c: const.alt      151541632
// 0x0004ad61: pop.alt        
// 0x0004ad62: jneq           0xb04bcaf
// 0x0004ad67: load.pri       146583347
// 0x0004ad6c: eq.pri         
// 0x0004ad6d: mod.c          
// 0x0004ad6e: jzer           0x-7ec74351
// 0x0004ad73: load.i         
// 0x0004ad74: const.pri      -2030252416
// 0x0004ad79: const.alt      605312896
// 0x0004ad7e: load.i         
// 0x0004ad7f: eq.alt         711950339
// 0x0004ad84: eq.alt         -696251383
// 0x0004ad89: op199          
// 0x0004ad8a: op219          
// 0x0004ad8b: sysreq.pri     
// 0x0004ad8c: load.s.pri     -2122743792
// 0x0004ad91: sysreq.c       
// 0x0004ad92: idxaddr        
// 0x0004ad93: move.alt       
// 0x0004ad94: load.i         
// 0x0004ad95: eq.pri         
// 0x0004ad96: neg            
// 0x0004ad97: eq.pri         
// 0x0004ad98: mul.c          
// 0x0004ad99: push.c         
// 0x0004ad9a: jrel           1468008740
// 0x0004ad9f: load.pri       159455019
// 0x0004ada4: const.alt      -607660416
// 0x0004ada9: sysreq.pri     
// 0x0004adaa: load.s.pri     -2122743792
// 0x0004adaf: sysreq.c       
// 0x0004adb0: idxaddr        
// 0x0004adb1: move.alt       
// 0x0004adb2: load.i         
// 0x0004adb3: eq.pri         
// 0x0004adb4: neg            
// 0x0004adb5: eq.pri         
// 0x0004adb6: mul.c          
// 0x0004adb7: push.c         
// 0x0004adb8: jrel           -2144918519
// 0x0004adbd: op223          
// 0x0004adbe: op187          
// 0x0004adbf: op214          
// 0x0004adc0: jneq           0xc271029
// 0x0004adc5: call           0x448a8581
// 0x0004adca: eq.alt         -696251383
// 0x0004adcf: op199          
// 0x0004add0: op219          
// 0x0004add1: sysreq.pri     
// 0x0004add2: load.s.pri     -2122743792
// 0x0004add7: sysreq.c       
// 0x0004add8: idxaddr        
// 0x0004add9: move.alt       
// 0x0004adda: load.i         
// 0x0004addb: eq.pri         
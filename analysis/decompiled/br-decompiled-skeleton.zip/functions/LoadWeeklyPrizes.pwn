// LoadWeeklyPrizes @ 0x63d44-0x63fc0 (636 bytes)
// Source: system_weekly_prizes.pwn

stock LoadWeeklyPrizes()
{
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack -2101398772
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack -2101398772
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack -2101398772
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack 654934284
    return 1;
    // stack -2101398772
    // load.pri 35715262
    // branch jneq -> 0x7080bf07
    // branch jump -> 1421852800
    // load.pri -2126740033
    // load.pri -2144927449
    // const.alt -2127490009
    // const.alt 1635810176
    // stack -2051067120
    // const.alt 1635810176
    // stack -2051067120
    // load.pri 858817727
    // branch jzer -> 0x-7e937941
    // const.pri 159461377
    // const.alt -607660416
    // branch jneq -> 0x8a70c09
    // stack 656157052
}

// --- disasm (first 80) ---
// 0x00063d44: push.c         0x2affebf7 ""
// 0x00063d49: push.c         0x-7e847ff8 ""
// 0x00063d4e: ret            
// 0x00063d4f: stack          654934284
// 0x00063d54: eq.pri         
// 0x00063d55: op236          
// 0x00063d56: call.pri       
// 0x00063d57: op195          
// 0x00063d58: xor            
// 0x00063d59: push.c         0x2affebf7 ""
// 0x00063d5e: push.c         0x-7e847ff8 ""
// 0x00063d63: ret            
// 0x00063d64: stack          654934284
// 0x00063d69: eq.pri         
// 0x00063d6a: op236          
// 0x00063d6b: call.pri       
// 0x00063d6c: op197          
// 0x00063d6d: mul            
// 0x00063d6e: push.c         0x2affebf7 ""
// 0x00063d73: push.c         0x-7e847ff8 ""
// 0x00063d78: ret            
// 0x00063d79: stack          654934284
// 0x00063d7e: eq.pri         
// 0x00063d7f: op236          
// 0x00063d80: call.pri       
// 0x00063d81: op199          
// 0x00063d82: cmps           
// 0x00063d83: push.c         0x2affebf7 ""
// 0x00063d88: push.c         0x-7e847ff8 ""
// 0x00063d8d: ret            
// 0x00063d8e: stack          -2101398772
// 0x00063d93: cmps           
// 0x00063d94: eq.alt         -327145719
// 0x00063d99: call.pri       
// 0x00063d9a: op201          
// 0x00063d9b: add            
// 0x00063d9c: push.c         0x2affebf7 ""
// 0x00063da1: push.c         0x-7e847ff8 ""
// 0x00063da6: ret            
// 0x00063da7: stack          654934284
// 0x00063dac: eq.pri         
// 0x00063dad: op236          
// 0x00063dae: call.pri       
// 0x00063daf: op203          
// 0x00063db0: add            
// 0x00063db1: push.c         0x2affebf7 ""
// 0x00063db6: push.c         0x-7e847ff8 ""
// 0x00063dbb: ret            
// 0x00063dbc: stack          654934284
// 0x00063dc1: eq.pri         
// 0x00063dc2: op236          
// 0x00063dc3: call.pri       
// 0x00063dc4: op205          
// 0x00063dc5: sshr           
// 0x00063dc6: push.c         0x2affebf7 ""
// 0x00063dcb: push.c         0x-7e847ff8 ""
// 0x00063dd0: ret            
// 0x00063dd1: stack          654934284
// 0x00063dd6: eq.pri         
// 0x00063dd7: op236          
// 0x00063dd8: call.pri       
// 0x00063dd9: op207          
// 0x00063dda: zero.pri       
// 0x00063ddb: push.c         0x2affebf7 ""
// 0x00063de0: push.c         0x-7e847ff8 ""
// 0x00063de5: ret            
// 0x00063de6: stack          -2101398772
// 0x00063deb: cmps           
// 0x00063dec: eq.alt         -327145719
// 0x00063df1: call.pri       
// 0x00063df2: op209          
// 0x00063df3: div.c          
// 0x00063df4: push.c         0x2affebf7 ""
// 0x00063df9: push.c         0x-7e847ff8 ""
// 0x00063dfe: ret            
// 0x00063dff: stack          654934284
// 0x00063e04: eq.pri         
// 0x00063e05: op236          
// 0x00063e06: call.pri       
// 0x00063e07: op211          
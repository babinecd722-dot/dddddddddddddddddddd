// SnowNotificarionBJL @ 0x3b1f0-0x3b6d0 (1248 bytes)
// Source: system_blackjack_full.pwn

stock SnowNotificarionBJL()
{
    // const.alt 2071989287
    // const.alt -1263411328
    // stack -2129188076
    // const.alt -1263411328
    // const.alt 2071990311
    // const.alt 2071989287
    // stack 654934288
    // const.alt -1263411328
    // const.alt 2071989287
    // stack 654934288
    // const.alt 2071989287
    // stack 654934288
    // const.alt 2071989287
    // const.alt 2071989287
    // const.alt 2071989287
    // stack 654934288
    // load.pri -1310752756
    // const.alt 2071989287
    // const.alt -1263411328
    // stack -2129188076
    // const.alt -1263411328
    // const.alt 2071990311
    // const.alt 2071989287
    // stack 654934288
    // const.alt -1263411328
    // const.alt 2071989287
    // stack 654934288
    // const.alt 2071989287
    // stack 654934288
    // const.alt 2071989287
    // const.alt 2071989287
    // const.alt 2071989287
    // stack 654934288
    // load.pri -1310752756
    // const.alt 2071989287
    // const.alt -1263411328
    // branch jzer -> 0x-3b607bd9
    // stack -2129188076
    // const.alt -1263411328
    // const.alt 2071990311
    // const.alt 2071989287
    // stack 654934288
    // const.alt -1263411328
    // const.alt 2071989287
    // stack 654934288
    // const.alt 2071989287
    // stack 654934288
    // const.alt 2071989287
    // const.alt 2071989287
    // const.alt 2071989287
    // stack 654934288
    // load.pri -1310752756
    // const.alt 2071989287
    // const.alt -1263411328
    // stack -2129188076
    // const.alt -1263411328
    // const.alt 2071990311
    // const.alt 2071989287
}

// --- disasm (first 80) ---
// 0x0003b1f0: op177          
// 0x0003b1f1: op180          
// 0x0003b1f2: cmps           
// 0x0003b1f3: load.s.pri     -2122743796
// 0x0003b1f8: sysreq.c       
// 0x0003b1f9: idxaddr        
// 0x0003b1fa: move.alt       
// 0x0003b1fb: load.i         
// 0x0003b1fc: eq.pri         
// 0x0003b1fd: neg            
// 0x0003b1fe: eq.pri         
// 0x0003b1ff: mul.c          
// 0x0003b200: eq.alt         690227464
// 0x0003b205: const.alt      2071989287
// 0x0003b20a: eq.alt         -2129646524
// 0x0003b20f: load.i         
// 0x0003b210: const.alt      -1263411328
// 0x0003b215: cmps           
// 0x0003b216: load.s.pri     -2122743796
// 0x0003b21b: sysreq.c       
// 0x0003b21c: idxaddr        
// 0x0003b21d: move.alt       
// 0x0003b21e: load.i         
// 0x0003b21f: eq.pri         
// 0x0003b220: neg            
// 0x0003b221: eq.pri         
// 0x0003b222: mul.c          
// 0x0003b223: eq.alt         -2144918516
// 0x0003b228: op223          
// 0x0003b229: op181          
// 0x0003b22a: op214          
// 0x0003b22b: div.c          
// 0x0003b22c: push.c         0x-6e2a627c ""
// 0x0003b231: sysreq.c       
// 0x0003b232: push.c         0x-7f4f677c ""
// 0x0003b237: lref.s.pri     270994473
// 0x0003b23c: eq.pri         
// 0x0003b23d: emit           
// 0x0003b23e: eq.pri         
// 0x0003b23f: sysreq.c       
// 0x0003b240: stack          -2129188076
// 0x0003b245: load.i         
// 0x0003b246: push.c         0x-7f1f717c ""
// 0x0003b24b: op0            
// 0x0003b24c: push.c         0x-7f7f717c ""
// 0x0003b251: op0            
// 0x0003b252: const.alt      -1263411328
// 0x0003b257: cmps           
// 0x0003b258: load.s.pri     -2122743796
// 0x0003b25d: sysreq.c       
// 0x0003b25e: idxaddr        
// 0x0003b25f: move.alt       
// 0x0003b260: load.i         
// 0x0003b261: eq.pri         
// 0x0003b262: neg            
// 0x0003b263: eq.pri         
// 0x0003b264: mul.c          
// 0x0003b265: eq.alt         690227468
// 0x0003b26a: const.alt      2071990311
// 0x0003b26f: eq.alt         -2129384446
// 0x0003b274: load.i         
// 0x0003b275: push.c         0x-207ff3ff ""
// 0x0003b27a: op177          
// 0x0003b27b: op180          
// 0x0003b27c: cmps           
// 0x0003b27d: load.s.pri     -2122743796
// 0x0003b282: sysreq.c       
// 0x0003b283: idxaddr        
// 0x0003b284: move.alt       
// 0x0003b285: load.i         
// 0x0003b286: eq.pri         
// 0x0003b287: neg            
// 0x0003b288: eq.pri         
// 0x0003b289: mul.c          
// 0x0003b28a: eq.alt         690227468
// 0x0003b28f: const.alt      2071989287
// 0x0003b294: eq.pri         
// 0x0003b295: emit           
// 0x0003b296: stack          654934288
// 0x0003b29b: sign.alt       
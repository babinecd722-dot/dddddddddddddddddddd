// DeleteAsk @ 0x15050-0x15208 (440 bytes)
// Source: test.pwn

stock DeleteAsk()
{
    // const.alt 2038434819
    // branch jneq -> 0x17598022
    // const.alt 2038434819
    // const.alt 2038434819
    // const.alt 2038434819
    // const.alt 2038434819
    // const.alt 2038434819
    // const.alt 58788132
    // branch jump -> -2126972531
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt 58788132
    // const.alt 2038434819
    return 1;
    // const.alt 2038434819
    call_0x0x332cc48e();
    // branch jneq -> 0x-7ff3f67f
    // const.alt 2038434819
    // const.alt 58788132
    // const.alt 2038434819
    // const.alt -192071809
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 955878707
    // const.alt 2038434819
    // const.alt 58788132
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    call_0x0x332cc48e();
    // branch jneq -> 0x-7ff3f67f
    // const.alt 2038434819
}

// --- disasm (first 80) ---
// 0x00015050: const.alt      2038434819
// 0x00015055: lref.pri       -2146885093
// 0x0001505a: neg            
// 0x0001505b: eq.pri         
// 0x0001505c: mul.c          
// 0x0001505d: jneq           0x17598022
// 0x00015062: eq.alt         -696251383
// 0x00015067: op238          
// 0x00015068: nop            
// 0x00015069: const.alt      2038434819
// 0x0001506e: lref.pri       -2146885093
// 0x00015073: neg            
// 0x00015074: eq.pri         
// 0x00015075: mul.c          
// 0x00015076: jgeq           0x17598022
// 0x0001507b: eq.alt         -696251383
// 0x00015080: op238          
// 0x00015081: nop            
// 0x00015082: const.alt      2038434819
// 0x00015087: lref.pri       -2146885093
// 0x0001508c: neg            
// 0x0001508d: eq.pri         
// 0x0001508e: mul.c          
// 0x0001508f: strb.i         391741474
// 0x00015094: eq.alt         -696251383
// 0x00015099: op238          
// 0x0001509a: nop            
// 0x0001509b: const.alt      2038434819
// 0x000150a0: lref.pri       -2146885093
// 0x000150a5: neg            
// 0x000150a6: eq.pri         
// 0x000150a7: mul.c          
// 0x000150a8: idxaddr.b      391741474
// 0x000150ad: eq.alt         -696251383
// 0x000150b2: op238          
// 0x000150b3: nop            
// 0x000150b4: const.alt      2038434819
// 0x000150b9: lref.pri       -2146885093
// 0x000150be: neg            
// 0x000150bf: eq.pri         
// 0x000150c0: mul.c          
// 0x000150c1: sref.alt       391741474
// 0x000150c6: eq.alt         -696251383
// 0x000150cb: op238          
// 0x000150cc: nop            
// 0x000150cd: const.alt      2038434819
// 0x000150d2: lref.pri       -2146885093
// 0x000150d7: neg            
// 0x000150d8: eq.pri         
// 0x000150d9: mul.c          
// 0x000150da: const.alt      58788132
// 0x000150df: eq.pri         
// 0x000150e0: eq.c.pri       
// 0x000150e1: pop.pri        
// 0x000150e2: jump           -2126972531
// 0x000150e7: load.i         
// 0x000150e8: const.alt      -1561405824
// 0x000150ed: const.alt      2038434819
// 0x000150f2: lref.pri       -2146885093
// 0x000150f7: neg            
// 0x000150f8: eq.pri         
// 0x000150f9: mul.c          
// 0x000150fa: const.alt      58788132
// 0x000150ff: eq.pri         
// 0x00015100: eq.c.pri       
// 0x00015101: pop.pri        
// 0x00015102: eq.alt         -696251383
// 0x00015107: op238          
// 0x00015108: nop            
// 0x00015109: const.alt      2038434819
// 0x0001510e: lref.pri       -2146885093
// 0x00015113: neg            
// 0x00015114: eq.pri         
// 0x00015115: mul.c          
// 0x00015116: sctrl          931073033
// 0x0001511b: push.pri       
// 0x0001511c: op242          
// 0x0001511d: retn           
// 0x0001511e: eq.alt         202123529
// 0x00015123: eq.pri         
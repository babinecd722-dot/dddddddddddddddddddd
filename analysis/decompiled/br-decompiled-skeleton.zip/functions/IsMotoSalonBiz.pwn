// IsMotoSalonBiz @ 0xcceac-0xccecc (32 bytes)
// Source: test.pwn

stock IsMotoSalonBiz()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000cceac: movs.i         
// 0x000ccead: or             
// 0x000cceae: load.i         
// 0x000cceaf: eq.pri         
// 0x000cceb0: grtr           
// 0x000cceb1: sign.alt       
// 0x000cceb2: jzer           0x6cccfd80
// 0x000cceb7: eq.alt         50407177
// 0x000ccebc: stor.alt       1150506880
// 0x000ccec1: push.pri       
// 0x000ccec2: push.c         0x-627bd8ff ""
// 0x000ccec7: op203          
// 0x000ccec8: op206          
// 0x000ccec9: shr            
// 0x000cceca: push.c         0x-2e735b7c ""
// CreateEditAccessoryTD_Accessory @ 0x7296c-0x75780 (11796 bytes)
// Source: system_accessory.pwn

stock CreateEditAccessoryTD_Accessory()
{
    // const.alt 759332872
    return 1;
    // stack 763112740
    // stack 894730248
    // branch jneq -> 0x-7fccf67f
    return 1;
    // branch jzer -> 0x8c9c780
    // branch jnz -> 0x54c9c780
    // branch jzer -> 0x20cac780
    // const.alt -607660416
    // branch jeq -> 0x28cbc780
    // stack -947899632
    // stack -931122428
    // load.pri 622265389
    // stack -2122568424
    // stack 201949456
    // branch jrel -> -2141132797
    // const.pri 159454978
    // const.alt -2030252416
    // branch jrel -> -2141132797
    // const.alt -607660416
    call_0x0xca8a981();
    // const.pri -184824192
    // branch jrel -> -696251356
}

// --- disasm (first 80) ---
// 0x0007296c: load.i         
// 0x0007296d: const.alt      759332872
// 0x00072972: load.s.alt     -2144918249
// 0x00072977: op236          
// 0x00072978: sym.debug      
// 0x00072979: ret            
// 0x0007297a: op0            
// 0x0007297b: push.c         0x5813981 ""
// 0x00072980: op232          
// 0x00072981: sshr           
// 0x00072982: push.c         0x257b8020 ""
// 0x00072987: stack          763112740
// 0x0007298c: op255          
// 0x0007298d: op0            
// 0x0007298e: eq.alt         855648009
// 0x00072993: eq.pri         
// 0x00072994: op199          
// 0x00072995: op199          
// 0x00072996: sshr           
// 0x00072997: eq.alt         -395411447
// 0x0007299c: div.c          
// 0x0007299d: load.s.pri     -2129897240
// 0x000729a2: file           
// 0x000729a3: eq.pri         
// 0x000729a4: jsgeq          
// 0x000729a5: eq.pri         
// 0x000729a6: op199          
// 0x000729a7: op203          
// 0x000729a8: sshr           
// 0x000729a9: eq.alt         1491609865
// 0x000729ae: push.c         0xa7b8004 ""
// 0x000729b3: stack          894730248
// 0x000729b8: eq.pri         
// 0x000729b9: op199          
// 0x000729ba: op200          
// 0x000729bb: jneq           0x-7fccf67f
// 0x000729c0: op199          
// 0x000729c1: op199          
// 0x000729c2: div.c          
// 0x000729c3: eq.alt         -696251383
// 0x000729c8: op199          
// 0x000729c9: op219          
// 0x000729ca: sysreq.pri     
// 0x000729cb: load.s.pri     2038454504
// 0x000729d0: eq.alt         153230201
// 0x000729d5: eq.pri         
// 0x000729d6: neg            
// 0x000729d7: eq.pri         
// 0x000729d8: mul.c          
// 0x000729d9: movs.i         
// 0x000729da: retn           
// 0x000729db: load.i         
// 0x000729dc: eq.pri         
// 0x000729dd: mod            
// 0x000729de: jzer           0x8c9c780
// 0x000729e3: eq.alt         -947899639
// 0x000729e8: op199          
// 0x000729e9: div.c          
// 0x000729ea: eq.alt         -696251383
// 0x000729ef: op199          
// 0x000729f0: op219          
// 0x000729f1: sysreq.pri     
// 0x000729f2: load.s.pri     2038454504
// 0x000729f7: eq.alt         153230201
// 0x000729fc: eq.pri         
// 0x000729fd: neg            
// 0x000729fe: eq.pri         
// 0x000729ff: mul.c          
// 0x00072a00: push.pri       
// 0x00072a01: div.c          
// 0x00072a02: load.i         
// 0x00072a03: jnz            0x54c9c780
// 0x00072a08: eq.alt         -947899639
// 0x00072a0d: op199          
// 0x00072a0e: div.c          
// 0x00072a0f: eq.alt         -696251383
// 0x00072a14: op199          
// 0x00072a15: op219          
// 0x00072a16: sysreq.pri     
// 0x00072a17: load.s.pri     2038454504
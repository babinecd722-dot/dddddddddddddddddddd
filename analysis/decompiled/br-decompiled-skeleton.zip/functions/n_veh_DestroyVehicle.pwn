// n_veh_DestroyVehicle @ 0xe928-0xe9e4 (188 bytes)
// Source: system_vehicle.pwn

stock n_veh_DestroyVehicle()
{
    // stack 654934284
    // stor.alt 2038434819
    // const.alt 136782857
    // stack 811171852
    // proc @0xe953
    // stack -2129188080
    // stack 654934288
    return 1;
    // const.alt -689187200
    // stack 654934288
    // load.pri -338264052
}

// --- disasm (first 80) ---
// 0x0000e928: lref.s.alt     1937800064
// 0x0000e92d: stack          654934284
// 0x0000e932: load.s.alt     -338264052
// 0x0000e937: op212          
// 0x0000e938: stor.alt       2038434819
// 0x0000e93d: lref.pri       -2146885093
// 0x0000e942: neg            
// 0x0000e943: eq.pri         
// 0x0000e944: mul.c          
// 0x0000e945: const.alt      136782857
// 0x0000e94a: eq.pri         
// 0x0000e94b: emit           
// 0x0000e94c: eq.pri         
// 0x0000e94d: fill           
// 0x0000e94e: stack          811171852
// 0x0000e953: proc           
// 0x0000e954: eq.alt         201949449
// 0x0000e959: eq.pri         
// 0x0000e95a: op214          
// 0x0000e95b: op235          
// 0x0000e95c: op214          
// 0x0000e95d: sysreq.pri     
// 0x0000e95e: load.s.pri     91848716
// 0x0000e963: idxaddr        
// 0x0000e964: move.alt       
// 0x0000e965: load.i         
// 0x0000e966: eq.pri         
// 0x0000e967: neg            
// 0x0000e968: push.pri       
// 0x0000e969: push.c         0x-45102980 ""
// 0x0000e96e: push.pri       
// 0x0000e96f: push.c         0x-2a11667c ""
// 0x0000e974: pop.alt        
// 0x0000e975: push.c         0x-4c396a7c ""
// 0x0000e97a: lidx.b         2071989287
// 0x0000e97f: eq.pri         
// 0x0000e980: eq.c.pri       
// 0x0000e981: stack          -2129188080
// 0x0000e986: load.i         
// 0x0000e987: push.c         0xc002700 ""
// 0x0000e98c: eq.pri         
// 0x0000e98d: op214          
// 0x0000e98e: op235          
// 0x0000e98f: op214          
// 0x0000e990: sysreq.pri     
// 0x0000e991: load.s.pri     91848716
// 0x0000e996: idxaddr        
// 0x0000e997: move.alt       
// 0x0000e998: load.i         
// 0x0000e999: eq.pri         
// 0x0000e99a: neg            
// 0x0000e99b: load.i         
// 0x0000e99c: push.pri       
// 0x0000e99d: push.c         0x-7f847ff4 ""
// 0x0000e9a2: eq.c.alt       
// 0x0000e9a3: stack          654934288
// 0x0000e9a8: dec.s.pri      
// 0x0000e9a9: push.c         
// 0x0000e9aa: line.debug     
// 0x0000e9ab: op197          
// 0x0000e9ac: sysreq.c       
// 0x0000e9ad: push.c         0x-19536b7c ""
// 0x0000e9b2: retn           
// 0x0000e9b3: const.alt      -689187200
// 0x0000e9b8: sysreq.pri     
// 0x0000e9b9: load.s.pri     91848716
// 0x0000e9be: idxaddr        
// 0x0000e9bf: move.alt       
// 0x0000e9c0: load.i         
// 0x0000e9c1: eq.pri         
// 0x0000e9c2: neg            
// 0x0000e9c3: load.i         
// 0x0000e9c4: push.pri       
// 0x0000e9c5: push.c         0x-7f847ff4 ""
// 0x0000e9ca: bounds         
// 0x0000e9cb: stack          654934288
// 0x0000e9d0: load.pri       -338264052
// 0x0000e9d5: op214          
// 0x0000e9d6: sysreq.pri     
// 0x0000e9d7: load.s.pri     91848716
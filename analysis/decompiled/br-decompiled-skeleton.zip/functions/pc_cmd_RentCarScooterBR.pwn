// pc_cmd_RentCarScooterBR @ 0x2eabe0-0x2eac0c (44 bytes)
// Source: test.pwn

stock pc_cmd_RentCarScooterBR()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x002eabe0: op0            
// 0x002eabe1: op0            
// 0x002eabe2: op0            
// 0x002eabe3: op0            
// 0x002eabe4: op0            
// 0x002eabe5: op0            
// 0x002eabe6: op0            
// 0x002eabe7: op0            
// 0x002eabe8: op0            
// 0x002eabe9: op0            
// 0x002eabea: op0            
// 0x002eabeb: op0            
// 0x002eabec: op0            
// 0x002eabed: op0            
// 0x002eabee: op0            
// 0x002eabef: op0            
// 0x002eabf0: op0            
// 0x002eabf1: op0            
// 0x002eabf2: op0            
// 0x002eabf3: op0            
// 0x002eabf4: op0            
// 0x002eabf5: op0            
// 0x002eabf6: op0            
// 0x002eabf7: op0            
// 0x002eabf8: op0            
// 0x002eabf9: op0            
// 0x002eabfa: op0            
// 0x002eabfb: op0            
// 0x002eabfc: op0            
// 0x002eabfd: op0            
// 0x002eabfe: op0            
// 0x002eabff: op0            
// 0x002eac00: op0            
// 0x002eac01: op0            
// 0x002eac02: op0            
// 0x002eac03: op0            
// 0x002eac04: op0            
// 0x002eac05: op0            
// 0x002eac06: op0            
// 0x002eac07: op0            
// 0x002eac08: op0            
// 0x002eac09: op0            
// 0x002eac0a: op0            
// 0x002eac0b: op0            
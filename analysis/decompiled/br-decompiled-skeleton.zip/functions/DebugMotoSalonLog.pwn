// DebugMotoSalonLog @ 0xcf304-0xcf650 (844 bytes)
// Source: test.pwn

stock DebugMotoSalonLog()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000cf304: mul.c          
// 0x000cf305: eq.pri         
// 0x000cf306: div.c          
// 0x000cf307: load.i         
// 0x000cf308: push.pri       
// 0x000cf309: const.alt      -1465852544
// 0x000cf30e: eq.c.alt       
// 0x000cf30f: load.s.pri     108626044
// 0x000cf314: idxaddr        
// 0x000cf315: move.alt       
// 0x000cf316: load.i         
// 0x000cf317: eq.pri         
// 0x000cf318: neg            
// 0x000cf319: eq.pri         
// 0x000cf31a: mul.c          
// 0x000cf31b: eq.pri         
// 0x000cf31c: mod            
// 0x000cf31d: load.i         
// 0x000cf31e: push.pri       
// 0x000cf31f: const.alt      -1465852544
// 0x000cf324: eq.c.alt       
// 0x000cf325: load.s.pri     108626044
// 0x000cf32a: idxaddr        
// 0x000cf32b: move.alt       
// 0x000cf32c: load.i         
// 0x000cf32d: eq.pri         
// 0x000cf32e: neg            
// 0x000cf32f: eq.pri         
// 0x000cf330: mul.c          
// 0x000cf331: eq.pri         
// 0x000cf332: add            
// 0x000cf333: load.i         
// 0x000cf334: push.pri       
// 0x000cf335: push.s         824190732
// 0x000cf33a: eq.alt         -2129593212
// 0x000cf33f: load.i         
// 0x000cf340: const.alt      -607660416
// 0x000cf345: sysreq.pri     
// 0x000cf346: load.s.pri     -2122743796
// 0x000cf34b: sysreq.c       
// 0x000cf34c: idxaddr        
// 0x000cf34d: move.alt       
// 0x000cf34e: load.i         
// 0x000cf34f: eq.pri         
// 0x000cf350: neg            
// 0x000cf351: eq.pri         
// 0x000cf352: mul.c          
// 0x000cf353: movs.i         
// 0x000cf354: mul            
// 0x000cf355: move.alt       
// 0x000cf356: load.s.pri     69998352
// 0x000cf35b: eq.pri         
// 0x000cf35c: mod.c          
// 0x000cf35d: retn           
// 0x000cf35e: proc           
// 0x000cf35f: eq.alt         738820361
// 0x000cf364: zero.pri       
// 0x000cf365: const.alt      -607660416
// 0x000cf36a: sysreq.pri     
// 0x000cf36b: load.s.pri     -2122743796
// 0x000cf370: sysreq.c       
// 0x000cf371: idxaddr        
// 0x000cf372: move.alt       
// 0x000cf373: load.i         
// 0x000cf374: eq.pri         
// 0x000cf375: neg            
// 0x000cf376: eq.pri         
// 0x000cf377: mul.c          
// 0x000cf378: movs.i         
// 0x000cf379: mul            
// 0x000cf37a: load.i         
// 0x000cf37b: stor.s.pri     50954620
// 0x000cf380: zero.pri       
// 0x000cf381: const.alt      -8374401
// 0x000cf386: push.pri       
// 0x000cf387: sysreq.pri     
// 0x000cf388: eq.alt         209464329
// 0x000cf38d: eq.pri         
// 0x000cf38e: op220          
// 0x000cf38f: op232          
// ShowTabMy @ 0xa2908-0xa3fc4 (5820 bytes)
// Source: system_auction.pwn

stock ShowTabMy()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000a2908: jump           278389888
// 0x000a290d: eq.alt         -562033911
// 0x000a2912: op251          
// 0x000a2913: op211          
// 0x000a2914: idxaddr.b      -696251356
// 0x000a2919: op199          
// 0x000a291a: op219          
// 0x000a291b: sysreq.pri     
// 0x000a291c: load.s.pri     -2122743796
// 0x000a2921: sysreq.c       
// 0x000a2922: idxaddr        
// 0x000a2923: move.alt       
// 0x000a2924: load.i         
// 0x000a2925: eq.pri         
// 0x000a2926: neg            
// 0x000a2927: eq.pri         
// 0x000a2928: mul.c          
// 0x000a2929: inc.i          
// 0x000a292a: load.s.alt     175734793
// 0x000a292f: pop.alt        
// 0x000a2930: idxaddr        
// 0x000a2931: move.alt       
// 0x000a2932: load.i         
// 0x000a2933: eq.pri         
// 0x000a2934: neg            
// 0x000a2935: push.pri       
// 0x000a2936: push.c         0x-c431380 ""
// 0x000a293b: eq.c.alt       
// 0x000a293c: push.c         0x5810081 ""
// 0x000a2941: op251          
// 0x000a2942: cmps           
// 0x000a2943: push.c         0x257b8010 ""
// 0x000a2948: stack          -2130083564
// 0x000a294d: lref.pri       -64523013
// 0x000a2952: eq.alt         655108479
// 0x000a2957: const.alt      1635810176
// 0x000a295c: stack          185172240
// 0x000a2961: eq.pri         
// 0x000a2962: op222          
// 0x000a2963: op251          
// 0x000a2964: op211          
// 0x000a2965: idxaddr.b      -696251356
// 0x000a296a: op199          
// 0x000a296b: op219          
// 0x000a296c: sysreq.pri     
// 0x000a296d: load.s.pri     -2122743796
// 0x000a2972: sysreq.c       
// 0x000a2973: idxaddr        
// 0x000a2974: move.alt       
// 0x000a2975: load.i         
// 0x000a2976: eq.pri         
// 0x000a2977: neg            
// 0x000a2978: eq.pri         
// 0x000a2979: mul.c          
// 0x000a297a: inc.i          
// 0x000a297b: load.s.alt     175734793
// 0x000a2980: pop.alt        
// 0x000a2981: idxaddr        
// 0x000a2982: move.alt       
// 0x000a2983: load.i         
// 0x000a2984: eq.pri         
// 0x000a2985: neg            
// 0x000a2986: push.pri       
// 0x000a2987: eq.alt         -2146694139
// 0x000a298c: op214          
// 0x000a298d: op199          
// 0x000a298e: op219          
// 0x000a298f: sysreq.pri     
// 0x000a2990: load.s.pri     -2122743796
// 0x000a2995: sysreq.c       
// 0x000a2996: idxaddr        
// 0x000a2997: move.alt       
// 0x000a2998: load.i         
// 0x000a2999: eq.pri         
// 0x000a299a: neg            
// 0x000a299b: eq.pri         
// 0x000a299c: mul.c          
// 0x000a299d: cmps.i         
// 0x000a299e: mod            
// 0x000a299f: push.pri       
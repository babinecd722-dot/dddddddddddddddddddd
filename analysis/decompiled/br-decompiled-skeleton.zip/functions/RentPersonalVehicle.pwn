// RentPersonalVehicle @ 0xbb844-0xbbc7c (1080 bytes)
// Source: test.pwn

stock RentPersonalVehicle()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000bb844: div.c          
// 0x000bb845: move.alt       
// 0x000bb846: eq.pri         
// 0x000bb847: mod.c          
// 0x000bb848: stor.i         
// 0x000bb849: eq.alt         -595588087
// 0x000bb84e: op232          
// 0x000bb84f: op231          
// 0x000bb850: sysreq.pri     
// 0x000bb851: load.s.pri     -2022080388
// 0x000bb856: load.s.pri     -2146885093
// 0x000bb85b: neg            
// 0x000bb85c: eq.pri         
// 0x000bb85d: mul.c          
// 0x000bb85e: eq.pri         
// 0x000bb85f: leq            
// 0x000bb860: move.alt       
// 0x000bb861: eq.pri         
// 0x000bb862: mod.c          
// 0x000bb863: stor.i         
// 0x000bb864: eq.alt         662448393
// 0x000bb869: load.s.alt     -1275166671
// 0x000bb86e: jrel           2133264769
// 0x000bb873: push.s         822617980
// 0x000bb878: eq.pri         
// 0x000bb879: op254          
// 0x000bb87a: op188          
// 0x000bb87b: leq            
// 0x000bb87c: eq.alt         696198921
// 0x000bb881: zero.pri       
// 0x000bb882: push.c         0x-17fcef8 ""
// 0x000bb887: op194          
// 0x000bb888: shl.pri        
// 0x000bb889: eq.alt         553454857
// 0x000bb88e: push.pri       
// 0x000bb88f: const.alt      -404169600
// 0x000bb894: sysreq.pri     
// 0x000bb895: load.s.pri     -2022080388
// 0x000bb89a: load.s.pri     -2146885093
// 0x000bb89f: neg            
// 0x000bb8a0: eq.pri         
// 0x000bb8a1: mul.c          
// 0x000bb8a2: eq.pri         
// 0x000bb8a3: sleq           
// 0x000bb8a4: load.i         
// 0x000bb8a5: pop.alt        
// 0x000bb8a6: stor.i         
// 0x000bb8a7: eq.alt         553454857
// 0x000bb8ac: load.i         
// 0x000bb8ad: const.alt      -209700993
// 0x000bb8b2: push.r         
// 0x000bb8b3: eq.c.alt       
// 0x000bb8b4: eq.alt         553454857
// 0x000bb8b9: eq.pri         
// 0x000bb8ba: mul.c          
// 0x000bb8bb: load.s.alt     -595588316
// 0x000bb8c0: op232          
// 0x000bb8c1: op224          
// 0x000bb8c2: leq            
// 0x000bb8c3: push.pri       
// 0x000bb8c4: addr.pri       -2146885379
// 0x000bb8c9: sysreq.c       
// 0x000bb8ca: eq.alt         152775495
// 0x000bb8cf: pop.alt        
// 0x000bb8d0: stor.i         
// 0x000bb8d1: eq.alt         -595588343
// 0x000bb8d6: op232          
// 0x000bb8d7: op224          
// 0x000bb8d8: leq            
// 0x000bb8d9: push.pri       
// 0x000bb8da: addr.pri       -2146885379
// 0x000bb8df: sysreq.c       
// 0x000bb8e0: eq.alt         605760327
// 0x000bb8e5: load.i         
// 0x000bb8e6: eq.alt         711950339
// 0x000bb8eb: eq.alt         -595588343
// 0x000bb8f0: op231          
// 0x000bb8f1: op190          
// 0x000bb8f2: push           553454884
// 0x000bb8f7: load.i         
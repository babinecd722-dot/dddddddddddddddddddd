// TimerSecondUpdateBJ @ 0x27694-0x39d60 (75468 bytes)
// Source: system_blackjack_full.pwn

stock TimerSecondUpdateBJ()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00027694: sign.alt       
// 0x00027695: push.s         -2146687216
// 0x0002769a: emit           
// 0x0002769b: eq.pri         
// 0x0002769c: xor            
// 0x0002769d: stack          688488720
// 0x000276a2: const.alt      -1724840921
// 0x000276a7: op215          
// 0x000276a8: eq.c.alt       
// 0x000276a9: eq.alt         655370505
// 0x000276ae: load.s.alt     1893177649
// 0x000276b3: eq.alt         738265865
// 0x000276b8: load.s.alt     738820400
// 0x000276bd: op251          
// 0x000276be: jsgeq          
// 0x000276bf: eq.pri         
// 0x000276c0: mod.c          
// 0x000276c1: addr.alt       2004892923
// 0x000276c6: dec.s.pri      
// 0x000276c7: jsgeq          
// 0x000276c8: eq.alt         -562033655
// 0x000276cd: op243          
// 0x000276ce: eq.alt         -2146696380
// 0x000276d3: sysreq.c       
// 0x000276d4: eq.alt         153230201
// 0x000276d9: eq.pri         
// 0x000276da: neg            
// 0x000276db: eq.pri         
// 0x000276dc: mul.c          
// 0x000276dd: const.alt      -979815159
// 0x000276e2: leq            
// 0x000276e3: eq.alt         -696251383
// 0x000276e8: op199          
// 0x000276e9: op219          
// 0x000276ea: sysreq.pri     
// 0x000276eb: load.s.pri     -2122743796
// 0x000276f0: sysreq.c       
// 0x000276f1: idxaddr        
// 0x000276f2: move.alt       
// 0x000276f3: load.i         
// 0x000276f4: eq.pri         
// 0x000276f5: neg            
// 0x000276f6: eq.pri         
// 0x000276f7: mul.c          
// 0x000276f8: cmps.i         
// 0x000276f9: mod            
// 0x000276fa: push.pri       
// 0x000276fb: push.c         0x-250c2180 ""
// 0x00027700: stor.alt       -2129624793
// 0x00027705: lref.pri       271006971
// 0x0002770a: eq.pri         
// 0x0002770b: emit           
// 0x0002770c: push.alt       
// 0x0002770d: stack          -963038444
// 0x00027712: add            
// 0x00027713: eq.alt         -696251383
// 0x00027718: op199          
// 0x00027719: op219          
// 0x0002771a: sysreq.pri     
// 0x0002771b: load.s.pri     -2122743792
// 0x00027720: sysreq.c       
// 0x00027721: idxaddr        
// 0x00027722: move.alt       
// 0x00027723: load.i         
// 0x00027724: eq.pri         
// 0x00027725: neg            
// 0x00027726: eq.pri         
// 0x00027727: mul.c          
// 0x00027728: cmps.i         
// 0x00027729: mod            
// 0x0002772a: push.pri       
// 0x0002772b: push.c         0x-250c2180 ""
// 0x00027730: or             
// 0x00027731: push.c         0x5811081 ""
// 0x00027736: op251          
// 0x00027737: jgeq           0x7b801027
// 0x0002773c: push.alt       
// 0x0002773d: stack          -2130083564
// 0x00027742: lref.pri       -1926808325
// 0x00027747: op236          
// CarMarketShowNextCar @ 0xcfb5c-0xd0070 (1300 bytes)
// Source: test.pwn

stock CarMarketShowNextCar()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000cfb5c: eq.pri         
// 0x000cfb5d: and            
// 0x000cfb5e: stack          688488732
// 0x000cfb63: const.alt      -2127494105
// 0x000cfb68: push.pri       
// 0x000cfb69: op245          
// 0x000cfb6a: sref.alt       604067712
// 0x000cfb6f: const.alt      -607660416
// 0x000cfb74: sysreq.pri     
// 0x000cfb75: load.s.pri     -2122743796
// 0x000cfb7a: sysreq.c       
// 0x000cfb7b: idxaddr        
// 0x000cfb7c: move.alt       
// 0x000cfb7d: load.i         
// 0x000cfb7e: eq.pri         
// 0x000cfb7f: neg            
// 0x000cfb80: eq.pri         
// 0x000cfb81: mul.c          
// 0x000cfb82: bounds.p       
// 0x000cfb83: strb.i         1082141449
// 0x000cfb88: eq.pri         
// 0x000cfb89: op255          
// 0x000cfb8a: op169          
// 0x000cfb8b: cmps           
// 0x000cfb8c: eq.alt         -327145719
// 0x000cfb91: op205          
// 0x000cfb92: op214          
// 0x000cfb93: sshr           
// 0x000cfb94: push.c         0x-18637d ""
// 0x000cfb99: sign.alt       
// 0x000cfb9a: push.s         -2146687220
// 0x000cfb9f: emit           
// 0x000cfba0: eq.pri         
// 0x000cfba1: xor            
// 0x000cfba2: stack          185172240
// 0x000cfba7: sign.alt       
// 0x000cfba8: stack          159461384
// 0x000cfbad: const.alt      -607660416
// 0x000cfbb2: sysreq.pri     
// 0x000cfbb3: load.s.pri     -2122743796
// 0x000cfbb8: sysreq.c       
// 0x000cfbb9: idxaddr        
// 0x000cfbba: move.alt       
// 0x000cfbbb: load.i         
// 0x000cfbbc: eq.pri         
// 0x000cfbbd: neg            
// 0x000cfbbe: eq.pri         
// 0x000cfbbf: mul.c          
// 0x000cfbc0: cmps.i         
// 0x000cfbc1: const.alt      -8188919
// 0x000cfbc6: sign.alt       
// 0x000cfbc7: jeq            0x8abff80
// 0x000cfbcc: eq.alt         -327145719
// 0x000cfbd1: op205          
// 0x000cfbd2: op217          
// 0x000cfbd3: jsgeq          
// 0x000cfbd4: push.c         0x-4c193377 ""
// 0x000cfbd9: sign.alt       
// 0x000cfbda: push.s         -2146687220
// 0x000cfbdf: emit           
// 0x000cfbe0: eq.pri         
// 0x000cfbe1: xor            
// 0x000cfbe2: stack          185172240
// 0x000cfbe7: sign.alt       
// 0x000cfbe8: stack          159461384
// 0x000cfbed: push.c         0x-7effd900 ""
// 0x000cfbf2: load.i         
// 0x000cfbf3: load.s.pri     1753680916
// 0x000cfbf8: eq.pri         
// 0x000cfbf9: jsgeq          
// 0x000cfbfa: eq.pri         
// 0x000cfbfb: op255          
// 0x000cfbfc: op173          
// 0x000cfbfd: lref.s.alt     -2146694783
// 0x000cfc02: op207          
// 0x000cfc03: push.s         
// 0x000cfc04: op252          
// 0x000cfc05: jgeq           0x79801003
// 0x000cfc0a: load.s.alt     -2146885093
// 0x000cfc0f: neg            
// blackjack_OnPlayerClickTextDraw @ 0x69bb4-0x6e448 (18580 bytes)
// Source: system_accessory.pwn

stock blackjack_OnPlayerClickTextDraw()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00069bb4: const.pri      805841921
// 0x00069bb9: eq.alt         209464329
// 0x00069bbe: eq.pri         
// 0x00069bbf: op214          
// 0x00069bc0: op199          
// 0x00069bc1: op219          
// 0x00069bc2: sysreq.pri     
// 0x00069bc3: load.s.pri     -2122743796
// 0x00069bc8: sysreq.c       
// 0x00069bc9: idxaddr        
// 0x00069bca: move.alt       
// 0x00069bcb: load.i         
// 0x00069bcc: eq.pri         
// 0x00069bcd: neg            
// 0x00069bce: eq.pri         
// 0x00069bcf: mul.c          
// 0x00069bd0: movs.i         
// 0x00069bd1: div.c          
// 0x00069bd2: load.i         
// 0x00069bd3: stor.s.pri     50954612
// 0x00069bd8: cmps           
// 0x00069bd9: eq.pri         
// 0x00069bda: grtr           
// 0x00069bdb: sign.alt       
// 0x00069bdc: jzer           0x24bfc280
// 0x00069be1: eq.alt         738265865
// 0x00069be6: const.alt      738820400
// 0x00069beb: zero.pri       
// 0x00069bec: push.s         822355828
// 0x00069bf1: op179          
// 0x00069bf2: call.pri       
// 0x00069bf3: div.c          
// 0x00069bf4: stor.s.pri     201949552
// 0x00069bf9: eq.pri         
// 0x00069bfa: op221          
// 0x00069bfb: swap.alt       
// 0x00069bfc: op182          
// 0x00069bfd: mod            
// 0x00069bfe: load.s.pri     -2122743692
// 0x00069c03: shl.alt        
// 0x00069c04: idxaddr        
// 0x00069c05: move.alt       
// 0x00069c06: load.i         
// 0x00069c07: eq.pri         
// 0x00069c08: neg            
// 0x00069c09: eq.pri         
// 0x00069c0a: mul.c          
// 0x00069c0b: eq.alt         118229264
// 0x00069c10: jeq            0x30c0c280
// 0x00069c15: eq.alt         738265865
// 0x00069c1a: stor.alt       201949488
// 0x00069c1f: eq.pri         
// 0x00069c20: op207          
// 0x00069c21: push.s         
// 0x00069c22: heap           
// 0x00069c23: add            
// 0x00069c24: load.s.pri     -2122743796
// 0x00069c29: sysreq.c       
// 0x00069c2a: lidx           
// 0x00069c2b: push.pri       
// 0x00069c2c: push.s         655108464
// 0x00069c31: const.alt      -1627422671
// 0x00069c36: cmps           
// 0x00069c37: eq.alt         738265865
// 0x00069c3c: stor.alt       -360697040
// 0x00069c41: op245          
// 0x00069c42: mod            
// 0x00069c43: eq.alt         -2146172151
// 0x00069c48: mod            
// 0x00069c49: jzer           0x44c1c280
// 0x00069c4e: eq.alt         738265865
// 0x00069c53: lref.s.alt     738820400
// 0x00069c58: zero.pri       
// 0x00069c59: const.alt      -121774720
// 0x00069c5e: push           2038434819
// 0x00069c63: eq.alt         153230201
// 0x00069c68: eq.pri         
// 0x00069c69: neg            
// 0x00069c6a: push.pri       
// 0x00069c6b: load.s.pri     -2022080488
// GivePromoCar @ 0x4aa24-0x4ad0c (744 bytes)
// Source: system_new_promo.pwn

stock GivePromoCar()
{
    // stor.alt 2071991335
    // stack 654934296
    // load.pri -422803161
    // const.alt -2071101135
    // branch jrel -> 481275699
    // branch jneq -> 0x-7ec37ad9
    // stack 654934308
    // load.pri -422803161
    // const.alt -2071101135
    // branch jrel -> 268634497
    // const.alt 931135363
    // stack -2146694783
    // branch jzer -> 0x2928b0af
    // stor.alt -2127494105
    // const.pri -1330695423
    // stack -1355458176
    // const.alt -607660416
    // stor.alt -2127494105
    // const.alt -2144918486
    // stack 16723228
    // const.alt -1903328975
    // const.alt -1330215385
    // stack 654934288
    // stack 185172240
    // const.alt -1011927799
    // stack -2146694783
    // const.pri 728268810
    // branch jzer -> 0x-7ed33c51
    // stack -830469252
    // const.pri -2030252416
    // const.alt 151279488
    // const.alt 203886633
    // const.pri -1213254911
    // branch jzer -> 0x-7edb3c51
    // stack 240746616
    // load.pri 159455019
    // load.pri 159455019
    // const.pri -2030252416
    // const.alt 151541632
    // branch jneq -> 0xd4cbaaf
    // const.pri -2030252416
}

// --- disasm (first 80) ---
// 0x0004aa24: sysreq.c       
// 0x0004aa25: idxaddr        
// 0x0004aa26: move.alt       
// 0x0004aa27: load.i         
// 0x0004aa28: eq.pri         
// 0x0004aa29: neg            
// 0x0004aa2a: eq.pri         
// 0x0004aa2b: mul.c          
// 0x0004aa2c: cmps.i         
// 0x0004aa2d: mod            
// 0x0004aa2e: push.pri       
// 0x0004aa2f: push.c         0x-30442080 ""
// 0x0004aa34: sshr           
// 0x0004aa35: push.c         0x5813c85 ""
// 0x0004aa3a: op234          
// 0x0004aa3b: stor.alt       2071991335
// 0x0004aa40: push.alt       
// 0x0004aa41: stack          654934296
// 0x0004aa46: load.pri       -422803161
// 0x0004aa4b: op179          
// 0x0004aa4c: sign.alt       
// 0x0004aa4d: eq.alt         655419909
// 0x0004aa52: const.alt      -2071101135
// 0x0004aa57: jrel           481275699
// 0x0004aa5c: eq.alt         -562033655
// 0x0004aa61: op251          
// 0x0004aa62: push.alt       
// 0x0004aa63: xor            
// 0x0004aa64: load.s.pri     779714580
// 0x0004aa69: idxaddr        
// 0x0004aa6a: move.alt       
// 0x0004aa6b: load.i         
// 0x0004aa6c: eq.pri         
// 0x0004aa6d: neg            
// 0x0004aa6e: push.pri       
// 0x0004aa6f: eq.alt         -2146694139
// 0x0004aa74: op214          
// 0x0004aa75: op199          
// 0x0004aa76: op219          
// 0x0004aa77: sysreq.pri     
// 0x0004aa78: load.s.pri     -2122743796
// 0x0004aa7d: sysreq.c       
// 0x0004aa7e: idxaddr        
// 0x0004aa7f: move.alt       
// 0x0004aa80: load.i         
// 0x0004aa81: eq.pri         
// 0x0004aa82: neg            
// 0x0004aa83: eq.pri         
// 0x0004aa84: mul.c          
// 0x0004aa85: cmps.i         
// 0x0004aa86: mod            
// 0x0004aa87: push.pri       
// 0x0004aa88: eq.alt         -2146693115
// 0x0004aa8d: op214          
// 0x0004aa8e: op199          
// 0x0004aa8f: op219          
// 0x0004aa90: sysreq.pri     
// 0x0004aa91: load.s.pri     -2122743792
// 0x0004aa96: sysreq.c       
// 0x0004aa97: idxaddr        
// 0x0004aa98: move.alt       
// 0x0004aa99: load.i         
// 0x0004aa9a: eq.pri         
// 0x0004aa9b: neg            
// 0x0004aa9c: eq.pri         
// 0x0004aa9d: mul.c          
// 0x0004aa9e: cmps.i         
// 0x0004aa9f: mod            
// 0x0004aaa0: push.pri       
// 0x0004aaa1: push.c         0x-2f442080 ""
// 0x0004aaa6: jneq           0x-7ec37ad9
// 0x0004aaab: lref.pri       539431146
// 0x0004aab0: eq.pri         
// 0x0004aab1: emit           
// 0x0004aab2: push.alt       
// 0x0004aab3: stack          654934308
// 0x0004aab8: load.pri       -422803161
// 0x0004aabd: op179          
// 0x0004aabe: sign.alt       
// 0x0004aabf: eq.alt         655419909
// ReloadTable @ 0x27574-0x27694 (288 bytes)
// Source: system_blackjack_full.pwn

stock ReloadTable()
{
    return 1;
    // stack -1097256188
    return 1;
    // const.alt 1635810176
    // stack 185172240
    // load.pri 159460912
    return 1;
    // branch jnz -> 0x-7fcf4067
    // branch jump -> 188268441
    // load.pri 1891670325
    // const.alt 1635810176
    // stack 654934288
    // stack 688488720
    // const.alt -1724840921
    // stor.alt -2122575607
    // const.alt -607660416
    // branch jneq -> 0x3d7c0409
    return 1;
    // const.alt -607660416
    // branch jneq -> 0x3d7c0409
    return 1;
    // branch jump -> 190366361
    // load.pri 415537461
    // stor.alt 204046119
    // stack 654934288
}

// --- disasm (first 80) ---
// 0x00027574: load.i         
// 0x00027575: push.s         822355724
// 0x0002757a: retn           
// 0x0002757b: op215          
// 0x0002757c: eq.c.alt       
// 0x0002757d: eq.alt         662448393
// 0x00027582: load.s.alt     1893177649
// 0x00027587: stack          -1097256188
// 0x0002758c: retn           
// 0x0002758d: eq.alt         -562026743
// 0x00027592: op243          
// 0x00027593: op210          
// 0x00027594: push.pri       
// 0x00027595: push.c         0x270c297f ""
// 0x0002759a: const.alt      1635810176
// 0x0002759f: stack          185172240
// 0x000275a4: load.pri       159460912
// 0x000275a9: eq.alt         655108361
// 0x000275ae: load.s.alt     738884480
// 0x000275b3: lref.s.alt     -1724492672
// 0x000275b8: op191          
// 0x000275b9: retn           
// 0x000275ba: push.s         -2147211504
// 0x000275bf: emit           
// 0x000275c0: lodb.i         1417676844
// 0x000275c5: jnz            0x-7fcf4067
// 0x000275ca: mod.c          
// 0x000275cb: jump           188268441
// 0x000275d0: load.pri       1891670325
// 0x000275d5: eq.alt         -562026743
// 0x000275da: op243          
// 0x000275db: op211          
// 0x000275dc: leq            
// 0x000275dd: push.c         0x270c297f ""
// 0x000275e2: const.alt      1635810176
// 0x000275e7: stack          654934288
// 0x000275ec: eq.pri         
// 0x000275ed: op222          
// 0x000275ee: op243          
// 0x000275ef: op213          
// 0x000275f0: jgeq           0x10297f27
// 0x000275f5: push.c         0x-7f847ff4 ""
// 0x000275fa: xor            
// 0x000275fb: stack          688488720
// 0x00027600: const.alt      -1724840921
// 0x00027605: op215          
// 0x00027606: eq.c.alt       
// 0x00027607: eq.alt         655370505
// 0x0002760c: load.s.alt     1893177649
// 0x00027611: eq.alt         805374729
// 0x00027616: eq.alt         209464329
// 0x0002761b: eq.pri         
// 0x0002761c: op222          
// 0x0002761d: op243          
// 0x0002761e: eq.alt         -2146696380
// 0x00027623: sysreq.c       
// 0x00027624: eq.alt         153230201
// 0x00027629: eq.pri         
// 0x0002762a: neg            
// 0x0002762b: eq.pri         
// 0x0002762c: mul.c          
// 0x0002762d: stor.alt       -2122575607
// 0x00027632: load.i         
// 0x00027633: const.alt      -607660416
// 0x00027638: sysreq.pri     
// 0x00027639: load.s.pri     -2122743796
// 0x0002763e: sysreq.c       
// 0x0002763f: idxaddr        
// 0x00027640: move.alt       
// 0x00027641: load.i         
// 0x00027642: eq.pri         
// 0x00027643: neg            
// 0x00027644: eq.pri         
// 0x00027645: mul.c          
// 0x00027646: dec.s.pri      
// 0x00027647: jneq           0x3d7c0409
// 0x0002764c: retn           
// 0x0002764d: op194          
// 0x0002764e: add            
// 0x0002764f: const.alt      -607660416
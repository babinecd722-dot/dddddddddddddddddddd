// auc_OnGameModeInit @ 0xb0304-0xb7bec (30952 bytes)
// Source: test.pwn

stock auc_OnGameModeInit()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000b0304: op204          
// 0x000b0305: call           
// 0x000b0306: op234          
// 0x000b0307: push.pri       
// 0x000b0308: load.s.pri     -2122743796
// 0x000b030d: sysreq.c       
// 0x000b030e: idxaddr        
// 0x000b030f: move.alt       
// 0x000b0310: load.i         
// 0x000b0311: eq.pri         
// 0x000b0312: neg            
// 0x000b0313: load.i         
// 0x000b0314: push.pri       
// 0x000b0315: push.s         -2146949364
// 0x000b031a: emit           
// 0x000b031b: eq.pri         
// 0x000b031c: sgrtr          
// 0x000b031d: stack          654934284
// 0x000b0322: load.pri       136776745
// 0x000b0327: eq.pri         
// 0x000b0328: emit           
// 0x000b0329: eq.pri         
// 0x000b032a: sless          
// 0x000b032b: stack          654934284
// 0x000b0330: eq.pri         
// 0x000b0331: op236          
// 0x000b0332: op196          
// 0x000b0333: sym.debug      
// 0x000b0334: retn           
// 0x000b0335: push.c         0x270c297f ""
// 0x000b033a: const.alt      1635810176
// 0x000b033f: stack          1954950160
// 0x000b0344: eq.alt         -2122373367
// 0x000b0349: load.i         
// 0x000b034a: push.c         0x-137fccfd ""
// 0x000b034f: jump           
// 0x000b0350: zero.pri       
// 0x000b0351: eq.alt         1886289929
// 0x000b0356: load.s.pri     -2146825104
// 0x000b035b: jsgeq          
// 0x000b035c: eq.pri         
// 0x000b035d: op236          
// 0x000b035e: switch         
// 0x000b035f: cmps           
// 0x000b0360: eq.alt         605029129
// 0x000b0365: const.alt      -375731072
// 0x000b036a: jgeq           0x79807003
// 0x000b036f: lidx           
// 0x000b0370: lidx           
// 0x000b0371: pop.alt        
// 0x000b0372: jneq           0x6c9dec80
// 0x000b0377: eq.alt         292553481
// 0x000b037c: cmps           
// 0x000b037d: eq.alt         -327142647
// 0x000b0382: switch         
// 0x000b0383: cmps           
// 0x000b0384: jump           1889332352
// 0x000b0389: stack          50954500
// 0x000b038e: cmps           
// 0x000b038f: const.alt      -327141505
// 0x000b0394: op170          
// 0x000b0395: stor.alt       2083260801
// 0x000b039a: push.c         0x-5a3b1380 ""
// 0x000b039f: leq            
// 0x000b03a0: push.s         -2146949364
// 0x000b03a5: emit           
// 0x000b03a6: jsleq          0x70110c2c
// 0x000b03ab: eq.alt         208667401
// 0x000b03b0: load.pri       -1611890627
// 0x000b03b5: sref.alt       118255619
// 0x000b03ba: jsgrtr         0x149fec80
// 0x000b03bf: eq.pri         
// 0x000b03c0: mod.c          
// 0x000b03c1: jump           480242816
// 0x000b03c6: const.pri      -327142143
// 0x000b03cb: swap.pri       
// 0x000b03cc: jneq           0x10b0981
// 0x000b03d1: stor.s.pri     738820464
// 0x000b03d6: zero.pri       
// 0x000b03d7: const.pri      -2139880445
// CarShare @ 0x5d068-0x5d1c4 (348 bytes)
// Source: system_carshare_welsi.pwn

stock CarShare()
{
    return 1;
    // stack 
    // stack 1501566207
    // const.pri -476713856
    // branch jneq -> 0x-7fef00f2
    // stack 654934292
    // stack 
    // stack 
    call_0x0x-7e8f087e();
    // const.pri 1888496641
    return 1;
    // branch jrel -> 136776745
    // const.pri -424004863
    // branch jzer -> 0x-7e8f1346
    // stack 738820380
    // stack 2029719824
    // stack 1501569544
    // stack 2083260801
}

// --- disasm (first 80) ---
// 0x0005d068: retn           
// 0x0005d069: eq.alt         655894793
// 0x0005d06e: eq.pri         
// 0x0005d06f: op236          
// 0x0005d070: stack          
// 0x0005d071: op226          
// 0x0005d072: sysreq.pri     
// 0x0005d073: push.s         -2146687220
// 0x0005d078: emit           
// 0x0005d079: jsgrtr         0x981102c
// 0x0005d07e: stack          1501566207
// 0x0005d083: addr.alt       2004881663
// 0x0005d088: eq.pri         
// 0x0005d089: sleq           
// 0x0005d08a: const.pri      -476713856
// 0x0005d08f: jneq           0x-7fef00f2
// 0x0005d094: fill           
// 0x0005d095: eq.pri         
// 0x0005d096: leq            
// 0x0005d097: eq.alt         15739913
// 0x0005d09c: eq.pri         
// 0x0005d09d: mod.c          
// 0x0005d09e: addr.alt       2004881647
// 0x0005d0a3: push.c         
// 0x0005d0a4: op0            
// 0x0005d0a5: eq.alt         285150729
// 0x0005d0aa: load.s.pri     91848728
// 0x0005d0af: idxaddr        
// 0x0005d0b0: move.alt       
// 0x0005d0b1: load.i         
// 0x0005d0b2: eq.pri         
// 0x0005d0b3: neg            
// 0x0005d0b4: push.pri       
// 0x0005d0b5: push.c         0x-1b6a1380 ""
// 0x0005d0ba: sctrl          -2130672601
// 0x0005d0bf: lref.pri       270995695
// 0x0005d0c4: eq.pri         
// 0x0005d0c5: emit           
// 0x0005d0c6: push.alt       
// 0x0005d0c7: stack          654934292
// 0x0005d0cc: eq.pri         
// 0x0005d0cd: op236          
// 0x0005d0ce: stack          
// 0x0005d0cf: op234          
// 0x0005d0d0: idxaddr.b      -1779662809
// 0x0005d0d5: op233          
// 0x0005d0d6: zero.pri       
// 0x0005d0d7: eq.alt         655421189
// 0x0005d0dc: eq.pri         
// 0x0005d0dd: op236          
// 0x0005d0de: stack          
// 0x0005d0df: op233          
// 0x0005d0e0: sctrl          -2144927193
// 0x0005d0e5: op206          
// 0x0005d0e6: sref.alt       472321065
// 0x0005d0eb: call           0x-7e8f087e
// 0x0005d0f0: load.i         
// 0x0005d0f1: const.pri      1888496641
// 0x0005d0f6: retn           
// 0x0005d0f7: eq.alt         -2146434295
// 0x0005d0fc: grtr           
// 0x0005d0fd: fill.i         
// 0x0005d0fe: jless          0x70e6ba35
// 0x0005d103: push.c         0x-156a1380 ""
// 0x0005d108: jrel           136776745
// 0x0005d10d: eq.pri         
// 0x0005d10e: emit           
// 0x0005d10f: jsleq          0x-45caf3d4
// 0x0005d114: op230          
// 0x0005d115: eq.c.alt       
// 0x0005d116: const.pri      -424004863
// 0x0005d11b: cmps           
// 0x0005d11c: eq.pri         
// 0x0005d11d: mod.c          
// 0x0005d11e: jzer           0x-7e8f1346
// 0x0005d123: load.i         
// 0x0005d124: push.c         0x-156a1380 ""
// 0x0005d129: sleq           
// 0x0005d12a: push.s         -2146949364
// 0x0005d12f: emit           
// Iter_OnPlayerDisconnect @ 0x18020-0x18588 (1384 bytes)
// Source: system_blackjack_full.pwn

stock Iter_OnPlayerDisconnect()
{
    // stack 654934288
    // load.pri -338264052
    // const.alt -269756800
    // stack -2129188076
    return 1;
    // const.alt -269756800
    // stack 654934292
    // load.pri -338264052
    // stack 654934288
    // const.alt -269756800
    // stack 654934288
    // const.alt -269756800
    // stack 654934288
    // load.pri -338264052
    // stack 654934288
    // branch jump -> -338264052
    // stack 654934288
    // load.pri -338264052
    // const.alt -269756800
    // branch jneq -> 0x-766e7bd9
    // stack -2129188076
    return 1;
    // const.alt -269756800
    // stack 654934292
    // load.pri -338264052
    // stack 654934288
    // const.alt -269756800
    // stack 654934288
    // const.alt -269756800
    // stack 654934288
    // load.pri -338264052
    // stack 654934288
    // branch jump -> -338264052
    // stack 654934288
    // load.pri -338264052
    // stack 654934288
    // load.pri -338264052
    // load.pri 159453228
    // const.alt -269756800
    // stack -2129188076
    return 1;
    // const.alt -269756800
    // stack 654934292
    // load.pri -338264052
    // stack 654934288
    // const.alt -269756800
    // stack 654934288
    // const.alt -269756800
    // stack 654934288
    // load.pri -338264052
    // stack 654934288
    // branch jump -> -338264052
    // stack 654934288
    // load.pri -338264052
    // stack 654934288
    // load.pri -338264052
    // load.pri 159453228
    // const.alt -269756800
    // const.alt -696244444
    // stack -2129188076
    return 1;
    // const.alt -269756800
    // const.alt 204022793
    // stack 654934292
    // load.pri -338264052
    // const.alt 204022793
    // stack 654934288
    // const.alt -269756800
    // const.alt 204022793
    // stack 654934288
    // const.alt -269756800
    // const.alt 204022793
    // stack 654934288
    // load.pri -338264052
    // const.alt 204022793
    // stack 654934288
    // branch jump -> -338264052
    // const.alt 204022793
    // stack 654934288
    // load.pri -338264052
}

// --- disasm (first 80) ---
// 0x00018020: load.s.pri     -2122743796
// 0x00018025: sysreq.c       
// 0x00018026: lidx           
// 0x00018027: push.pri       
// 0x00018028: push.s         -2146687220
// 0x0001802d: emit           
// 0x0001802e: eq.pri         
// 0x0001802f: sign.alt       
// 0x00018030: stack          654934288
// 0x00018035: load.pri       -338264052
// 0x0001803a: op231          
// 0x0001803b: jsgeq          
// 0x0001803c: load.s.pri     -2122743796
// 0x00018041: sysreq.c       
// 0x00018042: lidx           
// 0x00018043: push.pri       
// 0x00018044: push.s         -2146687220
// 0x00018049: emit           
// 0x0001804a: eq.alt         -2129646592
// 0x0001804f: load.i         
// 0x00018050: push.c         0x-297ff3ff ""
// 0x00018055: op235          
// 0x00018056: op231          
// 0x00018057: jsgeq          
// 0x00018058: load.s.pri     -2122743796
// 0x0001805d: sysreq.c       
// 0x0001805e: lidx           
// 0x0001805f: push.pri       
// 0x00018060: push.s         -2146687220
// 0x00018065: emit           
// 0x00018066: eq.alt         -2129646591
// 0x0001806b: load.i         
// 0x0001806c: const.alt      -269756800
// 0x00018071: push           2038434819
// 0x00018076: eq.alt         153230201
// 0x0001807b: eq.pri         
// 0x0001807c: neg            
// 0x0001807d: push.pri       
// 0x0001807e: push.c         0x-7a0f2980 ""
// 0x00018083: idxaddr.b      -1768258521
// 0x00018088: op192          
// 0x00018089: sless          
// 0x0001808a: push.c         0x-660c737c ""
// 0x0001808f: add            
// 0x00018090: push.s         -2146425076
// 0x00018095: emit           
// 0x00018096: eq.pri         
// 0x00018097: sysreq.c       
// 0x00018098: stack          -2129188076
// 0x0001809d: load.i         
// 0x0001809e: push.c         0x-6b37027d ""
// 0x000180a3: strb.i         -873168089
// 0x000180a8: op174          
// 0x000180a9: retn           
// 0x000180aa: const.alt      -269756800
// 0x000180af: push           2038434819
// 0x000180b4: eq.alt         153230201
// 0x000180b9: eq.pri         
// 0x000180ba: neg            
// 0x000180bb: load.i         
// 0x000180bc: push.pri       
// 0x000180bd: push.s         -2146425076
// 0x000180c2: emit           
// 0x000180c3: eq.pri         
// 0x000180c4: file           
// 0x000180c5: stack          654934292
// 0x000180ca: load.pri       -338264052
// 0x000180cf: op239          
// 0x000180d0: push           2038434819
// 0x000180d5: eq.alt         153230201
// 0x000180da: eq.pri         
// 0x000180db: neg            
// 0x000180dc: load.i         
// 0x000180dd: push.pri       
// 0x000180de: push.s         -2146687220
// 0x000180e3: emit           
// 0x000180e4: eq.pri         
// 0x000180e5: emit           
// 0x000180e6: stack          654934288
// 0x000180eb: sign.alt       
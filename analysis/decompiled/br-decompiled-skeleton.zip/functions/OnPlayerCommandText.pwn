// OnPlayerCommandText @ 0xc09e4-0xc0ac0 (220 bytes)
// Source: test.pwn

public OnPlayerCommandText()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000c09e4: op0            
// 0x000c09e5: load.i         
// 0x000c09e6: push.pri       
// 0x000c09e7: const.alt      -1046094464
// 0x000c09ec: jneq           0x-7fdf02fd
// 0x000c09f1: sysreq.c       
// 0x000c09f2: stor.s.pri     -2146885093
// 0x000c09f7: neg            
// 0x000c09f8: eq.pri         
// 0x000c09f9: mul.c          
// 0x000c09fa: eq.pri         
// 0x000c09fb: zero.pri       
// 0x000c09fc: load.i         
// 0x000c09fd: push.pri       
// 0x000c09fe: push.c         0x3b7b8020 ""
// 0x000c0a03: stack          -2129188060
// 0x000c0a08: load.i         
// 0x000c0a09: const.alt      -1046094464
// 0x000c0a0e: jneq           0x-7fdf02fd
// 0x000c0a13: sysreq.c       
// 0x000c0a14: stor.s.pri     -2146885093
// 0x000c0a19: neg            
// 0x000c0a1a: eq.pri         
// 0x000c0a1b: mul.c          
// 0x000c0a1c: eq.alt         2131436128
// 0x000c0a21: stor.i         
// 0x000c0a22: eq.alt         -578810871
// 0x000c0a27: line.debug     
// 0x000c0a28: op193          
// 0x000c0a29: jneq           0x-7fdf02fd
// 0x000c0a2e: sysreq.c       
// 0x000c0a2f: stor.s.pri     -2146885093
// 0x000c0a34: neg            
// 0x000c0a35: eq.pri         
// 0x000c0a36: mul.c          
// 0x000c0a37: eq.pri         
// 0x000c0a38: mod            
// 0x000c0a39: load.i         
// 0x000c0a3a: move.alt       
// 0x000c0a3b: eq.pri         
// 0x000c0a3c: mod.c          
// 0x000c0a3d: xchg           
// 0x000c0a3e: jsleq          0x788ef680
// 0x000c0a43: push.c         0x-79 ""
// 0x000c0a48: sign.alt       
// 0x000c0a49: push.c         0x-137fd8ff ""
// 0x000c0a4e: op200          
// 0x000c0a4f: op192          
// 0x000c0a50: push.pri       
// 0x000c0a51: const.alt      -1046094464
// 0x000c0a56: jneq           0x-7fdf02fd
// 0x000c0a5b: sysreq.c       
// 0x000c0a5c: stor.s.pri     -2146885093
// 0x000c0a61: neg            
// 0x000c0a62: eq.pri         
// 0x000c0a63: mul.c          
// 0x000c0a64: eq.alt         271000584
// 0x000c0a69: eq.pri         
// 0x000c0a6a: emit           
// 0x000c0a6b: stor.s.pri     1417679916
// 0x000c0a70: jzer           0x788ef680
// 0x000c0a75: const.pri      -159370495
// 0x000c0a7a: push.alt       
// 0x000c0a7b: zero.pri       
// 0x000c0a7c: eq.pri         
// 0x000c0a7d: mod.c          
// 0x000c0a7e: jzer           0x7c91f680
// 0x000c0a83: eq.alt         -578810871
// 0x000c0a88: line.debug     
// 0x000c0a89: op193          
// 0x000c0a8a: jneq           0x-7fdf02fd
// 0x000c0a8f: sysreq.c       
// 0x000c0a90: stor.s.pri     -2146885093
// 0x000c0a95: neg            
// 0x000c0a96: eq.pri         
// 0x000c0a97: mul.c          
// 0x000c0a98: eq.pri         
// 0x000c0a99: mod            
// 0x000c0a9a: push.pri       
// 0x000c0a9b: push.c         0x-3f371380 ""
// AutosalonSetVehicleSlots @ 0x170f4-0x174bc (968 bytes)
// Source: test.pwn

stock AutosalonSetVehicleSlots()
{
    // stack 201949452
    // const.alt 2038434819
    // const.alt -1634781313
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949452
    // branch jneq -> 0x79801803
    // const.alt -2146885093
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 185172240
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949452
    // branch jneq -> 0x79801803
    // const.alt -2146885093
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 185172240
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack 931073033
    // stor.alt -2146760319
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 136782857
    // stack 201949452
    // branch jneq -> 0x79801803
    // const.alt -2146885093
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 203891721
    // stack 185172240
    return 1;
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
}

// --- disasm (first 80) ---
// 0x000170f4: grtr           
// 0x000170f5: stack          201949452
// 0x000170fa: eq.pri         
// 0x000170fb: op214          
// 0x000170fc: op238          
// 0x000170fd: nop            
// 0x000170fe: const.alt      2038434819
// 0x00017103: lref.pri       -2146885093
// 0x00017108: neg            
// 0x00017109: eq.pri         
// 0x0001710a: mul.c          
// 0x0001710b: push.pri       
// 0x0001710c: load.i         
// 0x0001710d: const.alt      -1634781313
// 0x00017112: or             
// 0x00017113: eq.alt         -696251639
// 0x00017118: op236          
// 0x00017119: heap           
// 0x0001711a: retn           
// 0x0001711b: push.pri       
// 0x0001711c: const.alt      -1561405824
// 0x00017121: const.alt      2038434819
// 0x00017126: lref.pri       -2146885093
// 0x0001712b: neg            
// 0x0001712c: eq.pri         
// 0x0001712d: mul.c          
// 0x0001712e: push.pri       
// 0x0001712f: load.i         
// 0x00017130: eq.pri         
// 0x00017131: sysreq.c       
// 0x00017132: eq.alt         572205945
// 0x00017137: load.i         
// 0x00017138: eq.pri         
// 0x00017139: neg            
// 0x0001713a: push.pri       
// 0x0001713b: load.s.pri     75071504
// 0x00017140: pop.alt        
// 0x00017141: idxaddr        
// 0x00017142: move.alt       
// 0x00017143: load.i         
// 0x00017144: eq.pri         
// 0x00017145: neg            
// 0x00017146: push.pri       
// 0x00017147: load.s.pri     58294292
// 0x0001714c: pop.alt        
// 0x0001714d: idxaddr        
// 0x0001714e: load.i         
// 0x0001714f: push.pri       
// 0x00017150: const.alt      -1561405824
// 0x00017155: const.alt      2038434819
// 0x0001715a: lref.pri       -2146885093
// 0x0001715f: neg            
// 0x00017160: eq.pri         
// 0x00017161: mul.c          
// 0x00017162: push.pri       
// 0x00017163: load.i         
// 0x00017164: push.pri       
// 0x00017165: push.c         0x-7f847ff8 ""
// 0x0001716a: grtr           
// 0x0001716b: stack          201949452
// 0x00017170: eq.pri         
// 0x00017171: op214          
// 0x00017172: op237          
// 0x00017173: op234          
// 0x00017174: jneq           0x79801803
// 0x00017179: const.alt      -2146885093
// 0x0001717e: neg            
// 0x0001717f: push.pri       
// 0x00017180: load.s.pri     58294300
// 0x00017185: pop.alt        
// 0x00017186: idxaddr        
// 0x00017187: move.alt       
// 0x00017188: load.i         
// 0x00017189: eq.pri         
// 0x0001718a: neg            
// 0x0001718b: eq.pri         
// 0x0001718c: mul.c          
// 0x0001718d: load.s.alt     -696251612
// 0x00017192: op236          
// 0x00017193: heap           
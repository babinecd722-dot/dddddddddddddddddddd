// GetPromoCodeIndexByString @ 0x4a93c-0x4aa24 (232 bytes)
// Source: system_new_promo.pwn

stock GetPromoCodeIndexByString()
{
    // const.pri 159455103
    // const.alt -607660416
    // const.pri 159455103
    // const.alt -607660416
    // const.pri 159455103
    // const.alt -607660416
    // const.pri 159455103
    // const.alt -607660416
    // const.pri 159455103
    // const.alt -607660416
    // const.pri 159455103
    // branch jnz -> 0x364abaf
    // branch jump -> 191671215
    // load.pri 414035765
    // const.alt -607660416
}

// --- disasm (first 80) ---
// 0x0004a93c: strb.i         204022793
// 0x0004a941: push.c         0x-27fcef4 ""
// 0x0004a946: op204          
// 0x0004a947: cmps           
// 0x0004a948: eq.alt         -696251383
// 0x0004a94d: op199          
// 0x0004a94e: op219          
// 0x0004a94f: sysreq.pri     
// 0x0004a950: load.s.pri     -2122743796
// 0x0004a955: sysreq.c       
// 0x0004a956: idxaddr        
// 0x0004a957: move.alt       
// 0x0004a958: load.i         
// 0x0004a959: eq.pri         
// 0x0004a95a: neg            
// 0x0004a95b: eq.pri         
// 0x0004a95c: mul.c          
// 0x0004a95d: movs.i         
// 0x0004a95e: mul            
// 0x0004a95f: move.alt       
// 0x0004a960: const.pri      159455103
// 0x0004a965: const.alt      -607660416
// 0x0004a96a: sysreq.pri     
// 0x0004a96b: load.s.pri     -2122743796
// 0x0004a970: sysreq.c       
// 0x0004a971: idxaddr        
// 0x0004a972: move.alt       
// 0x0004a973: load.i         
// 0x0004a974: eq.pri         
// 0x0004a975: neg            
// 0x0004a976: eq.pri         
// 0x0004a977: mul.c          
// 0x0004a978: movs.i         
// 0x0004a979: div.c          
// 0x0004a97a: move.alt       
// 0x0004a97b: const.pri      159455103
// 0x0004a980: const.alt      -607660416
// 0x0004a985: sysreq.pri     
// 0x0004a986: load.s.pri     -2122743796
// 0x0004a98b: sysreq.c       
// 0x0004a98c: idxaddr        
// 0x0004a98d: move.alt       
// 0x0004a98e: load.i         
// 0x0004a98f: eq.pri         
// 0x0004a990: neg            
// 0x0004a991: eq.pri         
// 0x0004a992: mul.c          
// 0x0004a993: movs.i         
// 0x0004a994: eq.c.alt       
// 0x0004a995: move.alt       
// 0x0004a996: const.pri      159455103
// 0x0004a99b: const.alt      -607660416
// 0x0004a9a0: sysreq.pri     
// 0x0004a9a1: load.s.pri     -2122743796
// 0x0004a9a6: sysreq.c       
// 0x0004a9a7: idxaddr        
// 0x0004a9a8: move.alt       
// 0x0004a9a9: load.i         
// 0x0004a9aa: eq.pri         
// 0x0004a9ab: neg            
// 0x0004a9ac: eq.pri         
// 0x0004a9ad: mul.c          
// 0x0004a9ae: movs.i         
// 0x0004a9af: sleq           
// 0x0004a9b0: move.alt       
// 0x0004a9b1: const.pri      159455103
// 0x0004a9b6: const.alt      -607660416
// 0x0004a9bb: sysreq.pri     
// 0x0004a9bc: load.s.pri     -2122743796
// 0x0004a9c1: sysreq.c       
// 0x0004a9c2: idxaddr        
// 0x0004a9c3: move.alt       
// 0x0004a9c4: load.i         
// 0x0004a9c5: eq.pri         
// 0x0004a9c6: neg            
// 0x0004a9c7: eq.pri         
// 0x0004a9c8: mul.c          
// 0x0004a9c9: movs.i         
// 0x0004a9ca: or             
// 0x0004a9cb: move.alt       
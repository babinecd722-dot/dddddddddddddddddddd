// Dialog_Open @ 0x7c68-0x7d9c (308 bytes)
// Source: lib_m_dialog.inc

stock Dialog_Open()
{
    // const.pri -375600000
    // stack 1501586560
    return 1;
    // proc @0x7c85
    // const.alt -2145166720
    // const.pri 1736441985
    // branch jzer -> 0x-7edf637b
    // const.alt -877015936
    return 1;
    return 1;
    // proc @0x7cbb
    // stack 402859020
    // const.alt -2146949340
    // stack -2079645172
    // stack 
    // stack -2127679476
    // stor.alt 159480849
    // load.pri -307311488
    // stor.alt 1029996556
    // const.alt -743715712
    // stack -2146860784
    // stor.alt 17500545
    // stack -2127679484
    // load.pri -307311488
    // stor.alt 729765760
}

// --- disasm (first 80) ---
// 0x00007c68: idxaddr.b      -15836800
// 0x00007c6d: idxaddr.b      1686140800
// 0x00007c72: const.pri      -375600000
// 0x00007c77: xor            
// 0x00007c78: addr.alt       1971330303
// 0x00007c7d: eq.pri         
// 0x00007c7e: or             
// 0x00007c7f: stack          1501586560
// 0x00007c84: retn           
// 0x00007c85: proc           
// 0x00007c86: eq.alt         50954505
// 0x00007c8b: const.alt      -2145166720
// 0x00007c90: neq            
// 0x00007c91: push.pri       
// 0x00007c92: const.pri      1736441985
// 0x00007c97: pop.alt        
// 0x00007c98: eq.pri         
// 0x00007c99: sub            
// 0x00007c9a: jzer           0x-7edf637b
// 0x00007c9f: load.i         
// 0x00007ca0: const.alt      -877015936
// 0x00007ca5: strb.i         2038434819
// 0x00007caa: eq.pri         
// 0x00007cab: sign.alt       
// 0x00007cac: lidx           
// 0x00007cad: retn           
// 0x00007cae: eq.alt         -864023799
// 0x00007cb3: op185          
// 0x00007cb4: op203          
// 0x00007cb5: strb.i         151279488
// 0x00007cba: retn           
// 0x00007cbb: proc           
// 0x00007cbc: eq.alt         50954505
// 0x00007cc1: sref.alt       623119364
// 0x00007cc6: push.c         0x307b8008 ""
// 0x00007ccb: stack          402859020
// 0x00007cd0: load.s.alt     656745488
// 0x00007cd5: lref.s.alt     741374848
// 0x00007cda: const.alt      -2146949340
// 0x00007cdf: emit           
// 0x00007ce0: eq.pri         
// 0x00007ce1: mul            
// 0x00007ce2: stack          -2079645172
// 0x00007ce7: stack          
// 0x00007ce8: op208          
// 0x00007ce9: eq.pri         
// 0x00007cea: op0            
// 0x00007ceb: push.pri       
// 0x00007cec: push.alt       
// 0x00007ced: push.c         0x307b8008 ""
// 0x00007cf2: stack          -2127679476
// 0x00007cf7: load.i         
// 0x00007cf8: eq.alt         24914953
// 0x00007cfd: eq.pri         
// 0x00007cfe: op204          
// 0x00007cff: op174          
// 0x00007d00: op237          
// 0x00007d01: stor.alt       159480849
// 0x00007d06: load.pri       -307311488
// 0x00007d0b: stor.alt       1029996556
// 0x00007d10: dec.s.alt      
// 0x00007d11: casetbl        
// 0x00007d12: add            
// 0x00007d13: eq.alt         738265865
// 0x00007d18: load.s.alt     201949488
// 0x00007d1d: eq.pri         
// 0x00007d1e: op204          
// 0x00007d1f: op171          
// 0x00007d20: op211          
// 0x00007d21: or             
// 0x00007d22: load.s.pri     -2139520900
// 0x00007d27: shr            
// 0x00007d28: idxaddr        
// 0x00007d29: move.alt       
// 0x00007d2a: load.i         
// 0x00007d2b: eq.pri         
// 0x00007d2c: neg            
// 0x00007d2d: move.alt       
// 0x00007d2e: load.s.pri     159454988
// 0x00007d33: const.alt      -743715712
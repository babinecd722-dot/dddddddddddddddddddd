// OnPlayerCommandReceived @ 0x1acba8-0x1acd80 (472 bytes)
// Source: test.pwn

public OnPlayerCommandReceived()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001acba8: op0            
// 0x001acba9: op0            
// 0x001acbaa: op0            
// 0x001acbab: op0            
// 0x001acbac: op0            
// 0x001acbad: op0            
// 0x001acbae: op0            
// 0x001acbaf: op0            
// 0x001acbb0: op0            
// 0x001acbb1: op0            
// 0x001acbb2: op0            
// 0x001acbb3: op0            
// 0x001acbb4: op0            
// 0x001acbb5: op0            
// 0x001acbb6: op0            
// 0x001acbb7: op0            
// 0x001acbb8: eq.alt         -2124381878
// 0x001acbbd: eq.c.alt       
// 0x001acbbe: eq.alt         114
// 0x001acbc3: op0            
// 0x001acbc4: op0            
// 0x001acbc5: op0            
// 0x001acbc6: op0            
// 0x001acbc7: op0            
// 0x001acbc8: op0            
// 0x001acbc9: op0            
// 0x001acbca: op0            
// 0x001acbcb: op0            
// 0x001acbcc: op0            
// 0x001acbcd: op0            
// 0x001acbce: op0            
// 0x001acbcf: op0            
// 0x001acbd0: op0            
// 0x001acbd1: op0            
// 0x001acbd2: op0            
// 0x001acbd3: op0            
// 0x001acbd4: op0            
// 0x001acbd5: op0            
// 0x001acbd6: op0            
// 0x001acbd7: op0            
// 0x001acbd8: op0            
// 0x001acbd9: op0            
// 0x001acbda: op0            
// 0x001acbdb: op0            
// 0x001acbdc: op0            
// 0x001acbdd: op0            
// 0x001acbde: op0            
// 0x001acbdf: op0            
// 0x001acbe0: op0            
// 0x001acbe1: op0            
// 0x001acbe2: op0            
// 0x001acbe3: op0            
// 0x001acbe4: op0            
// 0x001acbe5: op0            
// 0x001acbe6: op0            
// 0x001acbe7: op0            
// 0x001acbe8: op0            
// 0x001acbe9: op0            
// 0x001acbea: op0            
// 0x001acbeb: op0            
// 0x001acbec: op0            
// 0x001acbed: op0            
// 0x001acbee: op0            
// 0x001acbef: op0            
// 0x001acbf0: op0            
// 0x001acbf1: op0            
// 0x001acbf2: op0            
// 0x001acbf3: op0            
// 0x001acbf4: op0            
// 0x001acbf5: op0            
// 0x001acbf6: op0            
// 0x001acbf7: op0            
// 0x001acbf8: op0            
// 0x001acbf9: op0            
// 0x001acbfa: op0            
// 0x001acbfb: op0            
// 0x001acbfc: op0            
// 0x001acbfd: op0            
// 0x001acbfe: op0            
// 0x001acbff: op0            
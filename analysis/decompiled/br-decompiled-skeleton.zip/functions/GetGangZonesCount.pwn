// GetGangZonesCount @ 0x1c29f0-0x1c2ac8 (216 bytes)
// Source: test.pwn

stock GetGangZonesCount()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001c29f0: op0            
// 0x001c29f1: op0            
// 0x001c29f2: op0            
// 0x001c29f3: op0            
// 0x001c29f4: op0            
// 0x001c29f5: op0            
// 0x001c29f6: op0            
// 0x001c29f7: op0            
// 0x001c29f8: op0            
// 0x001c29f9: op0            
// 0x001c29fa: op0            
// 0x001c29fb: op0            
// 0x001c29fc: op0            
// 0x001c29fd: op0            
// 0x001c29fe: op0            
// 0x001c29ff: op0            
// 0x001c2a00: op0            
// 0x001c2a01: op0            
// 0x001c2a02: op0            
// 0x001c2a03: op0            
// 0x001c2a04: op0            
// 0x001c2a05: op0            
// 0x001c2a06: op0            
// 0x001c2a07: op0            
// 0x001c2a08: op0            
// 0x001c2a09: op0            
// 0x001c2a0a: op0            
// 0x001c2a0b: op0            
// 0x001c2a0c: op0            
// 0x001c2a0d: op0            
// 0x001c2a0e: op0            
// 0x001c2a0f: op0            
// 0x001c2a10: op0            
// 0x001c2a11: op0            
// 0x001c2a12: op0            
// 0x001c2a13: op0            
// 0x001c2a14: op0            
// 0x001c2a15: op0            
// 0x001c2a16: op0            
// 0x001c2a17: op0            
// 0x001c2a18: op0            
// 0x001c2a19: op0            
// 0x001c2a1a: op0            
// 0x001c2a1b: op0            
// 0x001c2a1c: op0            
// 0x001c2a1d: op0            
// 0x001c2a1e: op0            
// 0x001c2a1f: op0            
// 0x001c2a20: op0            
// 0x001c2a21: op0            
// 0x001c2a22: op0            
// 0x001c2a23: op0            
// 0x001c2a24: op0            
// 0x001c2a25: op0            
// 0x001c2a26: op0            
// 0x001c2a27: op0            
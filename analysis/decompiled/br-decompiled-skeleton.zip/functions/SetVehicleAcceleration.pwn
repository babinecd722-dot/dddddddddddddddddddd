// SetVehicleAcceleration @ 0x14888-0x149b8 (304 bytes)
// Source: customtune.inc

stock SetVehicleAcceleration()
{
    // const.alt -689187200
    // const.alt 136782857
    // stack 201949452
    // const.alt 2038434819
    // const.alt 2038434819
    call_0x0x-7ef33d72();
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -930269313
    // const.alt -2146694783
    // const.alt 2038434819
    // const.alt -2146694783
    // const.alt 2038434819
    // const.alt 2038434819
    call_0x0x-7ef33d72();
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 931073033
    // branch jrel -> -2146694783
    // const.alt 2038434819
    // stack 69673993
    call_0x0x-7ef33d72();
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt 58788132
    // branch jump -> -2126972531
    // const.alt -1561405824
}

// --- disasm (first 80) ---
// 0x00014888: eq.alt         -696244471
// 0x0001488d: op239          
// 0x0001488e: op230          
// 0x0001488f: xor            
// 0x00014890: const.alt      -689187200
// 0x00014895: sysreq.pri     
// 0x00014896: load.s.pri     91848716
// 0x0001489b: idxaddr        
// 0x0001489c: move.alt       
// 0x0001489d: load.i         
// 0x0001489e: eq.pri         
// 0x0001489f: neg            
// 0x000148a0: eq.pri         
// 0x000148a1: mul.c          
// 0x000148a2: const.alt      136782857
// 0x000148a7: eq.pri         
// 0x000148a8: emit           
// 0x000148a9: eq.pri         
// 0x000148aa: div            
// 0x000148ab: stack          201949452
// 0x000148b0: eq.pri         
// 0x000148b1: op214          
// 0x000148b2: op238          
// 0x000148b3: nop            
// 0x000148b4: const.alt      2038434819
// 0x000148b9: lref.pri       -2146885093
// 0x000148be: neg            
// 0x000148bf: eq.pri         
// 0x000148c0: mul.c          
// 0x000148c1: sctrl          931073033
// 0x000148c6: push.pri       
// 0x000148c7: op198          
// 0x000148c8: sysreq.pri     
// 0x000148c9: eq.alt         -696251383
// 0x000148ce: op238          
// 0x000148cf: nop            
// 0x000148d0: const.alt      2038434819
// 0x000148d5: lref.pri       -2146885093
// 0x000148da: neg            
// 0x000148db: eq.pri         
// 0x000148dc: mul.c          
// 0x000148dd: sctrl          69673993
// 0x000148e2: call           0x-7ef33d72
// 0x000148e7: load.i         
// 0x000148e8: const.alt      -1561405824
// 0x000148ed: const.alt      2038434819
// 0x000148f2: lref.pri       -2146885093
// 0x000148f7: neg            
// 0x000148f8: eq.pri         
// 0x000148f9: mul.c          
// 0x000148fa: push.pri       
// 0x000148fb: load.i         
// 0x000148fc: const.alt      -930269313
// 0x00014901: const.alt      -2146694783
// 0x00014906: op214          
// 0x00014907: op238          
// 0x00014908: nop            
// 0x00014909: const.alt      2038434819
// 0x0001490e: lref.pri       -2146885093
// 0x00014913: neg            
// 0x00014914: eq.pri         
// 0x00014915: mul.c          
// 0x00014916: push.pri       
// 0x00014917: load.i         
// 0x00014918: push.pri       
// 0x00014919: push.c         0x-3d71cefc ""
// 0x0001491e: const.alt      -2146694783
// 0x00014923: op214          
// 0x00014924: op238          
// 0x00014925: nop            
// 0x00014926: const.alt      2038434819
// 0x0001492b: lref.pri       -2146885093
// 0x00014930: neg            
// 0x00014931: eq.pri         
// 0x00014932: mul.c          
// 0x00014933: push           931073033
// 0x00014938: push.pri       
// 0x00014939: op201          
// 0x0001493a: sctrl          -2146694783
// 0x0001493f: op214          
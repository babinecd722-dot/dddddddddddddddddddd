// AutosalonAddVehicleSlot @ 0x174bc-0x17564 (168 bytes)
// Source: test.pwn

stock AutosalonAddVehicleSlot()
{
    // const.alt 2038434819
    // stack 136782857
    // stack 75705356
    return 1;
    // proc @0x174db
    // const.alt 1870691200
    // stack -696250608
    // stack 654934288
    // stack 654934288
    // load.pri -338264024
    // stack 654934284
    // stack 654934284
    // stack 654934284
}

// --- disasm (first 80) ---
// 0x000174bc: nop            
// 0x000174bd: const.alt      2038434819
// 0x000174c2: lref.pri       -2146885093
// 0x000174c7: neg            
// 0x000174c8: eq.pri         
// 0x000174c9: mul.c          
// 0x000174ca: stack          136782857
// 0x000174cf: eq.pri         
// 0x000174d0: emit           
// 0x000174d1: eq.pri         
// 0x000174d2: grtr           
// 0x000174d3: stack          75705356
// 0x000174d8: eq.pri         
// 0x000174d9: mod.c          
// 0x000174da: retn           
// 0x000174db: proc           
// 0x000174dc: eq.alt         654934281
// 0x000174e1: eq.pri         
// 0x000174e2: op214          
// 0x000174e3: op239          
// 0x000174e4: op254          
// 0x000174e5: shl.pri        
// 0x000174e6: push.c         0x27002700 ""
// 0x000174eb: const.alt      1870691200
// 0x000174f0: stack          -696250608
// 0x000174f5: op235          
// 0x000174f6: op209          
// 0x000174f7: cmps           
// 0x000174f8: eq.alt         654321417
// 0x000174fd: op0            
// 0x000174fe: push           -773073280
// 0x00017503: cmps           
// 0x00017504: push.c         0x-7f847ff4 ""
// 0x00017509: eq.c.alt       
// 0x0001750a: stack          654934288
// 0x0001750f: dec.s.pri      
// 0x00017510: swap.pri       
// 0x00017511: eq.pri         
// 0x00017512: eq.pri         
// 0x00017513: op0            
// 0x00017514: push.c         0x-7f7f5e7c ""
// 0x00017519: op0            
// 0x0001751a: push           -773073280
// 0x0001751f: cmps           
// 0x00017520: push.c         0x-7f847ff4 ""
// 0x00017525: bounds         
// 0x00017526: stack          654934288
// 0x0001752b: load.pri       -338264024
// 0x00017530: op209          
// 0x00017531: cmps           
// 0x00017532: push.c         0x-7f847ff8 ""
// 0x00017537: inc            
// 0x00017538: stack          654934284
// 0x0001753d: sign.alt       
// 0x0001753e: push           -773073280
// 0x00017543: cmps           
// 0x00017544: push.c         0x-7f847ff8 ""
// 0x00017549: shr            
// 0x0001754a: stack          654934284
// 0x0001754f: op0            
// 0x00017550: push           -773073280
// 0x00017555: cmps           
// 0x00017556: push.c         0x-7f847ff8 ""
// 0x0001755b: dec            
// 0x0001755c: stack          654934284
// 0x00017561: op0            
// 0x00017562: push           -773073280
// pc_alias_promo @ 0x5a524-0x5a560 (60 bytes)
// Source: system_new_promo.pwn

stock pc_alias_promo()
{
    // const.alt 742357888
    // stor.alt -2144925311
    // branch jrel -> -2144925311
    // stor.alt 136776745
    call_0x0x70fcd981();
    // branch jump -> -2124640839
}

// --- disasm (first 80) ---
// 0x0005a524: const.alt      742357888
// 0x0005a529: stor.alt       -2144925311
// 0x0005a52e: op236          
// 0x0005a52f: pop.alt        
// 0x0005a530: op204          
// 0x0005a531: lref.s.alt     -1796440025
// 0x0005a536: op202          
// 0x0005a537: zero.pri       
// 0x0005a538: push.c         0x27002700 ""
// 0x0005a53d: lref.alt       204014375
// 0x0005a542: push.c         0x-127ecee4 ""
// 0x0005a547: movs.i         
// 0x0005a548: jrel           -2144925311
// 0x0005a54d: op236          
// 0x0005a54e: pop.alt        
// 0x0005a54f: op204          
// 0x0005a550: stor.alt       136776745
// 0x0005a555: call           0x70fcd981
// 0x0005a55a: jump           -2124640839
// 0x0005a55f: load.i         
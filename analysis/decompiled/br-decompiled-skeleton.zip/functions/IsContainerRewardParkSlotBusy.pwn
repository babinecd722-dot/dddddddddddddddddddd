// IsContainerRewardParkSlotBusy @ 0x1ac404-0x1ac67c (632 bytes)
// Source: test.pwn

stock IsContainerRewardParkSlotBusy()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001ac404: op0            
// 0x001ac405: op0            
// 0x001ac406: op0            
// 0x001ac407: op0            
// 0x001ac408: op0            
// 0x001ac409: op0            
// 0x001ac40a: op0            
// 0x001ac40b: op0            
// 0x001ac40c: op0            
// 0x001ac40d: op0            
// 0x001ac40e: op0            
// 0x001ac40f: op0            
// 0x001ac410: op0            
// 0x001ac411: op0            
// 0x001ac412: op0            
// 0x001ac413: op0            
// 0x001ac414: op0            
// 0x001ac415: op0            
// 0x001ac416: op0            
// 0x001ac417: op0            
// 0x001ac418: op0            
// 0x001ac419: op0            
// 0x001ac41a: op0            
// 0x001ac41b: eq.pri         
// 0x001ac41c: shr            
// 0x001ac41d: eq.pri         
// 0x001ac41e: not            
// 0x001ac41f: eq.pri         
// 0x001ac420: mul.c          
// 0x001ac421: sctrl          540560768
// 0x001ac426: eq.pri         
// 0x001ac427: sshr.pri       
// 0x001ac428: jless          0x32
// 0x001ac42d: op0            
// 0x001ac42e: op0            
// 0x001ac42f: op0            
// 0x001ac430: op0            
// 0x001ac431: op0            
// 0x001ac432: op0            
// 0x001ac433: op0            
// 0x001ac434: op0            
// 0x001ac435: op0            
// 0x001ac436: op0            
// 0x001ac437: op0            
// 0x001ac438: op0            
// 0x001ac439: op0            
// 0x001ac43a: op0            
// 0x001ac43b: op0            
// 0x001ac43c: op0            
// 0x001ac43d: op0            
// 0x001ac43e: op0            
// 0x001ac43f: op0            
// 0x001ac440: op0            
// 0x001ac441: op0            
// 0x001ac442: op0            
// 0x001ac443: op0            
// 0x001ac444: op0            
// 0x001ac445: op0            
// 0x001ac446: op0            
// 0x001ac447: op0            
// 0x001ac448: op0            
// 0x001ac449: op0            
// 0x001ac44a: op0            
// 0x001ac44b: op0            
// 0x001ac44c: op0            
// 0x001ac44d: op0            
// 0x001ac44e: op0            
// 0x001ac44f: op0            
// 0x001ac450: op0            
// 0x001ac451: op0            
// 0x001ac452: op0            
// 0x001ac453: op0            
// 0x001ac454: op0            
// 0x001ac455: op0            
// 0x001ac456: op0            
// 0x001ac457: op0            
// 0x001ac458: op0            
// 0x001ac459: op0            
// 0x001ac45a: op0            
// 0x001ac45b: op0            
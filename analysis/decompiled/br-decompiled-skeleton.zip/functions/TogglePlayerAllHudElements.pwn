// TogglePlayerAllHudElements @ 0x12bcc-0x12c58 (140 bytes)
// Source: customhud.inc

stock TogglePlayerAllHudElements()
{
    // const.alt -1561405824
    // const.alt 2038434819
    // stor.alt 1041566729
    // const.alt 2038434819
    return 1;
    // const.alt -1265877483
    // const.alt -1942595200
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
}

// --- disasm (first 80) ---
// 0x00012bcc: const.alt      -1561405824
// 0x00012bd1: const.alt      2038434819
// 0x00012bd6: lref.pri       -2146885093
// 0x00012bdb: neg            
// 0x00012bdc: eq.pri         
// 0x00012bdd: mul.c          
// 0x00012bde: stor.alt       1041566729
// 0x00012be3: bounds.p       
// 0x00012be4: op180          
// 0x00012be5: lref.s.alt     -287932404
// 0x00012bea: nop            
// 0x00012beb: const.alt      2038434819
// 0x00012bf0: lref.pri       -2146885093
// 0x00012bf5: neg            
// 0x00012bf6: eq.pri         
// 0x00012bf7: mul.c          
// 0x00012bf8: retn           
// 0x00012bf9: load.i         
// 0x00012bfa: const.alt      -1265877483
// 0x00012bff: lref.s.alt     -1942814453
// 0x00012c04: op180          
// 0x00012c05: const.alt      -1942595200
// 0x00012c0a: op180          
// 0x00012c0b: sctrl          -1942791808
// 0x00012c10: op180          
// 0x00012c11: push           -1942683381
// 0x00012c16: op185          
// 0x00012c17: div.c          
// 0x00012c18: eq.alt         -696244471
// 0x00012c1d: op239          
// 0x00012c1e: op206          
// 0x00012c1f: sref.alt       -304709621
// 0x00012c24: op225          
// 0x00012c25: jsgeq          
// 0x00012c26: push.pri       
// 0x00012c27: const.alt      -1561405824
// 0x00012c2c: const.alt      2038434819
// 0x00012c31: lref.pri       -2146885093
// 0x00012c36: neg            
// 0x00012c37: eq.pri         
// 0x00012c38: mul.c          
// 0x00012c39: sctrl          -2122743799
// 0x00012c3e: sysreq.c       
// 0x00012c3f: pop.alt        
// 0x00012c40: idxaddr        
// 0x00012c41: load.i         
// 0x00012c42: push.pri       
// 0x00012c43: const.alt      -1561405824
// 0x00012c48: const.alt      2038434819
// 0x00012c4d: lref.pri       -2146885093
// 0x00012c52: neg            
// 0x00012c53: eq.pri         
// 0x00012c54: mul.c          
// 0x00012c55: sctrl          203891721
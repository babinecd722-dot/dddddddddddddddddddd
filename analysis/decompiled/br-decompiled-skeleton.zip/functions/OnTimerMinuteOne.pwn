// OnTimerMinuteOne @ 0x75ee8-0x76dd8 (3824 bytes)
// Source: test.pwn

public OnTimerMinuteOne()
{
    // stack 763112740
    // stack 894730248
    return 1;
    // branch jzer -> 0x10bec980
    // branch jnz -> 0x5cbec980
    // branch jzer -> 0x28bfc980
    // const.alt -607660416
    // branch jeq -> 0x30c0c980
    // stack -914345200
    // stack -914345212
    // load.pri 622265389
    // stack -2122568424
    // stack 201949456
    // branch jrel -> -2141132797
    // const.pri 159454984
    // const.alt -2030252416
    // branch jrel -> -2141132797
    // const.alt -607660416
    call_0x0xca8a981();
    // const.pri -184824192
    // branch jrel -> -696251356
}

// --- disasm (first 80) ---
// 0x00075ee8: push.alt       
// 0x00075ee9: push.c         0x-25b1380 ""
// 0x00075eee: push.pri       
// 0x00075eef: push.c         0x5813981 ""
// 0x00075ef4: op232          
// 0x00075ef5: sshr           
// 0x00075ef6: push.c         0x257b8020 ""
// 0x00075efb: stack          763112740
// 0x00075f00: op255          
// 0x00075f01: op0            
// 0x00075f02: eq.alt         855648009
// 0x00075f07: eq.pri         
// 0x00075f08: op201          
// 0x00075f09: op188          
// 0x00075f0a: sleq           
// 0x00075f0b: eq.alt         -395411447
// 0x00075f10: div.c          
// 0x00075f11: load.s.pri     -2129897240
// 0x00075f16: file           
// 0x00075f17: eq.pri         
// 0x00075f18: jsgeq          
// 0x00075f19: eq.pri         
// 0x00075f1a: op201          
// 0x00075f1b: op192          
// 0x00075f1c: sleq           
// 0x00075f1d: eq.alt         1491609865
// 0x00075f22: push.c         0xa7b8004 ""
// 0x00075f27: stack          894730248
// 0x00075f2c: eq.pri         
// 0x00075f2d: op201          
// 0x00075f2e: op189          
// 0x00075f2f: jsgeq          
// 0x00075f30: eq.alt         -914345207
// 0x00075f35: op188          
// 0x00075f36: or             
// 0x00075f37: eq.alt         -696251383
// 0x00075f3c: op199          
// 0x00075f3d: op219          
// 0x00075f3e: sysreq.pri     
// 0x00075f3f: load.s.pri     2038454504
// 0x00075f44: eq.alt         153230201
// 0x00075f49: eq.pri         
// 0x00075f4a: neg            
// 0x00075f4b: eq.pri         
// 0x00075f4c: mul.c          
// 0x00075f4d: movs.i         
// 0x00075f4e: retn           
// 0x00075f4f: load.i         
// 0x00075f50: eq.pri         
// 0x00075f51: mod            
// 0x00075f52: jzer           0x10bec980
// 0x00075f57: eq.alt         -914345207
// 0x00075f5c: op188          
// 0x00075f5d: or             
// 0x00075f5e: eq.alt         -696251383
// 0x00075f63: op199          
// 0x00075f64: op219          
// 0x00075f65: sysreq.pri     
// 0x00075f66: load.s.pri     2038454504
// 0x00075f6b: eq.alt         153230201
// 0x00075f70: eq.pri         
// 0x00075f71: neg            
// 0x00075f72: eq.pri         
// 0x00075f73: mul.c          
// 0x00075f74: push.pri       
// 0x00075f75: div.c          
// 0x00075f76: load.i         
// 0x00075f77: jnz            0x5cbec980
// 0x00075f7c: eq.alt         -914345207
// 0x00075f81: op188          
// 0x00075f82: or             
// 0x00075f83: eq.alt         -696251383
// 0x00075f88: op199          
// 0x00075f89: op219          
// 0x00075f8a: sysreq.pri     
// 0x00075f8b: load.s.pri     2038454504
// 0x00075f90: eq.alt         153230201
// 0x00075f95: eq.pri         
// 0x00075f96: neg            
// 0x00075f97: eq.pri         
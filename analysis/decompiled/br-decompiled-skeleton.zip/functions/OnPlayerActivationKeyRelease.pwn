// OnPlayerActivationKeyRelease @ 0x7b318-0x7b43c (292 bytes)
// Source: test.pwn

public OnPlayerActivationKeyRelease()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0007b318: eq.alt         656734725
// 0x0007b31d: eq.pri         
// 0x0007b31e: op236          
// 0x0007b31f: op166          
// 0x0007b320: op195          
// 0x0007b321: retn           
// 0x0007b322: push.c         0x29002700 ""
// 0x0007b327: const.alt      -2127487961
// 0x0007b32c: push.pri       
// 0x0007b32d: op195          
// 0x0007b32e: add            
// 0x0007b32f: stack          -2127550326
// 0x0007b334: load.i         
// 0x0007b335: push.c         0x-3b591380 ""
// 0x0007b33a: leq            
// 0x0007b33b: push.c         0x-62440974 ""
// 0x0007b340: sign.alt       
// 0x0007b341: push.s         -2146687220
// 0x0007b346: emit           
// 0x0007b347: eq.pri         
// 0x0007b348: xor            
// 0x0007b349: stack          -864013552
// 0x0007b34e: op192          
// 0x0007b34f: stack          -2144925311
// 0x0007b354: op236          
// 0x0007b355: op166          
// 0x0007b356: op198          
// 0x0007b357: mod            
// 0x0007b358: push.c         0x270c297f ""
// 0x0007b35d: const.alt      1635810176
// 0x0007b362: stack          1418013712
// 0x0007b367: eq.alt         738265865
// 0x0007b36c: const.alt      -360697040
// 0x0007b371: op245          
// 0x0007b372: mod            
// 0x0007b373: eq.alt         -2146172151
// 0x0007b378: mod            
// 0x0007b379: jzer           0x4c1cc80
// 0x0007b37e: eq.alt         738265865
// 0x0007b383: lref.s.alt     738820400
// 0x0007b388: zero.pri       
// 0x0007b389: push.s         -2147211492
// 0x0007b38e: emit           
// 0x0007b38f: stor.alt       1947273260
// 0x0007b394: eq.alt         578028297
// 0x0007b399: eq.pri         
// 0x0007b39a: mod.c          
// 0x0007b39b: xchg           
// 0x0007b39c: jsleq          0x10c2cc80
// 0x0007b3a1: push.c         0x271c2900 ""
// 0x0007b3a6: lref.s.alt     -997359311
// 0x0007b3ab: sleq           
// 0x0007b3ac: jzer           0x10c2cc80
// 0x0007b3b1: const.pri      -864013567
// 0x0007b3b6: op194          
// 0x0007b3b7: sref.alt       -2143987328
// 0x0007b3bc: op204          
// 0x0007b3bd: op212          
// 0x0007b3be: mod            
// 0x0007b3bf: eq.alt         352005129
// 0x0007b3c4: eq.pri         
// 0x0007b3c5: mod.c          
// 0x0007b3c6: addr.alt       2004879611
// 0x0007b3cb: dec.s.pri      
// 0x0007b3cc: sleq           
// 0x0007b3cd: eq.alt         209464329
// 0x0007b3d2: eq.pri         
// 0x0007b3d3: op214          
// 0x0007b3d4: op199          
// 0x0007b3d5: op219          
// 0x0007b3d6: sysreq.pri     
// 0x0007b3d7: load.s.pri     -2122743796
// 0x0007b3dc: sysreq.c       
// 0x0007b3dd: idxaddr        
// 0x0007b3de: move.alt       
// 0x0007b3df: load.i         
// 0x0007b3e0: eq.pri         
// 0x0007b3e1: neg            
// 0x0007b3e2: eq.pri         
// 0x0007b3e3: mul.c          
// StartSpectateGUIRefresh @ 0x79db8-0x79ecc (276 bytes)
// Source: test.pwn

stock StartSpectateGUIRefresh()
{
    // branch jzer -> 0x1cdccb80
    // const.alt -607660416
    // branch jeq -> 0x24ddcb80
    // stack -880790768
    // stack -880790780
    // load.pri 622265389
    // stack -2122568424
    // stack 201949456
    // branch jrel -> -2141132797
    // const.pri 159454984
    // const.alt -2030252416
    // branch jrel -> -2141132797
    // const.alt -607660416
}

// --- disasm (first 80) ---
// 0x00079db8: sysreq.pri     
// 0x00079db9: load.s.pri     2038454504
// 0x00079dbe: eq.alt         153230201
// 0x00079dc3: eq.pri         
// 0x00079dc4: neg            
// 0x00079dc5: eq.pri         
// 0x00079dc6: mul.c          
// 0x00079dc7: movs.i         
// 0x00079dc8: add            
// 0x00079dc9: load.i         
// 0x00079dca: jzer           0x1cdccb80
// 0x00079dcf: eq.alt         -880790775
// 0x00079dd4: op217          
// 0x00079dd5: mod            
// 0x00079dd6: eq.alt         -696251383
// 0x00079ddb: op199          
// 0x00079ddc: op219          
// 0x00079ddd: sysreq.pri     
// 0x00079dde: load.s.pri     2038454504
// 0x00079de3: eq.alt         153230201
// 0x00079de8: eq.pri         
// 0x00079de9: neg            
// 0x00079dea: eq.pri         
// 0x00079deb: mul.c          
// 0x00079dec: push.pri       
// 0x00079ded: div.c          
// 0x00079dee: load.i         
// 0x00079def: push.pri       
// 0x00079df0: const.alt      -607660416
// 0x00079df5: sysreq.pri     
// 0x00079df6: load.s.pri     -2122743796
// 0x00079dfb: sysreq.c       
// 0x00079dfc: idxaddr        
// 0x00079dfd: move.alt       
// 0x00079dfe: load.i         
// 0x00079dff: eq.pri         
// 0x00079e00: neg            
// 0x00079e01: eq.pri         
// 0x00079e02: mul.c          
// 0x00079e03: push.pri       
// 0x00079e04: div.c          
// 0x00079e05: load.i         
// 0x00079e06: pop.alt        
// 0x00079e07: jeq            0x24ddcb80
// 0x00079e0c: eq.alt         -880790775
// 0x00079e11: op217          
// 0x00079e12: mod            
// 0x00079e13: eq.alt         -402292471
// 0x00079e18: sshr           
// 0x00079e19: push.c         0x-66184b7a ""
// 0x00079e1e: sign.alt       
// 0x00079e1f: push.s         203905256
// 0x00079e24: eq.pri         
// 0x00079e25: emit           
// 0x00079e26: eq.pri         
// 0x00079e27: xor            
// 0x00079e28: stack          -880790768
// 0x00079e2d: op217          
// 0x00079e2e: mod            
// 0x00079e2f: stack          -880790780
// 0x00079e34: op250          
// 0x00079e35: sref.alt       -402454143
// 0x00079e3a: or             
// 0x00079e3b: eq.pri         
// 0x00079e3c: mul.c          
// 0x00079e3d: load.pri       622265389
// 0x00079e42: push.c         0x-55a1380 ""
// 0x00079e47: eq.c.alt       
// 0x00079e48: push.c         0x5812c84 ""
// 0x00079e4d: op238          
// 0x00079e4e: shr.alt        
// 0x00079e4f: push           -1045704832
// 0x00079e54: or             
// 0x00079e55: push.c         0x-7f847fec ""
// 0x00079e5a: mod.c          
// 0x00079e5b: stack          -2122568424
// 0x00079e60: load.i         
// 0x00079e61: push.c         0x-11fa7f00 ""
// 0x00079e66: shr.alt        
// 0x00079e67: push           -1045704832
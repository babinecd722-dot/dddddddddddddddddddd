// EvictHouseRentersAll @ 0x1cff24-0x1d0428 (1284 bytes)
// Source: test.pwn

stock EvictHouseRentersAll()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001cff24: op0            
// 0x001cff25: op0            
// 0x001cff26: op0            
// 0x001cff27: op0            
// 0x001cff28: eq.pri         
// 0x001cff29: shl            
// 0x001cff2a: eq.pri         
// 0x001cff2b: fill           
// 0x001cff2c: eq.pri         
// 0x001cff2d: sshr           
// 0x001cff2e: eq.pri         
// 0x001cff2f: grtr           
// 0x001cff30: sctrl          540562048
// 0x001cff35: eq.pri         
// 0x001cff36: sub.c          
// 0x001cff37: call           0x30
// 0x001cff3c: op0            
// 0x001cff3d: op0            
// 0x001cff3e: op0            
// 0x001cff3f: op0            
// 0x001cff40: op0            
// 0x001cff41: op0            
// 0x001cff42: op0            
// 0x001cff43: op0            
// 0x001cff44: op0            
// 0x001cff45: op0            
// 0x001cff46: op0            
// 0x001cff47: op0            
// 0x001cff48: op0            
// 0x001cff49: op0            
// 0x001cff4a: op0            
// 0x001cff4b: op0            
// 0x001cff4c: op0            
// 0x001cff4d: op0            
// 0x001cff4e: op0            
// 0x001cff4f: op0            
// 0x001cff50: op0            
// 0x001cff51: op0            
// 0x001cff52: op0            
// 0x001cff53: op0            
// 0x001cff54: op0            
// 0x001cff55: op0            
// 0x001cff56: op0            
// 0x001cff57: op0            
// 0x001cff58: op0            
// 0x001cff59: op0            
// 0x001cff5a: op0            
// 0x001cff5b: op0            
// 0x001cff5c: op0            
// 0x001cff5d: op0            
// 0x001cff5e: op0            
// 0x001cff5f: op0            
// 0x001cff60: op0            
// 0x001cff61: op0            
// 0x001cff62: op0            
// 0x001cff63: op0            
// 0x001cff64: op0            
// 0x001cff65: op0            
// 0x001cff66: op0            
// 0x001cff67: op0            
// 0x001cff68: op0            
// 0x001cff69: op0            
// 0x001cff6a: op0            
// 0x001cff6b: op0            
// 0x001cff6c: op0            
// 0x001cff6d: op0            
// 0x001cff6e: op0            
// 0x001cff6f: op0            
// 0x001cff70: op0            
// 0x001cff71: op0            
// 0x001cff72: op0            
// 0x001cff73: op0            
// 0x001cff74: op0            
// 0x001cff75: op0            
// 0x001cff76: op0            
// 0x001cff77: op0            
// 0x001cff78: op0            
// 0x001cff79: op0            
// 0x001cff7a: op0            
// 0x001cff7b: op0            
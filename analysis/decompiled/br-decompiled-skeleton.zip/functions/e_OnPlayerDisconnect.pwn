// e_OnPlayerDisconnect @ 0xb9490-0xbb12c (7324 bytes)
// Source: test.pwn

stock e_OnPlayerDisconnect()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000b9490: const.alt      -1091381632
// 0x000b9495: shr.alt        
// 0x000b9496: load.s.pri     2038438142
// 0x000b949b: eq.pri         
// 0x000b949c: op245          
// 0x000b949d: stor.i         
// 0x000b949e: idxaddr        
// 0x000b949f: move.alt       
// 0x000b94a0: load.i         
// 0x000b94a1: eq.pri         
// 0x000b94a2: neg            
// 0x000b94a3: eq.pri         
// 0x000b94a4: mul.c          
// 0x000b94a5: dec.s.pri      
// 0x000b94a6: jsgeq          
// 0x000b94a7: push.pri       
// 0x000b94a8: push.c         0x-137fd8ff ""
// 0x000b94ad: op198          
// 0x000b94ae: op214          
// 0x000b94af: eq.c.alt       
// 0x000b94b0: push.c         0x-7ff3d900 ""
// 0x000b94b5: emit           
// 0x000b94b6: eq.pri         
// 0x000b94b7: mod            
// 0x000b94b8: stack          -2129188080
// 0x000b94bd: load.i         
// 0x000b94be: const.alt      -1091381632
// 0x000b94c3: shr.alt        
// 0x000b94c4: load.s.pri     2038438142
// 0x000b94c9: eq.pri         
// 0x000b94ca: op245          
// 0x000b94cb: stor.i         
// 0x000b94cc: idxaddr        
// 0x000b94cd: move.alt       
// 0x000b94ce: load.i         
// 0x000b94cf: eq.pri         
// 0x000b94d0: neg            
// 0x000b94d1: eq.pri         
// 0x000b94d2: mul.c          
// 0x000b94d3: dec.s.pri      
// 0x000b94d4: jgeq           0x27012724
// 0x000b94d9: eq.pri         
// 0x000b94da: op236          
// 0x000b94db: op198          
// 0x000b94dc: op215          
// 0x000b94dd: retn           
// 0x000b94de: push.c         0x-7ff3d900 ""
// 0x000b94e3: emit           
// 0x000b94e4: eq.pri         
// 0x000b94e5: mod            
// 0x000b94e6: stack          -2129188080
// 0x000b94eb: load.i         
// 0x000b94ec: const.alt      -1091381632
// 0x000b94f1: shr.alt        
// 0x000b94f2: load.s.pri     2038438142
// 0x000b94f7: eq.pri         
// 0x000b94f8: op245          
// 0x000b94f9: stor.i         
// 0x000b94fa: idxaddr        
// 0x000b94fb: move.alt       
// 0x000b94fc: load.i         
// 0x000b94fd: eq.pri         
// 0x000b94fe: neg            
// 0x000b94ff: eq.pri         
// 0x000b9500: mul.c          
// 0x000b9501: dec.s.pri      
// 0x000b9502: shl.pri        
// 0x000b9503: push.pri       
// 0x000b9504: push.c         0x-137fd8ff ""
// 0x000b9509: op198          
// 0x000b950a: op215          
// 0x000b950b: cmps           
// 0x000b950c: push.c         0x-7ff3d900 ""
// 0x000b9511: emit           
// 0x000b9512: eq.pri         
// 0x000b9513: mod            
// 0x000b9514: stack          -2129188080
// 0x000b9519: load.i         
// 0x000b951a: push.c         0xc012720 ""
// SetPlayerLookAt @ 0xc8dc-0xcd48 (1132 bytes)
// Source: fly.inc

stock SetPlayerLookAt()
{
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // const.alt 204022793
    // stack 201949452
    // stor.alt 204022793
    // stack 201949452
    // stack 654934284
    return 1;
    // const.alt -504506752
    // stack 201949456
    // stack 201949452
    // stack 201949452
    // const.alt 204022793
    // stack 185172236
    // stack 185172236
    // stack 671711500
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // const.alt 204022793
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // const.alt 204022793
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // stack 201949452
    // const.alt 204022793
    // stack 654934284
    // load.pri 213551155
    return 1;
    // stack 201949452
    return 1;
    // stack 201949452
    return 1;
    // stack 201949452
    return 1;
    // const.alt 204022793
    // stack 654934284
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
}

// --- disasm (first 80) ---
// 0x0000c8dc: push.pri       
// 0x0000c8dd: push.s         -2146949364
// 0x0000c8e2: emit           
// 0x0000c8e3: eq.pri         
// 0x0000c8e4: geq            
// 0x0000c8e5: stack          201949452
// 0x0000c8ea: eq.pri         
// 0x0000c8eb: op214          
// 0x0000c8ec: op235          
// 0x0000c8ed: op210          
// 0x0000c8ee: sref.alt       2038435843
// 0x0000c8f3: lref.pri       -2146885093
// 0x0000c8f8: neg            
// 0x0000c8f9: eq.pri         
// 0x0000c8fa: mul.c          
// 0x0000c8fb: load.s.alt     204022793
// 0x0000c900: push.c         0x-7f847ff8 ""
// 0x0000c905: geq            
// 0x0000c906: stack          201949452
// 0x0000c90b: eq.pri         
// 0x0000c90c: op214          
// 0x0000c90d: op235          
// 0x0000c90e: op210          
// 0x0000c90f: mul            
// 0x0000c910: load.s.pri     91848720
// 0x0000c915: idxaddr        
// 0x0000c916: move.alt       
// 0x0000c917: load.i         
// 0x0000c918: eq.pri         
// 0x0000c919: neg            
// 0x0000c91a: eq.pri         
// 0x0000c91b: mul.c          
// 0x0000c91c: load.s.alt     204022793
// 0x0000c921: push.c         0x-7f847ff8 ""
// 0x0000c926: geq            
// 0x0000c927: stack          201949452
// 0x0000c92c: eq.pri         
// 0x0000c92d: op214          
// 0x0000c92e: op235          
// 0x0000c92f: op210          
// 0x0000c930: mul            
// 0x0000c931: load.s.pri     91848720
// 0x0000c936: idxaddr        
// 0x0000c937: move.alt       
// 0x0000c938: load.i         
// 0x0000c939: eq.pri         
// 0x0000c93a: neg            
// 0x0000c93b: eq.pri         
// 0x0000c93c: mul.c          
// 0x0000c93d: lref.s.alt     204022793
// 0x0000c942: push.c         0x-7f847ff8 ""
// 0x0000c947: geq            
// 0x0000c948: stack          201949452
// 0x0000c94d: eq.pri         
// 0x0000c94e: op214          
// 0x0000c94f: op235          
// 0x0000c950: op210          
// 0x0000c951: mul            
// 0x0000c952: load.s.pri     91848720
// 0x0000c957: idxaddr        
// 0x0000c958: move.alt       
// 0x0000c959: load.i         
// 0x0000c95a: eq.pri         
// 0x0000c95b: neg            
// 0x0000c95c: eq.pri         
// 0x0000c95d: mul.c          
// 0x0000c95e: const.alt      204022793
// 0x0000c963: push.c         0x-7f847ff8 ""
// 0x0000c968: geq            
// 0x0000c969: stack          201949452
// 0x0000c96e: eq.pri         
// 0x0000c96f: op214          
// 0x0000c970: op235          
// 0x0000c971: op210          
// 0x0000c972: mul            
// 0x0000c973: load.s.pri     91848720
// 0x0000c978: idxaddr        
// 0x0000c979: move.alt       
// 0x0000c97a: load.i         
// 0x0000c97b: eq.pri         
// OnPlayerClickPlayerTextDraw @ 0x99680-0x9f1f0 (23408 bytes)
// Source: system_auction.pwn

public OnPlayerClickPlayerTextDraw()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00099680: sysreq.pri     
// 0x00099681: load.s.pri     -2122743796
// 0x00099686: sysreq.c       
// 0x00099687: idxaddr        
// 0x00099688: move.alt       
// 0x00099689: load.i         
// 0x0009968a: eq.pri         
// 0x0009968b: neg            
// 0x0009968c: eq.pri         
// 0x0009968d: mul.c          
// 0x0009968e: dec.s.alt      
// 0x0009968f: or             
// 0x00099690: push.pri       
// 0x00099691: push.c         0x-19481380 ""
// 0x00099696: jneq           0x-7e807ed9
// 0x0009969b: lref.pri       271020279
// 0x000996a0: eq.pri         
// 0x000996a1: emit           
// 0x000996a2: push.alt       
// 0x000996a3: stack          654934292
// 0x000996a8: eq.pri         
// 0x000996a9: op236          
// 0x000996aa: op183          
// 0x000996ab: op234          
// 0x000996ac: lref.s.alt     -1209237465
// 0x000996b1: op233          
// 0x000996b2: leq            
// 0x000996b3: eq.alt         661714693
// 0x000996b8: eq.pri         
// 0x000996b9: op236          
// 0x000996ba: op183          
// 0x000996bb: op232          
// 0x000996bc: div.c          
// 0x000996bd: push.c         0x29002700 ""
// 0x000996c2: const.alt      -2127487961
// 0x000996c7: push.pri       
// 0x000996c8: op195          
// 0x000996c9: add            
// 0x000996ca: eq.alt         -327145719
// 0x000996cf: op183          
// 0x000996d0: op234          
// 0x000996d1: const.alt      -2122254297
// 0x000996d6: sign.alt       
// 0x000996d7: push.s         -2146687220
// 0x000996dc: emit           
// 0x000996dd: eq.pri         
// 0x000996de: xor            
// 0x000996df: stack          654934288
// 0x000996e4: eq.pri         
// 0x000996e5: op236          
// 0x000996e6: op183          
// 0x000996e7: op237          
// 0x000996e8: shl.pri        
// 0x000996e9: push.c         0x7f8180f8 ""
// 0x000996ee: push.s         -2146687220
// 0x000996f3: emit           
// 0x000996f4: eq.pri         
// 0x000996f5: xor            
// 0x000996f6: stack          654934288
// 0x000996fb: load.pri       -2144927449
// 0x00099700: op236          
// 0x00099701: op183          
// 0x00099702: op240          
// 0x00099703: lref.s.alt     688432935
// 0x00099708: const.alt      -2127490009
// 0x0009970d: push.pri       
// 0x0009970e: op201          
// 0x0009970f: or             
// 0x00099710: eq.alt         -696251383
// 0x00099715: op199          
// 0x00099716: op219          
// 0x00099717: sysreq.pri     
// 0x00099718: load.s.pri     -2122743796
// 0x0009971d: sysreq.c       
// 0x0009971e: idxaddr        
// 0x0009971f: move.alt       
// 0x00099720: load.i         
// 0x00099721: eq.pri         
// 0x00099722: neg            
// 0x00099723: eq.pri         
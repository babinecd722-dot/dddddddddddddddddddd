// OnPlayerPickUpPickup @ 0xdd5c-0xdf90 (564 bytes)
// Source: system_pickup.pwn

public OnPlayerPickUpPickup()
{
    // stack 654934284
    // load.pri -338264052
}

// --- disasm (first 80) ---
// 0x0000dd5c: lref.s.alt     1971354496
// 0x0000dd61: stack          654934284
// 0x0000dd66: load.pri       -338264052
// 0x0000dd6b: op210          
// 0x0000dd6c: mul            
// 0x0000dd6d: load.s.pri     91848716
// 0x0000dd72: idxaddr        
// 0x0000dd73: move.alt       
// 0x0000dd74: load.i         
// 0x0000dd75: eq.pri         
// 0x0000dd76: neg            
// 0x0000dd77: eq.pri         
// 0x0000dd78: mul.c          
// 0x0000dd79: load.s.alt     136782857
// 0x0000dd7e: eq.pri         
// 0x0000dd7f: emit           
// 0x0000dd80: eq.pri         
// 0x0000dd81: halt           
// 0x0000dd82: stack          201949452
// 0x0000dd87: eq.pri         
// 0x0000dd88: op214          
// 0x0000dd89: op235          
// 0x0000dd8a: op210          
// 0x0000dd8b: mul            
// 0x0000dd8c: load.s.pri     91848716
// 0x0000dd91: idxaddr        
// 0x0000dd92: move.alt       
// 0x0000dd93: load.i         
// 0x0000dd94: eq.pri         
// 0x0000dd95: neg            
// 0x0000dd96: eq.pri         
// 0x0000dd97: mul.c          
// 0x0000dd98: lref.s.alt     -696244444
// 0x0000dd9d: op239          
// 0x0000dd9e: op180          
// 0x0000dd9f: or             
// 0x0000dda0: push.c         0x-697e667c ""
// 0x0000dda5: addr.pri       -1147501529
// 0x0000ddaa: retn           
// 0x0000ddab: halt           
// 0x0000ddac: push.c         0x-7f847ff4 ""
// 0x0000ddb1: eq.c.pri       
// 0x0000ddb2: stack          -2129188080
// 0x0000ddb7: load.i         
// 0x0000ddb8: push.c         0x-620f037d ""
// 0x0000ddbd: jnz            0x-140a7cd9
// 0x0000ddc2: op246          
// 0x0000ddc3: div            
// 0x0000ddc4: const.alt      -756296064
// 0x0000ddc9: mul            
// 0x0000ddca: load.s.pri     91848716
// 0x0000ddcf: idxaddr        
// 0x0000ddd0: move.alt       
// 0x0000ddd1: load.i         
// 0x0000ddd2: eq.pri         
// 0x0000ddd3: neg            
// 0x0000ddd4: eq.pri         
// 0x0000ddd5: mul.c          
// 0x0000ddd6: lref.s.alt     203891721
// 0x0000dddb: eq.pri         
// 0x0000dddc: emit           
// 0x0000dddd: eq.pri         
// 0x0000ddde: eq.c.alt       
// 0x0000dddf: stack          654934288
// 0x0000dde4: load.alt       -338264052
// 0x0000dde9: op210          
// 0x0000ddea: mul            
// 0x0000ddeb: load.s.pri     91848716
// 0x0000ddf0: idxaddr        
// 0x0000ddf1: move.alt       
// 0x0000ddf2: load.i         
// 0x0000ddf3: eq.pri         
// 0x0000ddf4: neg            
// 0x0000ddf5: eq.pri         
// 0x0000ddf6: mul.c          
// 0x0000ddf7: lref.s.alt     136782857
// 0x0000ddfc: eq.pri         
// 0x0000ddfd: emit           
// 0x0000ddfe: eq.pri         
// 0x0000ddff: inc            
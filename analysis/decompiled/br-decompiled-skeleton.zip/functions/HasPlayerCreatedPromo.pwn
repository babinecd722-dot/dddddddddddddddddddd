// HasPlayerCreatedPromo @ 0x58aa8-0x58c04 (348 bytes)
// Source: system_new_promo.pwn

stock HasPlayerCreatedPromo()
{
    // stack 654934284
    // const.pri 806104065
    // load.alt 747812917
    // branch jnz -> 0x-47c9e7d4
    // const.pri -810824576
    // branch jnz -> 0x-47c9e7d4
    // const.pri -810824576
    // branch jnz -> 0x-47c9e7d4
    // const.pri -810824576
    // const.alt 1317013794
    // const.alt 1317013794
    // const.alt 1317013794
    // branch jnz -> 0x-47c9e7d4
    // branch jump -> 191401912
    // load.pri 814790709
}

// --- disasm (first 80) ---
// 0x00058aa8: push.s         -2147211508
// 0x00058aad: emit           
// 0x00058aae: eq.alt         -2130170778
// 0x00058ab3: load.i         
// 0x00058ab4: push.c         0x277c2900 ""
// 0x00058ab9: lref.s.alt     1954642816
// 0x00058abe: stack          654934284
// 0x00058ac3: op0            
// 0x00058ac4: push.s         -2146949364
// 0x00058ac9: emit           
// 0x00058aca: eq.alt         -2129908727
// 0x00058acf: load.i         
// 0x00058ad0: const.pri      806104065
// 0x00058ad5: eq.alt         -2146434295
// 0x00058ada: grtr           
// 0x00058adb: load.alt       747812917
// 0x00058ae0: eq.alt         -864023799
// 0x00058ae5: op171          
// 0x00058ae6: op207          
// 0x00058ae7: zero.pri       
// 0x00058ae8: move.alt       
// 0x00058ae9: load.i         
// 0x00058aea: eq.pri         
// 0x00058aeb: neg            
// 0x00058aec: eq.pri         
// 0x00058aed: mul.c          
// 0x00058aee: lref.s.alt     -2146753527
// 0x00058af3: op204          
// 0x00058af4: op171          
// 0x00058af5: op207          
// 0x00058af6: zero.pri       
// 0x00058af7: move.alt       
// 0x00058af8: load.i         
// 0x00058af9: eq.pri         
// 0x00058afa: neg            
// 0x00058afb: eq.pri         
// 0x00058afc: mul.c          
// 0x00058afd: load.s.alt     -2146753527
// 0x00058b02: op204          
// 0x00058b03: op171          
// 0x00058b04: op207          
// 0x00058b05: zero.pri       
// 0x00058b06: move.alt       
// 0x00058b07: load.i         
// 0x00058b08: eq.pri         
// 0x00058b09: neg            
// 0x00058b0a: load.i         
// 0x00058b0b: push.pri       
// 0x00058b0c: push.c         0x-7f7f7e7c ""
// 0x00058b11: op0            
// 0x00058b12: push.s         -2146162932
// 0x00058b17: emit           
// 0x00058b18: jnz            0x-47c9e7d4
// 0x00058b1d: push.r         
// 0x00058b1e: or             
// 0x00058b1f: const.pri      -810824576
// 0x00058b24: zero.pri       
// 0x00058b25: eq.pri         
// 0x00058b26: mul.c          
// 0x00058b27: load.s.alt     1317013794
// 0x00058b2c: eq.pri         
// 0x00058b2d: mul.c          
// 0x00058b2e: lref.s.alt     -2146753527
// 0x00058b33: op204          
// 0x00058b34: op171          
// 0x00058b35: op207          
// 0x00058b36: zero.pri       
// 0x00058b37: eq.pri         
// 0x00058b38: mul.c          
// 0x00058b39: load.s.alt     1317013794
// 0x00058b3e: eq.pri         
// 0x00058b3f: mul.c          
// 0x00058b40: load.s.alt     -2146753527
// 0x00058b45: op204          
// 0x00058b46: op171          
// 0x00058b47: op207          
// 0x00058b48: zero.pri       
// 0x00058b49: eq.pri         
// 0x00058b4a: mul.c          
// 0x00058b4b: load.s.alt     1317013794
// GetVehicleRGBAColorById @ 0x14dbc-0x14e3c (128 bytes)
// Source: test.pwn

stock GetVehicleRGBAColorById()
{
    // stack 136782857
    // stack 201949452
    // const.alt 2038434819
    // const.alt -494061697
    // const.alt 2038434819
    // stack 136782857
    // stack 201949452
    // const.alt 2038434819
}

// --- disasm (first 80) ---
// 0x00014dbc: eq.pri         
// 0x00014dbd: sysreq.c       
// 0x00014dbe: lref.pri       -2146885093
// 0x00014dc3: neg            
// 0x00014dc4: eq.pri         
// 0x00014dc5: mul.c          
// 0x00014dc6: stack          136782857
// 0x00014dcb: eq.pri         
// 0x00014dcc: emit           
// 0x00014dcd: eq.pri         
// 0x00014dce: sshr           
// 0x00014dcf: stack          201949452
// 0x00014dd4: eq.pri         
// 0x00014dd5: op214          
// 0x00014dd6: op238          
// 0x00014dd7: nop            
// 0x00014dd8: const.alt      2038434819
// 0x00014ddd: lref.pri       -2146885093
// 0x00014de2: neg            
// 0x00014de3: eq.pri         
// 0x00014de4: mul.c          
// 0x00014de5: push.pri       
// 0x00014de6: load.i         
// 0x00014de7: const.alt      -494061697
// 0x00014dec: shl.pri        
// 0x00014ded: eq.alt         -696251383
// 0x00014df2: op235          
// 0x00014df3: op214          
// 0x00014df4: sysreq.pri     
// 0x00014df5: load.s.pri     91848716
// 0x00014dfa: idxaddr        
// 0x00014dfb: move.alt       
// 0x00014dfc: load.i         
// 0x00014dfd: eq.pri         
// 0x00014dfe: neg            
// 0x00014dff: eq.pri         
// 0x00014e00: mul.c          
// 0x00014e01: load.s.alt     -2146687991
// 0x00014e06: op214          
// 0x00014e07: op238          
// 0x00014e08: nop            
// 0x00014e09: const.alt      2038434819
// 0x00014e0e: lref.pri       -2146885093
// 0x00014e13: neg            
// 0x00014e14: eq.pri         
// 0x00014e15: mul.c          
// 0x00014e16: stack          136782857
// 0x00014e1b: eq.pri         
// 0x00014e1c: emit           
// 0x00014e1d: eq.pri         
// 0x00014e1e: sshr           
// 0x00014e1f: stack          201949452
// 0x00014e24: eq.pri         
// 0x00014e25: op214          
// 0x00014e26: op238          
// 0x00014e27: nop            
// 0x00014e28: const.alt      2038434819
// 0x00014e2d: lref.pri       -2146885093
// 0x00014e32: neg            
// 0x00014e33: eq.pri         
// 0x00014e34: mul.c          
// 0x00014e35: push           931073033
// 0x00014e3a: push.pri       
// 0x00014e3b: op228          
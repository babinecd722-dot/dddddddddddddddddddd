// DestroyVehicleLabel @ 0xf0f0-0xf234 (324 bytes)
// Source: system_vehicle.pwn

stock DestroyVehicleLabel()
{
    // stack 185172236
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 654934284
    // const.pri -403974528
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949456
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack 201949452
    // const.alt -2146687991
    // const.alt 2038434819
    // stack 201949452
}

// --- disasm (first 80) ---
// 0x0000f0f0: lref.pri       -2146885093
// 0x0000f0f5: neg            
// 0x0000f0f6: eq.pri         
// 0x0000f0f7: mul.c          
// 0x0000f0f8: sctrl          136782857
// 0x0000f0fd: eq.pri         
// 0x0000f0fe: emit           
// 0x0000f0ff: eq.pri         
// 0x0000f100: sshr           
// 0x0000f101: stack          185172236
// 0x0000f106: eq.pri         
// 0x0000f107: op214          
// 0x0000f108: op235          
// 0x0000f109: op231          
// 0x0000f10a: jsgeq          
// 0x0000f10b: push.pri       
// 0x0000f10c: const.alt      -1561405824
// 0x0000f111: const.alt      2038434819
// 0x0000f116: lref.pri       -2146885093
// 0x0000f11b: neg            
// 0x0000f11c: eq.pri         
// 0x0000f11d: mul.c          
// 0x0000f11e: sctrl          -2122743799
// 0x0000f123: sysreq.c       
// 0x0000f124: pop.alt        
// 0x0000f125: idxaddr        
// 0x0000f126: load.i         
// 0x0000f127: push.pri       
// 0x0000f128: const.alt      -1561405824
// 0x0000f12d: const.alt      2038434819
// 0x0000f132: lref.pri       -2146885093
// 0x0000f137: neg            
// 0x0000f138: eq.pri         
// 0x0000f139: mul.c          
// 0x0000f13a: sctrl          136782857
// 0x0000f13f: eq.pri         
// 0x0000f140: emit           
// 0x0000f141: eq.pri         
// 0x0000f142: grtr           
// 0x0000f143: stack          654934284
// 0x0000f148: eq.pri         
// 0x0000f149: op214          
// 0x0000f14a: op239          
// 0x0000f14b: op188          
// 0x0000f14c: or             
// 0x0000f14d: const.pri      -403974528
// 0x0000f152: jsgeq          
// 0x0000f153: push.pri       
// 0x0000f154: const.alt      -1561405824
// 0x0000f159: const.alt      2038434819
// 0x0000f15e: lref.pri       -2146885093
// 0x0000f163: neg            
// 0x0000f164: eq.pri         
// 0x0000f165: mul.c          
// 0x0000f166: sctrl          -2122743799
// 0x0000f16b: sysreq.c       
// 0x0000f16c: pop.alt        
// 0x0000f16d: idxaddr        
// 0x0000f16e: load.i         
// 0x0000f16f: push.pri       
// 0x0000f170: const.alt      -1561405824
// 0x0000f175: const.alt      2038434819
// 0x0000f17a: lref.pri       -2146885093
// 0x0000f17f: neg            
// 0x0000f180: eq.pri         
// 0x0000f181: mul.c          
// 0x0000f182: sctrl          203891721
// 0x0000f187: eq.pri         
// 0x0000f188: emit           
// 0x0000f189: eq.pri         
// 0x0000f18a: eq             
// 0x0000f18b: stack          201949456
// 0x0000f190: eq.pri         
// 0x0000f191: op214          
// 0x0000f192: op235          
// 0x0000f193: op210          
// 0x0000f194: mul            
// 0x0000f195: load.s.pri     91848716
// 0x0000f19a: idxaddr        
// 0x0000f19b: move.alt       
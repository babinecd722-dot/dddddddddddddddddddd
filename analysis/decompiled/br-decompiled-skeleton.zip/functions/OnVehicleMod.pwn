// OnVehicleMod @ 0xdc824-0xdc85c (56 bytes)
// Source: test.pwn

public OnVehicleMod()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000dc824: op204          
// 0x000dc825: jump           
// 0x000dc826: op252          
// 0x000dc827: add            
// 0x000dc828: load.s.pri     -2122743684
// 0x000dc82d: sysreq.c       
// 0x000dc82e: idxaddr        
// 0x000dc82f: move.alt       
// 0x000dc830: load.i         
// 0x000dc831: eq.pri         
// 0x000dc832: neg            
// 0x000dc833: push.pri       
// 0x000dc834: push.c         0x-442f1380 ""
// 0x000dc839: sctrl          -1617001433
// 0x000dc83e: push.c         
// 0x000dc83f: jneq           0x-2d637bd9
// 0x000dc844: op179          
// 0x000dc845: sref.pri       271023145
// 0x000dc84a: eq.pri         
// 0x000dc84b: emit           
// 0x000dc84c: eq.pri         
// 0x000dc84d: sysreq.c       
// 0x000dc84e: stack          -2129188076
// 0x000dc853: load.i         
// 0x000dc854: push.c         0x-5d18037d ""
// 0x000dc859: neg            
// 0x000dc85a: push.c         0x-6a1a0a7d ""
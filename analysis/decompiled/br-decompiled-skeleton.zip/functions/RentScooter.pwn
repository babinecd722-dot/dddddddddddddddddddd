// RentScooter @ 0xbb59c-0xbb844 (680 bytes)
// Source: test.pwn

stock RentScooter()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000bb59c: push.c         0x-137fd8ff ""
// 0x000bb5a1: op199          
// 0x000bb5a2: halt.p         native#662448496 args=-2139389940
// 0x000bb5ab: mod            
// 0x000bb5ac: stack          -2129188080
// 0x000bb5b1: load.i         
// 0x000bb5b2: const.alt      -404169600
// 0x000bb5b7: sysreq.pri     
// 0x000bb5b8: load.s.pri     -2022080388
// 0x000bb5bd: load.s.pri     -2146885093
// 0x000bb5c2: neg            
// 0x000bb5c3: eq.pri         
// 0x000bb5c4: mul.c          
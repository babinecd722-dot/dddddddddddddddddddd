// UpdateAskText @ 0x15208-0x153b4 (428 bytes)
// Source: test.pwn

stock UpdateAskText()
{
    // const.alt 391741474
    // const.alt 2038434819
    // const.alt 2038434819
    // stack 931073033
    // stack 204016001
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 136782857
    call_0x0x332cc48e();
    // branch jneq -> 0x-72f0fd7f
    // branch jneq -> 0x8f28901
    // load.alt 52483978
    // stor.pri 856749709
    // stor.alt -2146694783
    // const.alt 2038434819
    // branch jnz -> 0x-7e8b5172
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt 2038434819
    // const.alt 385944354
    call_0x0x-7e8f1c72();
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack -696244444
    // stack 654934284
    // branch jump -> -2126446963
}

// --- disasm (first 80) ---
// 0x00015208: neg            
// 0x00015209: eq.pri         
// 0x0001520a: mul.c          
// 0x0001520b: const.alt      391741474
// 0x00015210: eq.alt         -696251383
// 0x00015215: op238          
// 0x00015216: nop            
// 0x00015217: const.alt      2038434819
// 0x0001521c: lref.pri       -2146885093
// 0x00015221: neg            
// 0x00015222: eq.pri         
// 0x00015223: mul.c          
// 0x00015224: load.s.alt     391741474
// 0x00015229: eq.alt         -696251383
// 0x0001522e: op238          
// 0x0001522f: nop            
// 0x00015230: const.alt      2038434819
// 0x00015235: lref.pri       -2146885093
// 0x0001523a: neg            
// 0x0001523b: eq.pri         
// 0x0001523c: mul.c          
// 0x0001523d: stack          931073033
// 0x00015242: push.pri       
// 0x00015243: op248          
// 0x00015244: stack          204016001
// 0x00015249: const.alt      -1561405824
// 0x0001524e: const.alt      2038434819
// 0x00015253: lref.pri       -2146885093
// 0x00015258: neg            
// 0x00015259: eq.pri         
// 0x0001525a: mul.c          
// 0x0001525b: stack          136782857
// 0x00015260: call           0x332cc48e
// 0x00015265: push.pri       
// 0x00015266: op249          
// 0x00015267: jneq           0x-72f0fd7f
// 0x0001526c: op249          
// 0x0001526d: jneq           0x8f28901
// 0x00015272: load.alt       52483978
// 0x00015277: halt.p         native#-1962641267 args=-1945817923
// 0x00015280: cmps.i         
// 0x00015281: strb.i         1218350086
// 0x00015286: lref.s.pri     137146764
// 0x0001528b: push.pri       
// 0x0001528c: op203          
// 0x0001528d: load.s.alt     1961200905
// 0x00015292: lodb.i         189064845
// 0x00015297: push.pri       
// 0x00015298: op231          
// 0x00015299: sref.alt       1290833164
// 0x0001529e: addr.pri       238613133
// 0x000152a3: push.pri       
// 0x000152a4: op244          
// 0x000152a5: push.pri       
// 0x000152a6: stor.pri       856749709
// 0x000152ab: push.alt       
// 0x000152ac: op177          
// 0x000152ad: stor.alt       -2146694783
// 0x000152b2: op214          
// 0x000152b3: op238          
// 0x000152b4: nop            
// 0x000152b5: const.alt      2038434819
// 0x000152ba: lref.pri       -2146885093
// 0x000152bf: neg            
// 0x000152c0: eq.pri         
// 0x000152c1: mul.c          
// 0x000152c2: lref.s.alt     -2147415031
// 0x000152c7: invert         
// 0x000152c8: jnz            0x-7e8b5172
// 0x000152cd: load.i         
// 0x000152ce: const.alt      -1561405824
// 0x000152d3: const.alt      2038434819
// 0x000152d8: lref.pri       -2146885093
// 0x000152dd: neg            
// 0x000152de: eq.pri         
// 0x000152df: mul.c          
// 0x000152e0: load.s.alt     385944354
// 0x000152e5: eq.alt         -696251383
// 0x000152ea: op238          
// 0x000152eb: nop            
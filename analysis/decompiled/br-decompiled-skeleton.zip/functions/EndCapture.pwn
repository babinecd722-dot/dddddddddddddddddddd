// EndCapture @ 0x29c528-0x29cae4 (1468 bytes)
// Source: test.pwn

stock EndCapture()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0029c528: call.pri       
// 0x0029c529: eq.c.alt       
// 0x0029c52a: eq.alt         -2126464518
// 0x0029c52f: op250          
// 0x0029c530: op215          
// 0x0029c531: stor.alt       1626667649
// 0x0029c536: eq.alt         -2127523077
// 0x0029c53b: op251          
// 0x0029c53c: op176          
// 0x0029c53d: op0            
// 0x0029c53e: eq.alt         -2125410821
// 0x0029c543: op251          
// 0x0029c544: op235          
// 0x0029c545: sctrl          1888025729
// 0x0029c54a: eq.alt         -2126469380
// 0x0029c54f: op252          
// 0x0029c550: op196          
// 0x0029c551: stor.alt       1625422977
// 0x0029c556: eq.alt         -2127495172
// 0x0029c55b: op253          
// 0x0029c55c: switch         
// 0x0029c55d: op0            
// 0x0029c55e: eq.alt         -2125415683
// 0x0029c563: op253          
// 0x0029c564: op216          
// 0x0029c565: sctrl          1895169409
// 0x0029c56a: eq.alt         -2126474242
// 0x0029c56f: op254          
// 0x0029c570: op177          
// 0x0029c571: stor.alt       1624178305
// 0x0029c576: eq.alt         -2127500034
// 0x0029c57b: op255          
// 0x0029c57c: fill.i         
// 0x0029c57d: op0            
// 0x0029c57e: eq.alt         -2125420545
// 0x0029c583: op255          
// 0x0029c584: op197          
// 0x0029c585: sctrl          1893924737
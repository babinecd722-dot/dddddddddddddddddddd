// pc_cmd_promo @ 0x5a3a8-0x5a524 (380 bytes)
// Source: system_new_promo.pwn

stock pc_cmd_promo()
{
    // branch jzer -> 0x-7ee37b47
    // const.pri 1560023297
    // branch jump -> -2126215751
    // branch jzer -> 0x32485b9
    // const.alt 911310856
    // branch jnz -> 0x-7fff7a47
    // branch jump -> 185107897
    // load.pri -1187687296
    // const.pri -2051460351
}

// --- disasm (first 80) ---
// 0x0005a3a8: inc.s.alt      
// 0x0005a3a9: sysreq.pri     
// 0x0005a3aa: eq.pri         
// 0x0005a3ab: mod.c          
// 0x0005a3ac: jzer           0x-7ee37b47
// 0x0005a3b1: load.i         
// 0x0005a3b2: const.pri      1560023297
// 0x0005a3b7: jump           -2126215751
// 0x0005a3bc: load.i         
// 0x0005a3bd: load.s.pri     537684220
// 0x0005a3c2: eq.pri         
// 0x0005a3c3: sub            
// 0x0005a3c4: jzer           0x32485b9
// 0x0005a3c9: op252          
// 0x0005a3ca: leq            
// 0x0005a3cb: const.alt      911310856
// 0x0005a3d0: op185          
// 0x0005a3d1: dec.s.alt      
// 0x0005a3d2: op0            
// 0x0005a3d3: load.s.pri     -2129893124
// 0x0005a3d8: op0            
// 0x0005a3d9: eq.pri         
// 0x0005a3da: sub            
// 0x0005a3db: jnz            0x-7fff7a47
// 0x0005a3e0: mod.c          
// 0x0005a3e1: jump           185107897
// 0x0005a3e6: load.pri       -1187687296
// 0x0005a3eb: dec.s.alt      
// 0x0005a3ec: push.pri       
// 0x0005a3ed: const.pri      -2051460351
// 0x0005a3f2: push           -1187686016
// 0x0005a3f7: dec.s.alt      
// 0x0005a3f8: shl.pri        
// 0x0005a3f9: eq.alt         285346569
// 0x0005a3fe: op252          
// 0x0005a3ff: mul            
// 0x0005a400: eq.alt         -813691895
// 0x0005a405: push.s         
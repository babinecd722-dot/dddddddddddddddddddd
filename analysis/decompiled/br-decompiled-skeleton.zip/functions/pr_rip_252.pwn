// pr_rip_252 @ 0x2fc6a8-0x2fc6ec (68 bytes)
// Source: test.pwn

stock pr_rip_252()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x002fc6a8: op0            
// 0x002fc6a9: op0            
// 0x002fc6aa: op0            
// 0x002fc6ab: op0            
// 0x002fc6ac: op0            
// 0x002fc6ad: op0            
// 0x002fc6ae: op0            
// 0x002fc6af: op0            
// 0x002fc6b0: op0            
// 0x002fc6b1: op0            
// 0x002fc6b2: op0            
// 0x002fc6b3: op0            
// 0x002fc6b4: op0            
// 0x002fc6b5: op0            
// 0x002fc6b6: op0            
// 0x002fc6b7: op0            
// 0x002fc6b8: op0            
// 0x002fc6b9: op0            
// 0x002fc6ba: op0            
// 0x002fc6bb: op0            
// 0x002fc6bc: op0            
// 0x002fc6bd: op0            
// 0x002fc6be: op0            
// 0x002fc6bf: op0            
// 0x002fc6c0: op0            
// 0x002fc6c1: op0            
// 0x002fc6c2: op0            
// 0x002fc6c3: op0            
// 0x002fc6c4: op0            
// 0x002fc6c5: op0            
// 0x002fc6c6: op0            
// 0x002fc6c7: op0            
// 0x002fc6c8: op0            
// 0x002fc6c9: op0            
// 0x002fc6ca: op0            
// 0x002fc6cb: op0            
// 0x002fc6cc: op0            
// 0x002fc6cd: op0            
// 0x002fc6ce: op0            
// 0x002fc6cf: op0            
// 0x002fc6d0: op0            
// 0x002fc6d1: op0            
// 0x002fc6d2: op0            
// 0x002fc6d3: op0            
// 0x002fc6d4: op0            
// 0x002fc6d5: op0            
// 0x002fc6d6: op0            
// 0x002fc6d7: op0            
// 0x002fc6d8: op0            
// 0x002fc6d9: op0            
// 0x002fc6da: op0            
// 0x002fc6db: op0            
// 0x002fc6dc: op0            
// 0x002fc6dd: op0            
// 0x002fc6de: op0            
// 0x002fc6df: op0            
// 0x002fc6e0: op0            
// 0x002fc6e1: op0            
// 0x002fc6e2: op0            
// 0x002fc6e3: op0            
// 0x002fc6e4: op0            
// 0x002fc6e5: op0            
// 0x002fc6e6: op0            
// 0x002fc6e7: op0            
// 0x002fc6e8: op0            
// 0x002fc6e9: op0            
// 0x002fc6ea: op0            
// 0x002fc6eb: op0            
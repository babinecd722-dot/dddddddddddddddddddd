// prom_OnDialogResponse @ 0x5b11c-0x5cb4c (6704 bytes)
// Source: system_carshare_welsi.pwn

stock prom_OnDialogResponse()
{
    return 1;
    // const.alt -607660416
}

// --- disasm (first 80) ---
// 0x0005b11c: mul.c          
// 0x0005b11d: halt.p         native#656673068 args=-795546496
// 0x0005b126: retn           
// 0x0005b127: push.s         822880012
// 0x0005b12c: eq.alt         -2126214523
// 0x0005b131: load.i         
// 0x0005b132: const.alt      -607660416
// 0x0005b137: sysreq.pri     
// 0x0005b138: load.s.pri     -2122743796
// 0x0005b13d: sysreq.c       
// 0x0005b13e: idxaddr        
// 0x0005b13f: move.alt       
// 0x0005b140: load.i         
// 0x0005b141: eq.pri         
// 0x0005b142: neg            
// 0x0005b143: eq.pri         
// 0x0005b144: mul.c          
// 0x0005b145: halt.p         native#1484785964 args=153560074
// 0x0005b14e: push.s         -2146687220
// 0x0005b153: emit           
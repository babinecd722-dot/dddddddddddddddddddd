// CreatePlTDButtonBR @ 0x68614-0x689bc (936 bytes)
// Source: system_accessory.pwn

stock CreatePlTDButtonBR()
{
    // const.alt -121774720
    // stack 654934292
    // branch jump -> 
    return 1;
    // stack -2130083564
    // stack 277031952
    // branch jump -> 1425402496
    // load.pri -1628667865
    // stack -1048562928
    // branch jrel -> 204022793
}

// --- disasm (first 80) ---
// 0x00068614: zero.pri       
// 0x00068615: const.alt      -121774720
// 0x0006861a: push           2038434819
// 0x0006861f: eq.alt         153230201
// 0x00068624: eq.pri         
// 0x00068625: neg            
// 0x00068626: push.pri       
// 0x00068627: load.s.pri     -2022080488
// 0x0006862c: sign.alt       
// 0x0006862d: pop.alt        
// 0x0006862e: idxaddr        
// 0x0006862f: load.i         
// 0x00068630: stor.s.pri     654934388
// 0x00068635: op0            
// 0x00068636: push.c         0x-7effd900 ""
// 0x0006863b: load.i         
// 0x0006863c: eq.alt         92366853
// 0x00068641: sleq           
// 0x00068642: eq.alt         1948872709
// 0x00068647: push.c         0x2f7b8010 ""
// 0x0006864c: stack          654934292
// 0x00068651: sign.alt       
// 0x00068652: push.c         0x-7f7f787c ""
// 0x00068657: op0            
// 0x00068658: push.s         694954344
// 0x0006865d: eq.c.alt       
// 0x0006865e: push.s         823666444
// 0x00068663: inc.s.alt      
// 0x00068664: jump           
// 0x00068665: retn           
// 0x00068666: eq.alt         16591881
// 0x0006866b: eq.pri         
// 0x0006866c: mod.c          
// 0x0006866d: addr.alt       2004904188
// 0x00068672: inc.s.alt      
// 0x00068673: op0            
// 0x00068674: eq.alt         -696251383
// 0x00068679: op199          
// 0x0006867a: op219          
// 0x0006867b: sysreq.pri     
// 0x0006867c: load.s.pri     -2122743692
// 0x00068681: sysreq.c       
// 0x00068682: idxaddr        
// 0x00068683: move.alt       
// 0x00068684: load.i         
// 0x00068685: eq.pri         
// 0x00068686: neg            
// 0x00068687: eq.pri         
// 0x00068688: mul.c          
// 0x00068689: cmps.i         
// 0x0006868a: mod            
// 0x0006868b: push.pri       
// 0x0006868c: push.c         0x-1c611380 ""
// 0x00068691: or             
// 0x00068692: push.c         0x5816080 ""
// 0x00068697: op252          
// 0x00068698: leq            
// 0x00068699: push.c         0x257b8010 ""
// 0x0006869e: stack          -2130083564
// 0x000686a3: lref.pri       2133289212
// 0x000686a8: push.s         -2146687220
// 0x000686ad: emit           
// 0x000686ae: eq.pri         
// 0x000686af: xor            
// 0x000686b0: stack          277031952
// 0x000686b5: jump           1425402496
// 0x000686ba: eq.alt         -327145719
// 0x000686bf: casetbl        
// 0x000686c0: op229          
// 0x000686c1: mod            
// 0x000686c2: push.s         -2146949364
// 0x000686c7: emit           
// 0x000686c8: jsleq          0x-7fc9f3d4
// 0x000686cd: op193          
// 0x000686ce: op217          
// 0x000686cf: strb.i         -2146694783
// 0x000686d4: op214          
// 0x000686d5: op199          
// 0x000686d6: op219          
// 0x000686d7: sysreq.pri     
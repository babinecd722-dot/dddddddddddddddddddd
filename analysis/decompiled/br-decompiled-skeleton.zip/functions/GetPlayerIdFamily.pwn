// GetPlayerIdFamily @ 0x63b4c-0x63b64 (24 bytes)
// Source: test.pwn

stock GetPlayerIdFamily()
{
    ();
    // stack -2144925311
}

// --- disasm (first 80) ---
// 0x00063b4c: push.s         -2146949364
// 0x00063b51: emit           
// 0x00063b52: eq.alt         -2129908673
// 0x00063b57: load.i         
// 0x00063b58: push.s         822355724
// 0x00063b5d: inc.s.alt      
// 0x00063b5e: sysreq.n       
// 0x00063b5f: stack          -2144925311
// sscanf_vehicle @ 0x1c18-0x65e4 (18892 bytes)
// Source: sscanf2.inc

stock sscanf_vehicle()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00001c18: eq.pri         
// 0x00001c19: mod            
// 0x00001c1a: jzer           0x-7ecb687f
// 0x00001c1f: load.i         
// 0x00001c20: const.pri      -2127554684
// 0x00001c25: load.i         
// 0x00001c26: push.c         0x-79 ""
// 0x00001c2b: sign.alt       
// 0x00001c2c: push.c         0x34b42701 ""
// 0x00001c31: push.s         -2146425076
// 0x00001c36: emit           
// 0x00001c37: stor.s.pri     1417679916
// 0x00001c3c: jzer           0x-7ef3677f
// 0x00001c41: load.i         
// 0x00001c42: const.pri      -2127554428
// 0x00001c47: load.i         
// 0x00001c48: push.c         0x-79 ""
// 0x00001c4d: sign.alt       
// 0x00001c4e: push.c         0x4cb42701 ""
// 0x00001c53: push.s         -2146425076
// 0x00001c58: emit           
// 0x00001c59: stor.s.pri     1417679916
// 0x00001c5e: jzer           0x-7e9b677f
// 0x00001c63: load.i         
// 0x00001c64: const.pri      -2127554172
// 0x00001c69: load.i         
// 0x00001c6a: push.c         0x-79 ""
// 0x00001c6f: sign.alt       
// 0x00001c70: push.c         0xcb52701 ""
// 0x00001c75: push.s         -2146425076
// 0x00001c7a: emit           
// 0x00001c7b: stor.s.pri     1417679916
// 0x00001c80: jzer           0x-7ec3667f
// 0x00001c85: load.i         
// 0x00001c86: const.pri      -2127553916
// 0x00001c8b: load.i         
// 0x00001c8c: push.c         0x-79 ""
// 0x00001c91: sign.alt       
// 0x00001c92: push.c         0x5cb52701 ""
// 0x00001c97: push.s         -2146425076
// 0x00001c9c: emit           
// 0x00001c9d: stor.s.pri     1417679916
// 0x00001ca2: jzer           0x-7eeb657f
// 0x00001ca7: load.i         
// 0x00001ca8: const.pri      -2127553660
// 0x00001cad: load.i         
// 0x00001cae: push.c         0x-79 ""
// 0x00001cb3: sign.alt       
// 0x00001cb4: push.c         0x78b52701 ""
// 0x00001cb9: push.s         -2146425076
// 0x00001cbe: emit           
// 0x00001cbf: stor.s.pri     1417679916
// 0x00001cc4: jzer           0x-7e93657f
// 0x00001cc9: load.i         
// 0x00001cca: const.pri      -2127553404
// 0x00001ccf: load.i         
// 0x00001cd0: push.c         0x-79 ""
// 0x00001cd5: sign.alt       
// 0x00001cd6: push.c         0x18b62701 ""
// 0x00001cdb: push.s         -2146425076
// 0x00001ce0: emit           
// 0x00001ce1: stor.s.pri     1417679916
// 0x00001ce6: jzer           0x-7ebb647f
// 0x00001ceb: load.i         
// 0x00001cec: const.pri      -2127553148
// 0x00001cf1: load.i         
// 0x00001cf2: push.c         0x-79 ""
// 0x00001cf7: sign.alt       
// 0x00001cf8: push.c         0x34b62701 ""
// 0x00001cfd: push.s         -2146425076
// 0x00001d02: emit           
// 0x00001d03: stor.s.pri     1417679916
// 0x00001d08: jzer           0x-7ee3637f
// 0x00001d0d: load.i         
// 0x00001d0e: const.pri      -2127552892
// 0x00001d13: load.i         
// 0x00001d14: push.c         0x-79 ""
// 0x00001d19: sign.alt       
// 0x00001d1a: push.c         0x50b62701 ""
// 0x00001d1f: push.s         -2146425076
// weekly_OnPlayerConnect @ 0x7cb18-0x7cbb4 (156 bytes)
// Source: system_roulette.pwn

stock weekly_OnPlayerConnect()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0007cb18: eq.alt         660665605
// 0x0007cb1d: push.pri       
// 0x0007cb1e: eq.pri         
// 0x0007cb1f: emit           
// 0x0007cb20: push.alt       
// 0x0007cb21: stack          763112744
// 0x0007cb26: op255          
// 0x0007cb27: op0            
// 0x0007cb28: eq.alt         855648009
// 0x0007cb2d: eq.pri         
// 0x0007cb2e: op205          
// 0x0007cb2f: op178          
// 0x0007cb30: eq.c.alt       
// 0x0007cb31: eq.alt         -177307639
// 0x0007cb36: mod            
// 0x0007cb37: load.s.pri     -2129898251
// 0x0007cb3c: file           
// 0x0007cb3d: eq.pri         
// 0x0007cb3e: jsgeq          
// 0x0007cb3f: eq.pri         
// 0x0007cb40: op205          
// 0x0007cb41: op182          
// 0x0007cb42: eq.c.alt       
// 0x0007cb43: eq.alt         1425352969
// 0x0007cb48: push.c         0xa7b8004 ""
// 0x0007cb4d: stack          894730248
// 0x0007cb52: eq.pri         
// 0x0007cb53: op205          
// 0x0007cb54: op179          
// 0x0007cb55: shl.pri        
// 0x0007cb56: eq.alt         -847236343
// 0x0007cb5b: op178          
// 0x0007cb5c: sshr           
// 0x0007cb5d: eq.alt         -696251383
// 0x0007cb62: op199          
// 0x0007cb63: op219          
// 0x0007cb64: sysreq.pri     
// 0x0007cb65: load.s.pri     2038453493
// 0x0007cb6a: eq.alt         153230201
// 0x0007cb6f: eq.pri         
// 0x0007cb70: neg            
// 0x0007cb71: eq.pri         
// 0x0007cb72: mul.c          
// 0x0007cb73: movs.i         
// 0x0007cb74: retn           
// 0x0007cb75: load.i         
// 0x0007cb76: eq.pri         
// 0x0007cb77: mod            
// 0x0007cb78: jzer           0x14b4cd80
// 0x0007cb7d: eq.alt         -847236343
// 0x0007cb82: op178          
// 0x0007cb83: sshr           
// 0x0007cb84: eq.alt         -696251383
// 0x0007cb89: op199          
// 0x0007cb8a: op219          
// 0x0007cb8b: sysreq.pri     
// 0x0007cb8c: load.s.pri     2038453493
// 0x0007cb91: eq.alt         153230201
// 0x0007cb96: eq.pri         
// 0x0007cb97: neg            
// 0x0007cb98: eq.pri         
// 0x0007cb99: mul.c          
// 0x0007cb9a: push.pri       
// 0x0007cb9b: div.c          
// 0x0007cb9c: load.i         
// 0x0007cb9d: jnz            0x60b4cd80
// 0x0007cba2: eq.alt         -847236343
// 0x0007cba7: op178          
// 0x0007cba8: sshr           
// 0x0007cba9: eq.alt         -696251383
// 0x0007cbae: op199          
// 0x0007cbaf: op219          
// 0x0007cbb0: sysreq.pri     
// 0x0007cbb1: load.s.pri     2038453493
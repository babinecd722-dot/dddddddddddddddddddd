// pc_alias_e @ 0x248e98-0x248ed4 (60 bytes)
// Source: test.pwn

stock pc_alias_e()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00248e98: op0            
// 0x00248e99: op0            
// 0x00248e9a: op0            
// 0x00248e9b: op0            
// 0x00248e9c: op0            
// 0x00248e9d: op0            
// 0x00248e9e: op0            
// 0x00248e9f: op0            
// 0x00248ea0: op0            
// 0x00248ea1: op0            
// 0x00248ea2: op0            
// 0x00248ea3: op0            
// 0x00248ea4: op0            
// 0x00248ea5: op0            
// 0x00248ea6: op0            
// 0x00248ea7: op0            
// 0x00248ea8: op0            
// 0x00248ea9: op0            
// 0x00248eaa: op0            
// 0x00248eab: op0            
// 0x00248eac: op0            
// 0x00248ead: op0            
// 0x00248eae: op0            
// 0x00248eaf: op0            
// 0x00248eb0: op0            
// 0x00248eb1: op0            
// 0x00248eb2: op0            
// 0x00248eb3: op0            
// 0x00248eb4: op0            
// 0x00248eb5: op0            
// 0x00248eb6: op0            
// 0x00248eb7: op0            
// 0x00248eb8: op0            
// 0x00248eb9: op0            
// 0x00248eba: op0            
// 0x00248ebb: op0            
// 0x00248ebc: op0            
// 0x00248ebd: op0            
// 0x00248ebe: op0            
// 0x00248ebf: op0            
// 0x00248ec0: op0            
// 0x00248ec1: op0            
// 0x00248ec2: op0            
// 0x00248ec3: op0            
// 0x00248ec4: op0            
// 0x00248ec5: op0            
// 0x00248ec6: op0            
// 0x00248ec7: op0            
// 0x00248ec8: op0            
// 0x00248ec9: op0            
// 0x00248eca: op0            
// 0x00248ecb: op0            
// 0x00248ecc: op0            
// 0x00248ecd: op0            
// 0x00248ece: op0            
// 0x00248ecf: op0            
// 0x00248ed0: op0            
// 0x00248ed1: op0            
// 0x00248ed2: op0            
// 0x00248ed3: op0            
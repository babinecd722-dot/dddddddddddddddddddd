// pc_alias_anim @ 0x248e5c-0x248e98 (60 bytes)
// Source: test.pwn

stock pc_alias_anim()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00248e5c: op0            
// 0x00248e5d: op0            
// 0x00248e5e: op0            
// 0x00248e5f: op0            
// 0x00248e60: op0            
// 0x00248e61: op0            
// 0x00248e62: op0            
// 0x00248e63: op0            
// 0x00248e64: op0            
// 0x00248e65: op0            
// 0x00248e66: op0            
// 0x00248e67: op0            
// 0x00248e68: op0            
// 0x00248e69: op0            
// 0x00248e6a: op0            
// 0x00248e6b: op0            
// 0x00248e6c: op0            
// 0x00248e6d: op0            
// 0x00248e6e: op0            
// 0x00248e6f: op0            
// 0x00248e70: op0            
// 0x00248e71: op0            
// 0x00248e72: op0            
// 0x00248e73: op0            
// 0x00248e74: op0            
// 0x00248e75: op0            
// 0x00248e76: op0            
// 0x00248e77: op0            
// 0x00248e78: op0            
// 0x00248e79: op0            
// 0x00248e7a: op0            
// 0x00248e7b: op0            
// 0x00248e7c: op0            
// 0x00248e7d: op0            
// 0x00248e7e: op0            
// 0x00248e7f: op0            
// 0x00248e80: op0            
// 0x00248e81: op0            
// 0x00248e82: op0            
// 0x00248e83: op0            
// 0x00248e84: op0            
// 0x00248e85: op0            
// 0x00248e86: op0            
// 0x00248e87: op0            
// 0x00248e88: op0            
// 0x00248e89: op0            
// 0x00248e8a: op0            
// 0x00248e8b: op0            
// 0x00248e8c: op0            
// 0x00248e8d: op0            
// 0x00248e8e: op0            
// 0x00248e8f: op0            
// 0x00248e90: op0            
// 0x00248e91: op0            
// 0x00248e92: op0            
// 0x00248e93: op0            
// 0x00248e94: op0            
// 0x00248e95: op0            
// 0x00248e96: op0            
// 0x00248e97: op0            
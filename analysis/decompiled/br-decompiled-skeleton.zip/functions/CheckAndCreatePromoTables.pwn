// CheckAndCreatePromoTables @ 0x4757c-0x48340 (3524 bytes)
// Source: system_new_promo.pwn

stock CheckAndCreatePromoTables()
{
    // stack -1943591924
    // stor.alt -1129872345
    // stack 654934308
    return 1;
    // stack -1943591924
    // stack 654934308
    // branch jump -> 
    call_0x0x-7ecf207f();
    return 1;
    call_0x();
    // branch jrel -> -2019195865
    // load.alt -1314487257
    // const.pri -1993926873
    // stor.pri -90518400
    return 1;
    // stack 159465600
    call_0x();
    // stack -1943591924
    // branch jzer -> 0x-205c7bd9
    // stack 159465600
    // load.pri -1297775577
    // branch jzer -> 0x-205c7bd9
    // stor.pri -422393472
    // stor.pri -1835086720
    // stack -1943591924
    // stack 159465600
    // stor.pri -1835086720
    // stack -1943591924
    // stor.pri 2139225127
    // stack 159465600
    // stor.pri -1977149657
    // stor.pri -1835086720
    // stack -1943591924
    ();
    // stack 159465600
    // stor.pri -1835086720
    // stack -1943591924
    // stack 159465600
    // stor.pri -1835086720
    // stack -1943591924
    // const.pri 2139225127
    // stack 159465600
    // const.pri -1977149657
    // stor.pri -1835086720
    // stack 159465600
    // const.pri -864022783
    // branch jump -> 
    // stack 159465600
    // stor.pri -56832896
    // stor.pri -526398336
    // branch jneq -> 0x-6f737bd9
    // stor.pri -240679897
    // branch jeq -> 0x-2c567bd9
    // stor.pri -526398336
    // proc @0x47b5b
    // stor.pri -1835086720
    // branch jneq -> 0x270981
    // proc @0x47b8a
    // stack 654934308
    // stor.pri -1835086720
    // stack 654934308
    // stor.pri -1112814464
    // proc @0x47c47
    // stack 654934308
    // stor.pri -1112814464
    // stack 654934308
    return 1;
    // stor.pri -1196766080
    return 1;
    // stack -1943591924
    // stack 
    // stack 159465600
    // stor.pri -1196766080
    // stack -2077809652
    ();
    // stack 159465600
    // stor.pri -1196766080
    // stack 159465600
    // stor.pri -2103456640
    // stack -1943591924
    // stack 159465600
    // stack 
    // stor.pri -2103456640
    // stack -1943591924
    // stack 159465600
    // branch jrel -> 2071989287
    // stor.pri -2103456640
    // stack -1943591924
    // stack 159465600
    // load.alt -1993926873
    call_0x0x-34757bd9();
    return 1;
    // proc @0x480f1
    // branch jump -> -1977149657
    // stor.pri -1448682112
    // proc @0x4813c
    // stack -2077809652
    // branch jump -> -2144895193
    // stack 159465600
}

// --- disasm (first 80) ---
// 0x0004757c: op192          
// 0x0004757d: eq.pri         
// 0x0004757e: op0            
// 0x0004757f: push.c         0x-4c19037d ""
// 0x00047584: lidx.b         -980843481
// 0x00047589: op235          
// 0x0004758a: op0            
// 0x0004758b: push.c         0x287b8008 ""
// 0x00047590: stack          -1943591924
// 0x00047595: op168          
// 0x00047596: op182          
// 0x00047597: op230          
// 0x00047598: stor.alt       -1129872345
// 0x0004759d: op191          
// 0x0004759e: sshr.alt       
// 0x0004759f: push.c         0x-207fd8ff ""
// 0x000475a4: op186          
// 0x000475a5: op205          
// 0x000475a6: push.pri       
// 0x000475a7: push.c         0x-7e847fe0 ""
// 0x000475ac: jsgeq          
// 0x000475ad: stack          654934308
// 0x000475b2: op0            
// 0x000475b3: push.c         0x-7f3f747c ""
// 0x000475b8: op0            
// 0x000475b9: push.c         0x-4c19037d ""
// 0x000475be: lidx.b         -1047690201
// 0x000475c3: retn           
// 0x000475c4: emit           
// 0x000475c5: push.c         0x287b8008 ""
// 0x000475ca: stack          -1943591924
// 0x000475cf: op168          
// 0x000475d0: push.r         
// 0x000475d1: op210          
// 0x000475d2: sshr.pri       
// 0x000475d3: push.c         0x-c4d577c ""
// 0x000475d8: push.alt       
// 0x000475d9: push.c         0x-207fd8ff ""
// 0x000475de: op186          
// 0x000475df: op208          
// 0x000475e0: zero.pri       
// 0x000475e1: push.c         0x-7e847fe0 ""
// 0x000475e6: jsgeq          
// 0x000475e7: stack          654934308
// 0x000475ec: dec.s.pri      
// 0x000475ed: jump           
// 0x000475ee: swap.pri       
// 0x000475ef: op177          
// 0x000475f0: sref.s.alt     -1131576281
// 0x000475f5: op191          
// 0x000475f6: stor.i         
// 0x000475f7: push.c         0x-92a5774 ""
// 0x000475fc: sshr           
// 0x000475fd: push.c         0x-7e4d567c ""
// 0x00047602: move.alt       
// 0x00047603: push.c         0x14272781 ""
// 0x00047608: call           0x-7ecf207f
// 0x0004760d: load.i         
// 0x0004760e: push.c         0x-7e13637c ""
// 0x00047613: ret            
// 0x00047614: push.c         0x-6771757c ""
// 0x00047619: push.alt       
// 0x0004761a: push.c         0x-49785a7c ""
// 0x0004761f: shl            
// 0x00047620: push.c         0x-b4f597c ""
// 0x00047625: cmps           
// 0x00047626: push.c         0x31142722 ""
// 0x0004762b: eq.alt         -2146488097
// 0x00047630: op204          
// 0x00047631: call           
// 0x00047632: op250          
// 0x00047633: strb.i         2133264769
// 0x00047638: push.c         0x-757bd881 ""
// 0x0004763d: push.pri       
// 0x0004763e: dec.i          
// 0x0004763f: jrel           -2019195865
// 0x00047644: op227          
// 0x00047645: load.alt       -1314487257
// 0x0004764a: op179          
// 0x0004764b: const.pri      -1993926873
// SpawnSetVWZero @ 0xbc0c0-0xbc144 (132 bytes)
// Source: test.pwn

stock SpawnSetVWZero()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000bc0c0: eq.alt         655160837
// 0x000bc0c5: const.alt      740129664
// 0x000bc0ca: stor.alt       -2146694783
// 0x000bc0cf: op220          
// 0x000bc0d0: op232          
// 0x000bc0d1: op231          
// 0x000bc0d2: sysreq.pri     
// 0x000bc0d3: load.s.pri     -2022080496
// 0x000bc0d8: load.s.pri     -2146885093
// 0x000bc0dd: neg            
// 0x000bc0de: eq.pri         
// 0x000bc0df: mul.c          
// 0x000bc0e0: eq.pri         
// 0x000bc0e1: mod            
// 0x000bc0e2: load.i         
// 0x000bc0e3: move.alt       
// 0x000bc0e4: eq.pri         
// 0x000bc0e5: mod.c          
// 0x000bc0e6: xchg           
// 0x000bc0e7: eq.pri         
// 0x000bc0e8: less           
// 0x000bc0e9: eq.pri         
// 0x000bc0ea: mod            
// 0x000bc0eb: jzer           0xcb5f380
// 0x000bc0f0: eq.alt         25306889
// 0x000bc0f5: push.c         0x-5a381380 ""
// 0x000bc0fa: load.s.alt     217449857
// 0x000bc0ff: push.c         0x1d7b800c ""
// 0x000bc104: stack          201949456
// 0x000bc109: eq.pri         
// 0x000bc10a: op220          
// 0x000bc10b: op232          
// 0x000bc10c: op231          
// 0x000bc10d: sysreq.pri     
// 0x000bc10e: load.s.pri     -2022080496
// 0x000bc113: load.s.pri     -2146885093
// 0x000bc118: neg            
// 0x000bc119: eq.pri         
// 0x000bc11a: mul.c          
// 0x000bc11b: eq.pri         
// 0x000bc11c: sleq           
// 0x000bc11d: load.i         
// 0x000bc11e: eq.pri         
// 0x000bc11f: mul.c          
// 0x000bc120: load.pri       622265389
// 0x000bc125: push.c         0x-5a381380 ""
// 0x000bc12a: const.alt      92355623
// 0x000bc12f: op254          
// 0x000bc130: stor.alt       2071990311
// 0x000bc135: push.alt       
// 0x000bc136: stack          -2122568428
// 0x000bc13b: load.i         
// 0x000bc13c: push.c         0x5810182 ""
// 0x000bc141: op254          
// 0x000bc142: stor.alt       217449857
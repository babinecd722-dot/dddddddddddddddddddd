// ExitPlayerBuyCarMarket @ 0xcf650-0xcfb5c (1292 bytes)
// Source: test.pwn

stock ExitPlayerBuyCarMarket()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000cf650: load.s.pri     -2122743796
// 0x000cf655: sysreq.c       
// 0x000cf656: idxaddr        
// 0x000cf657: move.alt       
// 0x000cf658: load.i         
// 0x000cf659: eq.pri         
// 0x000cf65a: neg            
// 0x000cf65b: eq.pri         
// 0x000cf65c: mul.c          
// 0x000cf65d: inc.i          
// 0x000cf65e: sctrl          -2122575607
// 0x000cf663: load.i         
// 0x000cf664: load.s.pri     931073148
// 0x000cf669: eq.pri         
// 0x000cf66a: op255          
// 0x000cf66b: proc           
// 0x000cf66c: load.s.alt     268634497
// 0x000cf671: eq.alt         -1761640447
// 0x000cf676: or             
// 0x000cf677: eq.alt         -696251383
// 0x000cf67c: op199          
// 0x000cf67d: op219          
// 0x000cf67e: sysreq.pri     
// 0x000cf67f: load.s.pri     -2122743796
// 0x000cf684: sysreq.c       
// 0x000cf685: idxaddr        
// 0x000cf686: move.alt       
// 0x000cf687: load.i         
// 0x000cf688: eq.pri         
// 0x000cf689: neg            
// 0x000cf68a: eq.pri         
// 0x000cf68b: mul.c          
// 0x000cf68c: inc.i          
// 0x000cf68d: strb.i         -8374775
// 0x000cf692: push.c         
// 0x000cf693: div.c          
// 0x000cf694: eq.alt         -595588087
// 0x000cf699: op232          
// 0x000cf69a: op231          
// 0x000cf69b: sysreq.pri     
// 0x000cf69c: load.s.pri     -2022080388
// 0x000cf6a1: load.s.pri     -2146885093
// 0x000cf6a6: neg            
// 0x000cf6a7: eq.pri         
// 0x000cf6a8: mul.c          
// 0x000cf6a9: eq.pri         
// 0x000cf6aa: mod            
// 0x000cf6ab: load.i         
// 0x000cf6ac: push.pri       
// 0x000cf6ad: const.alt      -607660416
// 0x000cf6b2: sysreq.pri     
// 0x000cf6b3: load.s.pri     -2122743796
// 0x000cf6b8: sysreq.c       
// 0x000cf6b9: idxaddr        
// 0x000cf6ba: move.alt       
// 0x000cf6bb: load.i         
// 0x000cf6bc: eq.pri         
// 0x000cf6bd: neg            
// 0x000cf6be: load.i         
// 0x000cf6bf: pop.alt        
// 0x000cf6c0: jneq           0x5890ff80
// 0x000cf6c5: eq.alt         746324745
// 0x000cf6ca: load.s.alt     -8375504
// 0x000cf6cf: proc           
// 0x000cf6d0: load.s.alt     -2146694783
// 0x000cf6d5: op214          
// 0x000cf6d6: op199          
// 0x000cf6d7: op219          
// 0x000cf6d8: sysreq.pri     
// 0x000cf6d9: load.s.pri     -2122743796
// 0x000cf6de: sysreq.c       
// 0x000cf6df: idxaddr        
// 0x000cf6e0: move.alt       
// 0x000cf6e1: load.i         
// 0x000cf6e2: eq.pri         
// 0x000cf6e3: neg            
// 0x000cf6e4: eq.pri         
// 0x000cf6e5: mul.c          
// 0x000cf6e6: inc.i          
// 0x000cf6e7: strb.i         23691273
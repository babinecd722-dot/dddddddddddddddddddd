// name_OnPlayerDisconnect @ 0x642fc-0x64348 (76 bytes)
// Source: system_weekly_prizes.pwn

stock name_OnPlayerDisconnect()
{
    // load.pri -2127246401
    // load.pri 271022121
    call_0x0x78998e81();
    // const.alt -607660416
}

// --- disasm (first 80) ---
// 0x000642fc: eq.pri         
// 0x000642fd: bounds         
// 0x000642fe: push.pri       
// 0x000642ff: eq.c.alt       
// 0x00064300: eq.alt         -2129132791
// 0x00064305: load.pri       -2127246401
// 0x0006430a: load.i         
// 0x0006430b: push.c         0x270a2701 ""
// 0x00064310: load.pri       271022121
// 0x00064315: call           0x78998e81
// 0x0006431a: eq.alt         2013626633
// 0x0006431f: const.alt      -607660416
// 0x00064324: sysreq.pri     
// 0x00064325: load.s.pri     -2122743688
// 0x0006432a: sysreq.c       
// 0x0006432b: idxaddr        
// 0x0006432c: move.alt       
// 0x0006432d: load.i         
// 0x0006432e: eq.pri         
// 0x0006432f: neg            
// 0x00064330: eq.pri         
// 0x00064331: mul.c          
// 0x00064332: cmps.i         
// 0x00064333: mod            
// 0x00064334: push.pri       
// 0x00064335: eq.alt         -2146694139
// 0x0006433a: op214          
// 0x0006433b: op199          
// 0x0006433c: op219          
// 0x0006433d: sysreq.pri     
// 0x0006433e: load.s.pri     -2122743796
// 0x00064343: sysreq.c       
// 0x00064344: idxaddr        
// 0x00064345: move.alt       
// 0x00064346: load.i         
// 0x00064347: eq.pri         
// ToggleInteractionWindow @ 0x3b448c-0x3b44a4 (24 bytes)
// Source: test.pwn

stock ToggleInteractionWindow()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x003b448c: op0            
// 0x003b448d: op0            
// 0x003b448e: op0            
// 0x003b448f: op0            
// 0x003b4490: op0            
// 0x003b4491: op0            
// 0x003b4492: op0            
// 0x003b4493: op0            
// 0x003b4494: op0            
// 0x003b4495: op0            
// 0x003b4496: op0            
// 0x003b4497: op0            
// 0x003b4498: op0            
// 0x003b4499: op0            
// 0x003b449a: op0            
// 0x003b449b: op0            
// 0x003b449c: op0            
// 0x003b449d: op0            
// 0x003b449e: op0            
// 0x003b449f: op0            
// 0x003b44a0: op0            
// 0x003b44a1: op0            
// 0x003b44a2: op0            
// 0x003b44a3: op0            
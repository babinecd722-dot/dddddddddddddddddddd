// LoadBlackJack @ 0x22b10-0x23728 (3096 bytes)
// Source: system_blackjack_full.pwn

stock LoadBlackJack()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00022b10: bounds         
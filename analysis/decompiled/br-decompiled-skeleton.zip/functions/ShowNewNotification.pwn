// ShowNewNotification @ 0x11d18-0x1212c (1044 bytes)
// Source: brnotification.inc

stock ShowNewNotification()
{
    // const.alt 2038434819
    // stack -304709621
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 185172240
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack 738820376
    // const.alt -756296064
    // stack 654934284
    // const.alt -756296064
    // stack 654934284
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt 159453228
    // stack 654934284
    // stack 1619012620
    // branch jump -> -2129857397
    // const.alt -1561405824
    // const.alt 2038434819
    // branch jzer -> 0x-7ef30e75
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt 2038434819
    // stack 654934284
    // const.alt -756296064
    // stack -192204020
    // const.alt -2146694783
    // const.alt 2038434819
    // const.alt 2038434819
    // stack -2130083564
    // stack 654934284
    // const.alt -756296064
    // stack 1619012620
    // branch jump -> -2124614517
    // const.alt -1561405824
    // const.alt 2038434819
    // branch jump -> -2129622644
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 931073033
    // const.alt 2038434819
    // branch jnz -> 0xc44f68b
    // const.alt 2038434819
    // const.pri -141871871
    // const.alt 2038434819
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 159461380
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2146694783
    // const.alt 2038434819
    // const.pri -504506752
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 203891721
    // stack 185172240
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
}

// --- disasm (first 80) ---
// 0x00011d18: load.s.alt     -2146694783
// 0x00011d1d: op214          
// 0x00011d1e: op238          
// 0x00011d1f: nop            
// 0x00011d20: const.alt      2038434819
// 0x00011d25: lref.pri       -2146885093
// 0x00011d2a: neg            
// 0x00011d2b: eq.pri         
// 0x00011d2c: mul.c          
// 0x00011d2d: idxaddr.b      386861858
// 0x00011d32: eq.alt         -696244471
// 0x00011d37: op239          
// 0x00011d38: op199          
// 0x00011d39: stack          -304709621
// 0x00011d3e: op225          
// 0x00011d3f: jsgeq          
// 0x00011d40: push.pri       
// 0x00011d41: const.alt      -1561405824
// 0x00011d46: const.alt      2038434819
// 0x00011d4b: lref.pri       -2146885093
// 0x00011d50: neg            
// 0x00011d51: eq.pri         
// 0x00011d52: mul.c          
// 0x00011d53: push           -2122743799
// 0x00011d58: sysreq.c       
// 0x00011d59: pop.alt        
// 0x00011d5a: idxaddr        
// 0x00011d5b: load.i         
// 0x00011d5c: push.pri       
// 0x00011d5d: const.alt      -1561405824
// 0x00011d62: const.alt      2038434819
// 0x00011d67: lref.pri       -2146885093
// 0x00011d6c: neg            
// 0x00011d6d: eq.pri         
// 0x00011d6e: mul.c          
// 0x00011d6f: push           203891721
// 0x00011d74: eq.pri         
// 0x00011d75: emit           
// 0x00011d76: eq.pri         
// 0x00011d77: eq             
// 0x00011d78: stack          185172240
// 0x00011d7d: eq.pri         
// 0x00011d7e: op214          
// 0x00011d7f: op237          
// 0x00011d80: op225          
// 0x00011d81: jsgeq          
// 0x00011d82: push.pri       
// 0x00011d83: const.alt      -1561405824
// 0x00011d88: const.alt      2038434819
// 0x00011d8d: lref.pri       -2146885093
// 0x00011d92: neg            
// 0x00011d93: eq.pri         
// 0x00011d94: mul.c          
// 0x00011d95: push           -2122743799
// 0x00011d9a: sysreq.c       
// 0x00011d9b: pop.alt        
// 0x00011d9c: idxaddr        
// 0x00011d9d: load.i         
// 0x00011d9e: push.pri       
// 0x00011d9f: const.alt      -1561405824
// 0x00011da4: const.alt      2038434819
// 0x00011da9: lref.pri       -2146885093
// 0x00011dae: neg            
// 0x00011daf: eq.pri         
// 0x00011db0: mul.c          
// 0x00011db1: push           136782857
// 0x00011db6: eq.pri         
// 0x00011db7: emit           
// 0x00011db8: eq.pri         
// 0x00011db9: grtr           
// 0x00011dba: stack          201949452
// 0x00011dbf: eq.pri         
// 0x00011dc0: op214          
// 0x00011dc1: op238          
// 0x00011dc2: nop            
// 0x00011dc3: const.alt      2038434819
// 0x00011dc8: lref.pri       -2146885093
// 0x00011dcd: neg            
// 0x00011dce: eq.pri         
// 0x00011dcf: mul.c          
// OnPlayerKeyStateChange @ 0xdd294-0xe2d3c (23208 bytes)
// Source: test.pwn

public OnPlayerKeyStateChange()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000dd294: eq.pri         
// 0x000dd295: eq.c.alt       
// 0x000dd296: stack          654934288
// 0x000dd29b: dec.s.pri      
// 0x000dd29c: bounds.p       
// 0x000dd29d: op192          
// 0x000dd29e: eq.pri         
// 0x000dd29f: op0            
// 0x000dd2a0: push.c         0x-617bd8ec ""
// 0x000dd2a5: op174          
// 0x000dd2a6: eq.pri         
// 0x000dd2a7: op0            
// 0x000dd2a8: push.c         0x28823108 ""
// 0x000dd2ad: push.pri       
// 0x000dd2ae: const.pri      -508833920
// 0x000dd2b3: zero.pri       
// 0x000dd2b4: eq.pri         
// 0x000dd2b5: mul.c          
// 0x000dd2b6: load.s.alt     203891721
// 0x000dd2bb: eq.pri         
// 0x000dd2bc: emit           
// 0x000dd2bd: eq.pri         
// 0x000dd2be: bounds         
// 0x000dd2bf: stack          654934288
// 0x000dd2c4: load.s.pri     -1412464629
// 0x000dd2c9: op225          
// 0x000dd2ca: zero.pri       
// 0x000dd2cb: eq.pri         
// 0x000dd2cc: mul.c          
// 0x000dd2cd: load.s.alt     136782857
// 0x000dd2d2: eq.pri         
// 0x000dd2d3: emit           
// 0x000dd2d4: eq.pri         
// 0x000dd2d5: inc            
// 0x000dd2d6: stack          654934284
// 0x000dd2db: sign.alt       
// 0x000dd2dc: const.pri      -508833920
// 0x000dd2e1: zero.pri       
// 0x000dd2e2: eq.pri         
// 0x000dd2e3: mul.c          
// 0x000dd2e4: load.s.alt     136782857
// 0x000dd2e9: eq.pri         
// 0x000dd2ea: emit           
// 0x000dd2eb: eq.pri         
// 0x000dd2ec: shr            
// 0x000dd2ed: stack          654934284
// 0x000dd2f2: op0            
// 0x000dd2f3: const.pri      -508833920
// 0x000dd2f8: zero.pri       
// 0x000dd2f9: eq.pri         
// 0x000dd2fa: mul.c          
// 0x000dd2fb: load.s.alt     136782857
// 0x000dd300: eq.pri         
// 0x000dd301: emit           
// 0x000dd302: eq.pri         
// 0x000dd303: dec            
// 0x000dd304: stack          654934284
// 0x000dd309: load.pri       -1412464629
// 0x000dd30e: op225          
// 0x000dd30f: zero.pri       
// 0x000dd310: eq.pri         
// 0x000dd311: mul.c          
// 0x000dd312: load.s.alt     136782857
// 0x000dd317: eq.pri         
// 0x000dd318: emit           
// 0x000dd319: eq.pri         
// 0x000dd31a: movs           
// 0x000dd31b: stack          654934284
// 0x000dd320: jump           -1412464629
// 0x000dd325: op225          
// 0x000dd326: zero.pri       
// 0x000dd327: eq.pri         
// 0x000dd328: mul.c          
// 0x000dd329: load.s.alt     136782857
// 0x000dd32e: eq.pri         
// 0x000dd32f: emit           
// 0x000dd330: eq.pri         
// 0x000dd331: cmps           
// 0x000dd332: stack          654934284
// 0x000dd337: load.s.pri     -1412464629
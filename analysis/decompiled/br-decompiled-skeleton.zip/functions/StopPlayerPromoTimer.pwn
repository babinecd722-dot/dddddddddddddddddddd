// StopPlayerPromoTimer @ 0x49564-0x49ce4 (1920 bytes)
// Source: system_new_promo.pwn

stock StopPlayerPromoTimer()
{
    // stack 50954508
    // branch jzer -> 0x-7ea73a52
    // const.alt 1635810176
    // stack -961662192
    return 1;
    // branch jrel -> 204046119
    // stack 688488720
    // const.alt 2071987239
    // const.alt -607660416
    // branch jeq -> 0x-7eb73752
    // const.alt 54307210
    return 1;
    // load.pri 1221111349
    // const.alt -928105207
    // stack 201949448
    // stack -877775607
    // stor.alt -2122837751
    // branch jeq -> 0x-7ef73552
    // const.alt -607660416
    // stack 931073033
    // const.alt -607660416
    // stack -2122743799
    // const.alt -2146694783
    // const.alt -2144269273
    // const.alt 931135363
    // const.pri 394264451
    // const.alt -8188919
    // branch jeq -> 0x-7ee72e52
    // const.alt -607660416
    // const.alt 69673993
    call_0x0x-7ed72d7d();
    // const.alt -607660416
    // const.alt -8189150
    // branch jzer -> 0xc48d2ae
    // stack -760335096
    // const.pri -760335615
    // branch jzer -> 0x-7e932c52
    // const.alt -607660416
    // stack 201949448
    // const.pri 159455103
    // const.alt -607660416
    // stack -710003448
    // stack 201949448
    // const.pri 159455103
    // const.alt -607660416
    // const.alt -8188919
    // branch jeq -> 0x-7ed72852
    // const.alt -607660416
    // const.alt 69673993
    call_0x0x50a4fc80();
    // const.alt -676448385
    // stor.alt -8188919
    // branch jeq -> 0x-7ebb2752
    // const.alt -607660416
    // stor.alt 69673993
    // const.alt -607660416
    // const.alt 931135363
    // const.pri 394264451
    // const.alt -1657731033
}

// --- disasm (first 80) ---
// 0x00049564: mul            
// 0x00049565: stack          50954508
// 0x0004956a: op249          
// 0x0004956b: div.c          
// 0x0004956c: jzer           0x-7ea73a52
// 0x00049571: load.i         
// 0x00049572: push.c         0x-51442080 ""
// 0x00049577: jsgeq          
// 0x00049578: push.c         0x270c297f ""
// 0x0004957d: const.alt      1635810176
// 0x00049582: stack          -961662192
// 0x00049587: retn           
// 0x00049588: eq.alt         -545249527
// 0x0004958d: op187          
// 0x0004958e: op176          
// 0x0004958f: jrel           204046119
// 0x00049594: push.c         0x-7f847ff4 ""
// 0x00049599: xor            
// 0x0004959a: stack          688488720
// 0x0004959f: const.alt      2071987239
// 0x000495a4: eq.alt         738733155
// 0x000495a9: inc.i          
// 0x000495aa: push           2083260801
// 0x000495af: const.alt      -607660416
// 0x000495b4: sysreq.pri     
// 0x000495b5: load.s.pri     -2122743796
// 0x000495ba: sysreq.c       
// 0x000495bb: idxaddr        
// 0x000495bc: move.alt       
// 0x000495bd: load.i         
// 0x000495be: eq.pri         
// 0x000495bf: neg            
// 0x000495c0: eq.pri         
// 0x000495c1: mul.c          
// 0x000495c2: dec.i          
// 0x000495c3: idxaddr.b      -2122837751
// 0x000495c8: load.i         
// 0x000495c9: load.s.pri     -8188808
// 0x000495ce: sign.alt       
// 0x000495cf: jeq            0x-7eb73752
// 0x000495d4: load.i         
// 0x000495d5: const.alt      54307210
// 0x000495da: sysreq.pri     
// 0x000495db: eq.pri         
// 0x000495dc: sysreq.c       
// 0x000495dd: cmps.i         
// 0x000495de: ret            
// 0x000495df: idxaddr        
// 0x000495e0: move.alt       
// 0x000495e1: load.i         
// 0x000495e2: eq.pri         
// 0x000495e3: neg            
// 0x000495e4: eq.pri         
// 0x000495e5: mul.c          
// 0x000495e6: push.pri       
// 0x000495e7: load.i         
// 0x000495e8: eq.pri         
// 0x000495e9: grtr           
// 0x000495ea: load.pri       1221111349
// 0x000495ef: eq.alt         -578810871
// 0x000495f4: op177          
// 0x000495f5: op236          
// 0x000495f6: eq.c.alt       
// 0x000495f7: load.s.pri     -2122743796
// 0x000495fc: sysreq.c       
// 0x000495fd: idxaddr        
// 0x000495fe: move.alt       
// 0x000495ff: load.i         
// 0x00049600: eq.pri         
// 0x00049601: neg            
// 0x00049602: load.i         
// 0x00049603: const.alt      -928105207
// 0x00049608: shr.alt        
// 0x00049609: eq.alt         662186249
// 0x0004960e: load.s.alt     1686207360
// 0x00049613: stack          201949448
// 0x00049618: eq.pri         
// 0x00049619: op214          
// 0x0004961a: op199          
// 0x0004961b: op219          
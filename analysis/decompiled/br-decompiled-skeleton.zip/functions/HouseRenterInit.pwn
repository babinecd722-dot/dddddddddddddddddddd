// HouseRenterInit @ 0x1cd248-0x1cd564 (796 bytes)
// Source: test.pwn

stock HouseRenterInit()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001cd248: op0            
// 0x001cd249: op0            
// 0x001cd24a: op0            
// 0x001cd24b: op0            
// 0x001cd24c: op0            
// 0x001cd24d: op0            
// 0x001cd24e: op0            
// 0x001cd24f: op0            
// 0x001cd250: op0            
// 0x001cd251: op0            
// 0x001cd252: op0            
// 0x001cd253: op0            
// 0x001cd254: op0            
// 0x001cd255: op0            
// 0x001cd256: op0            
// 0x001cd257: op0            
// 0x001cd258: op0            
// 0x001cd259: op0            
// 0x001cd25a: op0            
// 0x001cd25b: op0            
// 0x001cd25c: op0            
// 0x001cd25d: op0            
// 0x001cd25e: op0            
// 0x001cd25f: op0            
// 0x001cd260: op0            
// 0x001cd261: op0            
// 0x001cd262: op0            
// 0x001cd263: op0            
// 0x001cd264: op0            
// 0x001cd265: op0            
// 0x001cd266: op0            
// 0x001cd267: op0            
// 0x001cd268: op0            
// 0x001cd269: op0            
// 0x001cd26a: op0            
// 0x001cd26b: op0            
// 0x001cd26c: op0            
// 0x001cd26d: op0            
// 0x001cd26e: op0            
// 0x001cd26f: op0            
// 0x001cd270: op0            
// 0x001cd271: op0            
// 0x001cd272: op0            
// 0x001cd273: op0            
// 0x001cd274: eq.alt         -2123464382
// 0x001cd279: eq             
// 0x001cd27a: eq.alt         -2123529875
// 0x001cd27f: emit           
// 0x001cd280: eq.alt         1619075177
// 0x001cd285: eq.alt         -2123202206
// 0x001cd28a: sgeq           
// 0x001cd28b: eq.alt         -2123136671
// 0x001cd290: inc            
// 0x001cd291: op0            
// 0x001cd292: op0            
// 0x001cd293: op0            
// 0x001cd294: op0            
// 0x001cd295: op0            
// 0x001cd296: op0            
// 0x001cd297: op0            
// 0x001cd298: op0            
// 0x001cd299: op0            
// 0x001cd29a: op0            
// 0x001cd29b: op0            
// 0x001cd29c: op0            
// 0x001cd29d: op0            
// 0x001cd29e: op0            
// 0x001cd29f: op0            
// 0x001cd2a0: op0            
// 0x001cd2a1: op0            
// 0x001cd2a2: op0            
// 0x001cd2a3: op0            
// 0x001cd2a4: op0            
// 0x001cd2a5: op0            
// 0x001cd2a6: op0            
// 0x001cd2a7: op0            
// 0x001cd2a8: op0            
// 0x001cd2a9: op0            
// 0x001cd2aa: op0            
// 0x001cd2ab: op0            
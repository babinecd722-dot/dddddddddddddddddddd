// SetVehicleParam @ 0xeca4-0xeecc (552 bytes)
// Source: system_vehicle.pwn

stock SetVehicleParam()
{
    // stack 201949452
    // const.alt -696244444
    // const.alt -291929049
    // stack -2129188080
    // const.alt 203891721
    // stack 654934288
    return 1;
    // const.alt -689187200
    // const.alt 203891721
    // stack 654934288
    // load.pri -338264052
    // const.alt 136782857
    // stack 654934284
    // const.alt -689187200
    // const.alt 136782857
    // stack 654934284
    // const.alt -689187200
    // const.alt 136782857
    // stack 654934284
    // const.alt -689187200
    // const.alt 136782857
    // stack 654934284
    // const.alt 136782857
    // stack 811171852
    // proc @0xedd5
    // const.alt 2038434819
    // const.alt 2038434819
    // const.pri 159455103
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt 2038434819
    // stack 394201890
    return 1;
    // proc @0xee3f
    // const.alt 2038434819
    // const.alt 17500545
    return 1;
    // const.alt 2038434819
    // const.alt -292997249
    // branch jump -> -2127499127
    // const.alt -1561405824
    // const.alt 2038434819
    // branch jump -> -2127499127
    // const.alt -1561405824
    // const.alt 2038434819
}

// --- disasm (first 80) ---
// 0x0000eca4: push.pri       
// 0x0000eca5: push.c         0x-7f847ff8 ""
// 0x0000ecaa: fill           
// 0x0000ecab: stack          201949452
// 0x0000ecb0: eq.pri         
// 0x0000ecb1: op214          
// 0x0000ecb2: op235          
// 0x0000ecb3: op214          
// 0x0000ecb4: sysreq.pri     
// 0x0000ecb5: load.s.pri     91848716
// 0x0000ecba: idxaddr        
// 0x0000ecbb: move.alt       
// 0x0000ecbc: load.i         
// 0x0000ecbd: eq.pri         
// 0x0000ecbe: neg            
// 0x0000ecbf: eq.pri         
// 0x0000ecc0: mul.c          
// 0x0000ecc1: const.alt      -696244444
// 0x0000ecc6: op239          
// 0x0000ecc7: op188          
// 0x0000ecc8: const.alt      -291929049
// 0x0000eccd: op213          
// 0x0000ecce: pop.alt        
// 0x0000eccf: push.c         0x-7f465f7c ""
// 0x0000ecd4: lodb.i         2071989287
// 0x0000ecd9: eq.pri         
// 0x0000ecda: eq.c.pri       
// 0x0000ecdb: stack          -2129188080
// 0x0000ece0: load.i         
// 0x0000ece1: push.c         0xc002700 ""
// 0x0000ece6: eq.pri         
// 0x0000ece7: op214          
// 0x0000ece8: op235          
// 0x0000ece9: op214          
// 0x0000ecea: sysreq.pri     
// 0x0000eceb: load.s.pri     91848716
// 0x0000ecf0: idxaddr        
// 0x0000ecf1: move.alt       
// 0x0000ecf2: load.i         
// 0x0000ecf3: eq.pri         
// 0x0000ecf4: neg            
// 0x0000ecf5: eq.pri         
// 0x0000ecf6: mul.c          
// 0x0000ecf7: const.alt      203891721
// 0x0000ecfc: eq.pri         
// 0x0000ecfd: emit           
// 0x0000ecfe: eq.pri         
// 0x0000ecff: eq.c.alt       
// 0x0000ed00: stack          654934288
// 0x0000ed05: dec.s.pri      
// 0x0000ed06: push.c         
// 0x0000ed07: line.debug     
// 0x0000ed08: op197          
// 0x0000ed09: sysreq.c       
// 0x0000ed0a: push.c         0x-19536b7c ""
// 0x0000ed0f: retn           
// 0x0000ed10: const.alt      -689187200
// 0x0000ed15: sysreq.pri     
// 0x0000ed16: load.s.pri     91848716
// 0x0000ed1b: idxaddr        
// 0x0000ed1c: move.alt       
// 0x0000ed1d: load.i         
// 0x0000ed1e: eq.pri         
// 0x0000ed1f: neg            
// 0x0000ed20: eq.pri         
// 0x0000ed21: mul.c          
// 0x0000ed22: const.alt      203891721
// 0x0000ed27: eq.pri         
// 0x0000ed28: emit           
// 0x0000ed29: eq.pri         
// 0x0000ed2a: bounds         
// 0x0000ed2b: stack          654934288
// 0x0000ed30: load.pri       -338264052
// 0x0000ed35: op214          
// 0x0000ed36: sysreq.pri     
// 0x0000ed37: load.s.pri     91848716
// 0x0000ed3c: idxaddr        
// 0x0000ed3d: move.alt       
// 0x0000ed3e: load.i         
// 0x0000ed3f: eq.pri         
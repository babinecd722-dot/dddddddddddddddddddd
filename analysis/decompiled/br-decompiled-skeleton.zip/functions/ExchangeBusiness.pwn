// ExchangeBusiness @ 0x605a4-0x61044 (2720 bytes)
// Source: system_exchange_welsi.pwn

stock ExchangeBusiness()
{
    // stack 656157052
    // const.alt -1796481917
    // load.pri 686603315
    // branch jzer -> 0x-7edf1144
    // const.alt -607660416
    // stack -289656048
    return 1;
    // stack -2130433008
    // branch jzer -> 0x-7ea37c43
    return 1;
    // stor.alt 2038434819
    // const.alt -509621120
    return 1;
    // stack 654934296
    // load.pri 16254337
    // stack 654934288
    // load.pri 2071987239
    // stack 2096566536
    // branch jnz -> 0x-7efb0b44
    return 1;
    // stack 411577360
    return 1;
    // load.pri 203882535
}

// --- disasm (first 80) ---
// 0x000605a4: load.i         
// 0x000605a5: stack          656157052
// 0x000605aa: load.s.alt     739277696
// 0x000605af: lref.s.alt     159480849
// 0x000605b4: load.s.pri     1501569660
// 0x000605b9: xchg           
// 0x000605ba: jsleq          0x324ecbc
// 0x000605bf: zero.pri       
// 0x000605c0: const.alt      -1796481917
// 0x000605c5: op0            
// 0x000605c6: jsgrtr         0xb24ecbc
// 0x000605cb: load.pri       686603315
// 0x000605d0: eq.pri         
// 0x000605d1: mod.c          
// 0x000605d2: jzer           0x-7edf1144
// 0x000605d7: load.i         
// 0x000605d8: const.alt      -607660416
// 0x000605dd: sysreq.pri     
// 0x000605de: load.s.pri     -2122743796
// 0x000605e3: sysreq.c       
// 0x000605e4: idxaddr        
// 0x000605e5: move.alt       
// 0x000605e6: load.i         
// 0x000605e7: eq.pri         
// 0x000605e8: neg            
// 0x000605e9: eq.pri         
// 0x000605ea: mul.c          
// 0x000605eb: push.c         
// 0x000605ec: op0            
// 0x000605ed: push.pri       
// 0x000605ee: load.i         
// 0x000605ef: load.s.alt     726564988
// 0x000605f4: stor.i         
// 0x000605f5: eq.alt         -696251383
// 0x000605fa: op199          
// 0x000605fb: op219          
// 0x000605fc: sysreq.pri     
// 0x000605fd: load.s.pri     -2122743796
// 0x00060602: sysreq.c       
// 0x00060603: idxaddr        
// 0x00060604: move.alt       
// 0x00060605: load.i         
// 0x00060606: eq.pri         
// 0x00060607: neg            
// 0x00060608: eq.pri         
// 0x00060609: mul.c          
// 0x0006060a: push.c         
// 0x0006060b: op0            
// 0x0006060c: load.i         
// 0x0006060d: eq.pri         
// 0x0006060e: mul.c          
// 0x0006060f: inc.s.alt      
// 0x00060610: shr            
// 0x00060611: push.pri       
// 0x00060612: push.c         0x-2671380 ""
// 0x00060617: sysreq.pri     
// 0x00060618: push.s         822880012
// 0x0006061d: eq.alt         -2126214523
// 0x00060622: load.i         
// 0x00060623: push.c         0x-1671380 ""
// 0x00060628: sref.alt       204046119
// 0x0006062d: push.c         0x-7f847ff4 ""
// 0x00060632: xor            
// 0x00060633: stack          -289656048
// 0x00060638: mod            
// 0x00060639: eq.alt         -327145719
// 0x0006063e: ret            
// 0x0006063f: op255          
// 0x00060640: op0            
// 0x00060641: push.c         0x7f8180f8 ""
// 0x00060646: push.s         -2146687220
// 0x0006064b: emit           
// 0x0006064c: eq.pri         
// 0x0006064d: xor            
// 0x0006064e: stack          -2130433008
// 0x00060653: load.i         
// 0x00060654: load.s.pri     -1788248048
// 0x00060659: pop.pri        
// 0x0006065a: jzer           0x-7ea37c43
// 0x0006065f: load.i         
// GetSelectedBusiness @ 0x1ef4f0-0x1ef528 (56 bytes)
// Source: test.pwn

stock GetSelectedBusiness()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001ef4f0: op0            
// 0x001ef4f1: op0            
// 0x001ef4f2: op0            
// 0x001ef4f3: op0            
// 0x001ef4f4: op0            
// 0x001ef4f5: op0            
// 0x001ef4f6: op0            
// 0x001ef4f7: op0            
// 0x001ef4f8: op0            
// 0x001ef4f9: op0            
// 0x001ef4fa: op0            
// 0x001ef4fb: op0            
// 0x001ef4fc: op0            
// 0x001ef4fd: op0            
// 0x001ef4fe: op0            
// 0x001ef4ff: op0            
// 0x001ef500: op0            
// 0x001ef501: op0            
// 0x001ef502: op0            
// 0x001ef503: op0            
// 0x001ef504: op0            
// 0x001ef505: op0            
// 0x001ef506: op0            
// 0x001ef507: op0            
// 0x001ef508: op0            
// 0x001ef509: op0            
// 0x001ef50a: op0            
// 0x001ef50b: op0            
// 0x001ef50c: op0            
// 0x001ef50d: op0            
// 0x001ef50e: op0            
// 0x001ef50f: op0            
// 0x001ef510: op0            
// 0x001ef511: op0            
// 0x001ef512: op0            
// 0x001ef513: op0            
// 0x001ef514: op0            
// 0x001ef515: op0            
// 0x001ef516: op0            
// 0x001ef517: op0            
// 0x001ef518: op0            
// 0x001ef519: op0            
// 0x001ef51a: op0            
// 0x001ef51b: op0            
// 0x001ef51c: op0            
// 0x001ef51d: op0            
// 0x001ef51e: op0            
// 0x001ef51f: op0            
// 0x001ef520: op0            
// 0x001ef521: op0            
// 0x001ef522: op0            
// 0x001ef523: op0            
// 0x001ef524: op0            
// 0x001ef525: op0            
// 0x001ef526: op0            
// 0x001ef527: op0            
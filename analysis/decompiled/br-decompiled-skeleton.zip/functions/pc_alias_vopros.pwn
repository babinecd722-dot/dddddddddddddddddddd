// pc_alias_vopros @ 0x247cbc-0x247cf8 (60 bytes)
// Source: test.pwn

stock pc_alias_vopros()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00247cbc: op0            
// 0x00247cbd: op0            
// 0x00247cbe: op0            
// 0x00247cbf: op0            
// 0x00247cc0: op0            
// 0x00247cc1: op0            
// 0x00247cc2: op0            
// 0x00247cc3: op0            
// 0x00247cc4: op0            
// 0x00247cc5: op0            
// 0x00247cc6: op0            
// 0x00247cc7: op0            
// 0x00247cc8: op0            
// 0x00247cc9: op0            
// 0x00247cca: op0            
// 0x00247ccb: op0            
// 0x00247ccc: op0            
// 0x00247ccd: op0            
// 0x00247cce: op0            
// 0x00247ccf: op0            
// 0x00247cd0: op0            
// 0x00247cd1: op0            
// 0x00247cd2: op0            
// 0x00247cd3: op0            
// 0x00247cd4: op0            
// 0x00247cd5: op0            
// 0x00247cd6: op0            
// 0x00247cd7: op0            
// 0x00247cd8: op0            
// 0x00247cd9: op0            
// 0x00247cda: op0            
// 0x00247cdb: op0            
// 0x00247cdc: op0            
// 0x00247cdd: op0            
// 0x00247cde: op0            
// 0x00247cdf: op0            
// 0x00247ce0: op0            
// 0x00247ce1: op0            
// 0x00247ce2: op0            
// 0x00247ce3: op0            
// 0x00247ce4: op0            
// 0x00247ce5: op0            
// 0x00247ce6: op0            
// 0x00247ce7: op0            
// 0x00247ce8: op0            
// 0x00247ce9: op0            
// 0x00247cea: op0            
// 0x00247ceb: op0            
// 0x00247cec: op0            
// 0x00247ced: op0            
// 0x00247cee: op0            
// 0x00247cef: op0            
// 0x00247cf0: op0            
// 0x00247cf1: op0            
// 0x00247cf2: op0            
// 0x00247cf3: op0            
// 0x00247cf4: op0            
// 0x00247cf5: op0            
// 0x00247cf6: op0            
// 0x00247cf7: op0            
// LoadGangZones @ 0x1c0fe0-0x1c0ff8 (24 bytes)
// Source: test.pwn

stock LoadGangZones()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001c0fe0: op0            
// 0x001c0fe1: op0            
// 0x001c0fe2: op0            
// 0x001c0fe3: op0            
// 0x001c0fe4: op0            
// 0x001c0fe5: op0            
// 0x001c0fe6: op0            
// 0x001c0fe7: op0            
// 0x001c0fe8: op0            
// 0x001c0fe9: op0            
// 0x001c0fea: op0            
// 0x001c0feb: op0            
// 0x001c0fec: op0            
// 0x001c0fed: op0            
// 0x001c0fee: op0            
// 0x001c0fef: op0            
// 0x001c0ff0: op0            
// 0x001c0ff1: op0            
// 0x001c0ff2: op0            
// 0x001c0ff3: op0            
// 0x001c0ff4: op0            
// 0x001c0ff5: op0            
// 0x001c0ff6: op0            
// 0x001c0ff7: op0            
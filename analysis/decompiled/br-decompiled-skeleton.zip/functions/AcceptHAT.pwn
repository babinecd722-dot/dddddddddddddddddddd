// AcceptHAT @ 0x67008-0x67804 (2044 bytes)
// Source: system_orel_reshka.pwn

stock AcceptHAT()
{
    // stack -1065340144
    // stor.alt -289374207
    // stor.alt -360697040
    // branch jzer -> 0x64f1c080
    // stack 1501561043
    call_0x0x889ba81();
    // branch jump -> 552910976
    call_0x0x889ba81();
    // branch jump -> 552910976
    call_0x0x889ba81();
    // branch jump -> 552910976
    call_0x0x889ba81();
    // branch jump -> 552910976
    // load.pri 1894957184
    // load.alt 485736576
    // stor.alt -360697040
    // branch jzer -> 0x70f4c080
    // stack 1501561043
    call_0x0x788bba81();
    // branch jump -> 1157021824
    // load.pri 2096480384
    // stor.alt -360697040
    // branch jzer -> 0x14f7c080
    // stack 1501561043
    // stack 136776745
    call_0x0x5c8cba81();
    // branch jump -> 1358545024
    return 1;
    // branch jrel -> 136776745
    call_0x0x889ba81();
    // branch jump -> 1358545024
    // branch jneq -> 0x8270c29
    call_0x0x889ba81();
    // branch jump -> 1358545024
    // load.pri 553173120
    // load.alt 1291370624
    // stor.alt -360697040
    // branch jzer -> 0x20fac080
    // stack 1501561043
    // stack -1065340144
    // branch jump -> 620544128
    // stack -1065340144
    // load.pri 1023131776
    // load.alt 1157349504
    // stor.alt -360697040
    // branch jzer -> 0x74fcc080
    // stack 1501561043
    call_0x0x3cb4ba81();
    // branch jump -> 486523008
    // const.alt 1635810176
    // stack -1065340144
    // const.alt 1635810176
    // stack -1065340144
    // load.pri 16695424
    // load.alt 1023328384
    // stor.alt -360697040
    // branch jzer -> 0x6cffc080
    // stack 1501561043
    // const.alt 1635810176
    // stack -1048562928
}

// --- disasm (first 80) ---
// 0x00067008: op192          
// 0x00067009: op241          
// 0x0006700a: sref.alt       -2144925311
// 0x0006700f: op236          
// 0x00067010: switch         
// 0x00067011: op208          
// 0x00067012: sref.alt       204046119
// 0x00067017: push.c         0x-7f847ff4 ""
// 0x0006701c: xor            
// 0x0006701d: stack          -1065340144
// 0x00067022: op241          
// 0x00067023: sref.alt       -2147089791
// 0x00067028: op192          
// 0x00067029: op241          
// 0x0006702a: sref.alt       -289374208
// 0x0006702f: stor.alt       -289374207
// 0x00067034: jgeq           0x-113f7ffe
// 0x00067039: sysreq.pri     
// 0x0006703a: load.s.pri     888127616
// 0x0006703f: load.s.alt     1626325120
// 0x00067044: lref.pri       485539968
// 0x00067049: eq.alt         738265865
// 0x0006704e: op177          
// 0x0006704f: stor.alt       -360697040
// 0x00067054: op245          
// 0x00067055: mod            
// 0x00067056: eq.alt         -2146172151
// 0x0006705b: mod            
// 0x0006705c: jzer           0x64f1c080
// 0x00067061: eq.alt         738265865
// 0x00067066: lref.s.alt     738820400
// 0x0006706b: op252          
// 0x0006706c: op0            
// 0x0006706d: eq.pri         
// 0x0006706e: mod.c          
// 0x0006706f: addr.alt       2004908283
// 0x00067074: dec.s.pri      
// 0x00067075: op0            
// 0x00067076: stack          1501561043
// 0x0006707b: addr.alt       2004908238
// 0x00067080: op173          
// 0x00067081: op0            
// 0x00067082: push.c         0x-7effd900 ""
// 0x00067087: load.i         
// 0x00067088: load.s.pri     -2147385064
// 0x0006708d: op192          
// 0x0006708e: op243          
// 0x0006708f: cmps           
// 0x00067090: eq.alt         -327145719
// 0x00067095: switch         
// 0x00067096: op209          
// 0x00067097: sref.alt       136776745
// 0x0006709c: call           0x889ba81
// 0x000670a1: jump           552910976
// 0x000670a6: eq.alt         -327145719
// 0x000670ab: switch         
// 0x000670ac: op209          
// 0x000670ad: strb.i         136776745
// 0x000670b2: call           0x889ba81
// 0x000670b7: jump           552910976
// 0x000670bc: eq.alt         -327145719
// 0x000670c1: switch         
// 0x000670c2: op209          
// 0x000670c3: idxaddr.b      136776745
// 0x000670c8: call           0x889ba81
// 0x000670cd: jump           552910976
// 0x000670d2: eq.alt         -327145719
// 0x000670d7: switch         
// 0x000670d8: op209          
// 0x000670d9: sctrl          136776745
// 0x000670de: call           0x889ba81
// 0x000670e3: jump           552910976
// 0x000670e8: eq.alt         -1065352190
// 0x000670ed: op244          
// 0x000670ee: sctrl          -222265344
// 0x000670f3: shl.pri        
// 0x000670f4: load.pri       1894957184
// 0x000670f9: load.alt       485736576
// 0x000670fe: load.s.pri     1223934080
// 0x00067103: eq.alt         738265865
// OnPlayerDeath @ 0xbcf6c-0xbe4b0 (5444 bytes)
// Source: test.pwn

public OnPlayerDeath()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000bcf6c: op205          
// 0x000bcf6d: sign.alt       
// 0x000bcf6e: push           -425403008
// 0x000bcf73: jneq           0x7b800c27
// 0x000bcf78: eq.pri         
// 0x000bcf79: shl.alt        
// 0x000bcf7a: stack          209988624
// 0x000bcf7f: eq.pri         
// 0x000bcf80: mod.c          
// 0x000bcf81: retn           
// 0x000bcf82: proc           
// 0x000bcf83: eq.alt         201949449
// 0x000bcf88: eq.pri         
// 0x000bcf89: op220          
// 0x000bcf8a: op232          
// 0x000bcf8b: op231          
// 0x000bcf8c: sysreq.pri     
// 0x000bcf8d: load.s.pri     -2022080500
// 0x000bcf92: load.s.pri     -2146885093
// 0x000bcf97: neg            
// 0x000bcf98: eq.pri         
// 0x000bcf99: mul.c          
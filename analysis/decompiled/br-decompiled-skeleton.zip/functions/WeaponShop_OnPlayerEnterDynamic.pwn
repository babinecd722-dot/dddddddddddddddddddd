// WeaponShop_OnPlayerEnterDynamic @ 0xac374-0xac408 (148 bytes)
// Source: system_weapon_shop.inc

stock WeaponShop_OnPlayerEnterDynamic()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000ac374: push.s         823928588
// 0x000ac379: eq.alt         -2127507751
// 0x000ac37e: load.i         
// 0x000ac37f: push.s         655108464
// 0x000ac384: lref.s.alt     -1679720143
// 0x000ac389: load.s.alt     807706668
// 0x000ac38e: jump           1224403328
// 0x000ac393: eq.alt         661661961
// 0x000ac398: load.pri       203885609
// 0x000ac39d: call           0x8ce181
// 0x000ac3a2: stack          -2144128996
// 0x000ac3a7: op233          
// 0x000ac3a8: op250          
// 0x000ac3a9: shr.alt        
// 0x000ac3aa: eq.alt         655108361
// 0x000ac3af: load.s.alt     -576880335
// 0x000ac3b4: jneq           0x33301c2c
// 0x000ac3b9: eq.pri         
// 0x000ac3ba: op233          
// 0x000ac3bb: op250          
// 0x000ac3bc: shr.alt        
// 0x000ac3bd: eq.alt         -377485566
// 0x000ac3c2: op250          
// 0x000ac3c3: shr.alt        
// 0x000ac3c4: op0            
// 0x000ac3c5: eq.pri         
// 0x000ac3c6: op233          
// 0x000ac3c7: op229          
// 0x000ac3c8: eq.c.alt       
// 0x000ac3c9: load.pri       1223289216
// 0x000ac3ce: load.alt       15395200
// 0x000ac3d3: load.s.pri     82635136
// 0x000ac3d8: load.s.alt     1358096768
// 0x000ac3dd: lref.pri       351922560
// 0x000ac3e2: lref.alt       1425664384
// 0x000ac3e7: eq.alt         738265865
// 0x000ac3ec: idxaddr.b      -360697040
// 0x000ac3f1: op245          
// 0x000ac3f2: mod            
// 0x000ac3f3: eq.alt         662449161
// 0x000ac3f8: eq.pri         
// 0x000ac3f9: op236          
// 0x000ac3fa: op194          
// 0x000ac3fb: op182          
// 0x000ac3fc: push.pri       
// 0x000ac3fd: push.s         -2146949364
// 0x000ac402: emit           
// 0x000ac403: jsleq          0x74110c2c
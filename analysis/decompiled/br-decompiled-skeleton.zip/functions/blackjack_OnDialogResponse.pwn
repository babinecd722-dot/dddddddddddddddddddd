// blackjack_OnDialogResponse @ 0x4be6c-0x57dc0 (48980 bytes)
// Source: system_new_promo.pwn

stock blackjack_OnDialogResponse()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0004be6c: op255          
// 0x0004be6d: op255          
// 0x0004be6e: op255          
// 0x0004be6f: sign.alt       
// 0x0004be70: push.c         0x-207fd8ff ""
// 0x0004be75: op187          
// 0x0004be76: op250          
// 0x0004be77: or             
// 0x0004be78: push.s         -2146425072
// 0x0004be7d: emit           
// 0x0004be7e: stor.s.pri     1417679916
// 0x0004be83: jzer           0x-7e9b6f50
// 0x0004be88: load.i         
// 0x0004be89: push.c         0x-717bd900 ""
// 0x0004be8e: swap.alt       
// 0x0004be8f: eq.pri         
// 0x0004be90: op0            
// 0x0004be91: push.c         0x-5442080 ""
// 0x0004be96: sleq           
// 0x0004be97: push.s         823142156
// 0x0004be9c: eq.alt         863561357
// 0x0004bea1: op176          
// 0x0004bea2: pop.pri        
// 0x0004bea3: div.c          
// 0x0004bea4: eq.alt         209464329
// 0x0004bea9: eq.pri         
// 0x0004beaa: op214          
// 0x0004beab: op199          
// 0x0004beac: op219          
// 0x0004bead: sysreq.pri     
// 0x0004beae: load.s.pri     -2122743796
// 0x0004beb3: sysreq.c       
// 0x0004beb4: idxaddr        
// 0x0004beb5: move.alt       
// 0x0004beb6: load.i         
// 0x0004beb7: eq.pri         
// 0x0004beb8: neg            
// 0x0004beb9: eq.pri         
// 0x0004beba: mul.c          
// 0x0004bebb: movs.i         
// 0x0004bebc: div.c          
// 0x0004bebd: load.i         
// 0x0004bebe: stor.s.pri     50954620
// 0x0004bec3: zero.pri       
// 0x0004bec4: const.alt      -1833945217
// 0x0004bec9: div.c          
// 0x0004beca: const.alt      -1230971520
// 0x0004becf: mod            
// 0x0004bed0: load.s.pri     -2122743684
// 0x0004bed5: shl.alt        
// 0x0004bed6: idxaddr        
// 0x0004bed7: move.alt       
// 0x0004bed8: load.i         
// 0x0004bed9: eq.pri         
// 0x0004beda: neg            
// 0x0004bedb: eq.pri         
// 0x0004bedc: mul.c          
// 0x0004bedd: eq.alt         1769998608
// 0x0004bee2: lref.s.alt     1486008373
// 0x0004bee7: const.alt      1021281153
// 0x0004beec: load.s.pri     -2122743796
// 0x0004bef1: sysreq.c       
// 0x0004bef2: idxaddr        
// 0x0004bef3: move.alt       
// 0x0004bef4: load.i         
// 0x0004bef5: eq.pri         
// 0x0004bef6: neg            
// 0x0004bef7: eq.pri         
// 0x0004bef8: mul.c          
// 0x0004bef9: stor.alt       -1833945847
// 0x0004befe: div.c          
// 0x0004beff: const.pri      -1833946367
// 0x0004bf04: mul            
// 0x0004bf05: eq.pri         
// 0x0004bf06: mod.c          
// 0x0004bf07: jzer           0x-7edb6c50
// 0x0004bf0c: load.i         
// 0x0004bf0d: push.s         655108368
// 0x0004bf12: lref.s.alt     -1417379535
// 0x0004bf17: mul            
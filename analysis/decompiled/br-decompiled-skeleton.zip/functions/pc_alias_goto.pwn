// pc_alias_goto @ 0x399c58-0x399c94 (60 bytes)
// Source: test.pwn

stock pc_alias_goto()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00399c58: op0            
// 0x00399c59: op0            
// 0x00399c5a: op0            
// 0x00399c5b: op0            
// 0x00399c5c: op0            
// 0x00399c5d: op0            
// 0x00399c5e: op0            
// 0x00399c5f: op0            
// 0x00399c60: op0            
// 0x00399c61: op0            
// 0x00399c62: op0            
// 0x00399c63: op0            
// 0x00399c64: op0            
// 0x00399c65: op0            
// 0x00399c66: op0            
// 0x00399c67: op0            
// 0x00399c68: op0            
// 0x00399c69: op0            
// 0x00399c6a: op0            
// 0x00399c6b: op0            
// 0x00399c6c: op0            
// 0x00399c6d: op0            
// 0x00399c6e: op0            
// 0x00399c6f: op0            
// 0x00399c70: op0            
// 0x00399c71: op0            
// 0x00399c72: op0            
// 0x00399c73: op0            
// 0x00399c74: op0            
// 0x00399c75: op0            
// 0x00399c76: op0            
// 0x00399c77: op0            
// 0x00399c78: op0            
// 0x00399c79: op0            
// 0x00399c7a: op0            
// 0x00399c7b: op0            
// 0x00399c7c: op0            
// 0x00399c7d: op0            
// 0x00399c7e: op0            
// 0x00399c7f: op0            
// 0x00399c80: op0            
// 0x00399c81: op0            
// 0x00399c82: op0            
// 0x00399c83: op0            
// 0x00399c84: op0            
// 0x00399c85: op0            
// 0x00399c86: op0            
// 0x00399c87: op0            
// 0x00399c88: op0            
// 0x00399c89: op0            
// 0x00399c8a: op0            
// 0x00399c8b: op0            
// 0x00399c8c: op0            
// 0x00399c8d: op0            
// 0x00399c8e: op0            
// 0x00399c8f: op0            
// 0x00399c90: op0            
// 0x00399c91: op0            
// 0x00399c92: op0            
// 0x00399c93: op0            
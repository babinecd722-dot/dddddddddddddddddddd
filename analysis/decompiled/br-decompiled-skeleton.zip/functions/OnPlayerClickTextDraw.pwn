// OnPlayerClickTextDraw @ 0x18588-0x1b868 (13024 bytes)
// Source: system_blackjack_full.pwn

public OnPlayerClickTextDraw()
{
    // const.alt 204022793
    // stack 654934288
    // load.pri -338264052
    // const.alt 204022793
    // load.pri 159453228
    // const.alt -1762863488
    return 1;
    // const.alt -1197833177
    // stack -2129188076
    return 1;
    // stack 654934292
    // proc @0x18632
    // const.alt -1762863488
    return 1;
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    return 1;
    // const.alt -1762863488
    return 1;
    // stack -2129188076
    return 1;
    // stack 654934292
    // proc @0x18795
    // const.alt -1762863488
    return 1;
    // load.alt 159454252
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    return 1;
    // stack 201949456
    return 1;
    // stack -1197833177
    // stack -2129188076
    return 1;
    // stack 654934292
    // proc @0x1890a
    // const.alt -1762863488
    return 1;
    // load.alt 159454252
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    return 1;
    // stack 201949456
    return 1;
    // const.alt -696244444
    // stack -2129188076
    return 1;
    // const.alt 204022793
    // stack 654934292
    // proc @0x18a7f
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // load.alt 159454252
    return 1;
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // stack 654934288
    return 1;
    // const.alt 204022793
    // stack 201949456
    return 1;
    // stack -2129188076
    return 1;
    // stack 654934292
    // proc @0x18bee
    // const.alt -1762863488
    return 1;
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    return 1;
    // const.alt -1762863488
    return 1;
    // stack -2129188076
    return 1;
    // stack 654934292
    // proc @0x18d51
    // const.alt -1762863488
    return 1;
    // load.alt 159454252
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    return 1;
    // stack 201949456
    return 1;
    // stack -2129188076
    return 1;
    // stack 654934292
    // proc @0x18ec6
    // const.alt -1762863488
    return 1;
    // load.alt 159454252
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stack 654934288
    return 1;
    // stack 201949456
    return 1;
    // const.alt -696244444
    // stack -2129188076
    return 1;
    // const.alt 204022793
    // stack 654934292
    // proc @0x1903b
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // load.alt 159454252
    return 1;
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 204022793
    // stack 654934288
    return 1;
    // const.alt 204022793
    // stack 201949456
    return 1;
    // const.alt 1317013794
    // const.alt -393116633
    // stack -2129188076
    return 1;
    // const.alt 1317013794
    // stack 654934292
    // proc @0x191aa
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    return 1;
    // const.alt 1317013794
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack -2129188076
    return 1;
    // const.alt 1317013794
    // stack 654934292
    // proc @0x1930d
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // load.alt 159454252
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    return 1;
    // const.alt 1317013794
    // stack 201949456
    return 1;
    // const.alt 1317013794
    // stack -393116633
    // stack -2129188076
    return 1;
    // const.alt 1317013794
    // stack 654934292
    // proc @0x19482
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // load.alt 159454252
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // stack 654934288
    return 1;
    // const.alt 1317013794
    // stack 201949456
    return 1;
    // const.alt 1317013794
    // const.alt -696244444
    // stack -2129188076
    return 1;
    // const.alt 1317013794
    // const.alt 204022793
    // stack 654934292
    // proc @0x195f7
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // const.alt 204022793
    // load.alt 159454252
    return 1;
    // const.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // const.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    return 1;
    // const.alt 1317013794
    // const.alt 204022793
    // stack 201949456
    return 1;
    // stor.alt 1317013794
    // stack -2129188076
    return 1;
    // stor.alt 1317013794
    // stack 654934292
    // proc @0x19766
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    return 1;
    // stor.alt 1317013794
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack -2129188076
    return 1;
    // stor.alt 1317013794
    // stack 654934292
    // proc @0x198c9
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // load.alt 159454252
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    return 1;
    // stor.alt 1317013794
    // stack 201949456
    return 1;
    // stor.alt 1317013794
    // stack -2129188076
    return 1;
    // stor.alt 1317013794
    // stack 654934292
    // proc @0x19a3e
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // load.alt 159454252
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // stack 654934288
    return 1;
    // stor.alt 1317013794
    // stack 201949456
    return 1;
    // stor.alt 1317013794
    // const.alt -696244444
    // stack -2129188076
    return 1;
    // stor.alt 1317013794
    // const.alt 204022793
    // stack 654934292
    // proc @0x19bb3
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // const.alt 204022793
    // load.alt 159454252
    return 1;
    // stor.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    // const.alt -1762863488
    return 1;
    // stor.alt 1317013794
    // const.alt 204022793
    // stack 654934288
    return 1;
    // stor.alt 1317013794
    // const.alt 204022793
    // stack 201949456
    // const.alt -442792921
    // const.alt 270994473
    // stack -2129188076
    // stack 654934292
    // stack 654934288
    // const.alt -504506752
    // stack 654934288
    // const.alt -504506752
    // stack 654934288
    // const.alt -504506752
    // stack 654934288
    return 1;
    // proc @0x19dbc
    // stor.alt 593068066
    // const.alt -607660416
    // branch jneq -> 0x-7feffbf7
    // const.pri -2137967871
    // branch jzer -> 0x-7eef7e6f
    // const.pri 159461503
    // stack 1501568250
    // branch jneq -> 0x10040924
    // const.alt 2071988263
    // const.alt 1484815232
    // stack 762588432
    // stack -2122568412
    // stack 50954512
    // const.alt -607660416
    // branch jneq -> 0x-297fd8dc
    return 1;
    // stack 654934296
    // stack 50954512
    // stor.alt 1046052898
    // stack 654934292
    // stack 
    // stack 
    // stack 
    // stack 654934292
    // stack 
    // load.pri 86442279
    // stack 
    // const.pri 1686449153
    return 1;
    // proc @0x19fe0
    // branch jump -> -2129884271
    // const.alt -353511808
    // branch jneq -> 0x-f297fd9
    // const.alt -2144926937
    // stack 
    // proc @0x1a035
    // branch jump -> 738233233
    return 1;
    // proc @0x1a066
    call_0x0x-7eef2978();
    // stor.alt 159460912
    // stack 201949452
    // stack -1903086836
    // stor.alt 159460912
    // branch jnz -> 0x-7ecf5d6f
    // branch jump -> -2129882735
    // branch jnz -> 0x-6ecae7d4
    // const.alt 2038462467
    // const.alt 2038462467
    // branch jzer -> 0x-7e93696f
    // const.alt -1561405824
    // const.alt 2038462467
    // const.pri 159454977
    // const.alt -1494296960
    // stor.alt 385944354
    return 1;
    // branch jump -> -2130665071
    // const.alt -1561405824
    // const.alt 2038462467
    // branch jzer -> 0x-7ef3656f
    // const.alt -1561405824
    // const.alt 2038462467
    // const.alt -1494296960
    // const.pri 159454977
    // const.alt -1494296960
    // stor.alt 386009890
    return 1;
    // branch jump -> -2130665071
    // const.alt -1561405824
    // const.alt 2038462467
    // branch jzer -> 0x-7ed3626f
    // const.alt -1561405824
    // const.alt 2038462467
    // const.pri 159454977
    // const.alt -1494296960
    // stor.alt 386075426
    return 1;
    // branch jump -> -2130665071
    // const.alt -1561405824
    // const.alt 2038462467
    // stack 2137620489
    // branch jzer -> 0x-7eb35f6f
    // const.alt -1561405824
    // const.alt 2038462467
    // stack 386663202
    // const.pri 159454977
    // const.alt -1494296960
    // stor.alt 386140962
    return 1;
    // branch jump -> -2130665071
    // stack -1584319728
    return 1;
    // stack -1584319728
    // branch jump -> 738234769
    // branch jnz -> 0x-7ed75d6f
    // branch jrel -> -507447001
    // stack -2130433008
    // const.pri -2127679487
    // load.pri 144937277
    ();
    ();
    // stor.alt -1858797301
    ();
    // load.pri 1688441149
    ();
    // branch jump -> 191669137
    // load.pri 10785077
    // const.pri -2146171903
    // const.pri -2146434047
    // stack 184756092
    // load.pri 1350571012
    // const.pri -2146434047
    // stack 184821628
    // load.pri 1350571012
    // const.pri -2146434047
    // stack 184887164
    // load.pri 1350571012
    // const.pri -2146434047
    // branch jump -> 188786577
    // load.pri 682135861
    // const.alt 2071992359
    // stack -2146860772
    // stack 159461392
    // stor.alt -942243828
    // branch jrel -> -2130673113
    // stack 185172268
    // stor.alt -404455119
    // const.alt -1361215449
    // stack 8924188
    // branch jump -> -2129873007
    // branch jzer -> 0x-7eb7526f
    // const.alt -607660416
    // const.pri 806366209
    // stor.alt -942243828
    // stack 185172268
    // stor.alt -404455119
    // stack -1858928504
    // const.alt -2146694783
    // stack 203885609
    call_0x0x448a8581();
    // const.pri 1812222095
    // const.pri 1812222095
    // const.alt -607660416
    // stack 203885609
    call_0x0x448a8581();
    // stack -1215220980
    // const.alt 19335553
    // branch jump -> -2129873007
    // stor.alt -2129918591
    // stack -1215220960
    // const.alt -1861942655
    // load.alt 70825361
    // stor.alt 159460912
    // const.alt 2071987239
    // stack -2122837752
    // stack 662186364
    // const.alt 2038434819
    // load.pri 654934295
    // load.pri -1461813209
    return 1;
    // branch jneq -> 0xc277029
    // branch jneq -> 0x-7fd8dbf7
    // stack 738820364
    // ... truncated ...
}

// --- disasm (first 80) ---
// 0x00018588: eq.pri         
// 0x00018589: op214          
// 0x0001858a: op235          
// 0x0001858b: op239          
// 0x0001858c: push           2038434819
// 0x00018591: eq.alt         153230201
// 0x00018596: eq.pri         
// 0x00018597: neg            
// 0x00018598: eq.pri         
// 0x00018599: mul.c          
// 0x0001859a: const.alt      204022793
// 0x0001859f: push.c         0x-7e847ff4 ""
// 0x000185a4: op0            
// 0x000185a5: stack          654934288
// 0x000185aa: load.pri       -338264052
// 0x000185af: op239          
// 0x000185b0: push           2038434819
// 0x000185b5: eq.alt         153230201
// 0x000185ba: eq.pri         
// 0x000185bb: neg            
// 0x000185bc: eq.pri         
// 0x000185bd: mul.c          
// 0x000185be: const.alt      204022793
// 0x000185c3: push.c         0x-7e847ff4 ""
// 0x000185c8: load.pri       159453228
// 0x000185cd: const.alt      -1762863488
// 0x000185d2: retn           
// 0x000185d3: load.s.pri     -2122743796
// 0x000185d8: sysreq.c       
// 0x000185d9: idxaddr        
// 0x000185da: move.alt       
// 0x000185db: load.i         
// 0x000185dc: eq.pri         
// 0x000185dd: neg            
// 0x000185de: eq.pri         
// 0x000185df: mul.c          
// 0x000185e0: load.s.alt     1317013794
// 0x000185e5: push.pri       
// 0x000185e6: push.c         0x-790f2980 ""
// 0x000185eb: const.alt      -1197833177
// 0x000185f0: op168          
// 0x000185f1: sysreq.c       
// 0x000185f2: push.c         0x-7e7c ""
// 0x000185f7: zero.pri       
// 0x000185f8: push.s         -2146425076
// 0x000185fd: emit           
// 0x000185fe: eq.pri         
// 0x000185ff: sysreq.c       
// 0x00018600: stack          -2129188076
// 0x00018605: load.i         
// 0x00018606: push.c         0xc002700 ""
// 0x0001860b: eq.pri         
// 0x0001860c: op214          
// 0x0001860d: op236          
// 0x0001860e: heap           
// 0x0001860f: retn           
// 0x00018610: load.s.pri     -2122743796
// 0x00018615: sysreq.c       
// 0x00018616: idxaddr        
// 0x00018617: move.alt       
// 0x00018618: load.i         
// 0x00018619: eq.pri         
// 0x0001861a: neg            
// 0x0001861b: eq.pri         
// 0x0001861c: mul.c          
// 0x0001861d: load.s.alt     1317013794
// 0x00018622: load.i         
// 0x00018623: push.pri       
// 0x00018624: push.s         -2146425076
// 0x00018629: emit           
// 0x0001862a: eq.pri         
// 0x0001862b: file           
// 0x0001862c: stack          654934292
// 0x00018631: dec.s.pri      
// 0x00018632: proc           
// 0x00018633: op169          
// 0x00018634: op232          
// 0x00018635: load.i         
// 0x00018636: push.c         0x-662c6a7c ""
// 0x0001863b: neg            
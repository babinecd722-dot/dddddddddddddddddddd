// FindAccsDataIndexByModel @ 0xf7c4-0xf880 (188 bytes)
// Source: test.pwn

stock FindAccsDataIndexByModel()
{
    // const.alt -705964416
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // branch jrel -> -2146694783
    // const.alt 2038434819
    // stack 201949452
    // const.alt 2038434819
    // stack 931073033
    // const.alt -2146687991
    // const.alt 2038434819
}

// --- disasm (first 80) ---
// 0x0000f7c4: const.alt      -705964416
// 0x0000f7c9: lref.s.alt     2038434819
// 0x0000f7ce: lref.pri       -2146885093
// 0x0000f7d3: neg            
// 0x0000f7d4: eq.pri         
// 0x0000f7d5: mul.c          
// 0x0000f7d6: load.s.alt     -2146687991
// 0x0000f7db: op214          
// 0x0000f7dc: op238          
// 0x0000f7dd: nop            
// 0x0000f7de: const.alt      2038434819
// 0x0000f7e3: lref.pri       -2146885093
// 0x0000f7e8: neg            
// 0x0000f7e9: eq.pri         
// 0x0000f7ea: mul.c          
// 0x0000f7eb: push.pri       
// 0x0000f7ec: load.i         
// 0x0000f7ed: push.pri       
// 0x0000f7ee: push.c         0x-7f847ff8 ""
// 0x0000f7f3: sshr           
// 0x0000f7f4: stack          201949452
// 0x0000f7f9: eq.pri         
// 0x0000f7fa: op214          
// 0x0000f7fb: op238          
// 0x0000f7fc: nop            
// 0x0000f7fd: const.alt      2038434819
// 0x0000f802: lref.pri       -2146885093
// 0x0000f807: neg            
// 0x0000f808: eq.pri         
// 0x0000f809: mul.c          
// 0x0000f80a: push           931073033
// 0x0000f80f: fill.i         
// 0x0000f810: nop            
// 0x0000f811: jrel           -2146694783
// 0x0000f816: op214          
// 0x0000f817: op235          
// 0x0000f818: op213          
// 0x0000f819: lref.s.alt     2038434819
// 0x0000f81e: lref.pri       -2146885093
// 0x0000f823: neg            
// 0x0000f824: eq.pri         
// 0x0000f825: mul.c          
// 0x0000f826: lref.s.alt     -2146687991
// 0x0000f82b: op214          
// 0x0000f82c: op238          
// 0x0000f82d: nop            
// 0x0000f82e: const.alt      2038434819
// 0x0000f833: lref.pri       -2146885093
// 0x0000f838: neg            
// 0x0000f839: eq.pri         
// 0x0000f83a: mul.c          
// 0x0000f83b: push.pri       
// 0x0000f83c: load.i         
// 0x0000f83d: push.pri       
// 0x0000f83e: push.c         0x-7f847ff8 ""
// 0x0000f843: sshr           
// 0x0000f844: stack          201949452
// 0x0000f849: eq.pri         
// 0x0000f84a: op214          
// 0x0000f84b: op238          
// 0x0000f84c: nop            
// 0x0000f84d: const.alt      2038434819
// 0x0000f852: lref.pri       -2146885093
// 0x0000f857: neg            
// 0x0000f858: eq.pri         
// 0x0000f859: mul.c          
// 0x0000f85a: stack          931073033
// 0x0000f85f: fill.i         
// 0x0000f860: sym.debug      
// 0x0000f861: lref.s.alt     -2146694783
// 0x0000f866: op214          
// 0x0000f867: op235          
// 0x0000f868: op213          
// 0x0000f869: lref.s.alt     2038434819
// 0x0000f86e: lref.pri       -2146885093
// 0x0000f873: neg            
// 0x0000f874: eq.pri         
// 0x0000f875: mul.c          
// 0x0000f876: const.alt      -2146687991
// 0x0000f87b: op214          
// ExchangeFuelStation @ 0x5fbf8-0x605a4 (2476 bytes)
// Source: system_exchange_welsi.pwn

stock ExchangeFuelStation()
{
    // branch jrel -> 335743361
    // branch jzer -> 0x-7ecb4244
    // branch jneq -> 0x79800c03
    // stack -2146694783
    // branch jneq -> 0x79800c03
    // load.pri 688488727
    // const.alt 2071987239
    // branch jzer -> 0x-7e833f44
    // load.pri -2124889924
    // branch jrel -> -2144927193
}

// --- disasm (first 80) ---
// 0x0005fbf8: op189          
// 0x0005fbf9: jrel           335743361
// 0x0005fbfe: jzer           0x-7ecb4244
// 0x0005fc03: load.i         
// 0x0005fc04: push.c         0xc098100 ""
// 0x0005fc09: eq.pri         
// 0x0005fc0a: op204          
// 0x0005fc0b: casetbl        
// 0x0005fc0c: pop.pri        
// 0x0005fc0d: jneq           0x79800c03
// 0x0005fc12: eq.alt         -1137305223
// 0x0005fc17: op189          
// 0x0005fc18: stack          -2146694783
// 0x0005fc1d: op204          
// 0x0005fc1e: casetbl        
// 0x0005fc1f: pop.pri        
// 0x0005fc20: jneq           0x79800c03
// 0x0005fc25: eq.alt         186784633
// 0x0005fc2a: load.pri       688488727
// 0x0005fc2f: const.alt      2071987239
// 0x0005fc34: eq.alt         285748286
// 0x0005fc39: zero.pri       
// 0x0005fc3a: eq.alt         1621698313
// 0x0005fc3f: push.s         -2146949364
// 0x0005fc44: emit           
// 0x0005fc45: eq.alt         738995263
// 0x0005fc4a: load.s.alt     268634497
// 0x0005fc4f: eq.pri         
// 0x0005fc50: grtr           
// 0x0005fc51: eq.pri         
// 0x0005fc52: mul            
// 0x0005fc53: jzer           0x-7e833f44
// 0x0005fc58: load.i         
// 0x0005fc59: load.s.pri     -1061407468
// 0x0005fc5e: zero.pri       
// 0x0005fc5f: eq.alt         -2129132791
// 0x0005fc64: load.pri       -2124889924
// 0x0005fc69: load.i         
// 0x0005fc6a: push.c         0x-39671380 ""
// 0x0005fc6f: zero.pri       
// 0x0005fc70: push.c         0x-39671380 ""
// 0x0005fc75: mul            
// 0x0005fc76: push.c         0x-3a671380 ""
// 0x0005fc7b: sysreq.pri     
// 0x0005fc7c: push.c         0x-3a671380 ""
// 0x0005fc81: jrel           -2144927193
// 0x0005fc86: div            
// 0x0005fc87: push.s         823928588
// GetPromoLevelForOwner @ 0x5a0c8-0x5a25c (404 bytes)
// Source: system_new_promo.pwn

stock GetPromoLevelForOwner()
{
    // stack 654934284
    // branch jneq -> 0x8270c29
    // const.alt 136776745
    // branch jump -> 185137080
    // load.pri 419018805
    // stack 136776745
    return 1;
    // branch jrel -> 136776745
    // stor.alt 136776745
    // stack 136776745
    // stack -327145604
    // load.alt -1432564608
}

// --- disasm (first 80) ---
// 0x0005a0c8: lref.s.alt     444693376
// 0x0005a0cd: stack          654934284
// 0x0005a0d2: eq.pri         
// 0x0005a0d3: op236          
// 0x0005a0d4: pop.alt        
// 0x0005a0d5: op189          
// 0x0005a0d6: leq            
// 0x0005a0d7: push.s         -2146949364
// 0x0005a0dc: emit           
// 0x0005a0dd: eq.alt         738995226
// 0x0005a0e2: lref.s.alt     419018803
// 0x0005a0e7: eq.alt         -327145719
// 0x0005a0ec: pop.alt        
// 0x0005a0ed: op190          
// 0x0005a0ee: jneq           0x8270c29
// 0x0005a0f3: eq.pri         
// 0x0005a0f4: emit           
// 0x0005a0f5: jsleq          0x-47c9f3d4
// 0x0005a0fa: op247          
// 0x0005a0fb: op0            
// 0x0005a0fc: push.c         0x-406b1380 ""
// 0x0005a101: const.alt      136776745
// 0x0005a106: eq.pri         
// 0x0005a107: emit           
// 0x0005a108: jsleq          0x-47c9f3d4
// 0x0005a10d: op247          
// 0x0005a10e: op0            
// 0x0005a10f: eq.pri         
// 0x0005a110: mod.c          
// 0x0005a111: jump           185137080
// 0x0005a116: load.pri       419018805
// 0x0005a11b: eq.alt         -327145719
// 0x0005a120: pop.alt        
// 0x0005a121: op191          
// 0x0005a122: div.c          
// 0x0005a123: push.s         -2146949364
// 0x0005a128: emit           
// 0x0005a129: eq.alt         -2129908710
// 0x0005a12e: load.i         
// 0x0005a12f: push.c         0x-3f6b1380 ""
// 0x0005a134: stack          136776745
// 0x0005a139: eq.pri         
// 0x0005a13a: emit           
// 0x0005a13b: eq.alt         -2129908710
// 0x0005a140: load.i         
// 0x0005a141: push.c         0x-3e6b1380 ""
// 0x0005a146: lref.s.alt     136776745
// 0x0005a14b: eq.pri         
// 0x0005a14c: emit           
// 0x0005a14d: eq.alt         -2129908710
// 0x0005a152: load.i         
// 0x0005a153: push.c         0x-3e6b1380 ""
// 0x0005a158: div.c          
// 0x0005a159: push.s         -2146949364
// 0x0005a15e: emit           
// 0x0005a15f: eq.alt         -2129908710
// 0x0005a164: load.i         
// 0x0005a165: push.c         0x-3d6b1380 ""
// 0x0005a16a: push.pri       
// 0x0005a16b: push.s         -2146949364
// 0x0005a170: emit           
// 0x0005a171: eq.alt         -2129908710
// 0x0005a176: load.i         
// 0x0005a177: push.c         0x-3d6b1380 ""
// 0x0005a17c: sysreq.pri     
// 0x0005a17d: push.s         -2146949364
// 0x0005a182: emit           
// 0x0005a183: eq.alt         738995226
// 0x0005a188: load.s.alt     821868595
// 0x0005a18d: eq.alt         -327145719
// 0x0005a192: pop.alt        
// 0x0005a193: op195          
// 0x0005a194: jsgeq          
// 0x0005a195: push.s         -2146949364
// 0x0005a19a: emit           
// 0x0005a19b: jsleq          0x-47c9f3d4
// 0x0005a1a0: op250          
// 0x0005a1a1: strb.i         -1796440025
// 0x0005a1a6: op196          
// 0x0005a1a7: sref.alt       136776745
// UnloadOwnableCarTrunk @ 0x1c9bbc-0x1c9c38 (124 bytes)
// Source: test.pwn

stock UnloadOwnableCarTrunk()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001c9bbc: op0            
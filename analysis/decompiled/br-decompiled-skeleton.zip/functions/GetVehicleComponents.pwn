// GetVehicleComponents @ 0xdd178-0xdd294 (284 bytes)
// Source: test.pwn

stock GetVehicleComponents()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000dd178: shr.pri        
// 0x000dd179: const.pri      -508833920
// 0x000dd17e: zero.pri       
// 0x000dd17f: load.i         
// 0x000dd180: push.pri       
// 0x000dd181: push.c         0x-7f847ff4 ""
// 0x000dd186: eq.c.alt       
// 0x000dd187: stack          654934288
// 0x000dd18c: dec.s.pri      
// 0x000dd18d: bounds.p       
// 0x000dd18e: op192          
// 0x000dd18f: eq.pri         
// 0x000dd190: op0            
// 0x000dd191: push.c         0x-647bd8ec ""
// 0x000dd196: pop.alt        
// 0x000dd197: eq.pri         
// 0x000dd198: op0            
// 0x000dd199: push.c         0x28823108 ""
// 0x000dd19e: push.pri       
// 0x000dd19f: const.pri      -508833920
// 0x000dd1a4: zero.pri       
// 0x000dd1a5: load.i         
// 0x000dd1a6: push.pri       
// 0x000dd1a7: push.c         0x-7f847ff4 ""
// 0x000dd1ac: bounds         
// 0x000dd1ad: stack          654934288
// 0x000dd1b2: load.pri       -1412464629
// 0x000dd1b7: op225          
// 0x000dd1b8: zero.pri       
// 0x000dd1b9: load.i         
// 0x000dd1ba: push.pri       
// 0x000dd1bb: push.c         0x-7f847ff8 ""
// 0x000dd1c0: inc            
// 0x000dd1c1: stack          654934284
// 0x000dd1c6: sign.alt       
// 0x000dd1c7: const.pri      -508833920
// 0x000dd1cc: zero.pri       
// 0x000dd1cd: load.i         
// 0x000dd1ce: push.pri       
// 0x000dd1cf: push.c         0x-7f847ff8 ""
// 0x000dd1d4: shr            
// 0x000dd1d5: stack          654934284
// 0x000dd1da: op0            
// 0x000dd1db: const.pri      -508833920
// 0x000dd1e0: zero.pri       
// 0x000dd1e1: load.i         
// 0x000dd1e2: push.pri       
// 0x000dd1e3: push.c         0x-7f847ff8 ""
// 0x000dd1e8: dec            
// 0x000dd1e9: stack          654934284
// 0x000dd1ee: load.pri       -1412464629
// 0x000dd1f3: op225          
// 0x000dd1f4: zero.pri       
// 0x000dd1f5: load.i         
// 0x000dd1f6: push.pri       
// 0x000dd1f7: push.c         0x-7f847ff8 ""
// 0x000dd1fc: movs           
// 0x000dd1fd: stack          654934284
// 0x000dd202: jump           -1412464629
// 0x000dd207: op225          
// 0x000dd208: zero.pri       
// 0x000dd209: load.i         
// 0x000dd20a: push.pri       
// 0x000dd20b: push.c         0x-7f847ff8 ""
// 0x000dd210: cmps           
// 0x000dd211: stack          654934284
// 0x000dd216: load.pri       -1412464629
// 0x000dd21b: op225          
// 0x000dd21c: zero.pri       
// 0x000dd21d: load.i         
// 0x000dd21e: push.pri       
// 0x000dd21f: push.c         0x-7f847ff8 ""
// 0x000dd224: fill           
// 0x000dd225: stack          654934284
// 0x000dd22a: load.pri       -1412464629
// 0x000dd22f: op225          
// 0x000dd230: zero.pri       
// 0x000dd231: load.i         
// 0x000dd232: push.pri       
// 0x000dd233: push.c         0x-7f847ff8 ""
// GetCaseBonusRequiredOpenCount @ 0x11868-0x11940 (216 bytes)
// Source: test.pwn

stock GetCaseBonusRequiredOpenCount()
{
    // stack -2130083564
    // stack 654934284
    // const.alt -756296064
    // stack 1619012620
    // branch jump -> -2129866613
    // const.alt -1561405824
    // const.alt 2038434819
    // branch jump -> -2129622644
    // const.alt -1561405824
    // const.alt 2038434819
    // const.alt -510969985
    // const.alt 2038434819
    // branch jrel -> 359235593
    // branch jnz -> 0xc74d18b
    // const.alt 2038434819
    // branch jrel -> 1058343945
    // const.pri -745851647
}

// --- disasm (first 80) ---
// 0x00011868: push.c         0x-fa7ee8 ""
// 0x0001186d: idxaddr.b      2071990311
// 0x00011872: push.alt       
// 0x00011873: stack          -2130083564
// 0x00011878: lref.pri       -2146689793
// 0x0001187d: op214          
// 0x0001187e: op235          
// 0x0001187f: op210          
// 0x00011880: sref.alt       2038434819
// 0x00011885: lref.pri       -2146885093
// 0x0001188a: neg            
// 0x0001188b: load.i         
// 0x0001188c: push.pri       
// 0x0001188d: push.c         0x-7f847ff8 ""
// 0x00011892: div            
// 0x00011893: stack          654934284
// 0x00011898: sign.alt       
// 0x00011899: const.alt      -756296064
// 0x0001189e: sref.alt       2038434819
// 0x000118a3: lref.pri       -2146885093
// 0x000118a8: neg            
// 0x000118a9: load.i         
// 0x000118aa: push.pri       
// 0x000118ab: push.c         0x-7f847ff8 ""
// 0x000118b0: shr            
// 0x000118b1: stack          1619012620
// 0x000118b6: jump           -2129866613
// 0x000118bb: load.i         
// 0x000118bc: const.alt      -1561405824
// 0x000118c1: const.alt      2038434819
// 0x000118c6: lref.pri       -2146885093
// 0x000118cb: neg            
// 0x000118cc: eq.pri         
// 0x000118cd: mul.c          
// 0x000118ce: strb.i         58788132
// 0x000118d3: eq.pri         
// 0x000118d4: eq.c.pri       
// 0x000118d5: pop.pri        
// 0x000118d6: jump           -2129622644
// 0x000118db: load.i         
// 0x000118dc: const.alt      -1561405824
// 0x000118e1: const.alt      2038434819
// 0x000118e6: lref.pri       -2146885093
// 0x000118eb: neg            
// 0x000118ec: eq.pri         
// 0x000118ed: mul.c          
// 0x000118ee: push.pri       
// 0x000118ef: load.i         
// 0x000118f0: const.alt      -510969985
// 0x000118f5: sleq           
// 0x000118f6: eq.alt         -696251383
// 0x000118fb: op238          
// 0x000118fc: nop            
// 0x000118fd: const.alt      2038434819
// 0x00011902: lref.pri       -2146885093
// 0x00011907: neg            
// 0x00011908: eq.pri         
// 0x00011909: mul.c          
// 0x0001190a: jrel           359235593
// 0x0001190f: jnz            0xc74d18b
// 0x00011914: eq.pri         
// 0x00011915: op214          
// 0x00011916: op238          
// 0x00011917: nop            
// 0x00011918: const.alt      2038434819
// 0x0001191d: lref.pri       -2146885093
// 0x00011922: neg            
// 0x00011923: eq.pri         
// 0x00011924: mul.c          
// 0x00011925: jrel           1058343945
// 0x0001192a: halt.p         native#1501590737 args=2094107443
// 0x00011933: const.pri      -745851647
// 0x00011938: sref.alt       -2146694783
// 0x0001193d: op214          
// 0x0001193e: op238          
// 0x0001193f: nop            
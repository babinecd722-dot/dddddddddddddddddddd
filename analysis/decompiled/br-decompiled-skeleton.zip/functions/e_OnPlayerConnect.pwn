// e_OnPlayerConnect @ 0x991c4-0x99230 (108 bytes)
// Source: system_auction.pwn

stock e_OnPlayerConnect()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000991c4: op183          
// 0x000991c5: op207          
// 0x000991c6: or             
// 0x000991c7: push.c         0x-62440974 ""
// 0x000991cc: sign.alt       
// 0x000991cd: push.s         -2146687220
// 0x000991d2: emit           
// 0x000991d3: eq.pri         
// 0x000991d4: xor            
// 0x000991d5: stack          -562023664
// 0x000991da: op191          
// 0x000991db: stack          -2144925311
// 0x000991e0: op236          
// 0x000991e1: op183          
// 0x000991e2: op209          
// 0x000991e3: stack          -422803161
// 0x000991e8: op179          
// 0x000991e9: sign.alt       
// 0x000991ea: push.s         -2146687220
// 0x000991ef: emit           
// 0x000991f0: eq.pri         
// 0x000991f1: xor            
// 0x000991f2: stack          654934288
// 0x000991f7: eq.pri         
// 0x000991f8: op236          
// 0x000991f9: op183          
// 0x000991fa: op210          
// 0x000991fb: div.c          
// 0x000991fc: push.s         822617868
// 0x00099201: eq.alt         860133023
// 0x00099206: eq.pri         
// 0x00099207: op222          
// 0x00099208: op194          
// 0x00099209: eq.c.alt       
// 0x0009920a: eq.alt         -696251383
// 0x0009920f: op199          
// 0x00099210: op219          
// 0x00099211: sysreq.pri     
// 0x00099212: load.s.pri     -2122743796
// 0x00099217: sysreq.c       
// 0x00099218: idxaddr        
// 0x00099219: move.alt       
// 0x0009921a: load.i         
// 0x0009921b: eq.pri         
// 0x0009921c: neg            
// 0x0009921d: eq.pri         
// 0x0009921e: mul.c          
// 0x0009921f: dec.s.alt      
// 0x00099220: or             
// 0x00099221: load.i         
// 0x00099222: jzer           0x7cc0de80
// 0x00099227: eq.alt         -327145719
// 0x0009922c: op183          
// 0x0009922d: op213          
// 0x0009922e: sysreq.pri     
// 0x0009922f: push.c         0x-2a481380 ""
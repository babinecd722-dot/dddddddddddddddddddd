// pc_alias_f @ 0x2bbda4-0x2bbde0 (60 bytes)
// Source: test.pwn

stock pc_alias_f()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x002bbda4: op0            
// 0x002bbda5: op0            
// 0x002bbda6: op0            
// 0x002bbda7: op0            
// 0x002bbda8: op0            
// 0x002bbda9: op0            
// 0x002bbdaa: op0            
// 0x002bbdab: op0            
// 0x002bbdac: op0            
// 0x002bbdad: op0            
// 0x002bbdae: op0            
// 0x002bbdaf: op0            
// 0x002bbdb0: op0            
// 0x002bbdb1: op0            
// 0x002bbdb2: op0            
// 0x002bbdb3: op0            
// 0x002bbdb4: op0            
// 0x002bbdb5: op0            
// 0x002bbdb6: op0            
// 0x002bbdb7: op0            
// 0x002bbdb8: op0            
// 0x002bbdb9: op0            
// 0x002bbdba: op0            
// 0x002bbdbb: op0            
// 0x002bbdbc: op0            
// 0x002bbdbd: op0            
// 0x002bbdbe: op0            
// 0x002bbdbf: op0            
// 0x002bbdc0: op0            
// 0x002bbdc1: op0            
// 0x002bbdc2: op0            
// 0x002bbdc3: op0            
// 0x002bbdc4: op0            
// 0x002bbdc5: op0            
// 0x002bbdc6: op0            
// 0x002bbdc7: op0            
// 0x002bbdc8: op0            
// 0x002bbdc9: op0            
// 0x002bbdca: op0            
// 0x002bbdcb: op0            
// 0x002bbdcc: op0            
// 0x002bbdcd: op0            
// 0x002bbdce: op0            
// 0x002bbdcf: op0            
// 0x002bbdd0: op0            
// 0x002bbdd1: op0            
// 0x002bbdd2: op0            
// 0x002bbdd3: op0            
// 0x002bbdd4: op0            
// 0x002bbdd5: op0            
// 0x002bbdd6: op0            
// 0x002bbdd7: op0            
// 0x002bbdd8: op0            
// 0x002bbdd9: op0            
// 0x002bbdda: op0            
// 0x002bbddb: op0            
// 0x002bbddc: op0            
// 0x002bbddd: op0            
// 0x002bbdde: op0            
// 0x002bbddf: op0            
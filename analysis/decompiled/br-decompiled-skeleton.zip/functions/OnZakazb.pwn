// OnZakazb @ 0x1c2828-0x1c290c (228 bytes)
// Source: test.pwn

public OnZakazb()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001c2828: op0            
// 0x001c2829: op0            
// 0x001c282a: op0            
// 0x001c282b: op0            
// 0x001c282c: op0            
// 0x001c282d: op0            
// 0x001c282e: op0            
// 0x001c282f: op0            
// 0x001c2830: op0            
// 0x001c2831: op0            
// 0x001c2832: op0            
// 0x001c2833: op0            
// 0x001c2834: op0            
// 0x001c2835: op0            
// 0x001c2836: op0            
// 0x001c2837: op0            
// 0x001c2838: op0            
// 0x001c2839: op0            
// 0x001c283a: op0            
// 0x001c283b: op0            
// 0x001c283c: op0            
// 0x001c283d: op0            
// 0x001c283e: op0            
// 0x001c283f: op0            
// 0x001c2840: op0            
// 0x001c2841: op0            
// 0x001c2842: op0            
// 0x001c2843: op0            
// 0x001c2844: op0            
// 0x001c2845: op0            
// 0x001c2846: op0            
// 0x001c2847: op0            
// 0x001c2848: op0            
// 0x001c2849: op0            
// 0x001c284a: op0            
// 0x001c284b: op0            
// 0x001c284c: op0            
// 0x001c284d: op0            
// 0x001c284e: op0            
// 0x001c284f: op0            
// 0x001c2850: op0            
// 0x001c2851: op0            
// 0x001c2852: op0            
// 0x001c2853: op0            
// 0x001c2854: op0            
// 0x001c2855: op0            
// 0x001c2856: op0            
// 0x001c2857: op0            
// 0x001c2858: op0            
// 0x001c2859: op0            
// 0x001c285a: op0            
// 0x001c285b: op0            
// 0x001c285c: op0            
// 0x001c285d: op0            
// 0x001c285e: op0            
// 0x001c285f: op0            
// 0x001c2860: op0            
// 0x001c2861: op0            
// 0x001c2862: op0            
// 0x001c2863: op0            
// 0x001c2864: op0            
// 0x001c2865: op0            
// 0x001c2866: op0            
// 0x001c2867: op0            
// 0x001c2868: op0            
// 0x001c2869: op0            
// 0x001c286a: op0            
// 0x001c286b: op0            
// 0x001c286c: op0            
// 0x001c286d: op0            
// 0x001c286e: op0            
// 0x001c286f: op0            
// 0x001c2870: op0            
// 0x001c2871: eq.alt         -2123136703
// 0x001c2876: sless          
// 0x001c2877: eq.alt         -2124119684
// 0x001c287c: sgeq           
// 0x001c287d: eq.alt         -2124054169
// 0x001c2882: eq.c.alt       
// 0x001c2883: op0            
// fixp_OnPlayerConnect @ 0x446e4-0x44820 (316 bytes)
// Source: system_blackjack_full.pwn

stock fixp_OnPlayerConnect()
{
    // stack 1501561084
    // const.alt -2130673369
    // stack -2130083556
    // stack 738820368
    // stack 654934292
    // branch jrel -> 2558337
    // const.alt -457711744
    // const.pri 159455103
    // const.pri 1754868737
    return 1;
    // proc @0x44798
    return 1;
    // branch jzer -> 0x-7e931655
    return 1;
    // branch jzer -> 0x-7eaf1555
    // stack 811171856
    return 1;
}

// --- disasm (first 80) ---
// 0x000446e4: load.i         
// 0x000446e5: stack          1501561084
// 0x000446ea: addr.alt       2004883690
// 0x000446ef: dec.s.pri      
// 0x000446f0: op0            
// 0x000446f1: eq.alt         2013626633
// 0x000446f6: eq.alt         -2122777083
// 0x000446fb: lref.pri       -2144921362
// 0x00044700: op223          
// 0x00044701: op184          
// 0x00044702: op236          
// 0x00044703: const.alt      -2130673369
// 0x00044708: lref.pri       405215466
// 0x0004470d: eq.pri         
// 0x0004470e: emit           
// 0x0004470f: push.alt       
// 0x00044710: stack          -2130083556
// 0x00044715: lref.pri       2133268714
// 0x0004471a: push.s         -2146687220
// 0x0004471f: emit           
// 0x00044720: eq.pri         
// 0x00044721: xor            
// 0x00044722: stack          738820368
// 0x00044727: op252          
// 0x00044728: op0            
// 0x00044729: eq.pri         
// 0x0004472a: mod.c          
// 0x0004472b: addr.alt       2004883686
// 0x00044730: dec.s.pri      
// 0x00044731: op0            
// 0x00044732: eq.alt         2013626633
// 0x00044737: push.c         0x-12472080 ""
// 0x0004473c: add            
// 0x0004473d: push.c         0x5810081 ""
// 0x00044742: op230          
// 0x00044743: strb.i         2071990311
// 0x00044748: push.alt       
// 0x00044749: stack          654934292
// 0x0004474e: eq.pri         
// 0x0004474f: op223          
// 0x00044750: op184          
// 0x00044751: op238          
// 0x00044752: sctrl          417727873
// 0x00044757: push.c         0x27002700 ""
// 0x0004475c: lref.alt       204013607
// 0x00044761: push.c         0x-127ecee4 ""
// 0x00044766: movs.i         
// 0x00044767: jrel           2558337
// 0x0004476c: push.c         0x27002700 ""
// 0x00044771: movs.i         
// 0x00044772: zero.alt       
// 0x00044773: push.s         -2146162932
// 0x00044778: emit           
// 0x00044779: eq.alt         -2129122259
// 0x0004477e: load.i         
// 0x0004477f: const.alt      -457711744
// 0x00044784: xor            
// 0x00044785: load.s.pri     -2122743796
// 0x0004478a: sysreq.c       
// 0x0004478b: idxaddr        
// 0x0004478c: move.alt       
// 0x0004478d: const.pri      159455103
// 0x00044792: const.pri      1754868737
// 0x00044797: retn           
// 0x00044798: proc           
// 0x00044799: eq.alt         201949449
// 0x0004479e: eq.pri         
// 0x0004479f: op214          
// 0x000447a0: op199          
// 0x000447a1: op219          
// 0x000447a2: sysreq.pri     
// 0x000447a3: load.s.pri     -2122743796
// 0x000447a8: sysreq.c       
// 0x000447a9: idxaddr        
// 0x000447aa: move.alt       
// 0x000447ab: load.i         
// 0x000447ac: eq.pri         
// 0x000447ad: neg            
// 0x000447ae: eq.pri         
// 0x000447af: mul.c          
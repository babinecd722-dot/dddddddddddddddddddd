// ReturnPlayerToAutosalonPreview @ 0xd12e4-0xd19d4 (1776 bytes)
// Source: test.pwn

stock ReturnPlayerToAutosalonPreview()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000d12e4: load.i         
// 0x000d12e5: eq.alt         654321417
// 0x000d12ea: op0            
// 0x000d12eb: eq.alt         654386953
// 0x000d12f0: eq.pri         
// 0x000d12f1: op236          
// 0x000d12f2: op206          
// 0x000d12f3: push           
// 0x000d12f4: zero.pri       
// 0x000d12f5: push           -1045704832
// 0x000d12fa: or             
// 0x000d12fb: push.c         0x-7f847ff4 ""
// 0x000d1300: add            
// 0x000d1301: stack          -2122575600
// 0x000d1306: load.i         
// 0x000d1307: push.c         0x-7ffbd8ff ""
// 0x000d130c: emit           
// 0x000d130d: eq.pri         
// 0x000d130e: div            
// 0x000d130f: stack          -2122837752
// 0x000d1314: load.i         
// 0x000d1315: load.s.pri     1518406776
// 0x000d131a: jsleq          0x64a08081
// 0x000d131f: eq.alt         1518406409
// 0x000d1324: stor.s.pri     654934392
// 0x000d1329: op0            
// 0x000d132a: eq.alt         855648009
// 0x000d132f: eq.alt         -2129616512
// 0x000d1334: load.i         
// 0x000d1335: eq.pri         
// 0x000d1336: sgeq           
// 0x000d1337: eq.c.alt       
// 0x000d1338: load.s.pri     -2139618192
// 0x000d133d: jsgeq          
// 0x000d133e: eq.alt         -2126730880
// 0x000d1343: load.i         
// 0x000d1344: const.alt      -408560256
// 0x000d1349: xor            
// 0x000d134a: load.s.pri     -2122743696
// 0x000d134f: mod.c          
// 0x000d1350: idxaddr        
// 0x000d1351: move.alt       
// 0x000d1352: load.i         
// 0x000d1353: eq.pri         
// 0x000d1354: neg            
// 0x000d1355: push.pri       
// 0x000d1356: push.c         0x-137fd8ff ""
// 0x000d135b: op206          
// 0x000d135c: push.s         
// 0x000d135d: add            
// 0x000d135e: push.s         -2146687120
// 0x000d1363: emit           
// 0x000d1364: eq.pri         
// 0x000d1365: mod            
// 0x000d1366: stack          -2129188080
// 0x000d136b: load.i         
// 0x000d136c: const.alt      -408560256
// 0x000d1371: xor            
// 0x000d1372: load.s.pri     -2122743696
// 0x000d1377: mod.c          
// 0x000d1378: idxaddr        
// 0x000d1379: move.alt       
// 0x000d137a: load.i         
// 0x000d137b: eq.pri         
// 0x000d137c: neg            
// 0x000d137d: eq.pri         
// 0x000d137e: mul.c          
// 0x000d137f: load.s.alt     654386980
// 0x000d1384: eq.pri         
// 0x000d1385: op236          
// 0x000d1386: op206          
// 0x000d1387: push.s         
// 0x000d1388: mul            
// 0x000d1389: push.s         -2146687120
// 0x000d138e: emit           
// 0x000d138f: eq.pri         
// 0x000d1390: mod            
// 0x000d1391: stack          -2129188080
// 0x000d1396: load.i         
// 0x000d1397: const.alt      -408560256
// SetVehicleRuNumberPlate @ 0x144e0-0x14760 (640 bytes)
// Source: customtune.inc

stock SetVehicleRuNumberPlate()
{
    // const.alt 39354377
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 338109449
    call_0x0x2d78ff90();
    // const.alt 2038434819
    // stack -2122743799
    // const.alt 39354377
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 136782857
    call_0x0x-7e9f4072();
    // const.alt -338264052
    // const.alt 136782857
    // stack -980602100
    // const.alt 2038434819
    // stor.alt 359235593
    // branch jzer -> 0xc7cb68d
    // const.alt 2038434819
    // const.pri -1215483135
    // branch jnz -> 0xc38b88d
    // const.alt 2038434819
    // stor.alt -2146104311
    // const.alt 2038434819
    // branch jnz -> 0x-7fc74773
    // branch jump -> 188790925
    // load.pri 213683509
    // const.pri -504506752
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 203891721
    // stack 185172240
    // const.alt -1561405824
    // const.alt 2038434819
    // stack -2122743799
    // const.alt -1561405824
    // const.alt 2038434819
    // stack 136782857
    // stack 654934284
    // stack -338264052
    // const.alt 136782857
    // stack -980602100
    // const.alt 2038434819
    // stor.alt -2146104311
    // const.alt 2038434819
    // branch jzer -> 0xb28bd8d
    // load.pri 750619955
    // branch jnz -> 0xc64be8d
    // const.alt 2038434819
    // stor.alt 1041566729
    // const.alt -1561405824
    // const.alt 2038434819
    // const.pri -1098042623
    // branch jnz -> 0x-7f9b4173
    // branch jump -> 191676045
    // load.pri 1690668341
}

// --- disasm (first 80) ---
// 0x000144e0: load.i         
// 0x000144e1: eq.pri         
// 0x000144e2: sysreq.c       
// 0x000144e3: eq.alt         572205945
// 0x000144e8: load.i         
// 0x000144e9: eq.pri         
// 0x000144ea: neg            
// 0x000144eb: eq.pri         
// 0x000144ec: mul.c          
// 0x000144ed: const.alt      39354377
// 0x000144f2: push.pri       
// 0x000144f3: const.alt      -1561405824
// 0x000144f8: const.alt      2038434819
// 0x000144fd: lref.pri       -2146885093
// 0x00014502: neg            
// 0x00014503: eq.pri         
// 0x00014504: mul.c          
// 0x00014505: stack          338109449
// 0x0001450a: call           0x2d78ff90
// 0x0001450f: sleq           
// 0x00014510: eq.alt         -696251639
// 0x00014515: op238          
// 0x00014516: op166          
// 0x00014517: load.s.alt     -696251356
// 0x0001451c: op238          
// 0x0001451d: nop            
// 0x0001451e: const.alt      2038434819
// 0x00014523: lref.pri       -2146885093
// 0x00014528: neg            
// 0x00014529: eq.pri         
// 0x0001452a: mul.c          
// 0x0001452b: stack          -2122743799
// 0x00014530: sysreq.c       
// 0x00014531: pop.alt        
// 0x00014532: idxaddr        
// 0x00014533: move.alt       
// 0x00014534: load.i         
// 0x00014535: eq.pri         
// 0x00014536: neg            
// 0x00014537: eq.pri         
// 0x00014538: mul.c          
// 0x00014539: const.alt      39354377
// 0x0001453e: push.pri       
// 0x0001453f: const.alt      -1561405824
// 0x00014544: const.alt      2038434819
// 0x00014549: lref.pri       -2146885093
// 0x0001454e: neg            
// 0x0001454f: eq.pri         
// 0x00014550: mul.c          
// 0x00014551: stack          136782857
// 0x00014556: call           0x-7e9f4072
// 0x0001455b: load.i         
// 0x0001455c: push.c         0x-1b102980 ""
// 0x00014561: const.alt      -338264052
// 0x00014566: op214          
// 0x00014567: sysreq.pri     
// 0x00014568: load.s.pri     91848716
// 0x0001456d: idxaddr        
// 0x0001456e: move.alt       
// 0x0001456f: load.i         
// 0x00014570: eq.pri         
// 0x00014571: neg            
// 0x00014572: eq.pri         
// 0x00014573: mul.c          
// 0x00014574: const.alt      136782857
// 0x00014579: eq.pri         
// 0x0001457a: emit           
// 0x0001457b: eq.pri         
// 0x0001457c: div            
// 0x0001457d: stack          -980602100
// 0x00014582: sshr           
// 0x00014583: eq.alt         -696251383
// 0x00014588: op238          
// 0x00014589: nop            
// 0x0001458a: const.alt      2038434819
// 0x0001458f: lref.pri       -2146885093
// 0x00014594: neg            
// 0x00014595: eq.pri         
// 0x00014596: mul.c          
// 0x00014597: stor.alt       359235593
// UpdateHouseNewVisual @ 0x3aad54-0x3aad6c (24 bytes)
// Source: test.pwn

stock UpdateHouseNewVisual()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x003aad54: op0            
// 0x003aad55: op0            
// 0x003aad56: op0            
// 0x003aad57: op0            
// 0x003aad58: op0            
// 0x003aad59: op0            
// 0x003aad5a: op0            
// 0x003aad5b: op0            
// 0x003aad5c: op0            
// 0x003aad5d: op0            
// 0x003aad5e: op0            
// 0x003aad5f: op0            
// 0x003aad60: op0            
// 0x003aad61: op0            
// 0x003aad62: op0            
// 0x003aad63: op0            
// 0x003aad64: op0            
// 0x003aad65: op0            
// 0x003aad66: op0            
// 0x003aad67: op0            
// 0x003aad68: op0            
// 0x003aad69: op0            
// 0x003aad6a: op0            
// 0x003aad6b: op0            
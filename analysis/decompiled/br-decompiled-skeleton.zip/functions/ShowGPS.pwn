// ShowGPS @ 0x12858-0x12894 (60 bytes)
// Source: customhud.inc

stock ShowGPS()
{
    // branch jneq -> 0x79807803
    // const.alt -2146885093
    // const.alt 136782857
}

// --- disasm (first 80) ---
// 0x00012858: eq.alt         -696251383
// 0x0001285d: op237          
// 0x0001285e: op234          
// 0x0001285f: jneq           0x79807803
// 0x00012864: const.alt      -2146885093
// 0x00012869: neg            
// 0x0001286a: push.pri       
// 0x0001286b: load.s.pri     58294388
// 0x00012870: pop.alt        
// 0x00012871: idxaddr        
// 0x00012872: move.alt       
// 0x00012873: load.i         
// 0x00012874: eq.pri         
// 0x00012875: neg            
// 0x00012876: eq.pri         
// 0x00012877: mul.c          
// 0x00012878: load.s.alt     -696251356
// 0x0001287d: op235          
// 0x0001287e: op214          
// 0x0001287f: op0            
// 0x00012880: load.s.pri     91848716
// 0x00012885: idxaddr        
// 0x00012886: move.alt       
// 0x00012887: load.i         
// 0x00012888: eq.pri         
// 0x00012889: neg            
// 0x0001288a: eq.pri         
// 0x0001288b: mul.c          
// 0x0001288c: const.alt      136782857
// 0x00012891: eq.pri         
// 0x00012892: emit           
// 0x00012893: eq.pri         
// IsPlayerInPoliceTeam @ 0x29cea8-0x29cf34 (140 bytes)
// Source: test.pwn

stock IsPlayerInPoliceTeam()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0029cea8: op247          
// 0x0029cea9: eq.c.alt       
// 0x0029ceaa: inc.s.alt      
// 0x0029ceab: dec.i          
// 0x0029ceac: stack          
// 0x0029cead: jsgeq          
// 0x0029ceae: inc.s.alt      
// 0x0029ceaf: dec.i          
// 0x0029ceb0: op179          
// 0x0029ceb1: stor.alt       1624278915
// 0x0029ceb6: inc.s.alt      
// 0x0029ceb7: dec.i          
// 0x0029ceb8: op238          
// 0x0029ceb9: retn           
// 0x0029ceba: inc.s.alt      
// 0x0029cebb: movs.i         
// 0x0029cebc: bounds.p       
// 0x0029cebd: op0            
// 0x0029cebe: inc.s.alt      
// 0x0029cebf: movs.i         
// 0x0029cec0: op169          
// 0x0029cec1: add            
// 0x0029cec2: inc.s.alt      
// 0x0029cec3: movs.i         
// 0x0029cec4: op199          
// 0x0029cec5: sctrl          1894025347
// 0x0029ceca: inc.s.alt      
// 0x0029cecb: cmps.i         
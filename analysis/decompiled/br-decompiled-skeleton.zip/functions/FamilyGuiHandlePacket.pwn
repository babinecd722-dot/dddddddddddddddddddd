// FamilyGuiHandlePacket @ 0x63b78-0x63bb8 (64 bytes)
// Source: test.pwn

stock FamilyGuiHandlePacket()
{
    return 1;
    // const.alt -90256256
}

// --- disasm (first 80) ---
// 0x00063b78: swap.pri       
// 0x00063b79: retn           
// 0x00063b7a: push.s         -2146949364
// 0x00063b7f: emit           
// 0x00063b80: eq.alt         -2129908710
// 0x00063b85: load.i         
// 0x00063b86: push.c         0x-60641380 ""
// 0x00063b8b: mul            
// 0x00063b8c: push.s         -2146949364
// 0x00063b91: emit           
// 0x00063b92: eq.alt         -2129908710
// 0x00063b97: load.i         
// 0x00063b98: push.c         0x-5f641380 ""
// 0x00063b9d: lref.s.alt     136776745
// 0x00063ba2: eq.pri         
// 0x00063ba3: emit           
// 0x00063ba4: eq.alt         -2129908710
// 0x00063ba9: load.i         
// 0x00063baa: const.alt      -90256256
// 0x00063baf: cmps           
// 0x00063bb0: load.s.pri     -2122743796
// 0x00063bb5: sysreq.c       
// 0x00063bb6: lidx           
// 0x00063bb7: push.pri       
// StopAutosalonTestDriveMonitor @ 0xd0d6c-0xd0e2c (192 bytes)
// Source: test.pwn

stock StopAutosalonTestDriveMonitor()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000d0d6c: pop.alt        
// 0x000d0d6d: idxaddr        
// 0x000d0d6e: move.alt       
// 0x000d0d6f: load.i         
// 0x000d0d70: eq.pri         
// 0x000d0d71: neg            
// 0x000d0d72: move.alt       
// 0x000d0d73: eq.pri         
// 0x000d0d74: mod.c          
// 0x000d0d75: stor.i         
// 0x000d0d76: eq.alt         -595588087
// 0x000d0d7b: op249          
// 0x000d0d7c: op193          
// 0x000d0d7d: jgeq           0x79800c03
// 0x000d0d82: dec.i          
// 0x000d0d83: load.s.pri     -2146885093
// 0x000d0d88: neg            
// 0x000d0d89: push.pri       
// 0x000d0d8a: load.s.pri     75071504
// 0x000d0d8f: pop.alt        
// 0x000d0d90: idxaddr        
// 0x000d0d91: move.alt       
// 0x000d0d92: load.i         
// 0x000d0d93: eq.pri         
// 0x000d0d94: neg            
// 0x000d0d95: eq.pri         
// 0x000d0d96: mul.c          
// 0x000d0d97: load.s.alt     391741474
// 0x000d0d9c: eq.alt         -595588087
// 0x000d0da1: op249          
// 0x000d0da2: op193          
// 0x000d0da3: jgeq           0x79800c03
// 0x000d0da8: dec.i          
// 0x000d0da9: load.s.pri     -2146885093
// 0x000d0dae: neg            
// 0x000d0daf: push.pri       
// 0x000d0db0: load.s.pri     75071504
// 0x000d0db5: pop.alt        
// 0x000d0db6: idxaddr        
// 0x000d0db7: move.alt       
// 0x000d0db8: load.i         
// 0x000d0db9: eq.pri         
// 0x000d0dba: neg            
// 0x000d0dbb: eq.pri         
// 0x000d0dbc: mul.c          
// 0x000d0dbd: lref.s.alt     391741474
// 0x000d0dc2: eq.alt         -595588087
// 0x000d0dc7: op249          
// 0x000d0dc8: op193          
// 0x000d0dc9: jgeq           0x79800c03
// 0x000d0dce: dec.i          
// 0x000d0dcf: load.s.pri     -2146885093
// 0x000d0dd4: neg            
// 0x000d0dd5: push.pri       
// 0x000d0dd6: load.s.pri     75071504
// 0x000d0ddb: pop.alt        
// 0x000d0ddc: idxaddr        
// 0x000d0ddd: move.alt       
// 0x000d0dde: load.i         
// 0x000d0ddf: eq.pri         
// 0x000d0de0: neg            
// 0x000d0de1: eq.pri         
// 0x000d0de2: mul.c          
// 0x000d0de3: const.alt      391741474
// 0x000d0de8: eq.alt         -578810871
// 0x000d0ded: heap           
// 0x000d0dee: line.debug     
// 0x000d0def: sleq           
// 0x000d0df0: load.s.pri     -2022080500
// 0x000d0df5: load.s.pri     201925659
// 0x000d0dfa: load.pri       388714368
// 0x000d0dff: eq.alt         738265865
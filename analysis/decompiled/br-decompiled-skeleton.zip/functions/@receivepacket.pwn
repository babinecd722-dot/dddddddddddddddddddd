// @receivepacket @ 0x588-0x928 (928 bytes)
// Source: Pawn.CMD.inc

stock @receivepacket()
{
    // branch jzer -> 0x98130a1
    // const.pri 159461387
    // branch jzer -> 0x98108a2
    // const.pri 159461388
    // branch jzer -> 0x98160a2
    // const.pri 159461389
    // branch jzer -> 0x98138a3
    // const.pri 159461390
    // branch jzer -> 0x98110a4
    // const.pri 159461391
    // branch jzer -> 0x98168a4
    // const.pri 159461392
    // branch jzer -> 0x98140a5
    // const.pri 159461393
    // branch jzer -> 0x98118a6
    // const.pri 159461394
    // branch jzer -> 0x98170a6
    // const.pri 159461398
    // branch jzer -> 0x98148a7
    // const.pri 159461399
    // branch jzer -> 0x98120a8
    // const.pri 159461400
    // branch jzer -> 0x98178a8
    // const.pri 159461401
    // branch jzer -> 0x98150a9
    // const.pri 159461402
    // branch jzer -> 0x98128aa
    // const.pri 159461403
    // branch jzer -> 0x98100ab
    // const.pri 159461404
    // branch jzer -> 0x98158ab
    // const.pri 159461404
    // branch jzer -> 0x98130ac
    // const.pri 159461405
    // branch jzer -> 0x98108ad
    // const.pri 159461406
    // branch jzer -> 0x98160ad
    // const.pri 159461407
    // branch jzer -> 0x98138ae
    // const.pri 159461408
    // branch jzer -> 0x98110af
    // const.pri 159461409
    // branch jzer -> 0x98168af
    // const.pri 159461410
    // branch jzer -> 0x98140b0
    // const.pri 159461411
    // branch jzer -> 0x98118b1
    // const.pri 159461412
    // branch jzer -> 0x98170b1
    // const.pri 159461413
    // branch jzer -> 0x98148b2
    // const.pri 159461414
    // branch jzer -> 0x98120b3
    // const.pri 159461415
    // branch jzer -> 0x98178b3
    // const.pri 159461416
    // branch jzer -> 0x98150b4
}

// --- disasm (first 80) ---
// 0x00000588: div.c          
// 0x00000589: eq.alt         805964553
// 0x0000058e: eq.alt         -7919863
// 0x00000593: op255          
// 0x00000594: op255          
// 0x00000595: sign.alt       
// 0x00000596: push.c         0x48832701 ""
// 0x0000059b: push.s         -2146425076
// 0x000005a0: emit           
// 0x000005a1: stor.s.pri     1417679916
// 0x000005a6: jzer           0x98130a1
// 0x000005ab: const.pri      159461387
// 0x000005b0: push.c         0x-79 ""
// 0x000005b5: sign.alt       
// 0x000005b6: push.c         0x78832701 ""
// 0x000005bb: push.s         -2146425076
// 0x000005c0: emit           
// 0x000005c1: stor.s.pri     1417679916
// 0x000005c6: jzer           0x98108a2
// 0x000005cb: const.pri      159461388
// 0x000005d0: push.c         0x-79 ""
// 0x000005d5: sign.alt       
// 0x000005d6: push.c         0x3c842701 ""
// 0x000005db: push.s         -2146425076
// 0x000005e0: emit           
// 0x000005e1: stor.s.pri     1417679916
// 0x000005e6: jzer           0x98160a2
// 0x000005eb: const.pri      159461389
// 0x000005f0: push.c         0x-79 ""
// 0x000005f5: sign.alt       
// 0x000005f6: push.c         0x74842701 ""
// 0x000005fb: push.s         -2146425076
// 0x00000600: emit           
// 0x00000601: stor.s.pri     1417679916
// 0x00000606: jzer           0x98138a3
// 0x0000060b: const.pri      159461390
// 0x00000610: push.c         0x-79 ""
// 0x00000615: sign.alt       
// 0x00000616: push.c         0x14852701 ""
// 0x0000061b: push.s         -2146425076
// 0x00000620: emit           
// 0x00000621: stor.s.pri     1417679916
// 0x00000626: jzer           0x98110a4
// 0x0000062b: const.pri      159461391
// 0x00000630: push.c         0x-79 ""
// 0x00000635: sign.alt       
// 0x00000636: push.c         0x28852701 ""
// 0x0000063b: push.s         -2146425076
// 0x00000640: emit           
// 0x00000641: stor.s.pri     1417679916
// 0x00000646: jzer           0x98168a4
// 0x0000064b: const.pri      159461392
// 0x00000650: push.c         0x-79 ""
// 0x00000655: sign.alt       
// 0x00000656: push.c         0x4c852701 ""
// 0x0000065b: push.s         -2146425076
// 0x00000660: emit           
// 0x00000661: stor.s.pri     1417679916
// 0x00000666: jzer           0x98140a5
// 0x0000066b: const.pri      159461393
// 0x00000670: push.c         0x-79 ""
// 0x00000675: sign.alt       
// 0x00000676: push.c         0x70852701 ""
// 0x0000067b: push.s         -2146425076
// 0x00000680: emit           
// 0x00000681: stor.s.pri     1417679916
// 0x00000686: jzer           0x98118a6
// 0x0000068b: const.pri      159461394
// 0x00000690: push.c         0x-79 ""
// 0x00000695: sign.alt       
// 0x00000696: push.c         0x14862701 ""
// 0x0000069b: push.s         -2146425076
// 0x000006a0: emit           
// 0x000006a1: stor.s.pri     1417679916
// 0x000006a6: jzer           0x98170a6
// 0x000006ab: const.pri      159461398
// 0x000006b0: push.c         0x-79 ""
// 0x000006b5: sign.alt       
// 0x000006b6: push.c         0x30862701 ""
// 0x000006bb: push.s         -2146425076
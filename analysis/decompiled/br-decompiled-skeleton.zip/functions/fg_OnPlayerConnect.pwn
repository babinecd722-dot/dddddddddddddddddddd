// fg_OnPlayerConnect @ 0xe11c-0xe178 (92 bytes)
// Source: system_pickup.pwn

stock fg_OnPlayerConnect()
{
    // stor.alt 136782857
    // stack 654934284
    // load.pri -338264052
    // stor.alt 136782857
}

// --- disasm (first 80) ---
// 0x0000e11c: eq.pri         
// 0x0000e11d: op214          
// 0x0000e11e: op235          
// 0x0000e11f: op210          
// 0x0000e120: mul            
// 0x0000e121: load.s.pri     91848716
// 0x0000e126: idxaddr        
// 0x0000e127: move.alt       
// 0x0000e128: load.i         
// 0x0000e129: eq.pri         
// 0x0000e12a: neg            
// 0x0000e12b: eq.pri         
// 0x0000e12c: mul.c          
// 0x0000e12d: stor.alt       136782857
// 0x0000e132: eq.pri         
// 0x0000e133: emit           
// 0x0000e134: eq.pri         
// 0x0000e135: fill           
// 0x0000e136: stack          654934284
// 0x0000e13b: load.pri       -338264052
// 0x0000e140: op210          
// 0x0000e141: mul            
// 0x0000e142: load.s.pri     91848716
// 0x0000e147: idxaddr        
// 0x0000e148: move.alt       
// 0x0000e149: load.i         
// 0x0000e14a: eq.pri         
// 0x0000e14b: neg            
// 0x0000e14c: eq.pri         
// 0x0000e14d: mul.c          
// 0x0000e14e: stor.alt       136782857
// 0x0000e153: eq.pri         
// 0x0000e154: emit           
// 0x0000e155: eq.pri         
// 0x0000e156: halt           
// 0x0000e157: stack          811171852
// 0x0000e15c: proc           
// 0x0000e15d: eq.alt         201949449
// 0x0000e162: eq.pri         
// 0x0000e163: op214          
// 0x0000e164: op235          
// 0x0000e165: op214          
// 0x0000e166: op0            
// 0x0000e167: load.s.pri     91848716
// 0x0000e16c: idxaddr        
// 0x0000e16d: move.alt       
// 0x0000e16e: load.i         
// 0x0000e16f: eq.pri         
// 0x0000e170: neg            
// 0x0000e171: eq.pri         
// 0x0000e172: mul.c          
// 0x0000e173: load.s.alt     -696244444
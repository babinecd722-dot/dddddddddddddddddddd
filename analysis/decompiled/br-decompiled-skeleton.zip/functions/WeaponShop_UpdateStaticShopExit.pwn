// WeaponShop_UpdateStaticShopExit @ 0xab300-0xab928 (1576 bytes)
// Source: system_weapon_shop.inc

stock WeaponShop_UpdateStaticShopExit()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000ab300: push           -578810844
// 0x000ab305: swap.alt       
// 0x000ab306: op168          
// 0x000ab307: eq.c.alt       
// 0x000ab308: load.s.pri     108625944
// 0x000ab30d: idxaddr        
// 0x000ab30e: move.alt       
// 0x000ab30f: load.i         
// 0x000ab310: eq.pri         
// 0x000ab311: neg            
// 0x000ab312: eq.pri         
// 0x000ab313: mul.c          
// 0x000ab314: eq.pri         
// 0x000ab315: div.c          
// 0x000ab316: load.i         
// 0x000ab317: pop.alt        
// 0x000ab318: stor.i         
// 0x000ab319: eq.alt         -578810871
// 0x000ab31e: heap           
// 0x000ab31f: op193          
// 0x000ab320: zero.pri       
// 0x000ab321: load.s.pri     -2022080400
// 0x000ab326: less           
// 0x000ab327: idxaddr        
// 0x000ab328: move.alt       
// 0x000ab329: load.i         
// 0x000ab32a: eq.pri         
// 0x000ab32b: neg            
// 0x000ab32c: eq.pri         
// 0x000ab32d: mul.c          
// 0x000ab32e: stack          -578810844
// 0x000ab333: swap.alt       
// 0x000ab334: op168          
// 0x000ab335: eq.c.alt       
// 0x000ab336: load.s.pri     108625944
// 0x000ab33b: idxaddr        
// 0x000ab33c: move.alt       
// 0x000ab33d: load.i         
// 0x000ab33e: eq.pri         
// 0x000ab33f: neg            
// 0x000ab340: eq.pri         
// 0x000ab341: mul.c          
// 0x000ab342: eq.pri         
// 0x000ab343: mul            
// 0x000ab344: load.i         
// 0x000ab345: pop.alt        
// 0x000ab346: stor.i         
// 0x000ab347: eq.alt         -578810871
// 0x000ab34c: heap           
// 0x000ab34d: op193          
// 0x000ab34e: zero.pri       
// 0x000ab34f: load.s.pri     -2022080400
// 0x000ab354: less           
// 0x000ab355: idxaddr        
// 0x000ab356: move.alt       
// 0x000ab357: load.i         
// 0x000ab358: eq.pri         
// 0x000ab359: neg            
// 0x000ab35a: eq.pri         
// 0x000ab35b: mul.c          
// 0x000ab35c: retn           
// 0x000ab35d: push.pri       
// 0x000ab35e: const.alt      -1465852544
// 0x000ab363: eq.c.alt       
// 0x000ab364: load.s.pri     108625944
// 0x000ab369: idxaddr        
// 0x000ab36a: move.alt       
// 0x000ab36b: load.i         
// 0x000ab36c: eq.pri         
// 0x000ab36d: neg            
// 0x000ab36e: eq.pri         
// 0x000ab36f: mul.c          
// 0x000ab370: eq.pri         
// 0x000ab371: sysreq.pri     
// 0x000ab372: load.i         
// 0x000ab373: pop.alt        
// 0x000ab374: stor.i         
// 0x000ab375: eq.alt         15739913
// 0x000ab37a: eq.pri         
// 0x000ab37b: mod.c          
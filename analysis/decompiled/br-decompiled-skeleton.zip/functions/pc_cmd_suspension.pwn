// pc_cmd_suspension @ 0x2ce8b4-0x2ce8cc (24 bytes)
// Source: test.pwn

stock pc_cmd_suspension()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x002ce8b4: op0            
// 0x002ce8b5: op0            
// 0x002ce8b6: op0            
// 0x002ce8b7: op0            
// 0x002ce8b8: op0            
// 0x002ce8b9: op0            
// 0x002ce8ba: op0            
// 0x002ce8bb: op0            
// 0x002ce8bc: op0            
// 0x002ce8bd: op0            
// 0x002ce8be: op0            
// 0x002ce8bf: op0            
// 0x002ce8c0: op0            
// 0x002ce8c1: op0            
// 0x002ce8c2: op0            
// 0x002ce8c3: op0            
// 0x002ce8c4: op0            
// 0x002ce8c5: op0            
// 0x002ce8c6: op0            
// 0x002ce8c7: op0            
// 0x002ce8c8: op0            
// 0x002ce8c9: op0            
// 0x002ce8ca: op0            
// 0x002ce8cb: op0            
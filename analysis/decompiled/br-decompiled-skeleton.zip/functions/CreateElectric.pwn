// CreateElectric @ 0x8b400-0x8bc2c (2092 bytes)
// Source: system_electric_job.pwn

stock CreateElectric()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0008b400: eq.alt         890503945
// 0x0008b405: eq.pri         
// 0x0008b406: op214          
// ProbelText @ 0xab098-0xab1ec (340 bytes)
// Source: system_auction.pwn

stock ProbelText()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x000ab098: push.c         0x-1a3e1380 ""
// 0x000ab09d: idxaddr.b      136776745
// 0x000ab0a2: eq.pri         
// 0x000ab0a3: emit           
// 0x000ab0a4: eq.alt         -2129908710
// 0x000ab0a9: load.i         
// 0x000ab0aa: push.c         0x-1a3e1380 ""
// 0x000ab0af: sshr           
// 0x000ab0b0: push.s         -2146949364
// 0x000ab0b5: emit           
// 0x000ab0b6: eq.alt         -2129908710
// 0x000ab0bb: load.i         
// 0x000ab0bc: push.c         0x-193e1380 ""
// 0x000ab0c1: idxaddr.b      136776745
// 0x000ab0c6: eq.pri         
// 0x000ab0c7: emit           
// 0x000ab0c8: eq.alt         -2129908710
// 0x000ab0cd: load.i         
// 0x000ab0ce: push.c         0x-193e1380 ""
// 0x000ab0d3: mod            
// 0x000ab0d4: push.s         -2146949364
// 0x000ab0d9: emit           
// 0x000ab0da: eq.alt         -2129908710
// 0x000ab0df: load.i         
// 0x000ab0e0: push.c         0x-183e1380 ""
// 0x000ab0e5: const.alt      136776745
// 0x000ab0ea: eq.pri         
// 0x000ab0eb: emit           
// 0x000ab0ec: eq.alt         -2129908710
// 0x000ab0f1: load.i         
// 0x000ab0f2: const.pri      805841921
// 0x000ab0f7: eq.alt         -2145910007
// 0x000ab0fc: add            
// 0x000ab0fd: xchg           
// 0x000ab0fe: eq.pri         
// 0x000ab0ff: neq            
// 0x000ab100: push.pri       
// 0x000ab101: const.pri      1702896391
// 0x000ab106: eq.alt         726761476
// 0x000ab10b: eq.pri         
// 0x000ab10c: mod            
// 0x000ab10d: jzer           0x389de980
// 0x000ab112: eq.alt         -327145719
// 0x000ab117: op193          
// 0x000ab118: op231          
// 0x000ab119: shl.pri        
// 0x000ab11a: push.c         0x270c297f ""
// 0x000ab11f: const.alt      1635810176
// 0x000ab124: stack          805841936
// 0x000ab129: eq.alt         662449161
// 0x000ab12e: eq.pri         
// 0x000ab12f: op236          
// 0x000ab130: op193          
// 0x000ab131: op232          
// 0x000ab132: push.pri       
// 0x000ab133: push.s         -2146949364
// 0x000ab138: emit           
// 0x000ab139: jsleq          0x74110c2c
// 0x000ab13e: eq.alt         208929545
// 0x000ab143: load.pri       -377470848
// 0x000ab148: casetbl        
// 0x000ab149: add            
// 0x000ab14a: eq.alt         -327145719
// 0x000ab14f: op193          
// 0x000ab150: op232          
// 0x000ab151: sleq           
// 0x000ab152: push.c         0x270c297f ""
// 0x000ab157: const.alt      1635810176
// 0x000ab15c: stack          806104080
// 0x000ab161: eq.alt         662449161
// 0x000ab166: op0            
// 0x000ab167: call           0x18d9ea81
// 0x000ab16c: stor.s.pri     50954608
// 0x000ab171: eq.c.alt       
// 0x000ab172: eq.pri         
// 0x000ab173: grtr           
// 0x000ab174: sign.alt       
// 0x000ab175: jzer           0x509fe980
// 0x000ab17a: eq.alt         -327145719
// 0x000ab17f: op193          
// GetPlayerID @ 0x1f97c0-0x1f980c (76 bytes)
// Source: test.pwn

stock GetPlayerID()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x001f97c0: op0            
// 0x001f97c1: op0            
// 0x001f97c2: op0            
// 0x001f97c3: op0            
// 0x001f97c4: op0            
// 0x001f97c5: op0            
// 0x001f97c6: op0            
// 0x001f97c7: op0            
// 0x001f97c8: op0            
// 0x001f97c9: op0            
// 0x001f97ca: op0            
// 0x001f97cb: op0            
// 0x001f97cc: op0            
// 0x001f97cd: op0            
// 0x001f97ce: op0            
// 0x001f97cf: op0            
// 0x001f97d0: op0            
// 0x001f97d1: op0            
// 0x001f97d2: op0            
// 0x001f97d3: op0            
// 0x001f97d4: op0            
// 0x001f97d5: op0            
// 0x001f97d6: op0            
// 0x001f97d7: op0            
// 0x001f97d8: op0            
// 0x001f97d9: op0            
// 0x001f97da: op0            
// 0x001f97db: op0            
// 0x001f97dc: op0            
// 0x001f97dd: op0            
// 0x001f97de: op0            
// 0x001f97df: op0            
// 0x001f97e0: op0            
// 0x001f97e1: op0            
// 0x001f97e2: op0            
// 0x001f97e3: op0            
// 0x001f97e4: op0            
// 0x001f97e5: op0            
// 0x001f97e6: op0            
// 0x001f97e7: op0            
// 0x001f97e8: op0            
// 0x001f97e9: op0            
// 0x001f97ea: op0            
// 0x001f97eb: op0            
// 0x001f97ec: op0            
// 0x001f97ed: op0            
// 0x001f97ee: op0            
// 0x001f97ef: op0            
// 0x001f97f0: op0            
// 0x001f97f1: op0            
// 0x001f97f2: op0            
// 0x001f97f3: op0            
// 0x001f97f4: op0            
// 0x001f97f5: op0            
// 0x001f97f6: op0            
// 0x001f97f7: op0            
// 0x001f97f8: op0            
// 0x001f97f9: op0            
// 0x001f97fa: op0            
// 0x001f97fb: op0            
// 0x001f97fc: op0            
// 0x001f97fd: op0            
// 0x001f97fe: op0            
// 0x001f97ff: op0            
// 0x001f9800: op0            
// 0x001f9801: op0            
// 0x001f9802: op0            
// 0x001f9803: op0            
// 0x001f9804: op0            
// 0x001f9805: op0            
// 0x001f9806: op0            
// 0x001f9807: op0            
// 0x001f9808: op0            
// 0x001f9809: op0            
// 0x001f980a: op0            
// 0x001f980b: op0            
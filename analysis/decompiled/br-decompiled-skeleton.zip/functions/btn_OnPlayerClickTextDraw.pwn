// btn_OnPlayerClickTextDraw @ 0x7cbb4-0x7d854 (3232 bytes)
// Source: system_roulette.pwn

stock btn_OnPlayerClickTextDraw()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x0007cbb4: eq.pri         
// 0x0007cbb5: sysreq.c       
// 0x0007cbb6: eq.alt         153230201
// 0x0007cbbb: eq.pri         
// 0x0007cbbc: neg            
// 0x0007cbbd: eq.pri         
// 0x0007cbbe: mul.c          
// 0x0007cbbf: movs.i         
// 0x0007cbc0: add            
// 0x0007cbc1: load.i         
// 0x0007cbc2: jzer           0x2cb5cd80
// 0x0007cbc7: eq.alt         -847236343
// 0x0007cbcc: op178          
// 0x0007cbcd: sshr           
// 0x0007cbce: eq.alt         -696251383
// 0x0007cbd3: op199          
// 0x0007cbd4: op219          
// 0x0007cbd5: sysreq.pri     
// 0x0007cbd6: load.s.pri     2038453493
// 0x0007cbdb: eq.alt         153230201
// 0x0007cbe0: eq.pri         
// 0x0007cbe1: neg            
// 0x0007cbe2: eq.pri         
// 0x0007cbe3: mul.c          
// 0x0007cbe4: push.pri       
// 0x0007cbe5: div.c          
// 0x0007cbe6: load.i         
// 0x0007cbe7: push.pri       
// 0x0007cbe8: const.alt      -607660416
// 0x0007cbed: sysreq.pri     
// 0x0007cbee: load.s.pri     -2122743796
// 0x0007cbf3: sysreq.c       
// 0x0007cbf4: idxaddr        
// 0x0007cbf5: move.alt       
// 0x0007cbf6: load.i         
// 0x0007cbf7: eq.pri         
// 0x0007cbf8: neg            
// 0x0007cbf9: eq.pri         
// 0x0007cbfa: mul.c          
// 0x0007cbfb: push.pri       
// 0x0007cbfc: div.c          
// 0x0007cbfd: load.i         
// 0x0007cbfe: pop.alt        
// 0x0007cbff: jeq            0x34b6cd80
// 0x0007cc04: eq.alt         -847236343
// 0x0007cc09: op178          
// 0x0007cc0a: sshr           
// 0x0007cc0b: eq.alt         -184188663
// 0x0007cc10: or             
// 0x0007cc11: push.c         0x-66184b7a ""
// 0x0007cc16: sign.alt       
// 0x0007cc17: push.s         203904245
// 0x0007cc1c: eq.pri         
// 0x0007cc1d: emit           
// 0x0007cc1e: eq.pri         
// 0x0007cc1f: xor            
// 0x0007cc20: stack          -847236336
// 0x0007cc25: op178          
// 0x0007cc26: sshr           
// 0x0007cc27: stack          201949444
// 0x0007cc2c: eq.pri         
// 0x0007cc2d: op214          
// 0x0007cc2e: op199          
// 0x0007cc2f: op219          
// 0x0007cc30: sysreq.pri     
// 0x0007cc31: load.s.pri     -2122743796
// 0x0007cc36: sysreq.c       
// 0x0007cc37: idxaddr        
// 0x0007cc38: move.alt       
// 0x0007cc39: load.i         
// 0x0007cc3a: eq.pri         
// 0x0007cc3b: neg            
// 0x0007cc3c: eq.pri         
// 0x0007cc3d: mul.c          
// 0x0007cc3e: dec.s.alt      
// 0x0007cc3f: cmps           
// 0x0007cc40: push.pri       
// 0x0007cc41: const.pri      -2030252416
// 0x0007cc46: jrel           -696251356
// 0x0007cc4b: op199          
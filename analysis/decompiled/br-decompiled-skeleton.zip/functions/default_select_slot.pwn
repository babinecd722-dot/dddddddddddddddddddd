// default_select_slot @ 0x99394-0x99680 (748 bytes)
// Source: system_auction.pwn

stock default_select_slot()
{
    return 1;
}

// --- disasm (first 80) ---
// 0x00099394: eq.c.alt       
// 0x00099395: eq.pri         
// 0x00099396: bounds         
// 0x00099397: dec.i          
// 0x00099398: zero.pri       
// 0x00099399: eq.alt         -578810871
// 0x0009939e: swap.alt       
// 0x0009939f: op182          
// 0x000993a0: mod            
// 0x000993a1: load.s.pri     -2122743692
// 0x000993a6: shl.alt        
// 0x000993a7: idxaddr        
// 0x000993a8: move.alt       
// 0x000993a9: load.i         
// 0x000993aa: eq.pri         
// 0x000993ab: neg            
// 0x000993ac: eq.pri         
// 0x000993ad: mul.c          
// 0x000993ae: eq.pri         
// 0x000993af: cmps           
// 0x000993b0: load.i         
// 0x000993b1: load.s.alt     -562021012
// 0x000993b6: op202          
// 0x000993b7: push.pri       
// 0x000993b8: eq.alt         -578810871
// 0x000993bd: swap.alt       
// 0x000993be: op182          
// 0x000993bf: mod            
// 0x000993c0: load.s.pri     -2122743692
// 0x000993c5: shl.alt        
// 0x000993c6: idxaddr        
// 0x000993c7: move.alt       
// 0x000993c8: load.i         
// 0x000993c9: eq.pri         
// 0x000993ca: neg            
// 0x000993cb: push.pri       
// 0x000993cc: const.alt      -607660416
// 0x000993d1: sysreq.pri     
// 0x000993d2: load.s.pri     -2122743796
// 0x000993d7: sysreq.c       
// 0x000993d8: idxaddr        
// 0x000993d9: move.alt       
// 0x000993da: load.i         
// 0x000993db: eq.pri         
// 0x000993dc: neg            
// 0x000993dd: push.pri       
// 0x000993de: const.alt      -1230971520
// 0x000993e3: mod            
// 0x000993e4: load.s.pri     -2122743692
// 0x000993e9: shl.alt        
// 0x000993ea: idxaddr        
// 0x000993eb: move.alt       
// 0x000993ec: load.i         
// 0x000993ed: eq.pri         
// 0x000993ee: neg            
// 0x000993ef: eq.pri         
// 0x000993f0: mul.c          
// 0x000993f1: eq.pri         
// 0x000993f2: zero.pri       
// 0x000993f3: load.i         
// 0x000993f4: load.s.alt     760119408
// 0x000993f9: load.s.alt     -2146753257
// 0x000993fe: op206          
// 0x000993ff: stor.alt       622265389
// 0x00099404: const.alt      -607660416
// 0x00099409: sysreq.pri     
// 0x0009940a: load.s.pri     -2122743796
// 0x0009940f: sysreq.c       
// 0x00099410: idxaddr        
// 0x00099411: move.alt       
// 0x00099412: load.i         
// 0x00099413: eq.pri         
// 0x00099414: neg            
// 0x00099415: load.i         
// 0x00099416: eq.pri         
// 0x00099417: mul.c          
// 0x00099418: op189          
// 0x00099419: dec.s.pri      
// 0x0009941a: jsgeq          
// 0x0009941b: heap           203757316
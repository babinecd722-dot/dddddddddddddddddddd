// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_pickup.pwn
// Functions: 7

// AMX 0xd824
stock n_CreatePickup()
{
    // if/goto jleq 0x2c
    // load.pri 168032
    // const.alt -1
    // if/goto jeq 0xdc48
    // load.pri 168032
    native#2047(_push.pri, 76880, "ÄcÿM", _push.s, _push.s, _push.s, _push.s, _push.s, _push.s);
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // const.alt 34
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // stor.alt 34
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // load.pri 168032
    native#2047(_push.pri, 76880);
    // load.pri 168032
    native#2047(_push.pri, 76880, 1);
    // if/goto jgrtr 0x2c
    // if/goto jgrtr 0x2c
    // stor.pri 76876
    // load.pri 168032
    return 1;
}

// AMX 0xdc58
stock n_DestroyPickup()
{
    // const.alt 76880
    native#2047();
    // if/goto jzer 0xdd34
    // const.alt 76880
    native#2047();
    // const.alt 76880
    native#2047(_push, 166992);
    // if/goto jgeq 0x2c
}

// AMX 0xdd5c
public OnPlayerPickUpPickup()
{
    // const.alt 105
    // load.pri 53
    return 1;
    // stor.alt 137
    // const.alt 167032
    Streamer_SetIntData("l", _push.s, "	", "9ºàñ");
    // locals stack 4
    // const.alt 167032
    Streamer_SetIntData("", _push.pri);
    // locals stack 4
    // if/goto jzer 0xdf44
    // const.alt 76880
    native#2047(2048, _push.pri, "", "", "", _push.pri);
    // stor.s.pri -4
    // const.alt 76880
    native#2047();
    // stor.s.pri -8
    OnPlayerPickUpPickupEx();
    // locals stack 8
    return 1;
}

// AMX 0xdf90
stock Iter_OnGameModeInit()
{
    // locals stack 8
    // locals stack 8
    // locals stack 8
    // locals stack 8
    // locals stack 8
    // locals stack 8
    // if/goto jump 57488
    // const.alt 2048
    // const.alt 76880
    native#2047("", "àñ", "'", "àñ", "'", "àñ", "", "àñ", "", "àñ", "", "àñ", "");
    // locals stack 4
    n_OnGameModeInit();
    return 1;
}

// AMX 0xe11c
stock fg_OnPlayerConnect()
{
    // stor.alt 137
    fixp_OnPlayerConnect();
    return 1;
}

// AMX 0xe178
public OnPlayerSpawn()
{
    // stor.alt 137
    fixp_OnPlayerSpawn();
    return 1;
}

// AMX 0xe1d4
public OnPlayerLeaveDynamicArea()
{
    // stor.alt 137
    fixp_OnPlayerLeaveDynamicArea();
    return 1;
}

// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_accessory.pwn
// Functions: 28

// AMX 0x680b4
stock AccessoryEdit_DestroyCoordsText()
{
    // const.alt 53
    // const.alt 199033828
    Streamer_SetIntData("", _push.s, "");
    // locals stack 12
    // const.alt 199033828
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    call_unknown();
    // locals stack 12
    // const.alt 199033828
    Streamer_SetIntData("", _push.s, "", "", _push.s, _push.pri);
    return 1;
}

// AMX 0x68210
stock AccessoryShop_IsValidIndex()
{
    return 1;
}

// AMX 0x68254
stock AccessoryShop_GetPriceByIndex()
{
    AccessoryShop_IsValidIndex();
    // if/goto jzer 0x68290
    return 1;
    // const.alt 199038012
    TextDrawBoxColor();
    return 1;
}

// AMX 0x682cc
stock AccessoryShop_GetModelByIndex()
{
    AccessoryShop_IsValidIndex();
    // if/goto jzer 0x68308
    return 1;
    // const.alt 199038012
    TextDrawBoxColor();
    return 1;
}

// AMX 0x6833c
stock AccessoryShop_GetInventoryItemB()
{
    // if/goto jump 426852
    // const.alt 207
    // const.alt 199094044
    SvCreateGStream("");
    // if/goto jneq 0x68404
    // const.alt 199094044
    SvCreateGStream();
    // locals stack 4
    return 1;
    // if/goto jump 426840
    // locals stack 4
    Inv11_GetAccItemByModel();
    return 1;
}

// AMX 0x68434
stock AccessoryShop_GiveInventoryItem()
{
    AccessoryShop_IsValidIndex();
    // if/goto jzer 0x68470
    return 1;
    // locals stack -4
    AccessoryShop_GetModelByIndex();
    // stor.s.pri -4
    // locals stack -4
    AccessoryShop_GetInventoryItemB();
    // stor.s.pri -8
    // stor.alt 133
    // const.alt 39
    // locals stack 20
    // locals stack 8
    return 1;
    // locals stack -4
    Inventory11_AddItemToDatabase();
    // stor.s.pri -12
    // if/goto jzer 0x685fc
    // stor.alt 133
    // const.alt 39
    // locals stack 24
    // locals stack 12
    return 1;
    // locals stack 12
    return 1;
}

// AMX 0x68614
stock CreatePlTDButtonBR()
{
    // const.alt 199035828
    Streamer_SetIntData();
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 199035828
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 199035828
    Streamer_SetIntData("", "", "¼ý;", _push.s, _push.pri);
}

// AMX 0x689bc
stock CreateTextDrawButtonBR()
{
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
}

// AMX 0x69468
stock HAT_OnPlayerSpawn()
{
    LoadAccessory();
    AccessoryEditSetMovementLock();
    name_OnPlayerSpawn();
    return 1;
}

// AMX 0x694d0
stock AccessoryEditSetMovementLock()
{
    // if/goto jzer 0x696d0
    return 1;
    // locals stack 20
    // stor.alt 137
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 20
    // locals stack 12
    // const.alt 39
    // locals stack 24
    // locals stack 12
    // if/goto jump 432148
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    // locals stack 20
    // locals stack 12
    // const.alt 39
    // locals stack 12
    return 1;
}

// AMX 0x69824
public OnPlayerUpdate()
{
    // const.alt 105
    // load.pri 53
    // locals stack -4
    // locals stack 12
    // stor.s.pri -4
    // locals stack -4
    // locals stack 12
    // stor.s.pri -8
    // locals stack -4
    // locals stack 12
    // stor.s.pri -12
    return 1;
    // locals stack 20
    return 1;
    // locals stack 12
    // locals stack 8
    func_0x2ac();
    // if/goto jnz 0x69b04
    return 1;
    // locals stack 12
    // locals stack 8
    func_0x2ac();
    // if/goto jnz 0x69b04
    return 1;
    // locals stack 12
    // locals stack 8
    func_0x2ac();
    // if/goto jnz 0x69b04
    // if/goto jump 432908
    // if/goto jzer 0x69b50
    // locals stack 20
    // locals stack 20
    // locals stack 24
    acsedit_OnPlayerUpdate();
    return 1;
}

// AMX 0x69bb4
stock blackjack_OnPlayerClickTextDraw()
{
    // if/goto jneq 0x69db4
    // locals stack -4
    // const.alt 154467216
    Streamer_SetIntData(199033704, _push.pri);
    // stor.s.pri -4
    // const.alt 205
    // const.alt 154468216
    Streamer_SetIntData();
    // locals stack 12
    // const.alt 154468216
    Streamer_SetIntData("", _push.s, _push.pri);
    // load.pri 121
    ("ð", _push.s, _push.pri, _push.pri, 199038012, "", "", "", "", "", "", "", _push.pri);
    // locals stack 40
    // const.alt 154467216
    Streamer_SetIntData();
    // load.pri 43
    // load.pri 36
    SetPriceAccesory();
    // locals stack 4
    // if/goto jneq 0x69fb0
    // locals stack -4
    // const.alt 154467216
    Streamer_SetIntData(199033704, _push.pri, "", _push.s, _push.pri);
    // stor.s.pri -4
    // const.alt 154468216
    Streamer_SetIntData();
    // locals stack 12
    // const.alt 154468216
    Streamer_SetIntData("", _push.s, _push.pri);
    TextDrawBoxColor(1, _push.pri, 199038012, "", "", "", "", "", "", "", _push.pri);
    ("ð", _push.s, _push.pri);
    // locals stack 40
    // const.alt 154467216
    Streamer_SetIntData();
    SetPriceAccesory();
    // locals stack 4
    // stor.alt 9
    // if/goto jneq 0x6a39c
    // const.alt 154468216
    Streamer_SetIntData(199033704, _push.pri, "", _push.s, _push.pri, 1, 1, _push.pri);
    // locals stack 12
    // const.alt 154468216
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 154467216
    Streamer_SetIntData(-1);
    // if/goto jump 434340
    // const.alt 5
    // const.alt 199033704
    floatsub("", -1);
    // locals stack 12
    // if/goto jump 434328
    // locals stack 4
    // const.alt 199035828
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    SetPlayerPosEx();
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    // const.alt 181530104
    Streamer_SetIntData("", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "8", _push.s, "", "", "", "", "", "", "9ºàñ", "", _push.s, _push.pri);
    // locals stack 8
    // locals stack 12
    ShowHud();
    TogglePlayerHudElement();
    // const.alt 9
    // if/goto jneq 0x6ad1c
    // locals stack -4
    // const.alt 154467216
    Streamer_SetIntData(199033704, _push.pri, "l", _push.s, "", "9ºàñ", "àñ", _push.s, "", _push.s, "9ºàñ", "àñ", _push.s, -1);
    // stor.s.pri -4
    AccessoryShop_IsValidIndex();
    // if/goto jzer 0x6a470
    // locals stack 16
    // locals stack 4
    return 1;
    // locals stack -4
    AccessoryShop_GetPriceByIndex();
    // stor.s.pri -8
    // locals stack -512
    // locals stack -4
    // stor.s.pri -524
    // const.alt 181530104
    Streamer_SetIntData(100, "àñ", _push.s);
    AccessoryShop_GiveInventoryItem();
    // if/goto jzer 0x6a5c4
    ShowNotificationNew();
    // locals stack 524
    return 1;
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -528
    // locals stack -4
    // locals stack 8
    // const.alt -1
    // if/goto jeq 0x6a6cc
    // const.alt 200
    // const.alt 195566420
    SetActorVirtualWorld("àñ", "àñ");
    // if/goto jump 435920
    // if/goto jzer 0x6a814
    // const.alt 195566420
    SetActorVirtualWorld(1);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.alt);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6acd0
    // const.alt -1
    // if/goto jeq 0x6a8cc
    // const.alt 200
    // const.alt 195566420
    SetActorVirtualWorld("àñ", "9ºàñ", "l", _push, "", _push.alt, "ÄcÿM", "/", "", _push.alt);
    // if/goto jump 436432
    // if/goto jzer 0x6a978
    // const.alt 195566420
    SetActorVirtualWorld(1);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt -1
    // if/goto jeq 0x6a9bc
    // const.alt 200
    // if/goto jump 436672
    // if/goto jzer 0x6ab94
    // const.alt 195566420
    SetActorVirtualWorld(1, _push.pri);
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "l", _push.alt, _push.alt, _push.alt, _push.alt);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // locals stack 44
    // locals stack 16
    GivePlayerMoneyEx();
    // locals stack -512
    // const.alt 199038012
    TextDrawBoxColor("Äc÷ÄcÿM", _push.s, _push.pri, 197904172, "9ºàñ", "9ºàñ", "l", _push, "", "è)", _push, "/", "", _push.pri);
    // locals stack 20
    ShowNewNotification();
    // locals stack 512
    // locals stack 8
    // if/goto jump 437524
    // locals stack 16
    // locals stack 524
    // if/goto jneq 0x6b120
    // if/goto jump 437612
    // const.alt 26
    // const.alt 199033724
    AddStaticVehicleEx("", 199033724, _push.pri, "l", _push.s, "", "", "M", _push.s, "àñ", "", "", "", "", _push.alt, "¼ý;", "/", "");
    // locals stack 12
    // if/goto jump 437600
    // locals stack 4
    TogglePlayerHudElement();
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    AccessoryEdit_DestroyCoordsText();
    // locals stack 8
    AccessoryEditSetMovementLock();
    TogglePlayerAllHudElements();
    // if/goto jneq 0x6d00c
    // if/goto jump 438640
    // const.alt 26
    // const.alt 199033724
    AddStaticVehicleEx("", 199033724, _push.pri, "", _push.s, "9ºàñ", "", _push.s, "", "àñ", _push.s, "àñ", _push.s, "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "l", _push.s, "", "9ºàñ", "", _push.s, _push.pri);
    // locals stack 12
    // if/goto jump 438628
    // locals stack 4
    TogglePlayerHudElement();
    // const.alt 105
    // load.pri 53
    // locals stack -2048
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", "", _push.s, "", "l", _push.s, "", "9ºàñ", "", _push.s, _push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 45
    // const.alt 45
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", "l", _push, "", "ÄcÿM", _push, "ÀÚ6", "", _push.pri);
    // locals stack 64
    // locals stack 16
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    AccessoryEdit_DestroyCoordsText();
    // locals stack 8
    AccessoryEditSetMovementLock();
    TogglePlayerAllHudElements();
    ShowHud();
    // locals stack 16
    // locals stack 2048
    return 1;
    // locals stack -2048
    // locals stack -4
    // const.alt 17
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 45
    // const.alt 45
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", "", _push.s, "", "");
    // const.alt 39
    // locals stack 60
    // const.alt 181530104
    Streamer_SetIntData("hY", _push.pri);
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 45
    // locals stack 68
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6c05c
    // locals stack 8
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "àñ", "9ºàñ", "àñ", "9ºàñ", "l", _push, "", "Ò,", _push, "ÀÚ6", "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.pri);
    // const.alt 39
    // locals stack 28
    // if/goto jump 442556
    // const.alt 181530104
    Streamer_SetIntData("ÄcÿM", _push.pri);
    // const.alt 39
    // locals stack 20
    LoadPlayerAccessories();
    // if/goto jump 443772
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", "àñ", _push.s, "¼ý;", _push.pri);
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 45
    // const.alt 45
    // locals stack 60
    // locals stack 16
    // stor.s.pri -2052
    // locals stack 8
    // if/goto jzer 0x6c4b8
    // locals stack 8
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", _push.alt, "àñ", "9ºàñ", "àñ", "9ºàñ", "l", _push, "9ºàñ", _push.alt, "hY", "ÀÚ6", "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.pri);
    // const.alt 39
    // locals stack 28
    // if/goto jump 443728
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", "ÄcÿM", _push.pri);
    // const.alt 39
    // locals stack 20
    // locals stack 12
    // locals stack -4
    // const.alt 17
    // const.alt 1073
    // if/goto jump 443908
    // if/goto jzer 0x6c654
    // const.alt 36
    AccessoryGetIndexByModel();
    // stor.s.pri -2060
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", "àñ", "", _push.s, "", 1, "", _push.s, "", "", _push.s, "9ºàñ", "¼ý;", _push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6c848
    // locals stack 8
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", _push.alt, "àñ", "9ºàñ", "àñ", "9ºàñ", "l", _push, "", "ÄcÿM", _push, "ÀÚ6", "", _push.pri);
    // const.alt 39
    // locals stack 28
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 45
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", _push.alt, "", _push.s, "", "ÄcÿM", _push.pri);
    // locals stack 64
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6cbf8
    // locals stack 8
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", _push.alt, "àñ", "9ºàñ", "àñ", "9ºàñ", "l", _push, "", "b*", _push, "ÀÚ6", "", _push.pri);
    // const.alt 39
    // locals stack 32
    // if/goto jump 445592
    // const.alt 45
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "", "M", _push.pri);
    // const.alt 39
    // locals stack 24
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    AccessoryEdit_DestroyCoordsText();
    // locals stack 8
    AccessoryEditSetMovementLock();
    TogglePlayerAllHudElements();
    // locals stack 16
    ShowHud();
    // locals stack 2060
    // if/goto jump 446520
    // const.alt 10
    // const.alt 199033724
    AddStaticVehicleEx(_push.pri, "àñ", "", "àñ", _push.s, "l", _push.s, "", "", "", _push.s, "9ºàñ", "", _push.s, "", "àñ", _push.s, "àñ", _push.s, "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "Äc÷ÄcÿM", _push.pri);
    // if/goto jneq 0x6d0a8
    // stor.s.pri -4
    // if/goto jump 446640
    // if/goto jump 446508
    // locals stack 4
    // const.alt -1
    // if/goto jeq 0x6d6f0
    // locals stack -4
    // const.alt 17
    // const.alt 1
    // const.alt 7
    // if/goto jump 446808
    // if/goto jzer 0x6d174
    // stor.s.pri -8
    // locals stack -4
    // stor.s.pri -12
    // locals stack 12
    // locals stack 12
    // stor.s.pri 121
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // stor.s.pri 121
    // locals stack 12
    // load.pri 36
    // stor.alt 137
    // load.pri 129
    // locals stack 12
    // stor.s.pri -16
    // if/goto jump 448032
    // locals stack 12
    // stor.s.pri -16
    // if/goto jump 448032
    // locals stack 12
    // stor.s.pri -16
    // if/goto jump 448032
    // locals stack 12
    // stor.s.pri -16
    // if/goto jump 448032
    // locals stack 12
    // stor.s.pri -16
    // if/goto jump 448032
    // locals stack 12
    // stor.s.pri -16
    // if/goto jump 448032
    // locals stack 12
    // stor.s.pri -16
    // if/goto jump 448032
}

// AMX 0x6e448
stock HAT_OnGameModeInit()
{
    // locals stack 8
    CreateTextDrawButtonBR();
    CreateEditAccessoryTD_Accessory();
    // locals stack 16
    acs_OnGameModeInit();
    return 1;
}

// AMX 0x6e4e8
stock EntryAccessoryMarket()
{
    return 1;
    // locals stack 20
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 8
    // stor.alt 137
    // locals stack 8
    // stor.alt 137
    // const.alt 154467216
    Streamer_SetIntData("l", _push.s, "", _push.pri, "àñ", _push.s, "l", _push.s, "", _push.pri, "àñ", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "", _push.s);
    // load.pri 36
    SetPlayerPosEx();
    HideHud();
    // locals stack 12
    // if/goto jump 452576
    // const.alt 12
    // locals stack 16
    // if/goto jump 452564
    // locals stack 4
    TogglePlayerHudElement();
    // locals stack 40
    // locals stack 40
    // const.alt 154468216
    Streamer_SetIntData("ð", _push.s, "", "", "", "", "", "", "Ü@!", "9ºàñ", "ð", _push.s, "", "", "", "", "", "", "Ü@!", "9ºàñ", "l", _push.s, "", "", "l", _push.s, "", "", "", "", _push.s, "", "àñ", _push.s, "8", _push.s, "", "", "", "", "9ºàñ", "9ºàñ");
    ("ð", _push.s, _push.pri, 199038012, "", "", "", "", "", "", "", _push.pri);
    // locals stack 40
    CreatePlTDButtonBR();
    SetPriceAccesory();
    // locals stack 12
    // locals stack 12
    // if/goto jump 453256
    // const.alt 5
    // const.alt 199033704
    floatsub("", "", _push.s, "", "", _push.s, "", "", _push.s, "", "àñ", _push.s);
    // locals stack 12
    // if/goto jump 453244
    // locals stack 4
    // const.alt 199035828
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // locals stack -496
    // locals stack 20
    // locals stack 12
    // locals stack 524
    return 1;
}

// AMX 0x6ec00
stock SetPriceAccesory()
{
    AccessoryShop_IsValidIndex();
    // if/goto jzer 0x6ec3c
    return 1;
    // locals stack -96
    // locals stack -60
    // if/goto jgeq 0x89
    AccessoryShop_GetPriceByIndex();
    ConvertMoney();
    // locals stack 20
    // const.alt 199035828
    Streamer_SetIntData(_push.alt, "¼ý;", "ÄcÿM", "", "l", _push.pri, "àñ", _push.s, "");
    // locals stack 16
    // locals stack 156
    return 1;
}

// AMX 0x6ed68
stock pc_cmd_testacs()
{
    // locals stack -512
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", "");
    // locals stack 28
    // locals stack 16
    // stor.s.pri -516
    // locals stack 8
    // if/goto jzer 0x6efbc
    // locals stack 12
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "", _push.s, "9ºàñ", "àñ", "9ºàñ", "l", _push, "9ºàñ", "ÄcÿM", _push, "/", "", _push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 16
    // if/goto jump 454684
    // locals stack 12
    // locals stack 16
    AccessoryShowInventory();
    // locals stack 520
    return 1;
}

// AMX 0x6f044
stock pc_cmd_myacs()
{
    AccessoryShowInventory();
    return 1;
}

// AMX 0x6f06c
stock AccessoryShowInventory()
{
    // locals stack -16384
    // const.alt 181530104
    Streamer_SetIntData("", "");
    // locals stack 24
    // locals stack 16
    // stor.s.pri -16388
    // locals stack -4
    // locals stack 8
    // stor.s.pri -16396
    // if/goto jzer 0x6f258
    // locals stack 16
    ShowNewNotification();
    // locals stack 12
    // locals stack 16396
    return 1;
    // locals stack -640
    // locals stack -280
    // locals stack 16
    // if/goto jump 455424
    // locals stack 16
    // stor.s.pri -16392
    // locals stack 16
    // stor.s.pri -17040
    // locals stack 16
    // stor.s.pri -17044
    // if/goto jzer 0x6f41c
    // if/goto jump 455412
    // locals stack 16
    // if/goto jump 455848
    // locals stack 16
    // const.alt 154469216
    native#1072(_push.alt, "l", "", "", _push.alt, "l", "", "", 1073, _push.pri, "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "", _push.alt, "l", "t'%", "", "", "", "");
    // load.pri 45
    // locals stack 28
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "t'%", _push.alt, "ÄcÿM", "Ü", "", _push.alt);
    native#1023(_push.pri);
    // locals stack 20
    // stor.alt 137
    // if/goto jump 455412
    // locals stack 4
    // if/goto jzer 0x6f6e8
    // locals stack 16
    // locals stack 12
    // locals stack 17328
    return 1;
    Dialog();
    // locals stack 12
    // locals stack 17328
    return 1;
}

// AMX 0x6f778
stock HAT_OnDialogResponse()
{
    // if/goto jzer 0x6f9e0
    // if/goto jzer 0x6f9e0
    // locals stack -4
    // const.alt 196049960
    Streamer_SetIntData();
    native#1023(_push.pri);
    // stor.s.pri -4
    // locals stack -96
    // stor.alt 137
    // locals stack 20
    // const.alt 84
    // if/goto jzer 0x6f958
    Dialog();
    // stor.alt 51
    Dialog();
    // stor.alt 44
    // if/goto jzer 0x6fbd8
    // if/goto jzer 0x6fbd8
    // locals stack -4
    // const.alt 17
    // const.alt 84
    // if/goto jzer 0x6fb48
    UseAccessory();
    // if/goto jump 457536
    SellAccessory();
    // if/goto jump 457536
    DeleteAccessory();
    // if/goto jump 457536
}

// AMX 0x6ff24
stock UseAccessory()
{
    // locals stack -880
    // const.alt 181530104
    Streamer_SetIntData("");
    // stor.alt 39
    // locals stack 28
    // locals stack 16
    // stor.s.pri -884
    // locals stack 8
    // if/goto jzer 0x700a8
    // locals stack 12
    // locals stack 16
    // locals stack 884
    return 1;
    // locals stack -4
    // locals stack 16
    // stor.s.pri -888
    // locals stack 12
    // if/goto jzer 0x701a8
    // locals stack 16
    // locals stack 888
    return 1;
    // locals stack -4
    // const.alt 154469216
    native#1072();
    // stor.s.pri -892
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
    // stor.s.pri -896
    // if/goto jump 459756
}

// AMX 0x70a50
stock TakeOffAccessory()
{
    // locals stack -736
    // stor.alt 39
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -744
    // locals stack -4
    // locals stack 16
    // stor.s.pri -748
    // locals stack 12
    // locals stack 8
    // if/goto jzer 0x70e98
    // const.alt 181530104
    Streamer_SetIntData("àñ", "9ºàñ", "", _push.s, "9ºàñ", "l", "", "", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "5", "");
    // locals stack 28
    // locals stack 16
    // stor.s.pri -744
    // locals stack 8
    // if/goto jzer 0x70cbc
    // locals stack 16
    // stor.s.pri -4
    // locals stack 12
    // const.alt 181530104
    Streamer_SetIntData("", _push.s, "9ºàñ", "l", "", "", "9ºàñ", "àñ", "9ºàñ", "l", _push, "9ºàñ", "ÄcÿM", _push, "5", "", _push.pri);
    // locals stack 28
    // locals stack 16
    // stor.alt 39
    // locals stack 24
    // locals stack 16
    // const.alt -1
    // if/goto jeq 0x70e98
    // locals stack 12
    ShowNewNotification();
    // locals stack 748
    return 1;
}

// AMX 0x70eb0
stock SellAccessory()
{
    // locals stack -496
    // stor.alt 39
    // locals stack 24
    // locals stack 16
    // stor.s.pri -500
    // locals stack 16
    // stor.alt 137
    // locals stack 12
    Dialog();
    // locals stack 500
    return 1;
}

// AMX 0x71050
stock DeleteAccessory()
{
    // locals stack -496
    // stor.alt 39
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x71164
    // locals stack 16
    // if/goto jump 463256
    // locals stack 16
    // locals stack 500
    return 1;
}

// AMX 0x711b0
stock EditAccessory()
{
    // locals stack -880
    // if/goto jump 463368
    // const.alt 12
    // locals stack 16
    // if/goto jump 463356
    // locals stack 4
    TogglePlayerHudElement();
    // stor.alt 39
    // locals stack 20
    // locals stack 16
    // stor.s.pri -888
    // locals stack -4
    // locals stack 16
    // stor.s.pri -892
    // locals stack 12
    // const.alt 181530104
    Streamer_SetIntData("", _push.s, "9ºàñ", "l", "", "", "9ºàñ", "l", _push, "9ºàñ", _push.alt, "¼ý;", "÷+", "l", _push.s, "", "", "l", _push.s, "", "", "", "", "");
    // locals stack 24
    // locals stack 16
    // stor.s.pri -888
    // locals stack 8
    // stor.s.pri -884
    // if/goto jzer 0x72278
    // locals stack -4
    // locals stack 16
    // stor.s.pri -896
    // locals stack -4
    // locals stack 16
    // stor.s.pri -900
    // locals stack -4
    // locals stack 16
    // stor.s.pri -904
    // locals stack -4
    // locals stack 16
    // stor.s.pri -908
    // locals stack -4
    // locals stack 16
    // stor.s.pri -912
    // locals stack -4
    // locals stack 16
    // stor.s.pri -916
    // locals stack -4
    // locals stack 16
    // stor.s.pri -920
    // locals stack -4
    // locals stack 16
    // stor.s.pri -924
    // locals stack -4
    // locals stack 16
    // stor.s.pri -928
    // stor.alt 137
    // stor.alt 137
    call_unknown();
    // locals stack 12
    // const.alt 154469216
    native#1072("", _push.s, "", "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "àñ", "9ºàñ", "l", _push, "9ºàñ", _push.alt, "Äc÷ÄcÿM", "÷+", "", _push.pri);
    // stor.alt 137
    // stor.alt 137
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 36
    // const.alt 34
    // const.alt 51
    // const.alt 121
    // const.alt 36
    // locals stack 64
    HideHud();
    // locals stack 12
    // if/goto jump 466080
    // const.alt 11
    // const.alt 199033724
    AddStaticVehicleEx("", "", _push.s, "", "àñ", _push.s, "b*", _push.s, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, 154469216, "", _push.s, "", "", _push.s, "", "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", _push.pri, "", _push.s, "", "", "", "", _push.s, _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", _push.pri);
    // locals stack 12
    // if/goto jump 466068
    // locals stack 4
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack -72
    // locals stack 12
    // locals stack 20
    AccessoryEdit_DestroyCoordsText();
    // const.alt 199033828
    Streamer_SetIntData("àñ", _push.s, _push.alt, "¼ý;", ";", "", _push.alt, "", _push.s, "", "", _push.s, _push.pri, 199033724, "", _push.s, _push.pri, 199033724, "", _push.s, _push.pri, 199033724, "", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", _push.pri);
    // const.alt 199033828
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 199033828
    Streamer_SetIntData("ºàñ", "¼ý;", _push.s, _push.pri);
    // locals stack 16
    // const.alt 199033828
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 199033828
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 199033828
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 199033828
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // stor.alt 137
    // const.alt 199033828
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 199033828
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 12
    // stor.alt 137
    // stor.alt 137
    TogglePlayerAllHudElements();
    AccessoryEditSetMovementLock();
    // locals stack 108
    // locals stack 12
    // locals stack 892
    return 1;
}

// AMX 0x722b4
stock AccessoryGetIndexByModel()
{
    // if/goto jump 467676
    // const.alt 1073
    // const.alt 154469216
    native#1072("");
    // if/goto jneq 0x72350
    // locals stack 4
    return 1;
    // if/goto jump 467664
    // locals stack 4
    return 1;
}

// AMX 0x72370
stock LoadAccessory()
{
    // locals stack -880
    // const.alt 181530104
    Streamer_SetIntData("", "");
    // locals stack 20
    // locals stack 16
    // stor.s.pri -888
    // locals stack 8
    // stor.s.pri -884
    // const.alt 181530104
    Streamer_SetIntData("àñ", "9ºàñ", "l", _push, "9ºàñ", _push.alt, "¼ý;", "÷+", "", _push.pri);
    // const.alt 39
    // locals stack 20
    // if/goto jzer 0x72928
    // if/goto jump 468312
    // locals stack 16
    // stor.s.pri -892
    // locals stack 16
    // stor.s.pri -896
    // locals stack 16
    // stor.s.pri -900
    // locals stack 16
    // stor.s.pri -904
    // locals stack 16
    // stor.s.pri -908
    // locals stack 16
    // stor.s.pri -912
    // locals stack 16
    // stor.s.pri -924
    // locals stack 16
    // stor.s.pri -920
    // locals stack 16
    // stor.s.pri -916
    // locals stack 16
    // stor.s.pri -928
    // const.alt 154469216
    native#1072(_push.s, _push.s, _push.s, _push.s, _push.s, _push.s, _push.s, _push.s, _push.s, _push.s, "", "", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "", "", "", "", "", "", "", "", "", "", "", "¼ý;", _push.pri);
    // locals stack 64
    // const.alt 154469216
    native#1072("b*", _push.s, _push.s, _push.pri);
    // const.alt 133
    // locals stack 60
    // if/goto jump 468300
    // locals stack 4
    // locals stack 40
    // locals stack 12
    // locals stack 888
    return 1;
}

// AMX 0x7296c
stock CreateEditAccessoryTD_Accessory()
{
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 36
    // locals stack 16
    // const.alt 9
    // locals stack 16
    // const.alt 9
    // locals stack 12
    // const.alt 9
    // locals stack 12
    // const.alt 9
    // locals stack 12
    // const.alt 9
    // locals stack 12
    // const.alt 9
    // locals stack 12
    // stor.alt 36
    // locals stack 16
    // stor.alt 9
    // locals stack 16
    // stor.alt 9
    // locals stack 12
    // stor.alt 9
    // locals stack 12
    // stor.alt 9
    // locals stack 12
    // stor.alt 9
    // locals stack 12
    // stor.alt 9
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 36
    // locals stack 16
    // locals stack 9
    // locals stack 16
    // locals stack 9
    // locals stack 12
    // locals stack 9
    // locals stack 12
    // locals stack 9
    // locals stack 12
    // locals stack 9
    // locals stack 12
    return 1;
    // locals stack 16
    return 1;
    // locals stack 16
    return 1;
    // locals stack 12
    return 1;
    // locals stack 12
    return 1;
    // locals stack 12
    return 1;
    // locals stack 12
    // if/goto jrel 36
    // locals stack 16
    // if/goto jrel 9
    // locals stack 16
    // if/goto jrel 9
    // locals stack 12
    // if/goto jrel 9
    // locals stack 12
    // if/goto jrel 9
    // locals stack 12
    // if/goto jrel 9
    // locals stack 12
    // if/goto jneq 0x24
    // locals stack 16
    // if/goto jneq 0x9
    // locals stack 16
    // if/goto jneq 0x9
    // locals stack 12
    // if/goto jneq 0x9
    // locals stack 12
    // if/goto jneq 0x9
    // locals stack 12
    // if/goto jneq 0x9
    // locals stack 12
    // if/goto jgeq 0x24
    // locals stack 16
    // if/goto jgeq 0x9
    // locals stack 16
    // if/goto jgeq 0x9
    // locals stack 12
    // if/goto jgeq 0x9
    // locals stack 12
    // if/goto jgeq 0x9
    // locals stack 12
    // if/goto jgeq 0x9
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
}

// AMX 0x75780
stock CREATE_TABLIST_ACCESSORY()
{
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x75870
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x75870
    // locals stack 8
    return 1;
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x75958
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x75958
    // locals stack 8
    return 1;
}

// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_weekly_prizes.pwn
// Functions: 9

// AMX 0x63c44
stock CREATE_ACCOUNTS_TABLE_WP()
{
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x63d34
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x63d34
    // locals stack 8
    return 1;
}

// AMX 0x63d44
stock LoadWeeklyPrizes()
{
    // locals stack -336
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -340
    // locals stack 8
    // if/goto jzer 0x63f7c
    // locals stack -192
    // if/goto jump 
    // locals stack 24
    // const.alt 199002120
    Streamer_SetIntData("Äc÷ÄcÿM", "", "", "9ºàñ", "X*", "àñ", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "¦*", "", _push.pri);
    // locals stack 16
    // const.alt 199002120
    Streamer_SetIntData("l", "", _push.pri);
    // locals stack 16
    // locals stack 192
    // locals stack 12
    // locals stack 340
    return 1;
}

// AMX 0x63fc0
stock UnLoadWeeklyPrizes()
{
    // locals stack -192
    // const.alt 199002120
    Streamer_SetIntData();
    // const.alt 199002120
    Streamer_SetIntData();
    // const.alt 199002120
    Streamer_SetIntData();
    // stor.alt 36
    // const.alt 199002120
    Streamer_SetIntData();
    // const.alt 36
    // const.alt 199002120
    Streamer_SetIntData();
    // const.alt 199002120
    Streamer_SetIntData();
    // const.alt 199002120
    Streamer_SetIntData();
    // locals stack 44
    // locals stack -736
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "è)", "X*", "", _push.pri);
    // const.alt 199002120
    Streamer_SetIntData(_push.pri);
    // locals stack 32
    // locals stack 16
    // locals stack 928
    return 1;
}

// AMX 0x64290
stock ch_OnPlayerConnect()
{
    // const.alt 39
    // locals stack 24
    weekly_OnPlayerConnect();
    return 1;
}

// AMX 0x642fc
stock name_OnPlayerDisconnect()
{
    UnLoadWeeklyPrizes();
    weekly_OnPlayerDisconnect();
    return 1;
}

// AMX 0x64348
stock ch_OnGameModeInit()
{
    // locals stack 16
    // locals stack 16
    // locals stack 8
    weekly_OnGameModeInit();
    return 1;
}

// AMX 0x643f4
stock CheckWeeklyPrizes()
{
    // switch ()
    // locals stack 16
    // locals stack 16
    // locals stack -4
    GetDayOfWeek();
    // const.alt 1
    // stor.s.pri -24
    // if/goto jzer 0x6453c
    // if/goto jzer 0x6453c
    // if/goto jzer 0x6453c
    // if/goto jump 410944
    // if/goto jzer 0x6457c
    // locals stack 16
    // if/goto jzer 0x645b8
    // if/goto jzer 0x645b8
    // if/goto jump 411068
    // if/goto jzer 0x645f8
    // locals stack 16
    // if/goto jump 411164
    // const.alt 9816
    GetPlayerMenu("", "", "l", _push, "", "9ºàñ", 1, "l", _push, "", "9ºàñ", 1, "l", _push.s, _push.s, _push.s, "l", _push.alt, "l", "", "", "", "", "");
    // stor.s.pri -32
    // const.alt 250
    // if/goto jeq 0x6492c
    // const.alt 199002120
    Streamer_SetIntData();
    // if/goto jzer 0x6469c
    // if/goto jump 411160
    // stor.s.pri -28
    // if/goto jump 411344
    // const.alt 7
    // const.alt 199002120
    Streamer_SetIntData("", -1);
    PR_Init(_push.pri);
    // if/goto jzer 0x64754
    // stor.s.pri -28
    // if/goto jump 411332
    // locals stack 4
    // if/goto jzer 0x6478c
    // if/goto jump 411160
    // const.alt 199002120
    Streamer_SetIntData();
    // if/goto jzer 0x64824
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 7200
    // if/goto jump 411688
    // if/goto jzer 0x64924
    // locals stack 16
    // const.alt 199002120
    Streamer_SetIntData("l", _push.s, "", "", 1);
    PR_Init(_push.pri);
    // const.alt 199002120
    Streamer_SetIntData(_push.pri);
    UnLoadWeeklyPrizes();
    // if/goto jump 411160
    // locals stack 4
    // locals stack 28
    return 1;
}

// AMX 0x6494c
stock pc_cmd_everyprize()
{
    // locals stack -1392
    // locals stack -112
    // locals stack -336
    // if/goto jump 412108
    // const.alt 7
    // const.alt 199002120
    Streamer_SetIntData("");
    PR_Init(_push.pri);
    // locals stack 16
    // if/goto jump 412432
    // locals stack 16
    // if/goto jump 412432
    // locals stack 16
    // if/goto jump 412432
}

// AMX 0x64c48
stock skin_OnDialogResponse()
{
    // if/goto jzer 0x657cc
    // if/goto jzer 0x657cc
    // locals stack -4
    // stor.s.pri -4
    // if/goto jzer 0x64d7c
    // const.alt 199002120
    Streamer_SetIntData();
    PR_Init(_push.pri);
    // load.pri 53
    // const.alt 199002120
    Streamer_SetIntData();
    PR_Init(1, _push.pri);
    // load.pri 53
    // if/goto jump 413056
    // if/goto jzer 0x64dc8
    // locals stack 16
    // locals stack 4
    return 1;
    // if/goto jzer 0x64ea0
    // const.alt 199002120
    Streamer_SetIntData();
    PR_Init(_push.pri);
    // if/goto jzer 0x64ea0
    // const.alt 199002120
    Streamer_SetIntData();
    PR_Init(1, _push.pri);
    // if/goto jzer 0x64ea0
    // if/goto jump 413348
    // if/goto jzer 0x64eec
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 199002120
    Streamer_SetIntData();
    PR_Init(_push.pri);
    // load.alt 53
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 199002120
    Streamer_SetIntData();
    PR_Init(_push.pri);
    // locals stack 16
    // if/goto jump 415684
    // const.alt 199001364
    PC_Init("l", _push.s, "", "");
    // const.alt 199001364
    PC_Init(197904564, "9ºàñ", "9ºàñ");
    GivePlayerDonateRub();
    // if/goto jump 415208
    // const.alt 199001364
    PC_Init(197904172, "9ºàñ", "9ºàñ", "Äc÷ÄcÿM", _push.s, _push.pri);
    GivePlayerMoneyEx();
    // if/goto jump 415208
    // const.alt 181530104
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, _push.pri);
    // if/goto jzer 0x652ec
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData(3);
    // locals stack 16
    // const.alt 199001364
    PC_Init(_push.pri, "l", _push.alt, _push.alt, _push.alt, _push.pri);
    // if/goto jump 414584
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 199001364
    PC_Init(_push.pri, _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, _push.alt, _push.alt, "", "", "");
    timestamp_to_date();
    UpdatePlayerDatabaseInt();
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", "àñ", "M", _push.pri);
    UpdatePlayerDatabaseInt();
    // locals stack 12
    // if/goto jump 415208
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // const.alt 199001364
    PC_Init(_push.pri, _push.pri);
    // const.alt 181530104
    Streamer_SetIntData();
    UpdatePlayerDatabaseInt();
    // if/goto jump 415208
}

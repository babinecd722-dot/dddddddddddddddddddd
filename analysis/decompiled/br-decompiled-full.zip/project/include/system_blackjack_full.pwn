// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_blackjack_full.pwn
// Functions: 36

// AMX 0x17ec8
stock BJSetPlayerCleanChat()
{
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    // locals stack 16
    // stor.alt 11
    // locals stack 16
    // locals stack 24
    // locals stack 8
    // locals stack 4
    return 1;
}

// AMX 0x18020
stock Iter_OnPlayerDisconnect()
{
    // const.alt 182162180
    Streamer_SetIntData();
    // load.pri 53
    // const.alt 182162180
    Streamer_SetIntData();
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676);
    floatcmp();
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676, -1);
    floatcmp();
    return 1;
    // if/goto jump 99492
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676);
    floatcmp();
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676, -1, _push.pri);
    floatcmp();
    // if/goto jrel 34
    // if/goto jump 99492
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676);
    floatcmp();
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676, -1, _push);
    floatcmp();
    // if/goto jneq 0x22
    // if/goto jump 99492
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676);
    floatcmp();
    // locals stack 34
    // const.alt 182162180
    Streamer_SetIntData(_push.pri, 182161676, -1);
    floatcmp();
    // if/goto jgeq 0x22
    // if/goto jump 99492
}

// AMX 0x18588
public OnPlayerClickTextDraw()
{
    // load.pri 182118672
    // if/goto jneq 0x18734
    // locals stack 16
    // locals stack 8
    // locals stack -4096
    // locals stack 16
    // locals stack 20
    // locals stack 20
    fg_ShowPlayerDialog();
    // locals stack 4096
    return 1;
    // load.pri 182118656
    // if/goto jneq 0x187e0
    // locals stack 16
    fg_ShowPlayerDialog();
    return 1;
    // load.pri 182118648
    // if/goto jneq 0x19d48
    // locals stack 16
    // locals stack -4
    // const.alt 182162180
    Streamer_SetIntData("l", _push.s, "", "");
    // stor.s.pri -4
    // const.alt 182161676
    floatcmp();
    // const.alt 182162180
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0x19c7c
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 182162180
    Streamer_SetIntData(_push.pri);
    // const.alt 9
    ShowNotification();
    ShowNewNotification();
    // locals stack 4
    return 1;
    // locals stack -268
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 20
    // const.alt 182118676
    floatcmp(_push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x18c14
    // const.alt 182118676
    floatcmp();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x18ce0
    // const.alt 182118676
    floatcmp(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x18dac
    // const.alt 182118676
    floatcmp(_push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x18e78
    // const.alt 182118676
    floatcmp();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182162180
    Streamer_SetIntData(182174496, "9ºàñ", "9ºàñ", "", _push.pri);
    // const.alt 9
    GivePlayerMoneyBjEx();
    // const.alt 182162180
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, _push.pri);
    // const.alt 36
    // const.alt 182162180
    Streamer_SetIntData();
    // const.alt 9
    // load.alt 43
    // locals stack -60
    // if/goto jgeq 0x89
    // const.alt 182162180
    Streamer_SetIntData();
    // const.alt 36
    // locals stack 20
    // const.alt 182119408
    Streamer_SetIntData(_push.alt, "¼ý;", "", "");
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 182120408
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 16
    // const.alt 182162180
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack -4
    // locals stack 8
    // stor.s.pri -336
    // locals stack -4
    // locals stack 8
    // stor.s.pri -340
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "");
    return 1;
    // const.alt 182154552
    GetPlayerName(_push.pri, _push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    return 1;
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 12
    // const.alt 182162180
    Streamer_SetIntData(_push.s, _push.s, "", _push.pri);
    // load.alt 36
    ShowMembersCardBJL();
    // const.alt 182162180
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, "9ºàñ");
    CheckTableBlackJack();
    // locals stack 8
    // if/goto jump 105580
    // locals stack -4
    // locals stack 8
    // stor.s.pri -336
    // locals stack -4
    // locals stack 8
    // stor.s.pri -340
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", "", _push.s, "9ºàñ");
    // if/goto jrel 36
    // const.alt 182154552
    GetPlayerName(_push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    // if/goto jrel 36
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "");
    // locals stack 12
    // const.alt 182162180
    Streamer_SetIntData(_push.s, _push.s, "", _push.pri);
    // load.alt 36
    ShowMembersCardBJL();
    // const.alt 182162180
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, "ºàñ");
    CheckTableBlackJack();
    // locals stack 8
    // if/goto jump 105580
    // locals stack -4
    // locals stack 8
    // stor.s.pri -336
    // locals stack -4
    // locals stack 8
    // stor.s.pri -340
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", "", _push.s, "ºàñ");
    // if/goto jneq 0x24
    // const.alt 182154552
    GetPlayerName(_push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    // if/goto jneq 0x24
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "");
    // locals stack 12
    // const.alt 182162180
    Streamer_SetIntData(_push.s, _push.s, "", _push.pri);
    // load.alt 36
    ShowMembersCardBJL();
    // const.alt 182162180
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, "àñ");
    CheckTableBlackJack();
    // locals stack 8
    // if/goto jump 105580
    // locals stack -4
    // locals stack 8
    // stor.s.pri -336
    // locals stack -4
    // locals stack 8
    // stor.s.pri -340
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", "", _push.s, "àñ");
    // if/goto jgeq 0x24
    // const.alt 182154552
    GetPlayerName(_push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    // if/goto jgeq 0x24
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "");
    // const.alt 9
    // locals stack 12
    // const.alt 182162180
    Streamer_SetIntData(_push.s, _push.s, "", _push.pri);
    // load.alt 36
    ShowMembersCardBJL();
    // const.alt 182162180
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, "àñ");
    CheckTableBlackJack();
    // locals stack 8
    // if/goto jump 105580
}

// AMX 0x1b868
stock fg_OnDialogResponse()
{
    // locals stack -512
    // if/goto jzer 0x1b958
    // const.alt 182162180
    Streamer_SetIntData();
    // if/goto jzer 0x1b910
    // locals stack 12
    blackjack_OnDialogResponse();
    // locals stack 512
    return 1;
    // if/goto jzer 0x1c884
    // locals stack 16
    // if/goto jzer 0x1c884
    // const.alt 182162180
    Streamer_SetIntData("l", _push.s, "", "");
    // if/goto jzer 0x1c884
    // locals stack 16
    // if/goto jzer 0x1bb2c
    ShowNotification();
    ShowNewNotification();
    fg_ShowPlayerDialog();
    // locals stack 516
    return 1;
    // if/goto jzer 0x1bc60
    ShowNotification();
    ShowNewNotification();
    fg_ShowPlayerDialog();
    // locals stack 516
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    ShowNotification();
    ShowNewNotification();
    fg_ShowPlayerDialog();
    // locals stack 516
    return 1;
    // locals stack 20
    // const.alt 182119408
    Streamer_SetIntData(_push.alt, "¼ý;", "/", "");
    // locals stack 12
    // const.alt 182119408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182162180
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 34
    // locals stack -4
    // const.alt 182162180
    Streamer_SetIntData();
    // stor.s.pri -520
    // locals stack -4
    // const.alt 182162180
    Streamer_SetIntData();
    // stor.alt 9
    // stor.s.pri -524
    // locals stack -4
    // const.alt 182161676
    floatcmp();
    // stor.s.pri -528
    // locals stack -4
    // const.alt 182161676
    floatcmp();
    // stor.s.pri -532
    // locals stack -4
    // const.alt 182161676
    floatcmp(_push.pri);
    // stor.s.pri -536
    // locals stack -4
    // const.alt 182161676
    floatcmp(_push);
    // locals stack 9
    // stor.s.pri -540
    // const.alt -1
    // if/goto jeq 0x1c234
    // const.alt 182118748
    floatcmp();
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt -1
    // if/goto jeq 0x1c410
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt -1
    // if/goto jeq 0x1c5ec
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt -1
    // if/goto jeq 0x1c7c8
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 39
    // locals stack 24
    // locals stack 28
    blackjack_OnDialogResponse();
    // locals stack 512
    return 1;
}

// AMX 0x1c8cc
stock InitPlayerLobby()
{
    // const.alt 182162180
    Streamer_SetIntData();
    BJSetPlayerCleanChat();
    // if/goto jump 117084
    // const.alt 12
    // locals stack 16
    // if/goto jump 117072
    // locals stack 4
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // const.alt 182118904
    floatcmp("", _push.s, _push, "", _push.s, _push, "", _push.s, _push, "", _push.s, _push, "", _push.s, _push, "", _push.s, _push, "", _push.s, _push, "", _push.s, _push, "l", _push.s, "", "", "", "", _push.s, "9ºàñ");
    // locals stack 12
    // const.alt 182119408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119408
    Streamer_SetIntData("", "", _push.s, _push.pri);
    // locals stack 16
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, _push.pri);
    // stor.s.pri -4
    // locals stack -96
    // locals stack 20
    // const.alt 182120408
    Streamer_SetIntData(_push.alt, "¼ý;", "ÄcÿM", "");
    // locals stack 12
    // const.alt 182120408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 16
    // locals stack 12
    HideHud();
    // if/goto jump 118144
    // const.alt 9816
    GetPlayerMenu("", "àñ", _push.s, "", _push.s, "", "l", _push.s, _push.pri);
    // stor.s.pri -104
    // const.alt 250
    // if/goto jeq 0x1cdf0
    // locals stack 16
    // if/goto jump 118140
    // locals stack 4
    // const.alt 182161676
    floatcmp("l", _push.s, _push.s, "");
    // const.alt -1
    // if/goto jeq 0x1d71c
    // locals stack -96
    // const.alt 182161676
    floatcmp("ÄcÿM");
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.pri);
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    // locals stack 12
    // locals stack -4
    // const.alt 182161676
    floatcmp("", _push.pri);
    // stor.s.pri -200
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, "ÄcÿM");
    floatadd(1, _push.pri);
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatadd(1, _push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // locals stack 100
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x1e050
    // locals stack -96
    // const.alt 182161676
    floatcmp("ÄcÿM", _push.pri);
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.pri, _push.pri);
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    // locals stack 12
    // locals stack -4
    // const.alt 182161676
    floatcmp("", _push.pri);
    // stor.s.pri -200
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, "ÄcÿM", _push.pri);
    floatadd(1, _push.pri);
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatadd(1, _push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // locals stack 100
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x1e984
    // locals stack -96
    // const.alt 182161676
    floatcmp("ÄcÿM", _push);
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.pri, _push);
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 34
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 34
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 34
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 34
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // locals stack -4
    // const.alt 182161676
    floatcmp("", _push.pri);
    // stor.s.pri -200
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, "ÄcÿM", _push);
    floatadd(1, _push.pri);
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatadd(1, _push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // locals stack 100
    // const.alt 182161676
    floatcmp("", _push.pri);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x1f2b8
    // locals stack -96
    // const.alt 182161676
    floatcmp("ÄcÿM");
    // locals stack 9
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    // stor.alt 34
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // stor.alt 34
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // stor.alt 34
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    // stor.alt 34
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    // stor.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    // stor.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    // stor.alt 9
    // locals stack 12
    // locals stack -4
    // const.alt 182161676
    floatcmp("", _push.pri);
    // locals stack 9
    // stor.s.pri -200
    // const.alt 44
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, "ÄcÿM");
    floatadd(1, _push.pri);
    // locals stack 12
    // const.alt 182122408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatadd(1, _push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // locals stack 100
    // locals stack 12
    // locals stack 100
    return 1;
}

// AMX 0x1f2fc
stock ExitPlayerLobby()
{
    // stor.alt 133
    // const.alt 39
    // locals stack 32
    // const.alt 182161676
    floatcmp("M", "", "tÖ", "");
    // if/goto jump 128200
    // const.alt 182161676
    floatcmp(-1);
    // if/goto jump 128200
    // const.alt 182161676
    floatcmp(-1, _push.pri);
    // if/goto jump 128200
    // const.alt 182161676
    floatcmp(-1, _push);
    // locals stack 34
    // if/goto jump 128200
}

// AMX 0x20f30
stock ExitPlayerLobbyTimer()
{
    // const.alt 182161676
    floatcmp();
    // if/goto jump 135336
    // const.alt 182161676
    floatcmp(-1);
    // if/goto jump 135336
    // const.alt 182161676
    floatcmp(-1, _push.pri);
    // if/goto jump 135336
    // const.alt 182161676
    floatcmp(-1, _push);
    // locals stack 34
    // if/goto jump 135336
}

// AMX 0x22b10
stock LoadBlackJack()
{
    // locals stack -512
    // if/goto jump 142168
    // const.alt 6
    // load.pri 45
    // locals stack 20
    // const.alt 182154408
    floatcmp(_push.alt, "¼ý;", "/", "", _push.alt, "");
    // const.alt 182154432
    floatcmp("", "	'Ì¹ÏX'", "	'Ì¹ÏX'", "", "", "", "", "", "", "", _push.pri);
    // const.alt 182154432
    floatcmp(_push.pri);
    // const.alt 182154432
    floatcmp(_push.pri);
    // locals stack 64
    // const.alt 182154528
    floatcmp("b*", "", _push.pri);
    // const.alt 182154432
    floatcmp("", "", "", "", "", _push.pri);
    // const.alt 182154432
    floatcmp(_push.pri);
    // const.alt 182154432
    floatcmp(_push.pri);
    // if/goto jgrtr 0x2c
    ReloadTable();
    LoadBJLobbyTimer();
    LoadBJLobbyPoint();
    LoadBJLobbyReady();
    LoadBJLobbyDealerCard();
    LoadBJTextBlackJack();
    LoadBJLobbyResult();
    LoadTextDrawBj();
    // locals stack 24
    // const.alt 182119048
    floatcmp("", "Äc÷ÄcÿM", "", "tÖ", "9ºàñ", "", "", "àñ", _push.s, "àñ", _push.s, "àñ", _push.s, "àñ", _push.s, "àñ", _push.s, "àñ", _push.s, "àñ", _push.s, _push.pri, "8", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri);
    // locals stack 16
    // const.alt 182118676
    floatcmp("", "", "l", "", "", "", _push.pri);
    // locals stack 16
    // const.alt 182118676
    floatcmp("ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("9ºàñ", "", _push.pri);
}

// AMX 0x23728
stock LoadBJLobbyTimer()
{
    // const.alt 182161676
    floatcmp();
    // const.alt 182118904
    floatcmp(60);
    // locals stack 16
    // const.alt 182118904
    floatcmp("", "", "l", "", "", "", _push.pri);
    // locals stack 16
    // const.alt 182118904
    floatcmp("ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182118904
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118904
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118904
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118904
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118904
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118904
    floatcmp("9ºàñ", "", _push.pri);
}

// AMX 0x23a00
stock LoadBJLobbyPoint()
{
    // const.alt 182119048
    floatcmp();
    // locals stack 16
    // const.alt 182119048
    floatcmp("", "", "l", "", "", "", _push.pri);
    // locals stack 16
    // const.alt 182119048
    floatcmp("ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("9ºàñ", "", _push.pri);
}

// AMX 0x24728
stock LoadBJLobbyReady()
{
    // const.alt 182118748
    floatcmp();
    // locals stack 16
    // const.alt 182118748
    floatcmp("", "", "l", "", "", "");
    // locals stack 16
    // const.alt 182118748
    floatcmp("ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("9ºàñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("9ºàñ", "", _push.pri);
}

// AMX 0x25498
stock LoadBJLobbyDealerCard()
{
    // const.alt 182119168
    floatcmp();
    // locals stack 16
    // const.alt 182119168
    floatcmp("", "", "l", "", "", "");
    // locals stack 16
    // const.alt 182119168
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182119168
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", _push.pri);
    // locals stack 16
    // const.alt 182119168
    floatcmp("", "", "l", "", "", "");
    // locals stack 16
    // const.alt 182119168
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182119168
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", _push.pri);
    // const.alt 36
    // locals stack 16
    // const.alt 182119168
    floatcmp("", "", "l", "", "", "");
    // const.alt 9
    // locals stack 16
    // const.alt 182119168
    floatcmp("", "", "l", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182119168
    floatcmp("9ºàñ", "l", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119168
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119168
    floatcmp("àñ", "", _push.pri);
    // const.alt 9
    // locals stack 12
    return 1;
}

// AMX 0x25db4
stock LoadBJTextBlackJack()
{
    // const.alt 182118928
    floatcmp();
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", "", "", "", _push.pri);
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182118928
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.pri);
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", "", "", "");
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182118928
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.pri);
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", "", "", "");
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182118928
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.pri);
    // const.alt 36
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", "", "", "");
    // const.alt 9
    // locals stack 16
    // const.alt 182118928
    floatcmp("", "", "l", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182118928
    floatcmp("9ºàñ", "l", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118928
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118928
    floatcmp("àñ", "", _push.pri);
    // const.alt 9
    // locals stack 12
    return 1;
}

// AMX 0x26994
stock LoadBJLobbyResult()
{
    // const.alt 182119288
    floatcmp();
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", "", "", "", _push.pri);
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182119288
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", _push.pri);
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", "", "", "");
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182119288
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", _push.pri);
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", "", "", "");
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", _push.pri);
    // locals stack 16
    // const.alt 182119288
    floatcmp("9ºàñ", "l", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("àñ", "", _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", _push.pri);
    // const.alt 36
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", "", "", "");
    // const.alt 9
    // locals stack 16
    // const.alt 182119288
    floatcmp("", "", "l", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182119288
    floatcmp("9ºàñ", "l", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119288
    floatcmp("", "", _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119288
    floatcmp("àñ", "", _push.pri);
    // const.alt 9
    // locals stack 12
    return 1;
}

// AMX 0x27574
stock ReloadTable()
{
    // const.alt 182161676
    floatcmp();
    // const.alt 182161676
    floatcmp(-1);
    // const.alt 182161676
    floatcmp(-1, _push.pri);
    // const.alt 182161676
    floatcmp(-1, _push);
    // locals stack 34
    return 1;
}

// AMX 0x27694
stock TimerSecondUpdateBJ()
{
    // const.alt 182161676
    floatcmp("");
    // const.alt -1
    // if/goto jeq 0x2770c
    // stor.s.pri -4
    // if/goto jump 161840
    // const.alt 182161676
    floatcmp(1);
    // const.alt -1
    // if/goto jeq 0x27770
    // stor.s.pri -4
    // if/goto jump 161840
    // const.alt 182161676
    floatcmp(1, _push.pri);
    // const.alt -1
    // if/goto jeq 0x277d4
    // stor.s.pri -4
    // if/goto jump 161840
    // const.alt 182161676
    floatcmp(1, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x27830
    // stor.s.pri -4
    // load.pri 53
    // const.alt 182161676
    floatcmp(1);
    // const.alt 182161676
    floatcmp(1);
    // if/goto jzer 0x37cc0
    // const.alt 182161676
    floatcmp();
    // const.alt 9
    // const.alt 182161676
    floatcmp();
    // const.alt -1
    // if/goto jeq 0x28588
    // if/goto jump 162160
    // const.alt 4
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "");
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri);
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri);
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri);
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // if/goto jump 162148
    // locals stack 4
    // const.alt 182161676
    floatcmp(_push, "", _push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push, "", _push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", _push.pri);
    Streamer_SetIntData();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", "", _push.pri);
    Streamer_SetIntData();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 16
    // const.alt 182118748
    floatcmp("l", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    // stor.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x283e0
    // const.alt 182119048
    floatcmp(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x284b4
    // const.alt 182119048
    floatcmp(_push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x28588
    // const.alt 182119048
    floatcmp();
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x29208
    // if/goto jump 165360
    // const.alt 4
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri);
    Streamer_SetIntData(_push.pri);
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri, _push.pri);
    Streamer_SetIntData(_push.pri);
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri, _push.pri);
    Streamer_SetIntData(_push.pri);
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri, _push.pri);
    Streamer_SetIntData(_push.pri);
    floatsub(_push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // if/goto jump 165348
    // locals stack 4
    // const.alt 182161676
    floatcmp(_push, "", _push.pri, _push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push, "", _push.pri, _push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", _push.pri, _push.pri);
    Streamer_SetIntData(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", "", _push.pri, _push.pri);
    Streamer_SetIntData(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 16
    // const.alt 182118748
    floatcmp("l", _push.pri, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri, _push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri, _push.pri);
    // stor.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x28fd4
    // const.alt 182119048
    floatcmp();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.pri, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x29134
    // const.alt 182119048
    floatcmp(_push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push.pri);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x29208
    // const.alt 182119048
    floatcmp();
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x29e88
    // if/goto jump 168560
    // const.alt 4
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push);
    Streamer_SetIntData(_push);
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri, _push);
    Streamer_SetIntData(_push);
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri, _push);
    Streamer_SetIntData(_push);
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri, _push);
    Streamer_SetIntData(_push);
    floatsub(_push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // if/goto jump 168548
    // locals stack 4
    // const.alt 182161676
    floatcmp(_push, "", _push.pri, _push);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push, "", _push.pri, _push);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", _push.pri, _push);
    Streamer_SetIntData(_push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", "", _push.pri, _push);
    Streamer_SetIntData(_push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 16
    // const.alt 182118748
    floatcmp("l", _push.pri, _push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri, _push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri, _push);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri, _push);
    // stor.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri, _push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri, _push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push);
    // const.alt -1
    // if/goto jeq 0x29c54
    // const.alt 182119048
    floatcmp();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push);
    // const.alt -1
    // if/goto jeq 0x29d28
    // const.alt 182119048
    floatcmp(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.pri, _push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x29e88
    // const.alt 182119048
    floatcmp();
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x2ab08
    // if/goto jump 171760
    // const.alt 4
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "");
    // locals stack 9
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri);
    // locals stack 9
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri);
    // locals stack 9
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182127408, "", _push.pri);
    // locals stack 9
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // if/goto jump 171748
    // locals stack 4
    // const.alt 182161676
    floatcmp(_push, "", _push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push, "", _push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", _push.pri);
    // locals stack 9
    Streamer_SetIntData();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, "", "", _push.pri);
    // locals stack 9
    Streamer_SetIntData();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 16
    // const.alt 182118748
    floatcmp("l", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182118748
    floatcmp("", _push.pri);
    // stor.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x2a8d4
    // const.alt 182119048
    floatcmp();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x2a9a8
    // const.alt 182119048
    floatcmp(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x2aa7c
    // const.alt 182119048
    floatcmp(_push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.pri);
    // const.alt 9
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt 36
    // const.alt 182161676
    floatcmp();
    // if/goto jump 228536
    // const.alt 182161676
    floatcmp();
    // const.alt 182161676
    floatcmp();
    // const.alt 39
    // locals stack 24
    // const.alt 182118676
    floatcmp("", "Äc÷ÄcÿM", "", "Ü@!", "");
    // locals stack 12
    // const.alt 182118676
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", "", _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", "", _push.pri);
    // locals stack 12
    // locals stack -4
    // locals stack 8
    // stor.s.pri -8
    // locals stack -4
    // locals stack 8
    // stor.s.pri -12
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", "", _push.pri);
    // stor.alt 36
    // const.alt 182154552
    GetPlayerName(_push.pri);
    floatadd(_push.pri);
    // const.alt 182154552
    GetPlayerName();
    floatadd(_push.pri);
    // const.alt 182119168
    floatcmp();
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x2b198
    // locals stack -8
    // const.alt 182161676
    floatcmp();
    // stor.alt 36
    // locals stack 20
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, _push.alt, "¼ý;", "ºàñ", "");
    Streamer_SetIntData();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 16
    // const.alt 182119168
    floatcmp("l", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // locals stack 8
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x2b3b0
    // locals stack -8
    // const.alt 182161676
    floatcmp(_push.pri);
    // stor.alt 36
    // locals stack 20
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, _push.alt, "¼ý;", "ºàñ", "");
    Streamer_SetIntData(_push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 16
    // const.alt 182119168
    floatcmp("l", _push.pri, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // locals stack 8
    // const.alt 182161676
    floatcmp("", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x2b5c8
    // locals stack -8
    // const.alt 182161676
    floatcmp(_push);
    // stor.alt 36
    // locals stack 20
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, _push.alt, "¼ý;", "ºàñ", "");
    Streamer_SetIntData(_push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 16
    // const.alt 182119168
    floatcmp("l", _push.pri, _push);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // locals stack 8
    // const.alt 182161676
    floatcmp("", _push.pri, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x2b7e0
    // locals stack -8
    // const.alt 182161676
    floatcmp();
    // stor.alt 36
    // locals stack 20
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, _push.alt, "¼ý;", "ºàñ", "");
    // locals stack 9
    Streamer_SetIntData();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 16
    // const.alt 182119168
    floatcmp("l", _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // locals stack 8
    // locals stack 8
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp("", _push.pri);
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp();
    // const.alt -1
    // if/goto jeq 0x2bc20
    // const.alt 182161676
    floatcmp();
    // locals stack -40
    // const.alt 182161676
    floatcmp(_push);
    // stor.alt 36
    // locals stack 20
    // const.alt 182161676
    floatcmp(_push.pri, 182121408, _push.alt, "¼ý;", "", "");
    Streamer_SetIntData();
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 16
    // locals stack -4
    // locals stack 8
    // stor.s.pri -48
    // locals stack -4
    // locals stack 8
    // stor.s.pri -52
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", "l", _push.pri);
    return 1;
    // const.alt 182154552
    GetPlayerName(_push.pri, _push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    return 1;
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 12
    ShowMembersCardBJL();
    // locals stack 48
    // if/goto jump 179300
    // const.alt 182161676
    floatcmp("Äc÷ÄcÿM", _push.s, "9ºàñ", "", _push.s, _push.s, "", _push.pri);
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp(5);
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp();
    // const.alt -1
    // if/goto jeq 0x2bf88
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack -40
    // locals stack -4
    // locals stack 8
    // stor.s.pri -48
    // locals stack -4
    // locals stack 8
    // stor.s.pri -52
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", _push);
    // if/goto jrel 36
    // const.alt 182154552
    GetPlayerName(_push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    // if/goto jrel 36
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "");
    // locals stack 12
    ShowMembersCardBJL();
    // locals stack 48
    // if/goto jump 180172
    // const.alt 182161676
    floatcmp("Äc÷ÄcÿM", _push.s, "ºàñ", "", _push.s, _push.s, "", _push.pri);
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp(7);
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp();
    // const.alt -1
    // if/goto jeq 0x2c2f0
    // const.alt 182161676
    floatcmp(_push);
    // locals stack -40
    // locals stack -4
    // locals stack 8
    // stor.s.pri -48
    // locals stack -4
    // locals stack 8
    // stor.s.pri -52
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", _push);
    // if/goto jneq 0x24
    // const.alt 182154552
    GetPlayerName(_push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    // if/goto jneq 0x24
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "");
    // locals stack 12
    ShowMembersCardBJL();
    // locals stack 48
    // if/goto jump 181044
    // const.alt 182161676
    floatcmp("Äc÷ÄcÿM", _push.s, "àñ", "", _push.s, _push.s, "", _push.pri);
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp(9);
    // if/goto jump 182000
    // const.alt 182161676
    floatcmp();
    // const.alt 182161676
    floatcmp(1);
    // const.alt 36
    // const.alt 182161676
    floatcmp();
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x2c694
    // locals stack -40
    // locals stack -4
    // locals stack 8
    // stor.s.pri -48
    // locals stack -4
    // locals stack 8
    // stor.s.pri -52
    // const.alt 182161676
    floatcmp("àñ", "àñ", "àñ", "", _push);
    // if/goto jgeq 0x24
    // const.alt 182154552
    GetPlayerName(_push.pri);
    floatadd(_push.pri);
    // const.alt 182161676
    floatcmp();
    // if/goto jgeq 0x24
    // locals stack 20
    // const.alt 182119048
    floatcmp(_push.alt, "¼ý;", "", "");
    // const.alt 9
    // locals stack 12
    ShowMembersCardBJL();
    // locals stack 48
    // if/goto jump 182000
}

// AMX 0x39d60
stock TimerDealerNext()
{
    // const.alt 182161676
    floatcmp();
    return 1;
}

// AMX 0x39db4
stock TimerHideBetText()
{
    // locals stack 12
    // locals stack 12
    return 1;
}

// AMX 0x39e34
stock TimerHideYouTurn()
{
    // const.alt 182153408
    Streamer_SetIntData();
    // locals stack 12
    return 1;
}

// AMX 0x39e88
stock BJAdvanceTurnIfCurrent()
{
    // const.alt 182161676
    floatcmp();
    // const.alt 182162180
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0x39fd8
    // const.alt 182153408
    Streamer_SetIntData();
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.s, _push.pri);
    // const.alt 182161676
    floatcmp();
    return 1;
}

// AMX 0x39fe0
stock BJNotifyWin()
{
    // if/goto jnz 0x3a02c
    // if/goto jump 237620
    // if/goto jzer 0x3a04c
    return 1;
    // locals stack -384
    // stor.alt 39
    // locals stack 20
    ShowNotificationNew();
    // locals stack 384
    return 1;
}

// AMX 0x3a10c
stock BJUpdateMoneyLabel()
{
    // if/goto jzer 0x3a140
    return 1;
    // locals stack -96
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 20
    // const.alt 182120408
    Streamer_SetIntData(_push.alt, "¼ý;", "ÄcÿM", "", _push.pri);
    // locals stack 16
    // locals stack 96
    return 1;
}

// AMX 0x3a22c
stock BJResetRoundPlayer()
{
    // if/goto jzer 0x3a260
    return 1;
    // const.alt 182162180
    Streamer_SetIntData();
    // const.alt 34
    // const.alt 182162180
    Streamer_SetIntData();
    // const.alt 182119408
    Streamer_SetIntData("");
    // locals stack 16
    // const.alt 182121408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    BJUpdateMoneyLabel();
    // const.alt 182153408
    Streamer_SetIntData("àñ", _push.s, "l", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182153408
    Streamer_SetIntData("", "", _push.s, _push.pri);
    // locals stack 16
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.s, _push, "l", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119168
    floatcmp("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119288
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119288
    floatcmp("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182119048
    floatcmp("", _push.s, _push.pri);
    // const.alt 9
    // locals stack 12
    // if/goto jump 240236
    // const.alt 4
    // const.alt 182127408
    Streamer_SetIntData("9ºàñ", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // const.alt 9
    // locals stack 12
    // const.alt 182127408
    Streamer_SetIntData("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 16
    // const.alt 182127408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    floatsub(_push.pri);
    // const.alt 9
    // locals stack 16
    // if/goto jump 240224
    // locals stack 4
    // const.alt 182162180
    Streamer_SetIntData("l", _push.s, _push.pri);
    InitPlayerLobby();
    return 1;
}

// AMX 0x3af30
stock SCMBJL()
{
    // const.alt 182161676
    floatcmp();
    // const.alt -1
    // if/goto jeq 0x3afe4
    // const.alt 182161676
    floatcmp(_push.s, _push.s);
    // locals stack 16
    // const.alt 182161676
    floatcmp("l", _push.pri);
    // const.alt -1
    // if/goto jeq 0x3b090
    // const.alt 182161676
    floatcmp(_push.s, _push.s, _push.pri);
    // locals stack 16
    // const.alt 182161676
    floatcmp("l", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x3b13c
    // const.alt 182161676
    floatcmp(_push.s, _push.s, _push);
    // locals stack 16
    // const.alt 182161676
    floatcmp("l", _push.pri, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x3b1e8
    // const.alt 182161676
    floatcmp(_push.s, _push.s);
    // locals stack 9
    // locals stack 16
    return 1;
}

// AMX 0x3b1f0
stock SnowNotificarionBJL()
{
    // const.alt 182161676
    floatcmp();
    // const.alt -1
    // if/goto jeq 0x3b32c
    // const.alt 182161676
    floatcmp(_push.s, "ñ", "9ºàñ", "9ºàñ", _push.s, "");
    ShowNewNotification();
    // const.alt 182161676
    floatcmp(_push.s, _push.s, "ñ", "", "", "M", _push.pri);
    ShowNotification();
    // const.alt 182161676
    floatcmp("ÄcÿM", _push.pri);
    // const.alt -1
    // if/goto jeq 0x3b460
    // const.alt 182161676
    floatcmp(_push.s, "ñ", "9ºàñ", "9ºàñ", _push.s, "", _push.pri);
    ShowNewNotification();
    // const.alt 182161676
    floatcmp(_push.s, _push.s, "ñ", "", "", "M", _push.pri, _push.pri);
    ShowNotification();
    // const.alt 182161676
    floatcmp("ÄcÿM", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x3b594
    // const.alt 182161676
    floatcmp(_push.s, "ñ", "9ºàñ", "9ºàñ", _push.s, "", _push);
    ShowNewNotification();
    // const.alt 182161676
    floatcmp(_push.s, _push.s, "ñ", "", "", "M", _push.pri, _push);
    ShowNotification();
    // const.alt 182161676
    floatcmp("ÄcÿM", _push.pri, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x3b6c8
    // const.alt 182161676
    floatcmp(_push.s, "ñ", "9ºàñ", "9ºàñ", _push.s, "");
    // locals stack 9
    ShowNewNotification();
    // const.alt 182161676
    floatcmp(_push.s, _push.s, "ñ", "", "", "M", _push.pri);
    // locals stack 9
    ShowNotification();
    return 1;
}

// AMX 0x3b6d0
stock CheckTableBlackJack()
{
    // const.alt 182161676
    floatcmp();
    return 1;
    // const.alt 182161676
    floatcmp(_push.s);
    GiveTableBlackJack();
    // if/goto jump 243764
    // const.alt 182161676
    floatcmp("l", _push.s, _push.pri);
    return 1;
    // const.alt 21
    // const.alt 182161676
    floatcmp();
    GiveTableLose();
    // if/goto jump 244824
    // const.alt 182161676
    floatcmp("", _push.s, _push.pri);
    // if/goto jrel 9
    // const.alt 182161676
    floatcmp(_push.s);
    GiveTableBlackJack();
    // if/goto jump 244100
    // const.alt 182161676
    floatcmp("l", _push.s, _push.pri, _push.pri);
    // if/goto jrel 9
    // const.alt 21
    // const.alt 182161676
    floatcmp();
    GiveTableLose();
    // if/goto jump 244824
    // const.alt 182161676
    floatcmp("", _push.s, _push.pri, _push.pri);
    // if/goto jneq 0x9
    // const.alt 182161676
    floatcmp(_push.s);
    GiveTableBlackJack();
    // if/goto jump 244436
    // const.alt 182161676
    floatcmp("l", _push.s, _push.pri, _push);
    // if/goto jneq 0x9
    // const.alt 21
    // const.alt 182161676
    floatcmp();
    GiveTableLose();
    // if/goto jump 244824
    // const.alt 182161676
    floatcmp("", _push.s, _push.pri, _push);
    // if/goto jgeq 0x9
    // const.alt 182161676
    floatcmp(_push.s);
    // locals stack 9
    GiveTableBlackJack();
    // if/goto jump 244772
    // const.alt 182161676
    floatcmp("l", _push.s, _push.pri);
    // if/goto jgeq 0x9
    // const.alt 21
    // const.alt 182161676
    floatcmp();
    // locals stack 9
    GiveTableLose();
    // if/goto jump 244824
}

// AMX 0x3bc60
stock GiveTableBlackJack()
{
    // const.alt 182161676
    floatcmp();
    // const.alt -1
    // if/goto jeq 0x3bd5c
    // const.alt 182118928
    floatcmp();
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.pri);
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri);
    // const.alt -1
    // if/goto jeq 0x3befc
    // const.alt 182118928
    floatcmp(_push.pri);
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.pri, _push.pri);
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push.pri);
    // const.alt -1
    // if/goto jeq 0x3c09c
    // const.alt 182118928
    floatcmp(_push);
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.pri, _push);
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.pri, _push);
    // locals stack 9
    // const.alt -1
    // if/goto jeq 0x3c23c
    // const.alt 182118928
    floatcmp();
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182118928
    floatcmp("", _push.pri);
    floatadd(1, _push.pri);
    // const.alt 182161676
    floatcmp(_push.pri);
    // locals stack 9
    // locals stack 12
    // const.alt 182153408
    Streamer_SetIntData("", "", _push.pri);
    // locals stack 16
    // const.alt 182153408
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 12
    // const.alt 182161676
    floatcmp("", _push.s, _push.pri);
    // const.alt 182161676
    floatcmp();
    return 1;
}

// AMX 0x3c408
stock GiveTableLose()
{
    // locals stack -128
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 20
    SCMBJL();
    // locals stack 128
    return 1;
}

// AMX 0x3c4d4
stock ShowMembersCardBJL()
{
    // const.alt 182161676
    floatcmp("");
    // stor.s.pri -4
    // if/goto jump 247368
    // const.alt 182161676
    floatcmp();
    // stor.s.pri -4
    // if/goto jump 247368
    // const.alt 182161676
    floatcmp(_push.pri);
    // stor.s.pri -4
    // if/goto jump 247368
    // const.alt 182161676
    floatcmp(_push);
    // locals stack 9
    // stor.s.pri -4
    // if/goto jump 247368
}

// AMX 0x3d6a0
stock LoadTextDrawBj()
{
    // locals stack 16
    // stor.pri 182118644
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.pri 182118656
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.pri 182118648
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.pri 182118652
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.pri 182118660
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.pri 182118664
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.pri 182118668
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.pri 182118672
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
}

// AMX 0x3e984
stock LoadPlayerTextDraw()
{
    // const.alt 182119408
    Streamer_SetIntData();
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 182119408
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 182119408
    Streamer_SetIntData("9ºàñ", "¼ý;", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182119408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182119408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182119408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182119408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182119408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182119408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // stor.alt 137
    // const.alt 182120408
    Streamer_SetIntData("l", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 182120408
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 182120408
    Streamer_SetIntData("9ºàñ", "¼ý;", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182120408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182120408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182120408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182120408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182120408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182120408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // stor.alt 137
    // const.alt 182121408
    Streamer_SetIntData("l", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 182121408
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 182121408
    Streamer_SetIntData("ºàñ", "¼ý;", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182121408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182121408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182121408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182121408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182121408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182121408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 182122408
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "¼ý;", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "");
    // const.alt 182122408
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "¼ý;", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "");
    // const.alt 182122408
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "¼ý;", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // stor.alt 137
    // const.alt 182122408
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 36
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "");
    // const.alt 182122408
    Streamer_SetIntData("", "");
    // const.alt 9
    // locals stack 20
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "¼ý;", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 182122408
    Streamer_SetIntData("9ºàñ", "l", _push.s, _push.pri);
    // const.alt 9
    // stor.alt 137
    // const.alt 182127408
    Streamer_SetIntData("l", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 182127408
    Streamer_SetIntData("", "");
    // locals stack 20
    // const.alt 182127408
    Streamer_SetIntData("", "", "¼ý;", _push.s, _push.pri);
}

// AMX 0x43ff8
stock GivePlayerMoneyBjEx()
{
    // const.alt 181530104
    Streamer_SetIntData();
    // if/goto jump 278648
    // if/goto jzer 0x44090
    return 1;
    // locals stack -740
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 12
    // stor.alt 89
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "l", _push.alt, _push.alt, _push.alt, _push.s, "", _push.s, _push.s, _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // locals stack 36
    // locals stack 16
    // if/goto jzer 0x44354
    // const.alt 181530104
    Streamer_SetIntData("l", _push, "", _push.alt, "8", "5", "", _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // locals stack 24
    // locals stack 16
    // if/goto jzer 0x4454c
    // locals stack -128
    // stor.alt 39
    // locals stack 20
    ShowNewNotification();
    ShowNotification();
    // if/goto jump 279876
    // stor.alt 39
    // locals stack 20
    ShowNewNotification();
    ShowNotification();
    // locals stack 128
    // locals stack 740
    return 1;
}

// AMX 0x44564
public OnPlayerEnterDynamicArea()
{
    // if/goto jump 279948
    // const.alt 6
    // const.alt 182154528
    floatcmp(_push.pri, "");
    // if/goto jneq 0x44678
    ShowNotification();
    ShowNewNotification();
    // if/goto jump 280192
    // if/goto jump 279936
    // locals stack 4
    blackjack_OnPlayerEnterDynamicA();
    return 1;
}

// AMX 0x446b0
stock n_veh_OnGameModeInit()
{
    LoadBlackJack();
    blackjack_OnGameModeInit();
    return 1;
}

// AMX 0x446e4
stock fixp_OnPlayerConnect()
{
    LoadPlayerTextDraw();
    // if/goto jump 280360
    // const.alt 6
    // const.alt 182118676
    floatcmp("", "àñ", _push.s);
    // locals stack 12
    // const.alt 182118676
    floatcmp("", _push.s, _push.pri);
    // locals stack 12
    // if/goto jump 280348
    // locals stack 4
    blackjack_OnPlayerConnect();
    return 1;
}

// AMX 0x44820
stock pc_cmd_blackjack()
{
    // const.alt 182162180
    Streamer_SetIntData();
    // if/goto jnz 0x45130
    // if/goto jump 280716
    // const.alt 6
    // const.alt 182154432
    floatcmp("", "");
    // const.alt 182154432
    floatcmp(_push.pri);
    // const.alt 182154432
    floatcmp(_push.pri);
    // if/goto jnz 0x2c
    // stor.s.pri -4
    // const.alt 182161676
    floatcmp(1, "Äc÷ÄcÿM", _push.s, "", _push.pri);
    // if/goto jnz 0x45088
    // const.alt 182161676
    floatcmp();
    // if/goto jzer 0x44b6c
    // const.alt 182161676
    floatcmp();
    // const.alt 182162180
    Streamer_SetIntData();
    // const.alt 182162180
    Streamer_SetIntData(1);
    // const.alt 182162180
    Streamer_SetIntData();
    // stor.alt 34
    HideHud();
    InitPlayerLobby();
    // if/goto jump 282752
    // const.alt 182161676
    floatcmp("l", _push.s, _push.s, "9ºàñ", "àñ", _push.s, 1);
    // if/goto jzer 0x44d0c
    // const.alt 182161676
    floatcmp(_push.pri);
    // const.alt 182162180
    Streamer_SetIntData(_push.pri);
    // const.alt 182162180
    Streamer_SetIntData(1);
    // const.alt 182162180
    Streamer_SetIntData();
    // stor.alt 34
    HideHud();
    InitPlayerLobby();
    // if/goto jump 282752
    // const.alt 182161676
    floatcmp("l", _push.s, _push.s, "ºàñ", "àñ", _push.s, 2);
    // if/goto jzer 0x44eac
    // const.alt 182161676
    floatcmp(_push);
    // const.alt 182162180
    Streamer_SetIntData(_push);
    // const.alt 182162180
    Streamer_SetIntData(1);
    // const.alt 182162180
    Streamer_SetIntData();
    // stor.alt 34
    HideHud();
    InitPlayerLobby();
    // if/goto jump 282752
    // const.alt 182161676
    floatcmp("l", _push.s, _push.s, "àñ", "àñ", _push.s, 3);
    // locals stack 9
    // if/goto jzer 0x4504c
    // const.alt 182161676
    floatcmp();
    // locals stack 34
    // const.alt 182162180
    Streamer_SetIntData();
    // const.alt 182162180
    Streamer_SetIntData(1);
    // const.alt 182162180
    Streamer_SetIntData();
    // stor.alt 34
    HideHud();
    InitPlayerLobby();
    // if/goto jump 282752
    // locals stack 16
    // if/goto jump 282812
    // locals stack 16
    // if/goto jump 282832
    // if/goto jump 280704
    // if/goto jump 280704
    // locals stack 4
    // if/goto jnz 0x45128
    // locals stack 16
    // locals stack 4
    return 1;
}

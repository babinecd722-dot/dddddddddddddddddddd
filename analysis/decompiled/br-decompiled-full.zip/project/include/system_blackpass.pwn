// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_blackpass.pwn
// Functions: 76

// AMX 0x355658
stock BlackPass_LogEvent()
{
    // if/goto jnz 0x3556dc
    // const.alt 181530104
    Streamer_SetIntData("àñ", _push.s);
    // if/goto jnz 0x3556dc
    // if/goto jump 3495652
    // if/goto jzer 0x3556f8
    return 1;
    // locals stack -2048
    // stor.alt 11
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, _push.pri);
    // locals stack 52
    // locals stack 16
    // locals stack 2048
    return 1;
}

// AMX 0x35581c
stock BlackPass_ResetPlayer()
{
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData(-1);
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 34
    // const.alt 229523480
    Streamer_SetIntData(1);
    // stor.alt 34
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // if/goto jump 3496516
    // const.alt 61
    // const.alt 229532480
    Streamer_SetIntData("");
    DestroyPickup(_push.pri);
    // const.alt 229595480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    // if/goto jump 3496504
    // locals stack 4
    // const.alt 229759124
    Streamer_SetIntData();
    // const.alt 229760124
    Streamer_SetIntData();
    // const.alt 229761124
    Streamer_SetIntData();
    // const.alt 229762124
    Streamer_SetIntData();
    // const.alt 229763124
    Streamer_SetIntData();
    // const.alt 229764124
    Streamer_SetIntData();
    // if/goto jump 3497020
    // const.alt 11
    // const.alt 229659124
    Streamer_SetIntData("");
    IsPlayerConnected(_push.pri);
    // locals stack -4
    // const.alt 229659080
    IsPlayerConnected();
    // stor.s.pri -8
    // locals stack -4
    BlackPass_FindTaskDefIndex();
    // stor.s.pri -12
    // const.alt 229659124
    Streamer_SetIntData("àñ", _push.s);
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x355e2c
    // const.alt 6
    // if/goto jump 3497508
    // if/goto jump 3497568
    // const.alt 229658480
    SSCANF_Join(2, 1);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 34
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 34
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // locals stack 8
    // if/goto jump 3497008
    // locals stack 4
    return 1;
}

// AMX 0x356098
stock BlackPass_GetLevelFromExperienc()
{
    // locals stack -4
    // load.pri 17
    // const.alt 1
    // stor.s.pri -4
    // const.alt 61
    // stor.s.pri -4
    // locals stack 4
    return 1;
}

// AMX 0x356148
stock BlackPass_GetMaxExperience()
{
    return 1;
}

// AMX 0x356160
stock BlackPass_BuildClaimFlagsString()
{
    // if/goto jump 3498400
    // const.alt 61
    // locals stack -8
    // if/goto jzer 0x356248
    // const.alt 229595480
    Streamer_SetIntData(_push.pri, "9ºàñ");
    DestroyPickup(_push.pri);
    // if/goto jump 3498640
    // const.alt 229532480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    // if/goto jzer 0x3562a8
    // if/goto jump 3498672
    // stor.alt 44
    // locals stack 4
    return 1;
}

// AMX 0x356334
stock BlackPass_ParseClaimFlagsString()
{
    // if/goto jump 3498844
    // const.alt 61
    // locals stack -4
    // locals stack 8
    func_0x35();
    // if/goto jump 3499032
    // stor.s.pri -8
    // if/goto jzer 0x356494
    // const.alt 229595480
    Streamer_SetIntData(1, 1, _push.pri, "àñ", _push.s, _push.pri, 1, "9ºàñ");
    DestroyPickup(_push.pri);
    // if/goto jump 3499244
    // const.alt 229532480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    // locals stack 4
    // if/goto jump 3498832
    // locals stack 4
    return 1;
}

// AMX 0x356514
stock BlackPass_GetCurrentLevel()
{
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 36
    // const.alt 229523480
    Streamer_SetIntData();
    BlackPass_GetLevelFromExperienc();
    // const.alt 229523480
    Streamer_SetIntData("àñ", _push.pri);
    // const.alt 9
    return 1;
}

// AMX 0x3565e0
stock BlackPass_GetClientPremiumStatu()
{
    return 1;
    // if/goto jump 3499592
    return 1;
    // if/goto jump 3499592
}

// AMX 0x356654
stock BlackPass_GetRewardInventoryIte()
{
    // if/goto jzer 0x356680
    // if/goto jump 3499656
    return 1;
}

// AMX 0x356698
stock BlackPass_GetDeluxeInventoryIte()
{
    return 1;
}

// AMX 0x3566b8
stock BlackPass_IsRewardInventoryItem()
{
    // const.alt 1001
    // const.alt 1061
    // if/goto jump 3499784
    // if/goto jzer 0x356720
    return 1;
    // const.alt 2001
    // const.alt 2061
    // if/goto jump 3499880
    // if/goto jzer 0x356780
    return 1;
    // const.alt 3001
    // const.alt 3004
    // if/goto jump 3499976
    // if/goto jzer 0x3567e0
    return 1;
}

// AMX 0x3567ec
stock BlackPass_GetRewardInventoryDat()
{
    // const.alt 1001
    // const.alt 1061
    // if/goto jump 3500196
    // if/goto jzer 0x356ad0
    // locals stack -4
    // stor.s.pri -4
    // if/goto jzer 0x356abc
    // const.alt 229766612
    DestroyPickup(61, _push.pri, 1, 1000, 1);
    // locals stack 20
    // const.alt 229765124
    DestroyPickup(_push.alt, "¼ý;", _push.s, _push.s, "", _push.pri);
    // const.alt 229765124
    DestroyPickup();
    // const.alt 229765124
    DestroyPickup();
    // const.alt 229765124
    DestroyPickup();
    // const.alt 9
    // const.alt 229765124
    DestroyPickup();
    // stor.alt 9
    // locals stack 4
    return 1;
    // locals stack 4
    return 1;
    // const.alt 2001
    // const.alt 2061
    // if/goto jump 3500824
    // if/goto jzer 0x356d44
    // locals stack -4
    // stor.s.pri -4
    // if/goto jzer 0x356d30
    // const.alt 229784220
    DestroyPickup(61, _push.pri, 1, 2000, 1);
    // locals stack 20
    // const.alt 229782732
    DestroyPickup(_push.alt, "¼ý;", _push.s, _push.s, "", _push.pri);
    // const.alt 229782732
    DestroyPickup();
    // const.alt 229782732
    DestroyPickup();
    // const.alt 229782732
    DestroyPickup();
    // const.alt 9
    // const.alt 229782732
    DestroyPickup();
    // stor.alt 9
    // locals stack 4
    return 1;
    // locals stack 4
    return 1;
    // const.alt 3001
    // const.alt 3004
    // if/goto jump 3501452
    // if/goto jzer 0x356fac
    // locals stack -4
    // stor.s.pri -4
    // if/goto jzer 0x356fa4
    // const.alt 229800460
    floatsub(4, _push.pri, 1, 3000, 1);
    // locals stack 20
    // const.alt 229800340
    floatsub(_push.alt, "¼ý;", _push.s, _push.s, "", _push.pri);
    // const.alt 229800340
    floatsub();
    // const.alt 229800340
    floatsub();
    // const.alt 229800340
    floatsub();
    // const.alt 9
    // const.alt 229800340
    floatsub();
    // stor.alt 9
    // locals stack 4
    return 1;
    // locals stack 4
    return 1;
}

// AMX 0x356fb8
stock BlackPass_HasQueuedReward()
{
    // if/goto jump 3502048
    // const.alt 178454104
    Streamer_SetIntData(_push.pri, "");
    // const.alt 174453104
    Streamer_SetIntData();
    native#999(_push.pri);
    // if/goto jzer 0x3570fc
    // const.alt 174453104
    Streamer_SetIntData();
    native#999(_push.pri);
    // if/goto jneq 0x3570fc
    // if/goto jump 3502336
    // if/goto jzer 0x357120
    // locals stack 4
    return 1;
    // if/goto jump 3502036
    // locals stack 4
    return 1;
}

// AMX 0x35713c
stock BlackPass_QueueInventoryReward()
{
    BlackPass_IsRewardInventoryItem();
    // if/goto jzer 0x357178
    return 1;
    BlackPass_HasQueuedReward();
    // if/goto jzer 0x3571b4
    return 1;
    // const.alt 178454104
    Streamer_SetIntData();
    // const.alt 1000
    // stor.alt 133
    // const.alt 39
    // locals stack 16
    return 1;
    // stor.alt 133
    // const.alt 39
    // locals stack 16
    // locals stack -4
    // const.alt 178454104
    Streamer_SetIntData("l");
    // stor.s.pri -4
    // const.alt 174453104
    Streamer_SetIntData();
    native#999(_push.pri);
    // const.alt 174453104
    Streamer_SetIntData(99);
    native#999(_push.pri);
    // const.alt 174453104
    Streamer_SetIntData();
    native#999(_push.pri);
    // const.alt 178454104
    Streamer_SetIntData();
    SavePlayerCaseRewardDB();
    // locals stack 4
    return 1;
}

// AMX 0x357440
stock BlackPass_QueueLevelReward()
{
    // const.alt 1
    // const.alt 61
    // if/goto jump 3503248
    // if/goto jzer 0x3574a4
    return 1;
    BlackPass_GetRewardInventoryIte();
    BlackPass_QueueInventoryReward();
    return 1;
}

// AMX 0x3574e8
stock BlackPass_QueueDeluxeRewards()
{
    // if/goto jump 3503376
    // const.alt 4
    // if/goto jzer 0x357564
    // if/goto jump 3503464
    // if/goto jzer 0x35757c
    // if/goto jump 3503364
    BlackPass_GetDeluxeInventoryIte();
    BlackPass_QueueInventoryReward();
    // if/goto jump 3503364
    // locals stack 4
    return 1;
}

// AMX 0x3575d4
stock BlackPass_ShowLootNotification()
{
    ShowClientNotification();
    return 1;
}

// AMX 0x357630
stock BlackPass_SendLayoutPacket()
{
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    BlackPass_SendMainPacket();
    // if/goto jrel 44
    // const.alt 137
    func_0xcd48();
    // locals stack 4
    return 1;
}

// AMX 0x357700
stock BlackPass_SendStateRefresh()
{
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    BlackPass_FillBasePacket();
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.s, "l", _push.s, "", "", "l", _push.s, "", "", "", _push.s, _push.s, "");
    // const.alt 9
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.alt, 1000);
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri, "àñ", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // locals stack 16
    // const.alt 229532480
    Streamer_SetIntData("l", _push.s, "", _push.s, "l", _push.s, "", _push.pri);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x357ab0
    // if/goto jump 3504824
    // locals stack 16
    // const.alt 229595480
    Streamer_SetIntData("l", _push.s, "", _push.pri, 1);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x357b54
    // if/goto jump 3504988
    // locals stack 16
    OnPacketIncoming();
    // if/goto jrel 44
    // const.alt 137
    func_0xcd48();
    // locals stack 4
    return 1;
}

// AMX 0x357c24
stock BlackPass_AutoClaimRewardsRange()
{
    // const.alt 1
    // stor.s.pri 16
    // const.alt 61
    // stor.s.pri 20
    return 1;
    // locals stack -4
    // stor.s.pri -4
    // if/goto jump 3505380
    // if/goto jzer 0x357d74
    // const.alt 229532480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    // if/goto jzer 0x357d74
    // if/goto jump 3505528
    // if/goto jzer 0x357e04
    // const.alt 229532480
    Streamer_SetIntData(1);
    DestroyPickup(_push.pri);
    BlackPass_QueueLevelReward();
    // if/goto jzer 0x357e7c
    // const.alt 229595480
    Streamer_SetIntData("l", _push.s, _push.s, "", 1);
    DestroyPickup(_push.pri);
    // if/goto jzer 0x357e7c
    // if/goto jump 3505792
    // if/goto jzer 0x357f0c
    // const.alt 229595480
    Streamer_SetIntData(1);
    DestroyPickup(_push.pri);
    BlackPass_QueueLevelReward();
    // if/goto jump 3505368
    // locals stack 4
    return 1;
}

// AMX 0x357f2c
stock BlackPass_GrantExperience()
{
    // const.alt 229523480
    Streamer_SetIntData();
    // if/goto jzer 0x357fa4
    BlackPass_LoadPlayer();
    // if/goto jzer 0x357fa4
    return 1;
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    BlackPass_GetMaxExperience();
    // const.alt 229523480
    Streamer_SetIntData("", _push.pri);
    BlackPass_GetMaxExperience();
    // const.alt 229523480
    Streamer_SetIntData("");
    // const.alt 36
    // const.alt 229523480
    Streamer_SetIntData();
    BlackPass_GetLevelFromExperienc();
    BlackPass_SavePlayer();
    return 1;
}

// AMX 0x3581d8
stock BlackPass_SetLevelWithReset()
{
    // const.alt 229523480
    Streamer_SetIntData();
    // if/goto jzer 0x358250
    BlackPass_LoadPlayer();
    // if/goto jzer 0x358250
    return 1;
    // const.alt 1
    // stor.s.pri 16
    // const.alt 61
    // stor.s.pri 16
    // const.alt 229523480
    Streamer_SetIntData(61, 1);
    // const.alt 34
    // const.alt 229523480
    Streamer_SetIntData();
    BlackPass_SavePlayer();
    return 1;
}

// AMX 0x35837c
stock BlackPass_AddLevelsWithReset()
{
    BlackPass_GetCurrentLevel();
    return 1;
    // locals stack -4
    BlackPass_GetCurrentLevel();
    // stor.s.pri -4
    // locals stack -4
    // stor.s.pri -8
    // const.alt 61
    // stor.s.pri -8
    BlackPass_SetLevelWithReset();
    BlackPass_GetCurrentLevel();
    // locals stack 8
    return 1;
}

// AMX 0x358490
stock BlackPass_SendLevelSyncPacket()
{
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    // if/goto jzer 0x358504
    BlackPass_GetCurrentLevel();
    // stor.s.pri 16
    // if/goto jzer 0x358574
    // const.alt 229523480
    Streamer_SetIntData("àñ", _push.s, "");
    // stor.s.pri 20
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    // if/goto jrel 44
    // const.alt 137
    func_0xcd48();
    // locals stack 4
    return 1;
}

// AMX 0x358714
stock BlackPass_SendLevelSyncRange()
{
    BlackPass_SendLevelSyncPacket();
    return 1;
    // locals stack -4
    // load.pri 17
    // if/goto jump 3508128
    // if/goto jneq 0x358824
    // const.alt 229523480
    Streamer_SetIntData();
    // if/goto jump 3508264
    BlackPass_SendLevelSyncPacket();
    // if/goto jump 3508116
    // locals stack 4
    return 1;
}

// AMX 0x35886c
stock BlackPass_SavePlayer()
{
    // const.alt 229523480
    Streamer_SetIntData();
    // if/goto jzer 0x3588bc
    return 1;
    // locals stack -248
    // locals stack -248
    // locals stack -4096
    BlackPass_BuildClaimFlagsString();
    BlackPass_BuildClaimFlagsString();
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, 28, "¼ý;", _push.s, "9ºàñ", "", "¼ý;", _push.s, "", "");
    // const.alt 229523480
    Streamer_SetIntData(_push.pri);
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // stor.alt 36
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 36
    // const.alt 229523480
    Streamer_SetIntData();
    // locals stack 60
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push, "", "hY", _push, "ØÉ", "");
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    // stor.alt 36
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 36
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 39
    // locals stack 40
    // locals stack 4592
    return 1;
}

// AMX 0x358d30
stock BlackPass_SendRewardClaimPacket()
{
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // if/goto jzer 0x358e8c
    // if/goto jump 3509904
    // locals stack 16
    OnPacketIncoming();
    // if/goto jrel 44
    // const.alt 137
    func_0xcd48();
    // locals stack 4
    return 1;
}

// AMX 0x358f58
stock BlackPass_SendClaimPacketsRange()
{
    // const.alt 1
    // stor.s.pri 16
    // const.alt 61
    // stor.s.pri 20
    return 1;
    // locals stack -4
    // stor.s.pri -4
    // if/goto jump 3510296
    // if/goto jzer 0x3590a4
    // const.alt 229532480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    // if/goto jzer 0x3590a4
    // if/goto jump 3510440
    // if/goto jzer 0x3590e4
    BlackPass_SendRewardClaimPacket();
    // if/goto jzer 0x359158
    // const.alt 229595480
    Streamer_SetIntData("¼ý;", _push.s, _push.s, "", _push.s, 1);
    DestroyPickup(_push.pri);
    // if/goto jzer 0x359158
    // if/goto jump 3510620
    // if/goto jzer 0x359198
    BlackPass_SendRewardClaimPacket();
    // if/goto jump 3510284
    // locals stack 4
    return 1;
}

// AMX 0x3591b8
stock BlackPass_SendAutoClaimSyncRang()
{
    return 1;
    // locals stack -4
    // load.pri 17
    // if/goto jump 3510816
    // if/goto jneq 0x3592a4
    // const.alt 229523480
    Streamer_SetIntData();
    // if/goto jump 3510952
    BlackPass_SendLevelSyncPacket();
    // if/goto jzer 0x359340
    // const.alt 229532480
    Streamer_SetIntData("l", _push.s, _push.s, _push.pri, 1000);
    DestroyPickup(_push.pri);
    // if/goto jzer 0x359340
    // if/goto jump 3511108
    // if/goto jzer 0x359380
    BlackPass_SendRewardClaimPacket();
    // if/goto jzer 0x3593f4
    // const.alt 229595480
    Streamer_SetIntData("¼ý;", _push.s, _push.s, "", _push.s, 1);
    DestroyPickup(_push.pri);
    // if/goto jzer 0x3593f4
    // if/goto jump 3511288
    // if/goto jzer 0x359434
    BlackPass_SendRewardClaimPacket();
    // if/goto jump 3510804
    // locals stack 4
    return 1;
}

// AMX 0x359454
stock BlackPass_LoadPlayer()
{
    BlackPass_ResetPlayer();
    // locals stack -1024
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, 28, "àñ", _push.s);
    // locals stack 28
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1028
    // locals stack 8
    // if/goto jzer 0x359668
    // locals stack 8
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "àñ", "9ºàñ", "àñ", "9ºàñ", "l", _push, "9ºàñ", "ÄcÿM", _push, "D ", "", _push.pri);
    // const.alt 39
    // locals stack 24
    // locals stack 12
    // locals stack 1028
    return 1;
    // locals stack 8
    // if/goto jnz 0x35984c
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, 28, "", "", "àñ", "9ºàñ");
    // locals stack 36
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push, "", "8", _push, "D ", "", _push.pri);
    // const.alt 229523480
    Streamer_SetIntData(1);
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 12
    // locals stack 1028
    return 1;
    // locals stack -248
    // locals stack -248
    // const.alt 229523480
    Streamer_SetIntData();
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", "", "", "9ºàñ");
    // const.alt 36
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", "", "", "9ºàñ");
    // stor.alt 36
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", "", "", "9ºàñ");
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", "", "", "9ºàñ");
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", "", "", "9ºàñ");
    // locals stack 16
    // locals stack 24
    // locals stack 24
    BlackPass_ParseClaimFlagsString();
    BlackPass_ParseClaimFlagsString();
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "9ºàñ", "l", _push.s, "", _push, "Äc÷ÄcÿM", "", "", "", "", _push, "Äc÷ÄcÿM", "", "", "", "", "l", "", "", "9ºàñ");
    // const.alt 9
    // const.alt 1
    // const.alt 229523480
    Streamer_SetIntData();
    // const.alt 36
    // const.alt 229523480
    Streamer_SetIntData();
    BlackPass_GetLevelFromExperienc();
    // const.alt 229523480
    Streamer_SetIntData("àñ", _push.pri);
    // const.alt 229523480
    Streamer_SetIntData(1);
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 12
    // locals stack 1524
    return 1;
}

// AMX 0x359dc8
stock BlackPass_GetCurrentTaskPeriod()
{
    // locals stack 16
    return 1;
    // if/goto jump 3514104
    // locals stack 16
    return 1;
    // if/goto jump 3514104
}

// AMX 0x359f04
stock BlackPass_GetTaskResetTimer()
{
    // locals stack -4
    // locals stack 16
    // const.alt 86400
    // stor.s.pri -4
    // stor.s.pri -4
    // locals stack 4
    return 1;
}

// AMX 0x359fe4
stock BlackPass_FindTaskDefIndex()
{
    // if/goto jump 3514380
    // const.alt 15
    // const.alt 229658480
    SSCANF_Join("");
    // if/goto jneq 0x35a080
    // locals stack 4
    return 1;
    // if/goto jump 3514368
    // locals stack 4
    return 1;
}

// AMX 0x35a0a0
stock BlackPass_FindTaskSlot()
{
    // if/goto jump 3514568
    // const.alt 11
    // const.alt 229659124
    Streamer_SetIntData("");
    IsPlayerConnected(_push.pri);
    // if/goto jneq 0x35a16c
    // locals stack 4
    return 1;
    // if/goto jump 3514556
    // locals stack 4
    return 1;
}

// AMX 0x35a18c
stock BlackPass_GetTaskDefIndexFromSl()
{
    // if/goto jzer 0x35a1e8
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    BlackPass_FindTaskDefIndex();
    return 1;
}

// AMX 0x35a2e0
stock BlackPass_ClearTaskSlot()
{
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 36
    BlackPass_GetCurrentTaskPeriod();
    // const.alt 229659124
    Streamer_SetIntData("àñ", _push.s);
    IsPlayerConnected(_push.pri);
    // stor.alt 34
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    return 1;
}

// AMX 0x35a64c
stock BlackPass_AssignTaskSlot()
{
    // locals stack -4
    BlackPass_FindTaskDefIndex();
    // stor.s.pri -4
    // if/goto jzer 0x35a6b0
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 36
    // const.alt 229658480
    SSCANF_Join();
    BlackPass_GetCurrentTaskPeriod();
    // const.alt 229659124
    Streamer_SetIntData("àñ", _push.pri);
    IsPlayerConnected(_push.pri);
    // stor.alt 34
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // locals stack 4
    return 1;
}

// AMX 0x35aa84
stock BlackPass_GetNextFreeTaskSlot()
{
    // locals stack -4
    // load.alt 53
    // if/goto jump 3517124
    // stor.s.pri -4
    // locals stack -4
    // load.alt 53
    // if/goto jump 3517192
    // stor.s.pri -8
    // locals stack -4
    // stor.s.pri -12
    // if/goto jump 3517248
    // const.alt 229659124
    Streamer_SetIntData(6, 11, 6);
    IsPlayerConnected(_push.pri);
    // if/goto jnz 0x35abd8
    // locals stack 12
    return 1;
    // if/goto jump 3517236
    // locals stack 4
    // locals stack 8
    return 1;
}

// AMX 0x35ac00
stock BlackPass_IsTaskActive()
{
    BlackPass_FindTaskSlot();
    // const.alt -1
    return 1;
}

// AMX 0x35ac3c
stock BlackPass_GetTaskDescription()
{
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
    // locals stack 16
    // if/goto jump 3518644
}

// AMX 0x35b0c4
stock BlackPass_TaskHasAction()
{
    // if/goto jzer 0x35b11c
    return 1;
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -4
    // if/goto jzer 0x35b180
    // locals stack 4
    return 1;
    // const.alt 229658480
    SSCANF_Join();
    // locals stack 4
    return 1;
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 4
    // locals stack 4
    return 1;
    // locals stack 4
    return 1;
}

// AMX 0x35b254
stock BlackPass_GetStoredTaskStatus()
{
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -4
    // if/goto jzer 0x35b2c0
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // const.alt 229658480
    SSCANF_Join(_push.pri);
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x35b4a4
    BlackPass_TaskHasAction();
    // if/goto jzer 0x35b4a4
    // if/goto jump 3519656
    // if/goto jzer 0x35b4c8
    // locals stack 4
    return 1;
    // locals stack 4
    return 1;
}

// AMX 0x35b4dc
stock BlackPass_GetClientTaskStatus()
{
    // if/goto jzer 0x35b538
    return 1;
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -4
    // if/goto jzer 0x35b5a0
    // locals stack 4
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 229658480
    SSCANF_Join(_push.pri);
    // locals stack 4
    return 1;
    // const.alt 229658480
    SSCANF_Join();
    // if/goto jzer 0x35b6c0
    // const.alt 229523480
    Streamer_SetIntData();
    // stor.alt 9
    // if/goto jnz 0x35b6c0
    // if/goto jump 3520196
    // if/goto jzer 0x35b6e4
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // const.alt 229658480
    SSCANF_Join(_push.pri);
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x35b8c8
    BlackPass_TaskHasAction();
    // if/goto jzer 0x35b8c8
    // if/goto jump 3520716
    // if/goto jzer 0x35b8ec
    // locals stack 4
    return 1;
    BlackPass_TaskHasAction();
    // if/goto jzer 0x35b930
    // locals stack 4
    return 1;
    // locals stack 4
    return 1;
}

// AMX 0x35b948
stock BlackPass_EnableTaskGps()
{
    // const.alt 9
    EnablePlayerGPS();
    return 1;
    // if/goto jump 3522336
    // const.alt 9
    EnablePlayerGPS();
    return 1;
    // if/goto jump 3522336
    // const.alt 9
    EnablePlayerGPS();
    return 1;
    // if/goto jump 3522336
    // const.alt 9
    EnablePlayerGPS();
    return 1;
    // if/goto jump 3522336
    // const.alt 9
    EnablePlayerGPS();
    return 1;
    // if/goto jump 3522336
    // const.alt 9
    EnablePlayerGPS();
    return 1;
    // if/goto jump 3522336
    // const.alt 9
    EnablePlayerGPS();
    return 1;
    // if/goto jump 3522336
}

// AMX 0x35bf2c
stock BlackPass_SaveTaskSlot()
{
    // if/goto jzer 0x35bf84
    return 1;
    // locals stack -2048
    // locals stack -4
    BlackPass_GetStoredTaskStatus();
    // stor.s.pri -2052
    // const.alt 229659124
    Streamer_SetIntData("", _push.s, _push.s);
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData(_push.pri);
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 36
    // locals stack 40
    // locals stack 16
    // locals stack 2052
    return 1;
}

// AMX 0x35c23c
stock BlackPass_InsertTaskSlot()
{
    // if/goto jzer 0x35c294
    return 1;
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -4
    // if/goto jzer 0x35c2f8
    // locals stack 4
    return 1;
    // locals stack -3072
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // stor.alt 36
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 36
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 36
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, 28, _push.pri);
    // locals stack 64
    // locals stack 16
    // locals stack 3076
    return 1;
}

// AMX 0x35c5e0
stock BlackPass_LoadTasks()
{
    // if/goto jnz 0x35c664
    // const.alt 181530104
    Streamer_SetIntData("àñ", _push.s);
    // if/goto jnz 0x35c664
    // if/goto jump 3524204
    // if/goto jzer 0x35c680
    return 1;
    // locals stack -4
    BlackPass_GetCurrentTaskPeriod();
    // stor.s.pri -4
    // locals stack -4
    BlackPass_GetCurrentTaskPeriod();
    // stor.s.pri -8
    // const.alt 229759124
    Streamer_SetIntData("àñ", "ºàñ", "àñ", "9ºàñ");
    // if/goto jzer 0x35c770
    // const.alt 229760124
    Streamer_SetIntData();
    // if/goto jneq 0x35c770
    // const.alt 229761124
    Streamer_SetIntData();
    // if/goto jneq 0x35c770
    // if/goto jump 3524468
    // if/goto jzer 0x35c794
    // locals stack 8
    return 1;
    // const.alt 229763124
    Streamer_SetIntData();
    // if/goto jump 3524576
    // const.alt 6
    BlackPass_ClearTaskSlot();
    // if/goto jump 3524564
    // locals stack 4
    // if/goto jump 3524692
    // const.alt 11
    BlackPass_ClearTaskSlot();
    // if/goto jump 3524680
    // locals stack 4
    // if/goto jump 3524808
    // const.alt 2
    // locals stack -60
    // if/goto jgeq 0x89
    // locals stack -1024
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, 28, _push.alt, 1, _push.alt, 2, "", "", "", "l", _push.s, _push.s, "ºàñ", "", "l", _push.s, _push.s, "9ºàñ", "");
    // locals stack 44
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1108
    // locals stack 8
    // if/goto jzer 0x35cb18
    // locals stack 8
    // const.alt 39
    // locals stack 20
    // locals stack 12
    // locals stack 1108
    return 1;
    // if/goto jump 3525432
    // locals stack 8
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1116
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1120
    // locals stack -4
    BlackPass_FindTaskDefIndex();
    // stor.s.pri -1124
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1128
    // if/goto jzer 0x35cc98
    // locals stack 16
    // if/goto jump 3525420
    // const.alt 229658480
    SSCANF_Join("l", _push.s, "", "9ºàñ", "àñ", _push.s, "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "àñ", "9ºàñ", _push.pri, "");
    // if/goto jeq 0x35ccf8
    // locals stack 16
    // if/goto jump 3525420
    SSCANF_Join();
    // if/goto jzer 0x35cd34
    // locals stack 16
    // if/goto jump 3525420
    SSCANF_Join();
    // locals stack 16
    // if/goto jump 3525420
    // locals stack -4
    BlackPass_GetNextFreeTaskSlot();
    // stor.s.pri -1132
    // if/goto jzer 0x35cdf8
    // locals stack 20
    // if/goto jump 3525420
    // locals stack 16
    BlackPass_AssignTaskSlot();
    // const.alt 229659124
    Streamer_SetIntData("¼ý;", _push.s, _push.s, _push.s, _push.pri, "l", _push.s, "", "9ºàñ", "", _push.s, _push.s, 1);
    IsPlayerConnected(_push.pri);
    // const.alt 36
    // locals stack 16
    // const.alt 229659124
    Streamer_SetIntData("l", _push.s, "", "9ºàñ");
    IsPlayerConnected(_push.pri);
    // stor.alt 36
    // locals stack 16
    // const.alt 229659124
    Streamer_SetIntData("l", _push.s, "", "9ºàñ");
    IsPlayerConnected(_push.pri);
    // locals stack 16
    // const.alt 229659124
    Streamer_SetIntData("l", _push.s, "", "9ºàñ");
    IsPlayerConnected(_push.pri);
    // locals stack 16
    // const.alt 229659124
    Streamer_SetIntData("l", _push.s, "", "9ºàñ");
    IsPlayerConnected(_push.pri);
    // locals stack 16
    SSCANF_Join("l", _push.s, "", "9ºàñ");
    // load.pri 53
    // if/goto jump 3527100
    // const.alt 229659124
    Streamer_SetIntData(1);
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x35d254
    // const.alt 229763124
    Streamer_SetIntData();
    // locals stack 20
    // if/goto jump 3525420
    // locals stack 4
    // locals stack 12
    // load.pri 53
    // locals stack 1096
    // if/goto jump 3528200
    // if/goto jump 3527412
    // const.alt 11
    // locals stack -4
    // const.alt 229659080
    IsPlayerConnected("", "", "", _push.s, "9ºàñ");
    // stor.s.pri -1120
    // locals stack -4
    BlackPass_FindTaskDefIndex();
    // stor.s.pri -1124
    // if/goto jnz 0x35d3b4
    SSCANF_Join("àñ", _push.s);
    // if/goto jnz 0x35d3b4
    // if/goto jump 3527612
    // if/goto jzer 0x35d3d8
    // locals stack 8
    // if/goto jump 3527400
    // locals stack -4
    // const.alt 229658480
    SSCANF_Join(1);
    // stor.s.pri -1128
    // load.pri 53
    // const.alt 6
    // if/goto jump 3527784
    // if/goto jzer 0x35d484
    // locals stack 12
    // if/goto jump 3527400
    // load.alt 53
    // const.alt 5
    // if/goto jump 3527884
    // if/goto jzer 0x35d4e8
    // locals stack 12
    // if/goto jump 3527400
    BlackPass_AssignTaskSlot();
    BlackPass_InsertTaskSlot();
    SSCANF_Join("", _push.s, _push.s, "¼ý;", _push.s, _push.s, _push.s, "", 1, 1);
    // load.pri 53
    // if/goto jump 3528108
    // locals stack 12
    // if/goto jump 3527400
    // locals stack 4
    // if/goto jnz 0x35d5f8
    // locals stack 1100
    // if/goto jump 3528200
    // locals stack 1100
    // if/goto jump 3524796
    // locals stack 4
    // const.alt 229760124
    Streamer_SetIntData(1);
    // const.alt 229761124
    Streamer_SetIntData();
    // const.alt 229759124
    Streamer_SetIntData();
    // locals stack 8
    return 1;
}

// AMX 0x35d6b8
stock BlackPass_ShowTaskReadyGui()
{
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 20
    // locals stack 20
    // locals stack 20
    ShowPlayerGUI();
    // if/goto jrel 44
    // const.alt 137
    // const.alt 229762124
    Streamer_SetIntData("", _push.s, "", "l", _push.s, "Ò,", _push.s, "¼ý;", _push.s, "", "", "", "¼ý;", _push.s, "", "", "", "¼ý;", _push.s, "", "", "M", "l", _push.s, "", "", "l", _push.s, "", "ºàñ", "l", _push.s, "", "9ºàñ", "");
    func_0xcd48();
    // locals stack 4
    return 1;
}

// AMX 0x35d908
stock BlackPass_ShowTrackedTaskGui()
{
    // locals stack -384
    BlackPass_GetTaskDescription();
    // locals stack -4
    // locals stack 4
    // stor.s.pri -388
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 16
    // locals stack 20
    // locals stack 4
    // locals stack 16
    // locals stack 4
    // locals stack 16
    // locals stack 4
    // locals stack 16
    // locals stack 4
    // locals stack 16
    // locals stack 16
    ShowPlayerGUI();
    // if/goto jrel 44
    // const.alt 137
    func_0xcd48();
    // locals stack 388
    return 1;
}

// AMX 0x35dcf4
stock BlackPass_OpenTasksScreen()
{
    BlackPass_LoadPlayer();
    // if/goto jzer 0x35dd30
    return 1;
    BlackPass_LoadTasks();
    // if/goto jzer 0x35dd64
    return 1;
    // const.alt 229523480
    Streamer_SetIntData();
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 8
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", _push.pri, "àñ", _push.s, "l", _push.s, "", "", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "", "l", _push.s, "", "àñ", "l", _push.s, "", "", "l", _push.s, "", "9ºàñ", "", 1);
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 165275908
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("", "", "l", _push.s, "", _push.pri);
    // stor.s.pri 44
    // const.alt 181530104
    Streamer_SetIntData("*", "¼ý;", "", _push.pri);
    // locals stack 20
    // if/goto jump 3531164
    // locals stack 20
    // const.alt 181530104
    Streamer_SetIntData("c÷ÄcÿM", "¼ý;", _push.s, "", "", "ºàñ", "¼ý;", _push.s, "", _push.pri);
    // locals stack 20
    ShowPlayerGUI();
    // if/goto jrel 44
    // const.alt 137
    // locals stack -4
    // locals stack 4
    // stor.s.pri -8
    BlackPass_SendMainPacket();
    // if/goto jrel 44
    // const.alt 137
    // locals stack -4
    // locals stack 4
    // stor.s.pri -12
    // locals stack -4
    BlackPass_SendMainPacket();
    // stor.s.pri -16
    // if/goto jrel 44
    // const.alt 137
    func_0xcd48();
    func_0xcd48();
    func_0xcd48();
    // locals stack 16
    return 1;
}

// AMX 0x35e400
stock BlackPass_AddTaskProgress()
{
    return 1;
    BlackPass_LoadPlayer();
    // if/goto jzer 0x35e464
    return 1;
    BlackPass_LoadTasks();
    // if/goto jzer 0x35e498
    return 1;
    // locals stack -4
    BlackPass_FindTaskSlot();
    // stor.s.pri -4
    // if/goto jzer 0x35e4fc
    // locals stack 4
    return 1;
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -8
    // if/goto jzer 0x35e560
    // locals stack 8
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // locals stack 8
    return 1;
    // locals stack -4
    // const.alt 229658480
    SSCANF_Join();
    // stor.s.pri -12
    // locals stack -4
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // stor.s.pri -16
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 36
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 34
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x35e8f0
    // if/goto jump 3533044
    // if/goto jzer 0x35e98c
    // const.alt 229659124
    Streamer_SetIntData(1);
    IsPlayerConnected(_push.pri);
    BlackPass_ShowTaskReadyGui();
    BlackPass_SaveTaskSlot();
    // const.alt 229523480
    Streamer_SetIntData("", _push.s, _push.s, "", _push.s, _push.s, 1);
    // load.pri 53
    BlackPass_SendLayoutPacket();
    // locals stack 16
    return 1;
}

// AMX 0x35ea34
stock BlackPass_ClaimTaskReward()
{
    BlackPass_LoadPlayer();
    // if/goto jzer 0x35ea70
    return 1;
    BlackPass_LoadTasks();
    // if/goto jzer 0x35eaa4
    return 1;
    // locals stack -4
    BlackPass_FindTaskSlot();
    // stor.s.pri -4
    // if/goto jzer 0x35eb08
    // locals stack 4
    return 1;
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -8
    // if/goto jzer 0x35eb6c
    // locals stack 8
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // locals stack 8
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // const.alt 229658480
    SSCANF_Join(_push.pri);
    // locals stack 8
    return 1;
    // locals stack -4
    BlackPass_GetCurrentLevel();
    // stor.s.pri -12
    // locals stack -4
    // const.alt 229658480
    SSCANF_Join("àñ", _push.s);
    // const.alt 9
    // stor.s.pri -16
    // locals stack -4
    // const.alt 229658480
    SSCANF_Join();
    // stor.alt 9
    // stor.s.pri -20
    // locals stack -4
    // const.alt 229658480
    SSCANF_Join();
    // stor.s.pri -24
    // locals stack -384
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData(6);
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229763124
    Streamer_SetIntData(1);
    // if/goto jneq 0x35ef6c
    // const.alt 229763124
    Streamer_SetIntData();
    // const.alt 229762124
    Streamer_SetIntData();
    // if/goto jneq 0x35efcc
    // const.alt 229762124
    Streamer_SetIntData();
    HidePlayerGUI();
    DisablePlayerGPS();
    HidePlayerGUI();
    BlackPass_SaveTaskSlot();
    BlackPass_ClearTaskSlot();
    BlackPass_GrantExperience();
    GivePlayerMoneyEx();
    BlackPass_LogEvent();
    // locals stack 20
    ShowNotificationNew();
    BlackPass_GetCurrentLevel();
    ShowNotificationNew();
    BlackPass_GetCurrentLevel();
    BlackPass_SendLevelSyncRange();
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, _push.s, _push.pri, "àñ", _push.s, "M", _push.s, "àñ", "àñ", "", "", "", "", "àñ", _push.s, "M", _push.s, "àñ", "àñ", "", "", "", _push.alt, "¼ý;", "ô:", "", "M", _push.s, "", _push.s, "", _push.s, "9ºàñ", _push.s, "Äc÷ÄcÿM", _push.s, _push.s, "", "9ºàñ", "9ºàñ", "", _push.s, _push.s, "l", _push.s, _push.s, _push.s, "", _push.s, _push.s, "", _push.s, "Ò,", "àñ", _push.s, "", _push.s, "");
    BlackPass_OpenTasksScreen();
    // locals stack 408
    return 1;
}

// AMX 0x35f2f4
stock BlackPass_BeginTrackTask()
{
    BlackPass_LoadTasks();
    // if/goto jzer 0x35f330
    return 1;
    // locals stack -4
    BlackPass_FindTaskSlot();
    // stor.s.pri -4
    // if/goto jzer 0x35f394
    // locals stack 4
    return 1;
    BlackPass_TaskHasAction();
    // if/goto jzer 0x35f3d8
    // locals stack 4
    return 1;
    // if/goto jump 3535864
    // const.alt 11
    // const.alt 229659124
    Streamer_SetIntData("");
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x35f4a0
    // if/goto jeq 0x35f4a0
    // if/goto jump 3536036
    // if/goto jzer 0x35f538
    // const.alt 229659124
    Streamer_SetIntData(1);
    IsPlayerConnected(_push.pri);
    BlackPass_SaveTaskSlot();
    // if/goto jump 3535852
    // locals stack 4
    // const.alt 229659124
    Streamer_SetIntData("", _push.s, _push.s);
    IsPlayerConnected(_push.pri);
    // const.alt 229763124
    Streamer_SetIntData(1);
    BlackPass_SaveTaskSlot();
    BlackPass_EnableTaskGps();
    HidePlayerGUI();
    ShowNotificationNew();
    BlackPass_ShowTrackedTaskGui();
    // locals stack 4
    return 1;
}

// AMX 0x35f6d8
stock BlackPass_StopTrackTask()
{
    BlackPass_LoadTasks();
    // if/goto jzer 0x35f714
    return 1;
    // locals stack -4
    BlackPass_FindTaskSlot();
    // stor.s.pri -4
    // if/goto jzer 0x35f778
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x35f7f8
    // locals stack 4
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229763124
    Streamer_SetIntData();
    // if/goto jneq 0x35f8c0
    // const.alt 229763124
    Streamer_SetIntData();
    BlackPass_SaveTaskSlot();
    DisablePlayerGPS();
    HidePlayerGUI();
    // const.alt 229523480
    Streamer_SetIntData("", _push.s, "", "àñ", _push.s, "", _push.s, _push.s);
    BlackPass_OpenTasksScreen();
    // locals stack 4
    return 1;
}

// AMX 0x35f990
stock BlackPass_FindExchangeReplaceme()
{
    // locals stack -4
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.s.pri -4
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -8
    // if/goto jzer 0x35fa70
    // locals stack 8
    return 1;
    // if/goto jump 3537552
    // const.alt 15
    // if/goto jneq 0x35fad0
    // if/goto jump 3537540
    // const.alt 229658480
    SSCANF_Join("");
    // const.alt 229658480
    SSCANF_Join(_push.pri);
    // if/goto jeq 0x35fb58
    // if/goto jump 3537540
    // const.alt 229658480
    SSCANF_Join();
    BlackPass_IsTaskActive();
    // if/goto jzer 0x35fbb8
    // if/goto jump 3537540
    // const.alt 229658480
    SSCANF_Join("", _push.s, _push.pri);
    // if/goto jneq 0x35fc08
    // if/goto jump 3537540
    // locals stack 12
    return 1;
    // if/goto jump 3537540
    // locals stack 4
    // locals stack 8
    return 1;
}

// AMX 0x35fc48
stock BlackPass_HandleTaskPress()
{
    BlackPass_LoadPlayer();
    // if/goto jzer 0x35fcb0
    func_0xcd48();
    return 1;
    BlackPass_LoadTasks();
    // if/goto jzer 0x35fd10
    func_0xcd48();
    return 1;
    // locals stack 16
    // locals stack -4
    BlackPass_FindTaskSlot();
    // stor.s.pri -8
    // if/goto jzer 0x35fe48
    // const.alt 229523480
    Streamer_SetIntData("", _push.s, _push.s, "l", _push.s, "", "");
    BlackPass_SendMainPacket();
    func_0xcd48();
    // locals stack 8
    return 1;
    BlackPass_GetClientTaskStatus();
    BlackPass_ClaimTaskReward();
    func_0xcd48();
    // locals stack 8
    return 1;
    // if/goto jump 3538884
    BlackPass_StopTrackTask();
    func_0xcd48();
    // locals stack 8
    return 1;
    // if/goto jump 3538884
    BlackPass_BeginTrackTask();
    func_0xcd48();
    // locals stack 8
    return 1;
    // if/goto jump 3538884
}

// AMX 0x36006c
stock BlackPass_HandleTaskExchange()
{
    // locals stack 16
    BlackPass_LoadPlayer();
    // if/goto jzer 0x360120
    func_0xcd48();
    // locals stack 4
    return 1;
    BlackPass_LoadTasks();
    // if/goto jzer 0x36018c
    func_0xcd48();
    // locals stack 4
    return 1;
    // locals stack -4
    BlackPass_FindTaskSlot();
    // stor.s.pri -8
    // if/goto jzer 0x360220
    func_0xcd48();
    // locals stack 8
    return 1;
    // locals stack -4
    BlackPass_GetTaskDefIndexFromSl();
    // stor.s.pri -12
    // if/goto jzer 0x3602b4
    func_0xcd48();
    // locals stack 12
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    func_0xcd48();
    // locals stack 12
    return 1;
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // const.alt 229658480
    SSCANF_Join(_push.pri);
    func_0xcd48();
    // locals stack 12
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 10
    ShowNotificationNew();
    func_0xcd48();
    // locals stack 12
    return 1;
    // locals stack -4
    BlackPass_FindExchangeReplaceme();
    // stor.s.pri -16
    // if/goto jzer 0x360608
    ShowNotificationNew();
    func_0xcd48();
    // locals stack 16
    return 1;
    // locals stack -4
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // stor.s.pri -20
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // if/goto jzer 0x360718
    DisablePlayerGPS();
    HidePlayerGUI();
    GivePlayerDonateRub();
    // const.alt 229659124
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, "", "", "9ºàñ", "9ºàñ", "", _push.s, "", "àñ", _push.s);
    IsPlayerConnected(_push.pri);
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 36
    // const.alt 229658480
    SSCANF_Join();
    BlackPass_GetCurrentTaskPeriod();
    // const.alt 229659124
    Streamer_SetIntData("àñ", _push.pri);
    IsPlayerConnected(_push.pri);
    // stor.alt 34
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 229763124
    Streamer_SetIntData();
    // if/goto jneq 0x360b98
    // const.alt 229763124
    Streamer_SetIntData();
    // locals stack -3072
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // stor.alt 36
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 36
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229659124
    Streamer_SetIntData();
    IsPlayerConnected(_push.pri);
    // const.alt 36
    // const.alt 229658480
    SSCANF_Join();
    // const.alt 229658480
    SSCANF_Join();
    // locals stack 60
    // locals stack 16
    // const.alt 229658480
    SSCANF_Join("l", _push, "", "hY", _push, "X«", "", _push.pri);
    BlackPass_LogEvent();
    ShowNotificationNew();
    BlackPass_OpenTasksScreen();
    func_0xcd48();
    // locals stack 3092
    return 1;
}

// AMX 0x360f38
stock BlackPass_HandleExtraGui()
{
    // locals stack 16
    // locals stack 16
    // load.pri 54
    // load.pri 54
    // if/goto jump 3543064
    // if/goto jzer 0x3610b4
    // const.alt 229762124
    Streamer_SetIntData(1, "l", _push.s, "", "l", _push.s, "", "", "");
    HidePlayerGUI();
    func_0xcd48();
    // locals stack 8
    return 1;
    // load.alt 53
    // const.alt 229762124
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData();
    HidePlayerGUI();
    BlackPass_OpenTasksScreen();
    func_0xcd48();
    // locals stack 8
    return 1;
    // if/goto jump 3543804
    // load.pri 53
    HidePlayerGUI();
    func_0xcd48();
    // locals stack 8
    return 1;
    HidePlayerGUI();
    BlackPass_OpenTasksScreen();
    func_0xcd48();
    // locals stack 8
    return 1;
    // if/goto jump 3543804
}

// AMX 0x36133c
stock BlackPass_OnPlayerLogged()
{
    BlackPass_LoadPlayer();
    // if/goto jzer 0x361378
    return 1;
    BlackPass_LoadTasks();
    // if/goto jzer 0x3613ac
    return 1;
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x3613dc
stock BlackPass_OnPlayedHour()
{
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x361414
stock BlackPass_OnScooterRent()
{
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x36144c
stock BlackPass_OnAdvertSent()
{
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x361484
stock BlackPass_OnPlateRegenerated()
{
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x3614bc
stock BlackPass_OnBankDeposit()
{
    BlackPass_AddTaskProgress();
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x361520
stock BlackPass_OnMoneyEarned()
{
    return 1;
    // locals stack 20
    // const.alt -1
    // if/goto jeq 0x3615a8
    return 1;
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x3615d8
stock BlackPass_OnCaseOpened()
{
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x361610
stock BlackPass_OnPlayerGreeting()
{
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x361648
stock BlackPass_OnTestDriveStarted()
{
    BlackPass_AddTaskProgress();
    return 1;
}

// AMX 0x361680
stock BlackPass_FillBasePacket()
{
    // locals stack -4
    BlackPass_GetCurrentLevel();
    // stor.s.pri -4
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.s, "l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", "", "àñ", _push.s);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.alt, 1000);
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri, "àñ", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229532480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    DestroyPickup(_push.pri);
    // if/goto jzer 0x3619fc
    // if/goto jump 3545604
    // locals stack 16
    // const.alt 229595480
    Streamer_SetIntData("l", _push.s, "", _push.pri, 1);
    DestroyPickup(_push.pri);
    // if/goto jzer 0x361a90
    // if/goto jump 3545752
    // locals stack 16
    func_0xcd48();
    // locals stack 4
    return 1;
}

// AMX 0x361b08
stock BlackPass_SendMainPacket()
{
    // const.alt 39
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 20
    // const.alt 181530104
    Streamer_SetIntData("c÷ÄcÿM", "¼ý;", _push.s, "", "", "", "l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", "", "l");
    // locals stack 20
    // const.alt 229523480
    Streamer_SetIntData("¼ý;", _push.s, "", _push.pri);
    // const.alt 9
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", "y", "l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.alt, 1000);
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // locals stack 16
    // const.alt 229532480
    Streamer_SetIntData("l", _push.s, "", "", "l", _push.s, "", _push.pri, "àñ", _push.pri);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x361ec0
    // if/goto jump 3546824
    // locals stack 16
    // const.alt 229595480
    Streamer_SetIntData("l", _push.s, "", _push.pri, 1);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x361f64
    // if/goto jump 3546988
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    return 1;
    // if/goto jump 3551564
    // locals stack 8
    BlackPass_LoadTasks();
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 20
    // const.alt 181530104
    Streamer_SetIntData("c÷ÄcÿM", "¼ý;", _push.s, "", "", "", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "", "l", _push.s, "", "", "àñ", _push.s, "àñ", "");
    // locals stack 20
    // const.alt 229523480
    Streamer_SetIntData("¼ý;", _push.s, "", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    // if/goto jump 3547820
    // const.alt 11
    // const.alt 229659124
    Streamer_SetIntData("", "", "l", _push.s, "", _push.alt, 1000);
    IsPlayerConnected(_push.pri);
    // if/goto jump 3547808
    // locals stack -4
    // locals stack 4
    // stor.s.pri -12
    // const.alt 229659124
    Streamer_SetIntData("");
    IsPlayerConnected(_push.pri);
    // locals stack 16
    // const.alt 229659124
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    IsPlayerConnected(_push.pri);
    // stor.alt 9
    // locals stack 16
    BlackPass_GetClientTaskStatus();
    // locals stack 16
    // locals stack 8
    // locals stack 12
    // stor.s.pri -4
    func_0xcd48();
    // locals stack 4
    // if/goto jump 3547808
    // locals stack 4
    // locals stack 16
    BlackPass_GetTaskResetTimer();
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    func_0xcd48();
    // locals stack 4
    return 1;
    // if/goto jump 3551564
    // locals stack 16
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    return 1;
    // if/goto jump 3551564
    // locals stack 8
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack -4096
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -4100
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4104
    // if/goto jump 3549520
    // locals stack 8
    // locals stack -100
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4212
    // locals stack 24
    // locals stack 20
    // locals stack 16
    // locals stack 16
    // locals stack 8
    // locals stack 12
    // stor.s.pri -4104
    func_0xcd48();
    // locals stack 104
    // if/goto jump 3549508
    // locals stack 4
    // locals stack 12
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, 28, "", _push.s, "9ºàñ", "", _push.pri, "9ºàñ", _push.pri, "", _push.s, _push.pri, "àñ", "l", _push.s, "", _push.pri, "l", _push.s, "", "9ºàñ", "¼ý;", _push.s, "", "cÿM", _push, "Äc÷ÄcÿM", _push.s, "", "cÿM", "cÿM", "", "àñ", "9ºàñ", _push.pri, "", "", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "ØÉ", "", _push.alt, 28, "l", _push.s, "", "àñ", "l", _push.s, "", "", "l", _push.s, "", "", "àñ", "");
    // locals stack 32
    // locals stack -4
    // locals stack 16
    // stor.s.pri -4108
    // locals stack 8
    // if/goto jzer 0x362ccc
    // locals stack 16
    // stor.s.pri -4112
    // locals stack 12
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    func_0xcd48();
    // locals stack 4112
    return 1;
    // if/goto jump 3551564
    // const.alt 229523480
    Streamer_SetIntData("/", "");
    // stor.alt 9
    // load.pri 53
    // stor.s.pri -8
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", "àñ", "l", _push.s, "", "", "l", _push.s, "", "", 900);
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // locals stack 20
    // locals stack 20
    // locals stack 20
    OnPacketIncoming();
    func_0xcd48();
    // locals stack 8
    return 1;
    // if/goto jump 3551564
}

// AMX 0x363184
stock BlackPass_HandleBuyLevels()
{
    // locals stack 16
    // stor.s.pri -4
    // locals stack -4
    BlackPass_GetCurrentLevel();
    // stor.s.pri -8
    // const.alt 61
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    // locals stack 8
    return 1;
    // locals stack -4
    // stor.s.pri -12
    // const.alt 61
    // stor.s.pri -12
    // stor.s.pri -4
    // locals stack -4
    // stor.s.pri -16
    // const.alt 181530104
    Streamer_SetIntData(61);
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    // locals stack 16
    return 1;
    BlackPass_SetLevelWithReset();
    // locals stack -4
    BlackPass_GetCurrentLevel();
    // stor.s.pri -20
    // const.alt 229523480
    Streamer_SetIntData("àñ", _push.s, "", _push.s, _push.s);
    // stor.alt 9
    // load.pri 36
    BlackPass_AutoClaimRewardsRange();
    GivePlayerDonateRub();
    BlackPass_SavePlayer();
    BlackPass_LogEvent();
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    // const.alt 229523480
    Streamer_SetIntData("", "l", _push.s, "÷ÄcÿM", _push.s, "l", _push.s, "", "9ºàñ", "l", _push.s, "", "", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "", "M", _push.s, "", "", "", "", _push.s, _push.s, "àñ", _push.s, "Äc÷ÄcÿM", _push.s, _push.pri, "", "9ºàñ", "9ºàñ", "Äc÷ÄcÿM", _push.s, _push.s, "9ºàñ", _push.pri);
    // stor.alt 9
    BlackPass_SendAutoClaimSyncRang();
    BlackPass_SendMainPacket();
    BlackPass_SendStateRefresh();
    BlackPass_ShowLootNotification();
    func_0xcd48();
    // locals stack 20
    return 1;
}

// AMX 0x363978
stock BlackPass_HandlePurchasePremium()
{
    // locals stack 16
    // locals stack -4
    // stor.s.pri -8
    // locals stack -4
    // if/goto jzer 0x363a10
    // if/goto jump 3553816
    // stor.s.pri -12
    // locals stack -4
    BlackPass_GetCurrentLevel();
    // stor.s.pri -16
    // locals stack -4
    // if/goto jzer 0x363a78
    // if/goto jump 3553920
    // stor.s.pri -20
    // load.alt 53
    // const.alt 229523480
    Streamer_SetIntData(790, 1690, "àñ", _push.s, 1, 2, "l", _push.s, "", "");
    // stor.alt 9
    // load.pri 53
    // if/goto jump 3554044
    // if/goto jzer 0x363b18
    // stor.s.pri -20
    // const.alt 229523480
    Streamer_SetIntData(900, 1);
    // stor.alt 9
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", "9ºàñ", "l", _push.s, "", "àñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "");
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    // locals stack 20
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    // locals stack 20
    return 1;
    // if/goto jzer 0x363f08
    // if/goto jump 3555088
    GivePlayerDonateRub();
    // const.alt 229523480
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, _push.pri, _push.pri, 229820724, 229820624, "9ºàñ", "9ºàñ");
    // stor.alt 34
    // const.alt 229523480
    Streamer_SetIntData();
    // if/goto jzer 0x3640fc
    BlackPass_AddLevelsWithReset();
    BlackPass_GetCurrentLevel();
    BlackPass_AutoClaimRewardsRange();
    // const.alt 229523480
    Streamer_SetIntData("Äc÷ÄcÿM", _push.s, "9ºàñ", _push.pri, "àñ", _push.s, "9ºàñ", "9ºàñ", "", _push.s, "");
    // if/goto jzer 0x3640f4
    // const.alt 229523480
    Streamer_SetIntData();
    BlackPass_QueueDeluxeRewards();
    // if/goto jump 3555660
    BlackPass_GetCurrentLevel();
    BlackPass_AutoClaimRewardsRange();
    BlackPass_SavePlayer();
    BlackPass_LogEvent();
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", "9ºàñ", "l", _push.s, "", "àñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "", "M", _push.s, "", "", "", _push.s, "9ºàñ", _push.s, "àñ", _push.s, "Äc÷ÄcÿM", _push.s, "9ºàñ", _push.pri, "àñ", _push.s, "", "9ºàñ", "", _push.s, "9ºàñ", 1);
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // locals stack 16
    BlackPass_GetCurrentLevel();
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri, "àñ", _push.s, "l", _push.s, "", "y", "l", _push.s, "", _push.pri, "àñ", _push.pri);
    // locals stack 16
    OnPacketIncoming();
    // if/goto jzer 0x364560
    // locals stack -4
    BlackPass_GetCurrentLevel();
    // stor.s.pri -24
    // const.alt 229523480
    Streamer_SetIntData("", "àñ", _push.s, "l", _push.s, "÷ÄcÿM", _push.s, "l", _push.s, "", _push.alt, 1000);
    // stor.alt 9
    BlackPass_SendAutoClaimSyncRang();
    BlackPass_SendMainPacket();
    BlackPass_SendStateRefresh();
    BlackPass_ShowLootNotification();
    // locals stack 4
    // if/goto jump 3556916
    BlackPass_GetCurrentLevel();
    BlackPass_SendClaimPacketsRange();
    BlackPass_SendMainPacket();
    BlackPass_SendStateRefresh();
    BlackPass_ShowLootNotification();
    func_0xcd48();
    // locals stack 20
    return 1;
}

// AMX 0x364678
stock BlackPass_HandleGetPrize()
{
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 1
    // const.alt 61
    // if/goto jump 3557248
    // if/goto jzer 0x3647cc
    func_0xcd48();
    // locals stack 12
    return 1;
    BlackPass_GetCurrentLevel();
    func_0xcd48();
    // locals stack 12
    return 1;
    // if/goto jzer 0x36489c
    // const.alt 229523480
    Streamer_SetIntData();
    // stor.alt 9
    // if/goto jnz 0x36489c
    // if/goto jump 3557536
    // if/goto jzer 0x3648ec
    func_0xcd48();
    // locals stack 12
    return 1;
    // if/goto jzer 0x364a24
    // const.alt 229595480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    // if/goto jzer 0x364998
    func_0xcd48();
    // locals stack 12
    return 1;
    // const.alt 229595480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    BlackPass_QueueLevelReward();
    // if/goto jump 3558208
    // const.alt 229532480
    Streamer_SetIntData("l", _push.s, _push.s, "9ºàñ", 1);
    DestroyPickup(_push.pri);
    // if/goto jzer 0x364abc
    func_0xcd48();
    // locals stack 12
    return 1;
    // const.alt 229532480
    Streamer_SetIntData();
    DestroyPickup(_push.pri);
    BlackPass_QueueLevelReward();
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, _push.s, "", 1);
    BlackPass_SavePlayer();
    BlackPass_LogEvent();
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    // locals stack 12
    return 1;
}

// AMX 0x364d94
stock BlackPass_HandleRefreshRating()
{
    // locals stack -4
    // locals stack 16
    // stor.s.pri -4
    // const.alt 229764124
    Streamer_SetIntData("l", _push.alt, _push.alt, _push.alt);
    // const.alt 229764124
    Streamer_SetIntData();
    // const.alt 39
    // locals stack 16
    ShowNotificationNew();
    func_0xcd48();
    // locals stack 4
    return 1;
    // const.alt 229764124
    Streamer_SetIntData();
    // const.alt 229523480
    Streamer_SetIntData(_push.pri);
    BlackPass_SendMainPacket();
    func_0xcd48();
    // locals stack 4
    return 1;
}

// AMX 0x36501c
stock BlackPass_HandlePacket()
{
    // if/goto jnz 0x3650a0
    // const.alt 181530104
    Streamer_SetIntData("àñ", _push.s);
    // if/goto jnz 0x3650a0
    // if/goto jump 3559592
    // if/goto jzer 0x3650e8
    func_0xcd48();
    return 1;
    BlackPass_LoadPlayer();
    // if/goto jzer 0x365148
    func_0xcd48();
    return 1;
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // if/goto jzer 0x3652f4
    // stor.s.pri -4
    // stor.s.pri -8
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.s, "l", _push.s, "", _push.s, "l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", "", -1, -1, "l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", "");
    // const.alt 9
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.alt, 1000);
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri, "àñ", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229532480
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x365690
    // if/goto jump 3561112
    // locals stack 16
    // const.alt 229595480
    Streamer_SetIntData("l", _push.s, "", _push.pri, 1);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x365734
    // if/goto jump 3561276
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.pri, 1);
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 20
    // const.alt 181530104
    Streamer_SetIntData("c÷ÄcÿM", "¼ý;", _push.s, "", "", "", "l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", "");
    // locals stack 20
    // const.alt 229523480
    Streamer_SetIntData("¼ý;", _push.s, "", _push.pri);
    // const.alt 9
    // locals stack 16
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", "y", "l", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 229523480
    Streamer_SetIntData("l", _push.s, "", _push.alt, 1000);
    // stor.alt 9
    BlackPass_GetClientPremiumStatu();
    // locals stack 16
    // locals stack 16
    // const.alt 229532480
    Streamer_SetIntData("l", _push.s, "", "", "l", _push.s, "", _push.pri, "àñ", _push.pri);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x365b38
    // if/goto jump 3562304
    // locals stack 16
    // const.alt 229595480
    Streamer_SetIntData("l", _push.s, "", _push.pri, 1);
    BlackPass_GetCurrentLevel();
    DestroyPickup("àñ", _push.s, _push.pri);
    // if/goto jzer 0x365bdc
    // if/goto jump 3562468
    // locals stack 16
    OnPacketIncoming();
    func_0xcd48();
    // locals stack 12
    return 1;
    // if/goto jump 3562652
}

// AMX 0x366624
stock pc_cmd_blackpass()
{
    // locals stack -4
    // locals stack 4
    // stor.s.pri -4
    // locals stack 16
    // locals stack -4
    BlackPass_HandlePacket();
    // stor.s.pri -8
    // if/goto jrel 44
    // const.alt 137
    func_0xcd48();
    // locals stack 8
    return 1;
}

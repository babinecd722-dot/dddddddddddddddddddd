// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_inventory_skin.pwn
// Functions: 4

// AMX 0x62bac
stock pc_cmd_myskinsz()
{
    // locals stack -2560
    // const.alt 181530104
    Streamer_SetIntData("", "");
    // locals stack 24
    // locals stack 16
    // stor.s.pri -2564
    // locals stack -4
    // locals stack 8
    // stor.s.pri -2572
    // if/goto jzer 0x62d2c
    // locals stack 16
    CheckSkinPlayer();
    // if/goto jump 405620
    // locals stack -240
    // locals stack -96
    // locals stack 16
    // if/goto jump 404940
    // locals stack 16
    // stor.s.pri -2568
    // locals stack 16
    // stor.s.pri -2816
    // locals stack 16
    // stor.s.pri -2820
    // if/goto jump 405236
    // const.alt 198017980
    SetPlayerWantedLevel(198097660, 198097568, "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "", _push.alt, "l", "h(/", "", "", "", "àñ", _push.s, "l", _push.s, "", "", "àñ", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "h(/", "", _push.pri);
    // load.pri 45
    // locals stack 28
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "h(/", _push.alt, "ÄcÿM", "b*", "", _push.alt, _push.pri);
    native#1023(_push.pri);
    // if/goto jump 404928
    // locals stack 4
    Dialog();
    // locals stack 344
    // locals stack 12
    // locals stack 2572
    return 1;
}

// AMX 0x630b8
stock CheckSkinPlayer()
{
    // locals stack -576
    // const.alt 181530104
    Streamer_SetIntData("");
    // locals stack 24
    // locals stack 16
    // stor.s.pri -580
    // locals stack -4
    // locals stack 8
    // stor.s.pri -584
    // locals stack 12
    // if/goto jzer 0x63388
    GetPlayerSkinEx();
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "àñ", _push.s, "", _push.s, "9ºàñ", "àñ", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "Ð", "", _push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6333c
    // locals stack 16
    // locals stack 584
    return 1;
    // locals stack 16
    // locals stack 584
    return 1;
    // locals stack 584
    return 1;
}

// AMX 0x6339c
stock ShowOwnableSkinLoadDialog()
{
    // stor.alt 137
    Dialog();
    return 1;
}

// AMX 0x6342c
stock ch_OnDialogResponse()
{
    // if/goto jzer 0x634ec
    // if/goto jzer 0x634ec
    // locals stack -4
    // const.alt 196049960
    Streamer_SetIntData();
    native#1023(_push.pri);
    // stor.s.pri -4
    ShowOwnableSkinLoadDialog();
    // locals stack 4
    // if/goto jzer 0x63b0c
    // if/goto jzer 0x63afc
    // locals stack -4
    // const.alt 17
    // locals stack -656
    // locals stack 24
    // locals stack 16
    // stor.s.pri -676
    // locals stack 16
    // stor.s.pri -664
    // locals stack 16
    // stor.s.pri -668
    // locals stack 12
    // locals stack 20
    // locals stack 16
    // stor.s.pri -676
    // locals stack 16
    // stor.s.pri -672
    // locals stack 12
    // load.pri 129
    // if/goto jzer 0x63818
    // locals stack 16
    // locals stack 676
    return 1;
    // locals stack -48
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    UpdatePlayerDatabaseInt();
    // locals stack 24
    // locals stack 16
    // locals stack 24
    // locals stack 16
    SetPlayerSkinInit();
    // locals stack 16
    // locals stack 48
    // if/goto jump 408308
    // if/goto jzer 0x63a58
    // locals stack 16
    // locals stack 676
    return 1;
    // locals stack 24
    // locals stack 16
    // if/goto jump 408308
}

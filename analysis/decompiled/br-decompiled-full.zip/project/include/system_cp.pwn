// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_cp.pwn
// Functions: 4

// AMX 0xcde0
stock ClearPlayerCPInfo()
{
    // const.alt 58812
    Streamer_SetIntData();
    return 1;
}

// AMX 0xce30
stock n_SetPlayerCheckpoint()
{
    // const.alt 58812
    Streamer_SetIntData();
    // const.alt 58812
    Streamer_SetIntData();
    // const.alt 58812
    Streamer_SetIntData();
    // const.alt 58812
    Streamer_SetIntData();
    // const.alt 34
    // const.alt 58812
    Streamer_SetIntData();
    // const.alt 58812
    Streamer_SetIntData();
    // stor.alt 34
    // if/goto jzer 0x2c
}

// AMX 0xd010
stock n_IsPlayerInCheckpoint()
{
    // const.alt 58812
    Streamer_SetIntData();
    // stor.alt 9
    // load.pri 53
    // const.alt 58812
    Streamer_SetIntData();
    // const.alt 58812
    Streamer_SetIntData(_push.pri);
    // const.alt 58812
    Streamer_SetIntData(_push.pri);
    // const.alt 58812
    Streamer_SetIntData(_push.pri);
    // const.alt 9
    // const.alt 36
    // if/goto jnz 0x2c
    return 1;
}

// AMX 0xd1ac
stock n_DisablePlayerCheckpoint()
{
    // const.alt 58812
    Streamer_SetIntData();
    // stor.alt 9
    // load.pri 53
    // const.alt 58812
    Streamer_SetIntData();
    // stor.alt 34
    // if/goto jeq 0x2c
    return 1;
}

// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_roulette.pwn
// Functions: 17

// AMX 0x7b43c
stock acs_OnGameModeInit()
{
    // locals stack 8
    RuletkaMenu();
    LoadPrizeRuletka();
    // locals stack 16
    rul_OnGameModeInit();
    return 1;
}

// AMX 0x7b4dc
stock acs_OnDialogResponse()
{
    // if/goto jzer 0x7cad8
    // if/goto jzer 0x7cad8
    // if/goto jzer 0x7b54c
    // load.pri 54
    // if/goto jump 505172
    // if/goto jzer 0x7bb28
    // locals stack -4
    // const.alt 17
    // locals stack -376
    // if/goto jzer 0x7b5e0
    // if/goto jump 505404
    // load.pri 53
    // const.alt 1
    // if/goto jeq 0x7b624
    // if/goto jump 505384
    // if/goto jzer 0x7b63c
    // const.alt 181530104
    Streamer_SetIntData(1, "", _push.s, "", 1);
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -384
    // locals stack -4
    // locals stack -208
    // locals stack -2296
    // stor.alt 137
    // locals stack 8
    // stor.s.pri -392
    // stor.s.pri -392
    // locals stack -4
    // stor.s.pri -2908
    // if/goto jump 505912
    // locals stack 16
    // stor.s.pri -396
    // locals stack 16
    // stor.s.pri -400
    // const.alt 199191180
    SSCANF_IsConnected("l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "ºàñ", 10, "àñ", "9ºàñ", "l", "", "", "", "", "", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "", "", _push.pri);
    // load.pri 45
    // locals stack 24
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "", _push.alt, "Äc÷ÄcÿM", "`*", "", _push.alt, _push.pri);
    native#1023(_push.pri);
    // locals stack 20
    // stor.alt 51
    // locals stack 8
    // locals stack 12
    // stor.alt 137
    Dialog();
    // locals stack 2904
    return 1;
    // locals stack -4
    // const.alt 196049960
    Streamer_SetIntData();
    native#1023(_push.pri);
    // stor.s.pri -4
    // locals stack -536
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "l", "", "", "");
    // const.alt 65535
    // if/goto jeq 0x7bc78
    // locals stack 16
    // locals stack 544
    return 1;
    // const.alt 199191180
    SSCANF_IsConnected("", "");
    GivePlayerCarRoulette();
    // const.alt 199191180
    SSCANF_IsConnected("¼ý;", _push.s, _push.pri);
    // locals stack 20
    // if/goto jump 510272
    // locals stack 8
    // load.pri 17
    GivePlayerDonateRub();
    // locals stack 20
    // if/goto jump 510272
    // const.alt 199191180
    SSCANF_IsConnected(_push.alt, "¼ý;", "", "", "Äc÷ÄcÿM", _push.s, _push.s, 197904564, "9ºàñ", "9ºàñ", "àñ", "", _push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 8
    // load.pri 17
    GivePlayerMoneyEx();
    // locals stack 20
    // if/goto jump 510272
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", "Äc÷ÄcÿM", _push.s, _push.s, 197904172, "9ºàñ", "9ºàñ", "àñ", _push.pri);
    // load.pri 43
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    UpdatePlayerDatabaseInt();
    // const.alt 199191180
    SSCANF_IsConnected("l", _push.s, "", _push.pri);
    // locals stack 20
    // if/goto jump 510272
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("", "", "", _push.alt, "¼ý;", "", "", _push.pri);
    // stor.s.pri -560
    // if/goto jzer 0x7c1e8
    // const.alt 181530104
    Streamer_SetIntData();
    // load.alt 43
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // const.alt 181530104
    Streamer_SetIntData(3);
    // locals stack 16
    // if/goto jump 508468
    // const.alt 181530104
    Streamer_SetIntData("l", _push.alt, _push.alt, _push.alt, _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, _push.alt, _push.alt, _push.pri);
    timestamp_to_date();
    // locals stack 28
    UpdatePlayerDatabaseInt();
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", "àñ", _push.alt, "ÄcÿM", "", "", "M", _push.pri);
    UpdatePlayerDatabaseInt();
    // locals stack 16
    // if/goto jump 510272
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(2);
    UpdatePlayerDatabaseInt();
    UpdatePlayerDatabaseInt();
    // const.alt 199191180
    SSCANF_IsConnected("l", _push.s, "", "9ºàñ", "l", _push.s, "", "ºàñ", 1);
    // locals stack 20
    // if/goto jump 510272
    // locals stack -28
    // locals stack 8
    PC_Init("àñ", "", _push.pri, "tÖ", 199235784, _push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 16
    // const.alt 199191180
    SSCANF_IsConnected("l", _push.s, _push.pri);
    // locals stack 20
    // locals stack 28
    // if/goto jump 510272
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // const.alt 199191180
    SSCANF_IsConnected(_push.pri, _push.pri);
    // const.alt 181530104
    Streamer_SetIntData();
    UpdatePlayerDatabaseInt();
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // load.pri 88
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData();
    // load.pri 43
    SetPlayerLevelInit();
    // locals stack 16
    // const.alt 199191180
    SSCANF_IsConnected("l", _push.s, "", "", "àñ", _push.s, _push.pri);
    // locals stack 20
    // if/goto jump 510272
}

// AMX 0x7cb18
stock weekly_OnPlayerConnect()
{
    // const.alt 199207236
    Streamer_SetIntData();
    // const.alt 39
    // locals stack 24
    rul_OnPlayerConnect();
    return 1;
}

// AMX 0x7cbb4
stock btn_OnPlayerClickTextDraw()
{
    // stor.alt 9
    // if/goto jneq 0x7ceb4
    // const.alt 199206236
    Streamer_SetIntData(199208236, _push.pri);
    // if/goto jzer 0x7cc4c
    // locals stack 16
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 50
    // const.alt 199198236
    Streamer_SetIntData();
    // const.alt 199198236
    Streamer_SetIntData(_push.pri);
    UpdatePlayerDatabaseInt();
    // locals stack 16
    GivePlayerDonateRub();
    // locals stack -40
    // const.alt 199198236
    Streamer_SetIntData(_push, "Äc÷ÄcÿM", _push.s, "", 197904564, "9ºàñ", "9ºàñ", "l", _push.s, "", "", "l", _push.s, "", _push.pri);
    // locals stack 20
    // const.alt 199214376
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 16
    // locals stack 40
    // if/goto jump 511668
    // locals stack 16
    // if/goto jneq 0x7cf00
    UpdateLastPlayerRuletka();
    // if/goto jneq 0x7d218
    // const.alt 199198236
    Streamer_SetIntData(199208236, _push.pri, "àñ", _push.s, 199208236, _push.pri, "l", _push.s, "", "", "l", _push.s, _push.pri);
    // if/goto jzer 0x7d1e4
    // const.alt 199207236
    Streamer_SetIntData();
    // if/goto jzer 0x7d1dc
    // const.alt 199206236
    Streamer_SetIntData();
    // if/goto jzer 0x7cfe8
    // locals stack 16
    return 1;
    // const.alt 199198236
    Streamer_SetIntData();
    // const.alt 199198236
    Streamer_SetIntData(_push.pri);
    UpdatePlayerDatabaseInt();
    // locals stack -40
    // const.alt 199198236
    Streamer_SetIntData(_push, "l", _push.s, "", _push.pri);
    // locals stack 20
    // const.alt 199214376
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 16
    // const.alt 199206236
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 199207236
    Streamer_SetIntData(1);
    // const.alt 39
    // locals stack 24
    // locals stack 40
    // if/goto jump 512536
    // locals stack 16
    // if/goto jneq 0x7d82c
    // const.alt 199206236
    Streamer_SetIntData(199208236, _push.pri, "l", _push.s, "", "", "Äc÷ÄcÿM", "", ".", "9ºàñ", _push.pri);
    // if/goto jzer 0x7d2a8
    // locals stack 16
    return 1;
    // locals stack 12
    ShowHud();
    // if/goto jump 512784
    // const.alt 35
    // const.alt 199208236
    memcpy("", "àñ", _push.s, "", _push.s, "9ºàñ");
    // locals stack 12
    // if/goto jump 512772
    // locals stack 4
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // if/goto jump 513016
    // const.alt 5
    // const.alt 199208376
    Streamer_SetIntData("", "", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    strcmp(_push.pri);
    // locals stack 12
    // const.alt 199199236
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // if/goto jump 513004
    // locals stack 4
    // if/goto jump 513400
    // const.alt 3
    // const.alt 199214376
    Streamer_SetIntData("", -1);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    // const.alt 9
    strcmp();
    // locals stack 12
    // if/goto jump 513388
    // locals stack 4
    // locals stack 8
    rul_OnPlayerClickTextDraw();
    return 1;
}

// AMX 0x7d854
stock pc_cmd_openroulette()
{
    // locals stack 12
    HideHud();
    RuletkaPlayer();
    // locals stack 12
    // if/goto jump 514316
    // const.alt 20
    // locals stack 16
    // if/goto jump 514304
    // locals stack 4
    // if/goto jump 514440
    // const.alt 35
    // const.alt 199208236
    memcpy("", "l", _push.s, "", "", "", "", _push.s, "", "àñ", _push.s, "àñ", _push.s, "", _push.s, "");
    // locals stack 12
    // if/goto jump 514428
    // locals stack 4
    // if/goto jump 514628
    // locals stack 8
    // stor.s.pri -8
    // const.alt 5
    // const.alt 199191180
    SSCANF_IsConnected("àñ", "l", "", "", "", _push.s, _push.pri);
    // const.alt 199208376
    Streamer_SetIntData();
    floatsub(_push.pri);
    // locals stack 16
    // const.alt 199191180
    SSCANF_IsConnected("l", _push.s, _push.pri);
    // const.alt 199214376
    Streamer_SetIntData(_push.pri);
    strcmp(_push.pri);
    // locals stack 16
    // const.alt 199208376
    Streamer_SetIntData("l", _push.s, _push.pri);
    floatsub(_push.pri);
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    strcmp(_push.pri);
    // locals stack 12
    // const.alt 199199236
    Streamer_SetIntData("", _push.s, _push.pri);
    floatsub(_push.pri);
    // if/goto jump 514576
    // locals stack 8
    UpdateLastPlayerRuletka();
    // if/goto jump 515368
    // const.alt 3
    // const.alt 199214376
    Streamer_SetIntData("", "àñ", _push.s);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 12
    // const.alt 199214376
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    // const.alt 9
    strcmp();
    // locals stack 12
    // if/goto jump 515356
    // locals stack 4
    // locals stack -40
    // const.alt 199198236
    Streamer_SetIntData(_push, "", _push.s, _push.pri);
    // locals stack 20
    // const.alt 199214376
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // locals stack 16
    // const.alt 199214376
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 12
    // locals stack 40
    return 1;
}

// AMX 0x7e104
stock RuletkaMenu()
{
    // locals stack 16
    // locals stack 16
    // locals stack 12
    // locals stack 12
    // locals stack 12
    // locals stack 12
}

// AMX 0x82930
stock RuletkaPlayer()
{
    // const.alt 199208376
    Streamer_SetIntData();
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 199208376
    Streamer_SetIntData("", "");
}

// AMX 0x87904
stock LoadPrizeRuletka()
{
    // if/goto jump 555308
    // const.alt 12
    // const.alt 199191180
    SSCANF_IsConnected("");
    // const.alt 199241224
    SSCANF_IsConnected(_push.pri, 199208236);
    memcpy();
    // locals stack 12
    // const.alt 199191180
    SSCANF_IsConnected("", _push.pri);
    // const.alt 199241224
    SSCANF_IsConnected(_push.pri, 199208236, _push.pri);
    memcpy();
    // locals stack 12
    // if/goto jump 555296
    // locals stack 4
    return 1;
}

// AMX 0x87aac
stock weekly_OnPlayerDisconnect()
{
    // const.alt 199198236
    Streamer_SetIntData();
    // const.alt 199205236
    Streamer_SetIntData();
    // const.alt 199206236
    Streamer_SetIntData();
    // const.alt 199207236
    Streamer_SetIntData();
    rul_OnPlayerDisconnect();
    return 1;
}

// AMX 0x87b90
stock RunRuletka()
{
    // const.alt 199206236
    Streamer_SetIntData();
    // const.alt 199205236
    Streamer_SetIntData(1);
    // if/goto jzer 0x88598
    // locals stack -540
    // const.alt 199205236
    Streamer_SetIntData();
    // stor.pri 53
    // const.alt 199199236
    Streamer_SetIntData(_push.pri, 199191180);
    SSCANF_IsConnected();
    // locals stack 20
    // locals stack 16
    // const.alt 199199236
    Streamer_SetIntData("l", _push.s, "", _push.alt, "¼ý;", "", "", _push.pri);
    GivePrizeRoulette();
    // const.alt 199206236
    Streamer_SetIntData("", _push.s, _push.pri);
    // const.alt 199207236
    Streamer_SetIntData();
    // locals stack 8
    // const.alt 199207236
    Streamer_SetIntData(_push.r, "àñ", _push.pri);
    // const.alt 199205236
    Streamer_SetIntData(-1);
    // locals stack 16
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData(199190868, _push.pri, 199190868, _push.alt, "l", _push.pri, 199190868, "ÄcÿM", _push.pri, 199190868, 199190868, _push.pri, 199190868, _push.alt, "l", _push.pri, 199190868, "ÄcÿM", _push.pri, 199190868);
    // locals stack 16
    // const.alt 199199236
    Streamer_SetIntData(_push.pri, 199190868, _push.alt, "l", _push.pri, 199190868, "ÄcÿM", _push.pri);
    // locals stack 540
    return 1;
    // const.alt 199205236
    Streamer_SetIntData();
    // const.alt 1
    // const.alt 199199236
    Streamer_SetIntData(_push.pri, 199191180, "ñ", _push.pri);
    floatsub(1, _push.pri);
    SSCANF_IsConnected();
    // const.alt 199208376
    Streamer_SetIntData();
    floatsub(_push.pri);
    // locals stack 16
    // const.alt 199199236
    Streamer_SetIntData(_push.pri, 199191180, "l", _push.s, _push.pri);
    floatsub(1, _push.pri);
    SSCANF_IsConnected();
    // const.alt 199214376
    Streamer_SetIntData(_push.pri);
    strcmp(_push.pri);
    // locals stack 16
    // const.alt 199199236
    Streamer_SetIntData("l", _push.s, _push.pri);
    floatsub(_push.pri);
    // const.alt 199199236
    Streamer_SetIntData(_push.pri);
    floatsub(1, _push.pri);
    // if/goto jump 557268
    // locals stack -48
    return 1;
    // const.alt 199199236
    Streamer_SetIntData();
    random2();
    // const.alt 199199236
    Streamer_SetIntData(_push.pri, 199191180, "", "l", _push.pri);
    SSCANF_IsConnected();
    // const.alt 199208376
    Streamer_SetIntData();
    // locals stack 16
    // const.alt 199199236
    Streamer_SetIntData(_push.pri, 199191180, "l", _push.s, _push.pri);
    SSCANF_IsConnected();
    // const.alt 199214376
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // locals stack 52
    // locals stack 540
    // if/goto jump 558536
    // const.alt 199205236
    Streamer_SetIntData("l", _push.s, _push.pri);
    return 1;
}

// AMX 0x885d8
stock UpdateLastPlayerRuletka()
{
    // if/goto jump 558592
    // const.alt 3
    // const.alt 199190868
    floatdiv("");
    // const.alt 199214376
    Streamer_SetIntData(_push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 16
    // const.alt 199190868
    floatdiv(_push.pri, 199191180, "l", _push.s, _push.pri);
    SSCANF_IsConnected();
    // const.alt 199214376
    Streamer_SetIntData();
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 16
    // const.alt 199190868
    floatdiv(_push.pri, 199191180, "l", _push.s, _push.pri);
    SSCANF_IsConnected();
    // const.alt 199214376
    Streamer_SetIntData(_push.pri);
    // const.alt 199190808
    floatdiv(_push.pri);
    strcmp();
    // locals stack 16
    // if/goto jump 558580
    // locals stack 4
    return 1;
}

// AMX 0x88900
stock random2()
{
    // const.alt 1
    return 1;
    // locals stack -4
    // stor.s.pri -12
    // if/goto jump 559492
    // const.alt -1
    // stor.s.pri -4
    // locals stack 8
    // stor.s.pri -8
    // if/goto jump 559480
    // locals stack 4
    // locals stack 8
    return 1;
}

// AMX 0x88a5c
stock GivePrizeRoulette()
{
    // locals stack -376
    // stor.alt 12
    Streamer_SetIntData();
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x88b88
    // locals stack 16
    // locals stack 376
    return 1;
}

// AMX 0x88ba0
stock CreateTablistRoulette()
{
    // locals stack -4
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jzer 0x88cd4
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x88cd4
    // locals stack 8
    // locals stack 12
    // locals stack 12
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jzer 0x88e24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x88e24
    // locals stack 8
    // locals stack 12
    // locals stack 12
    // locals stack 4
    return 1;
}

// AMX 0x88e68
stock GivePlayerCarRoulette()
{
    // locals stack -4
    // stor.s.pri -4
    // locals stack -12
    // const.alt 137
    return 1;
    // locals stack 20
    // locals stack -4
    // stor.s.pri -20
    // locals stack -4
    // stor.s.pri -24
    // locals stack -4
    // stor.s.pri -28
    // locals stack -880
    GetFreeOwnableCarID();
    // stor.s.pri -920
    // const.alt 182230856
    native#14999("", "", "", "");
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999("", "", "", "");
    // locals stack 24
    // const.alt 182230856
    native#14999("Äc÷ÄcÿM", _push.pri);
    // const.alt 182230856
    native#14999();
    // const.alt 182230856
    native#14999(1);
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.alt, _push.alt, _push.alt, _push.pri);
    // const.alt 182230856
    native#14999("c÷ÄcÿM", _push.pri);
    // locals stack 16
    // locals stack -4
    // const.alt 182230856
    native#14999("", "", "ºàñ", _push.s, _push.alt, "l");
    // const.alt 182230856
    native#14999(_push.pri);
    // const.alt 182230856
    native#14999(_push.pri);
    // const.alt 182230856
    native#14999(_push.pri);
    // const.alt 182230856
    native#14999(_push.pri);
    // const.alt 182230856
    native#14999(_push.pri);
    // const.alt 182230856
    native#14999(_push.pri);
    n_veh_CreateVehicle();
    // stor.s.pri -924
    // const.alt 65535
    // if/goto jeq 0x89764
    // const.alt 182230856
    native#14999("8*", _push.pri);
    // const.alt 182230856
    native#14999("l", _push.pri);
    // locals stack 16
    // const.alt 182230856
    native#14999("", _push.alt, "l", _push.pri);
    SetVehicleRuNumberPlate();
    SetVehicleParam();
    // const.alt 169148
    native#1199("l", _push.s, "àñ", "", "l", _push.s, _push.pri);
    // if/goto jgeq 0x22
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 16
    // stor.alt 12
    Streamer_SetIntData(_push.alt, "l", _push.alt, _push.alt, _push.alt);
    // locals stack 52
    // locals stack 16
    // stor.s.pri -916
    // const.alt 182230856
    native#14999("l", _push, "9ºàñ", _push.alt, "X*", "÷+", "", _push.pri);
    // locals stack 8
    // locals stack 12
    // locals stack 924
    return 1;
}

// AMX 0x89984
stock pc_cmd_roulette()
{
    // locals stack -376
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -380
    // locals stack 8
    // if/goto jzer 0x89ac8
    // locals stack 16
    // locals stack 380
    return 1;
    // locals stack -208
    // locals stack -2296
    // stor.alt 137
    // locals stack 8
    // stor.s.pri -384
    // const.alt 10
    // stor.s.pri -384
    // if/goto jump 564188
    // locals stack 16
    // stor.s.pri -388
    // locals stack 16
    // stor.s.pri -392
    // const.alt 199191180
    SSCANF_IsConnected("l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "ºàñ", "", 10, "àñ", "9ºàñ", "l", "", "", "", "", "");
    // load.pri 45
    // locals stack 24
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "", _push.alt, "Äc÷ÄcÿM", "`*", "", _push.alt, _push.pri);
    native#1023(_push.pri);
    // locals stack 20
    // stor.alt 51
    // locals stack 8
    // stor.alt 137
    Dialog();
    // locals stack 2896
    return 1;
}

// AMX 0x89ea0
stock LoadRuletka()
{
    // locals stack -496
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -500
    // locals stack 8
    // if/goto jzer 0x89fd4
    // locals stack 16
    // const.alt 199198236
    Streamer_SetIntData("l", _push.s, "", "", "àñ", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "ú*", "", _push.pri);
    // locals stack 16
    // locals stack 12
    // locals stack 500
    return 1;
}

// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_carshare_welsi.pwn
// Functions: 8

// AMX 0x5afd4
stock prom_OnPlayerConnect()
{
    // const.alt 197987692
    Streamer_SetIntData();
    // const.alt 197986692
    Streamer_SetIntData(-1);
    car_OnPlayerConnect();
    return 1;
}

// AMX 0x5b05c
stock prom_OnPlayerDisconnect()
{
    // const.alt 197986692
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x5b0b0
    DeleteCarShareVehicle();
    car_OnPlayerDisconnect();
    return 1;
}

// AMX 0x5b0d8
stock prom_OnGameModeInit()
{
    // locals stack 8
    car_OnGameModeInit();
    return 1;
}

// AMX 0x5b11c
stock prom_OnDialogResponse()
{
    // if/goto jzer 0x5b1d4
    // if/goto jzer 0x5b1d4
    DeleteCarShareVehicle();
    // locals stack 16
    // if/goto jump 373204
}

// AMX 0x5cb4c
stock pc_cmd_arendacar()
{
    // const.alt 197987692
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x5cbc0
    // const.alt 197986692
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x5cbc0
    // if/goto jump 379844
    // if/goto jzer 0x5cc20
    Dialog();
    // if/goto jump 380820
    // locals stack -512
    // locals stack -5320
    // if/goto jump 380060
    // const.alt 10
    // const.alt 197988692
    atan(_push.pri, 308428, "", "", 197993836, "", "M", _push.s, "", "ºàñ", "", "", "", "", 1);
    // const.alt 400
    native#2089();
    // const.alt 1008981770
    func_0x2c();
    func_0x80();
    // locals stack 12
    // stor.s.pri -4
    // const.alt 197988692
    atan(_push.pri, 308428, "", _push.pri, "", _push.alt, _push.pri, 100, "", _push.alt, _push.pri);
    // const.alt 400
    native#2089();
    // load.pri 45
    // locals stack 28
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "", _push.alt, "ÄcÿM", "/", "", _push.alt, _push.pri);
    native#1023(_push.pri);
    // if/goto jump 380048
    // locals stack 4
    // stor.alt 137
    // stor.alt 137
    DialogCarShare();
    // locals stack 5836
    return 1;
}

// AMX 0x5cf9c
stock DialogCarShare()
{
    fg_ShowPlayerDialog();
    fg_ShowPlayerDialog();
    return 1;
}

// AMX 0x5d068
stock CarShare()
{
    // const.alt 197986692
    Streamer_SetIntData();
    // if/goto jnz 0x5d0d8
    // const.alt 197987692
    Streamer_SetIntData();
    // if/goto jnz 0x5d0d8
    // if/goto jump 381152
    // if/goto jzer 0x5d0f8
    return 1;
    // locals stack 16
    Dialog();
    // const.alt 197987692
    Streamer_SetIntData("M", _push.s, "8p", "ºàñ", "", "", "", "", "l", _push.s, "", "");
    // locals stack 8
    return 1;
}

// AMX 0x5d1c4
stock DeleteCarShareVehicle()
{
    // const.alt 197986692
    Streamer_SetIntData();
    DestroyVehicleLabel();
    // const.alt 197986692
    Streamer_SetIntData("àñ", _push.pri);
    n_veh_DestroyVehicle();
    // const.alt 197987692
    Streamer_SetIntData("àñ", _push.pri);
    // locals stack 8
    // const.alt 197986692
    Streamer_SetIntData(_push.r, "àñ", _push.pri);
    // const.alt 197987692
    Streamer_SetIntData(-1);
    return 1;
}

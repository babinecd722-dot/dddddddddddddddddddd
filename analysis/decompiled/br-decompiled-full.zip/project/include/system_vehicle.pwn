// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_vehicle.pwn
// Functions: 11

// AMX 0xe238
stock SetVehicleDataAll()
{
    // if/goto jzer 0xe738
    // const.alt 169148
    native#1199(1200, _push.pri, 1);
    // const.alt 169148
    native#1199();
    // const.alt 169148
    native#1199();
    // const.alt 169148
    native#1199();
    // const.alt 34
    // const.alt 169148
    native#1199();
    // stor.alt 34
    // const.alt 169148
    native#1199();
    // const.alt 169148
    native#1199();
    // const.alt 169148
    native#1199();
    // const.alt 169148
    native#1199();
    // const.alt 169148
    native#1199();
    // const.alt 169148
    native#1199(_push.pri);
    // const.alt 169148
    native#1199(_push);
    // locals stack 34
    // const.alt 169148
    native#1199(65535);
    // if/goto jneq 0x22
    // const.alt 169148
    native#1199(1109393408);
    // if/goto jgeq 0x22
    // const.alt 169148
    native#1199();
    return 1;
    // const.alt 169148
    native#1199(1);
    IsABike();
    // if/goto jzer 0xe710
    // if/goto jump 59156
    // locals stack 36
    return 1;
}

// AMX 0xe740
stock n_veh_AddStaticVehicleEx()
{
    Iter_AddStaticVehicleEx();
    // stor.pri 1186228
    SetVehicleDataAll();
    // load.pri 1186228
    return 1;
}

// AMX 0xe834
stock n_veh_CreateVehicle()
{
    Iter_CreateVehicle();
    // stor.pri 1186232
    SetVehicleDataAll();
    // load.pri 1186232
    return 1;
}

// AMX 0xe928
stock n_veh_DestroyVehicle()
{
    // if/goto jzer 0xe9c4
    // const.alt 169148
    native#1199(1200, _push.pri, 1);
    DestroyVehicleLabel();
    Iter_DestroyVehicle();
    return 1;
}

// AMX 0xe9e4
stock n_OnGameModeInit()
{
    // if/goto jump 59916
    // const.alt 1200
    // const.alt 169148
    native#1199("");
    // if/goto jump 59904
    // locals stack 4
    n_veh_OnGameModeInit();
    return 1;
}

// AMX 0xea98
stock SetVehicleParamsInit()
{
    // const.alt 270028
    native#1199();
    // const.alt 270028
    native#1199();
    // const.alt 270028
    native#1199();
    // stor.alt 36
    // const.alt 270028
    native#1199();
    // const.alt 36
    // const.alt 270028
    native#1199();
    // const.alt 270028
    native#1199();
    // const.alt 270028
    native#1199();
    // locals stack 36
    return 1;
}

// AMX 0xec30
stock GetVehicleParam()
{
    SetVehicleParamsInit();
    // const.alt 270028
    native#1199("àñ", _push.s);
    PC_Init(_push.pri);
    return 1;
}

// AMX 0xeca4
stock SetVehicleParam()
{
    SetVehicleParamsInit();
    // const.alt 270028
    native#1199("àñ", _push.s);
    PC_Init(_push.pri);
    // const.alt 270028
    native#1199();
    // const.alt 270028
    native#1199(_push.pri);
    // const.alt 270028
    native#1199(_push.pri);
    // stor.alt 9
    // const.alt 270028
    native#1199(_push.pri);
    // const.alt 9
    // const.alt 270028
    native#1199(_push.pri);
    // const.alt 270028
    native#1199(_push.pri);
    // const.alt 270028
    native#1199(_push.pri);
    // locals stack 36
    return 1;
}

// AMX 0xeecc
stock CreateVehicleLabel()
{
    // locals stack 8
    // if/goto jzer 0xefd0
    // const.alt 169148
    native#1199("àñ", _push.s);
    // locals stack 64
    return 1;
}

// AMX 0xefe0
stock UpdateVehicleLabel()
{
    // if/goto jzer 0xf0e0
    // const.alt 169148
    native#1199(1200, _push.pri, 1);
    // locals stack 8
    // if/goto jzer 0xf0e0
    // const.alt 169148
    native#1199(_push.s, _push.s, "àñ", _push.pri);
    // locals stack 16
    return 1;
}

// AMX 0xf0f0
stock DestroyVehicleLabel()
{
    // if/goto jzer 0xf224
    // const.alt 169148
    native#1199(1200, _push.pri, 1);
    // locals stack 8
    // if/goto jzer 0xf224
    // const.alt 169148
    native#1199("àñ", _push.pri);
    // locals stack 8
    // const.alt 169148
    native#1199("àñ", _push.pri);
    return 1;
}

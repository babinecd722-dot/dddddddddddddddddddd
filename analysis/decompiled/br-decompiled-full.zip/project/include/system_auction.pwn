// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_auction.pwn
// Functions: 27

// AMX 0x8c824
stock e_OnDialogResponse()
{
    // if/goto jzer 0x8d498
    // if/goto jzer 0x8d498
    // locals stack -4
    // stor.alt 44
    // locals stack -4
    // const.alt 17
    // locals stack -36
    // locals stack -4
    // const.alt 199263884
    native#1023(_push.pri, "", _push.s, "", "àñ", _push.s);
    // stor.s.pri -48
    // locals stack -4
    // const.alt 199263884
    native#1023(100);
    // stor.s.pri -52
    // locals stack -4
    // const.alt 199263884
    native#1023(_push.pri);
    // stor.s.pri -56
    // locals stack -4
    // const.alt 199263884
    native#1023();
    // stor.s.pri -60
    // if/goto jzer 0x8ca9c
    // locals stack 16
    // locals stack 60
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x8ce08
    // if/goto jump 576292
    // const.alt 9816
    GetPlayerMenu("", "");
    // stor.s.pri -68
    // const.alt 250
    // if/goto jeq 0x8cc8c
    // const.alt 181530104
    Streamer_SetIntData();
    // if/goto jeq 0x8cba8
    // if/goto jump 576288
    // const.alt 199263884
    native#1023(197904172, "9ºàñ", "9ºàñ");
    GivePlayerMoneyEx();
    // stor.s.pri -64
    // locals stack 16
    // if/goto jump 576652
    // if/goto jump 576288
    // locals stack 4
    // if/goto jzer 0x8ce00
    // locals stack -496
    // const.alt 199263884
    native#1023("l", _push.s, "", "", 1, "Äc÷ÄcÿM", _push.s, _push.pri);
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x8cdf8
    // locals stack 8
    // locals stack 560
    return 1;
    // locals stack 496
    // locals stack 4
    GivePlayerMoneyEx();
    default_select_slot();
    // const.alt 200085092
    Streamer_SetIntData("àñ", _push.s, "Äc÷ÄcÿM", _push.s, _push.pri, 197904172, "9ºàñ", "9ºàñ");
    // if/goto jump 577252
    // const.alt 6
    // const.alt 200039028
    Streamer_SetIntData("", "9ºàñ");
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 16
    // if/goto jump 577240
    // locals stack 4
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // const.alt 199263884
    native#1023();
    // if/goto jump 577620
    // const.alt 4
    // const.alt 200080092
    Streamer_SetIntData("");
    floatadd(_push.pri);
    // if/goto jzer 0x8d0d4
    // if/goto jump 577608
    // const.alt 200080092
    Streamer_SetIntData(_push.pri, 199263884);
    floatadd(_push.pri);
    native#1023();
    // const.alt 200039028
    Streamer_SetIntData();
    // const.alt 200080028
    floatadd(_push.pri);
    GetPlayerCameraFrontVector();
    // locals stack 16
    // const.alt 200080092
    Streamer_SetIntData(_push.pri, 199263884, "l", _push.s, _push.pri);
    floatadd(_push.pri);
    native#1023();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // const.alt 200080028
    floatadd(_push.pri);
    GetPlayerCameraFrontVector();
    // locals stack 16
    // const.alt 200080092
    Streamer_SetIntData(_push.pri, 199263884, "", "l", _push.s, _push.pri);
    floatadd(_push.pri);
    native#1023();
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData("l", _push.pri);
    // const.alt 200080028
    floatadd(_push.pri);
    GetPlayerCameraFrontVector();
    // locals stack 16
    // if/goto jump 577608
    // locals stack 4
    // locals stack 16
    // locals stack 60
    // if/goto jzer 0x8ddb8
    // if/goto jzer 0x8d4d8
    return 1;
    // const.alt 129
    // load.pri 129
    // stor.alt 51
    // stor.alt 51
    // stor.alt 51
    // stor.alt 51
    // stor.alt 51
    // stor.alt 51
}

// AMX 0x8fdb4
stock PlayerTextDrawAuction()
{
    // const.alt 200039028
    Streamer_SetIntData();
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 200039028
    Streamer_SetIntData("", "");
}

// AMX 0x98de8
stock e_OnGameModeInit()
{
    // if/goto jump 626192
    // const.alt 200
    // const.alt 195566420
    SetActorVirtualWorld("");
    // if/goto jzer 0x98e74
    // if/goto jump 626180
    // locals stack 16
    // if/goto jump 626364
    // if/goto jump 626180
    // locals stack 4
    // locals stack 64
    // if/goto jgrtr 0x2c
    // stor.pri 199262724
    // if/goto jgrtr 0x2c
    // stor.pri 199262728
    // locals stack 48
    // locals stack 48
    // locals stack 36
    defualt_slot();
    // locals stack 16
    auc_OnGameModeInit();
    return 1;
}

// AMX 0x991c4
stock e_OnPlayerConnect()
{
    // const.alt 39
    // locals stack 24
    auc_OnPlayerConnect();
    return 1;
}

// AMX 0x99230
stock pc_cmd_tpa()
{
    // const.alt 39
    return 1;
}

// AMX 0x99284
stock e_OnPlayerEnterDynamicArea()
{
    // load.pri 199262724
    // if/goto jneq 0x992fc
    SetPlayerPosEx();
    // load.pri 199262728
    // if/goto jneq 0x9936c
    SetPlayerPosEx();
    auc_OnPlayerEnterDynamicArea();
    return 1;
}

// AMX 0x99394
stock default_select_slot()
{
    // const.alt 200085092
    Streamer_SetIntData();
    // if/goto jzer 0x99670
    // locals stack -80
    // stor.alt 137
    // const.alt 200085092
    Streamer_SetIntData("l", _push.pri, 200100092, "Äc÷ÄcÿM");
    // const.alt 200039028
    Streamer_SetIntData();
    // locals stack 16
    // if/goto jump 628328
    // const.alt 200039028
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 16
    // if/goto jump 628328
    // const.alt 200039028
    Streamer_SetIntData("l", _push.s, _push.pri, _push);
    // if/goto jneq 0x9
    // locals stack 16
    // if/goto jump 628328
    // const.alt 200039028
    Streamer_SetIntData("l", _push.s, _push.pri);
    // locals stack 16
    // if/goto jump 628328
}

// AMX 0x99680
public OnPlayerClickPlayerTextDraw()
{
    // const.alt 200039028
    Streamer_SetIntData();
    // locals stack 12
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "", "", _push.pri);
    // if/goto jneq 0x99dac
    default_select_slot();
    // locals stack -4
    // const.alt 200080092
    Streamer_SetIntData("àñ", _push.s);
    // const.alt 9
    // stor.s.pri -4
    // if/goto jzer 0x997c0
    // locals stack 4
    return 1;
    // const.alt 199263884
    native#1023();
    // const.alt 200039028
    Streamer_SetIntData();
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199262732, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199263376, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // locals stack -52
    // if/goto jrel 137
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // stor.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("àñ", "l", _push.s, _push.pri);
    // locals stack 16
    ConvertUnixTime();
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.alt, "", _push.pri, "l", _push.alt, _push.alt, _push.alt, _push.pri);
    // locals stack 16
    // const.alt 200085092
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, 4);
    // locals stack 16
    // locals stack 56
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "l", _push.s, _push.pri);
    // if/goto jneq 0x9a478
    default_select_slot();
    // locals stack -4
    // const.alt 200080092
    Streamer_SetIntData("àñ", _push.s, _push);
    // stor.s.pri -4
    // if/goto jzer 0x99e8c
    // locals stack 4
    return 1;
    // const.alt 199263884
    native#1023();
    // const.alt 200039028
    Streamer_SetIntData();
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199262732, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199263376, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // locals stack -52
    // if/goto jrel 137
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // stor.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("àñ", "l", _push.s, _push.pri);
    // locals stack 16
    ConvertUnixTime();
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.alt, "", _push.pri, "l", _push.alt, _push.alt, _push.alt, _push.pri);
    // locals stack 16
    // const.alt 200085092
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, 1);
    // locals stack 16
    // locals stack 56
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "l", _push.s, _push.pri, _push);
    // if/goto jneq 0x9
    // if/goto jneq 0x9ab4c
    default_select_slot();
    // locals stack -4
    // const.alt 200080092
    Streamer_SetIntData("àñ", _push.s);
    // stor.s.pri -4
    // if/goto jzer 0x9a560
    // locals stack 4
    return 1;
    // const.alt 199263884
    native#1023();
    // const.alt 200039028
    Streamer_SetIntData();
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199262732, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199263376, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // locals stack -52
    // if/goto jrel 137
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // stor.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("àñ", "l", _push.s, _push.pri);
    // locals stack 16
    ConvertUnixTime();
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.alt, "", _push.pri, "l", _push.alt, _push.alt, _push.alt, _push.pri);
    // locals stack 16
    // const.alt 200085092
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, 2);
    // if/goto jneq 0x9
    // locals stack 16
    // locals stack 56
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "l", _push.s, _push.pri);
    // if/goto jneq 0x9b220
    default_select_slot();
    // locals stack -4
    // const.alt 200080092
    Streamer_SetIntData("àñ", _push.s);
    // stor.s.pri -4
    // if/goto jzer 0x9ac34
    // locals stack 4
    return 1;
    // const.alt 199263884
    native#1023();
    // const.alt 200039028
    Streamer_SetIntData();
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199262732, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.pri, 199263376, "l", _push.s, _push.pri);
    PC_Init();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri);
    // locals stack 16
    // locals stack -52
    // if/goto jrel 137
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // const.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("l", _push.s, _push.pri);
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.pri);
    // stor.alt 9
    // locals stack 16
    // const.alt 199263884
    native#1023("àñ", "l", _push.s, _push.pri);
    // locals stack 16
    ConvertUnixTime();
    // locals stack 20
    // const.alt 200039028
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push.alt, "", _push.pri, "l", _push.alt, _push.alt, _push.alt, _push.pri);
    // locals stack 16
    // const.alt 200085092
    Streamer_SetIntData("l", _push.s, _push.pri);
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, 3);
    // locals stack 16
    // locals stack 56
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "l", _push.s, _push.pri);
    // if/goto jneq 0x9b28c
    ShowTabBuy();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "àñ", _push.s);
    // if/goto jneq 0x9b2f8
    ShowTabSell();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "àñ", _push.s);
    // if/goto jneq 0x9b364
    ShowTabMy();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "àñ", _push.s);
    // if/goto jneq 0x9b3d0
    HideTextDrawAuction();
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "àñ", _push.s);
    // if/goto jneq 0x9b568
    // const.alt 200085092
    Streamer_SetIntData();
    return 1;
    // if/goto jzer 0x9b49c
    // locals stack 16
    return 1;
    // const.alt 200085092
    Streamer_SetIntData();
    // locals stack 9
    // if/goto jzer 0x9b4e8
    return 1;
    Dialog();
    // stor.alt 137
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "l", _push.s, "", "àñ", "M", _push.s, "", "9ºàñ", "", "", "", "");
    // if/goto jneq 0x9bd10
    // const.alt 200085092
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData(_push.pri);
    // const.alt 200085092
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData(_push);
    // locals stack 34
    // const.alt 200085092
    Streamer_SetIntData();
    // if/goto jrel 34
    // const.alt 200085092
    Streamer_SetIntData();
    return 1;
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092);
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, "l", _push.s, _push.pri);
    // locals stack 16
    // stor.alt 34
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, "l", _push.s, _push.pri);
    // locals stack 16
    // if/goto jump 637368
    // const.alt 6
    // const.alt 200039028
    Streamer_SetIntData("", "9ºàñ", "l", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 16
    // if/goto jump 637356
    // locals stack 4
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    // const.alt 53
    call_unknown();
    // locals stack 12
    // const.alt 53
    call_unknown();
    // locals stack 12
    // const.alt 53
    call_unknown();
    // locals stack 12
    // const.alt 53
    call_unknown();
    // locals stack 12
    // const.alt 53
    call_unknown();
    // locals stack 12
    Dialog();
    // stor.alt 137
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, "l", _push.s, "", "9ºàñ", "M", _push.s, "", "ºàñ", "", "", "", "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "l", _push.s, _push.pri);
    // if/goto jneq 0x9d028
    // const.alt 200085092
    Streamer_SetIntData();
    // if/goto jzer 0x9bddc
    // locals stack 16
    return 1;
    // const.alt 200085092
    Streamer_SetIntData();
    // if/goto jrel 9
    // if/goto jzer 0x9be28
    return 1;
    // locals stack -1136
    // const.alt 129
    // const.alt 181530104
    Streamer_SetIntData("", _push.s, "");
    // const.alt 65535
    // if/goto jeq 0x9c10c
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -1140
    // locals stack -4
    // stor.s.pri -1144
    // locals stack -4
    // const.alt 169148
    native#1199("àñ", _push.s);
    // stor.s.pri -1148
    // const.alt 182230856
    native#14999(_push);
    // stor.alt 137
    // stor.alt 137
    // const.alt 182230856
    native#14999("l", _push.s, "", _push.s, "l", _push.s, "", _push.pri);
    // const.alt 308428
    native#2089(_push.pri);
    // locals stack 24
    Dialog();
    // locals stack 12
    // if/goto jump 639296
    // locals stack 16
    // if/goto jump 643104
    GetPlayerBusiness();
    // const.alt -1
    // if/goto jeq 0x9c314
    // locals stack -4
    GetPlayerBusiness();
    // stor.s.pri -1140
    // locals stack -4
    // const.alt 195566420
    SetActorVirtualWorld("àñ", _push.s, "àñ", _push.s, "l", _push.s, "", "", "M", _push.s, "l'", "", "", "", "", _push.alt, "Äc÷ÄcÿM", ",", "", _push.pri);
    // stor.s.pri -1144
    // stor.alt 137
    // stor.alt 137
    // const.alt 195566420
    SetActorVirtualWorld("l", _push.s, "", _push.s, "l", _push.s, "", _push.s);
    // locals stack 24
    Dialog();
    // locals stack 8
    // if/goto jump 639816
    // locals stack 16
    // if/goto jump 643104
    GetPlayerHouse();
    // const.alt -1
    // if/goto jeq 0x9c4f8
    // locals stack -4
    GetPlayerHouse();
    // stor.s.pri -1140
    // locals stack -4
    // const.alt 194655224
    native#899("", _push.s, "", "", _push.s, "", "l", _push.s, "", "", "M", _push.s, "l'", "", "", "", "", _push.alt, "Äc÷ÄcÿM", ",", "");
    // stor.s.pri -1144
    // stor.alt 137
    // stor.alt 137
    // locals stack 20
    Dialog();
    // locals stack 8
    // if/goto jump 640300
    // locals stack 16
    // if/goto jump 643104
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", "", "M", _push.s, "l'", "", "", "", "", _push.alt, "¼ý;", ",", "", "l", _push.s, "", _push.s, "l", _push.s, "", _push.s);
    // if/goto jzer 0x9c688
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -1140
    // stor.alt 137
    // locals stack 20
    Dialog();
    // locals stack 4
    // if/goto jump 640700
    // locals stack 16
    // if/goto jump 643104
    // const.alt 181530104
    Streamer_SetIntData("", "l", _push.s, "", "", "M", _push.s, "l'", "", "", "", "", _push.alt, "¼ý;", ",", "", "l", _push.s, "", _push.s);
    // locals stack 24
    // locals stack 16
    // stor.s.pri -1140
    // locals stack 8
    // if/goto jzer 0x9c7d0
    // locals stack 8
    // locals stack 1140
    return 1;
    // locals stack 8
    // if/goto jzer 0x9c840
    // locals stack 16
    // locals stack 1140
    return 1;
    // locals stack -4
    // locals stack 8
    // stor.s.pri -1144
    // locals stack -216
    // locals stack -28
    // locals stack 16
    // if/goto jump 641296
    // locals stack 16
    // stor.s.pri -1364
    // locals stack 16
    // const.alt 400
    // stor.s.pri -1368
    // locals stack 24
    // const.alt 308428
    native#2089(_push, "Äc÷ÄcÿM", _push.s, "", "9ºàñ", "", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "", _push.alt, "l", ",", "", "", "", "àñ", "9ºàñ");
    // load.pri 45
    // locals stack 28
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", ",", _push.alt, "ÄcÿM", "", "", _push.alt, _push.pri);
    native#1023(_push.pri);
    // locals stack 16
    // if/goto jump 641284
    // locals stack 4
    Dialog();
    // locals stack 260
    // if/goto jump 643104
    // const.alt 181530104
    Streamer_SetIntData("", "M", _push.s, "l'", "ºàñ", "", "", "", "l", "");
    // locals stack 20
    // locals stack 16
    // stor.s.pri -1140
    // locals stack 8
    // if/goto jzer 0x9ccb0
    // locals stack 8
    // locals stack 1140
    return 1;
    // locals stack 8
    // if/goto jzer 0x9cd20
    // locals stack 16
    // locals stack 1140
    return 1;
    // locals stack -4
    // locals stack 8
    // stor.s.pri -1144
    // locals stack -216
    // locals stack 16
    // if/goto jump 642516
    // locals stack 16
    // stor.s.pri -1364
    // locals stack 16
    // stor.s.pri -1368
    // const.alt 198017980
    SetPlayerWantedLevel("l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", "", _push.alt, "l", ",", "", "", "", "àñ", "9ºàñ");
    // load.pri 45
    // locals stack 24
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", ",", _push.alt, "Äc÷ÄcÿM", "", "", _push.alt, _push.pri);
    native#1023(_push.pri);
    // if/goto jump 642504
    // locals stack 4
    Dialog();
    // locals stack 232
    // if/goto jump 643104
}

// AMX 0x9f1f0
stock pc_cmd_auction()
{
    // locals stack 16
    // if/goto jzer 0x9f2dc
    // locals stack 16
    // locals stack 4
    return 1;
    // locals stack 8
    // const.alt 183
    // if/goto jeq 0x9f36c
    EnablePlayerGPS();
    // locals stack 4
    return 1;
    HideTextDrawAuction();
    // const.alt 200038028
    Streamer_SetIntData("àñ", _push.s);
    // locals stack 16
    HideHud();
    SetPlayerCleanChat();
    SetPlayerCleanChat();
    ShowTabBuy();
    // locals stack 4
    return 1;
}

// AMX 0x9f4ac
stock HideTextDrawAuction()
{
    ShowHud();
    SetPlayerCleanChat();
    default_select_slot();
    // const.alt 200085092
    Streamer_SetIntData("àñ", _push.s, "", _push.s, "", "àñ", _push.s);
    // stor.alt 9
    HideTabBuy();
    // if/goto jump 652768
    HideTabSell();
    // if/goto jump 652768
    HideTabMy();
    // if/goto jump 652768
}

// AMX 0x9f9a0
stock ShowTabBuy()
{
    // locals stack -4
    // locals stack 16
    // stor.s.pri -4
    // const.alt 200038028
    Streamer_SetIntData("l", _push.alt, _push.alt, _push.alt);
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 200038028
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData(_push.pri);
    // stor.alt 9
    HideTabSell();
    // if/goto jump 654224
    HideTabMy();
    // if/goto jump 654224
    // locals stack 4
    return 1;
    // if/goto jump 654224
}

// AMX 0xa033c
stock ShowTabSell()
{
    // locals stack -4
    // locals stack 16
    // stor.s.pri -4
    // const.alt 200038028
    Streamer_SetIntData("l", _push.alt, _push.alt, _push.alt);
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 200038028
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData(_push.pri);
    // stor.alt 9
    HideTabBuy();
    // if/goto jump 656676
    HideTabMy();
    // if/goto jump 656676
    // locals stack 4
    return 1;
    // if/goto jump 656676
}

// AMX 0xa0c74
stock HideTabSell()
{
    // locals stack 8
    // const.alt 200085092
    Streamer_SetIntData("àñ", _push.s);
    // const.alt 200085092
    Streamer_SetIntData(_push);
    // locals stack 34
    // const.alt 200085092
    Streamer_SetIntData();
    // if/goto jrel 34
    // const.alt 200085092
    Streamer_SetIntData();
    return 1;
    // const.alt 200039028
    Streamer_SetIntData();
    // if/goto jump 
    // locals stack 12
    // const.alt 200039028
    Streamer_SetIntData("", "", _push.s, _push.pri);
    // const.alt 9
    // locals stack 16
    // if/goto jump 659072
    // const.alt 6
    // const.alt 200039028
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 12
    // if/goto jump 659060
    // locals stack 4
    // const.alt 200039028
    Streamer_SetIntData("", _push.s, _push.pri);
    // locals stack 12
    // if/goto jump 659348
    // const.alt 33
    // const.alt 200039028
    Streamer_SetIntData("M", "", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 12
    // if/goto jump 659336
    // locals stack 4
    // if/goto jump 659532
    // const.alt 27
    // const.alt 200039028
    Streamer_SetIntData("ÄcÿM", "", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 12
    // if/goto jump 659520
    // locals stack 4
    return 1;
}

// AMX 0xa10f4
stock HideTabBuy()
{
    default_select_slot();
    // locals stack 8
    // const.alt 200085092
    Streamer_SetIntData("àñ", _push.s, "àñ", _push.s);
    // const.alt 200085092
    Streamer_SetIntData(1);
    // const.alt 200085092
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData();
    // const.alt 34
    // const.alt 200085092
    Streamer_SetIntData();
    // stor.alt 34
    // const.alt 200085092
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData(-1);
    // if/goto jump 660256
    // const.alt 39
    // const.alt 200039028
    Streamer_SetIntData("", -1);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 12
    // if/goto jump 660244
    // locals stack 4
    // if/goto jump 660440
    // const.alt 28
    // const.alt 200039028
    Streamer_SetIntData("", "", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 12
    // if/goto jump 660428
    // locals stack 4
    return 1;
}

// AMX 0xa1480
stock HideTabMy()
{
    // locals stack 8
    // const.alt 200039028
    Streamer_SetIntData("àñ", _push.s);
    // locals stack 12
    // if/goto jump 660768
    // const.alt 27
    // const.alt 200039028
    Streamer_SetIntData("ÄcÿM", "", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 12
    // if/goto jump 660756
    // locals stack 4
    // const.alt 200039028
    Streamer_SetIntData("", _push.s, _push.pri);
    GetPlayerAnimationIndex("¼ý;", _push.s, "", "", "", _push.pri);
    // const.alt 200039028
    Streamer_SetIntData("", "");
}

// AMX 0xa2908
stock ShowTabMy()
{
    // locals stack -4
    // locals stack 16
    // stor.s.pri -4
    // const.alt 200038028
    Streamer_SetIntData("l", _push.alt, _push.alt, _push.alt);
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 200038028
    Streamer_SetIntData();
    // const.alt 200085092
    Streamer_SetIntData(_push.pri);
    // stor.alt 9
    HideTabBuy();
    // if/goto jump 666352
    HideTabSell();
    // if/goto jump 666352
    // locals stack 4
    return 1;
    // if/goto jump 666352
}

// AMX 0xa3fc4
stock AuctionUpdate()
{
    // load.pri 199263880
    // if/goto jzer 0xa402c
    // locals stack 16
    LoadBusinessToAuction();
    // locals stack 16
    // if/goto jump 671916
    // const.alt 1024
    // const.alt 199263884
    native#1023("", "l", _push.alt, _push.alt, "", "", _push.alt, "l", "", "tÖ", "9ºàñ");
    // if/goto jzer 0xa410c
    // if/goto jump 671904
    // const.alt 199263884
    native#1023();
    // locals stack 16
    finish_auction_slot();
    // if/goto jump 672284
    // const.alt 199263884
    native#1023("àñ", _push.s, "l", _push.alt, _push.alt, _push.alt, _push.pri);
    // if/goto jump 671904
    // locals stack 4
    // locals stack 4
    return 1;
}

// AMX 0xa4244
stock create_auction_slot()
{
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, "", "");
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, "l", _push.s, _push.pri);
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, "l", _push.s, _push.pri);
    // locals stack 16
    // stor.alt 34
    // const.alt 200039028
    Streamer_SetIntData(_push.pri, 200100092, "l", _push.s, _push.pri);
    // locals stack 16
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    // if/goto jump 673236
    // const.alt 6
    // const.alt 200039028
    Streamer_SetIntData("", "9ºàñ", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "", _push.s, "", "l", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 16
    // if/goto jump 673224
    // locals stack 4
    // if/goto jump 673428
    // const.alt 1024
    // const.alt 199263884
    native#1023("", "l", _push.s, _push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa49b8
    // const.alt 199263884
    native#1023();
    // if/goto jneq 0xa47c4
    // const.alt 199263884
    native#1023();
    // if/goto jneq 0xa47c4
    // if/goto jump 673736
    // if/goto jzer 0xa4834
    // const.alt 199263884
    native#1023(1);
    // if/goto jneq 0xa4834
    // stor.s.pri -8
    // if/goto jump 674240
    // const.alt 199263884
    native#1023(1);
    // const.alt 199263884
    native#1023("9ºàñ", "");
    // locals stack 20
    // const.alt -1
    // if/goto jeq 0xa490c
    // stor.s.pri -8
    // if/goto jump 674240
    // const.alt 199263884
    native#1023(1, _push.pri, "¼ý;", _push.s, _push.pri);
    // const.alt 199263884
    native#1023();
    // if/goto jneq 0xa49b8
    // stor.s.pri -8
    // if/goto jump 674240
    // if/goto jump 673416
    // locals stack 4
    // if/goto jzer 0xa4a1c
    // locals stack 16
    // locals stack 8
    return 1;
    // if/goto jump 674364
    // const.alt 1024
    // const.alt 199263884
    native#1023("");
    // const.alt 1
    // if/goto jump 674352
    // stor.s.pri -4
    // if/goto jump 674504
    // if/goto jump 674352
    // locals stack 4
    // if/goto jzer 0xa4b2c
    // locals stack 16
    // locals stack 8
    return 1;
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 199263884
    native#1023("ÄcÿM", _push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023("ú*", _push.s, _push.alt, "l");
    // locals stack 16
    // locals stack 16
    // locals stack -4
    // const.alt 22
    // stor.s.pri -16
    // locals stack 16
    // locals stack -4
    // const.alt 22
    // stor.s.pri -32
    // locals stack -4
    // const.alt 59
    // stor.s.pri -36
    // locals stack -4
    // const.alt 59
    // stor.s.pri -40
    // locals stack -4
    // if/goto jgeq 0x2b
    // const.alt 3
    // stor.s.pri -44
    // const.alt 199263884
    native#1023(_push.pri, "l", "", "", "", "l", _push.alt, _push.alt, "", _push.alt, "l", _push.pri);
    // locals stack 16
    // locals stack 28
    // if/goto jump 676124
    // const.alt 199263884
    native#1023("l", _push.alt, _push.alt, _push.alt, _push.pri);
    // locals stack 16
    // if/goto jump 676124
}

// AMX 0xa57dc
stock finish_auction_slot()
{
    // const.alt 199263884
    native#1023();
    // if/goto jzer 0xa5848
    reset_slot_auction();
    // if/goto jump 677996
    // const.alt 9816
    GetPlayerMenu("", "", "àñ", _push.s);
    // stor.s.pri -8
    // const.alt 250
    // if/goto jeq 0xa59ec
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa59e4
    // locals stack 16
    // stor.s.pri -4
    // const.alt 199263884
    native#1023(197904172, "9ºàñ", "9ºàñ", 1, "l", _push.s, "", "");
    GivePlayerMoneyEx();
    // if/goto jump 677992
    // locals stack 4
    // locals stack -512
    // if/goto jzer 0xa5b60
    // const.alt 199263884
    native#1023("Äc÷ÄcÿM", _push.s, _push.pri);
    // const.alt 199263884
    native#1023();
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa5b60
    // locals stack 8
    // locals stack 516
    return 1;
    // const.alt 199263884
    native#1023();
    // if/goto jump 678832
    // const.alt 9816
    GetPlayerMenu("");
    // stor.s.pri -520
    // const.alt 250
    // if/goto jeq 0xa5c94
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa5c8c
    // locals stack 16
    // if/goto jump 678828
    // locals stack 4
    // const.alt 199263884
    native#1023(_push.s, "l", _push.s, "", "");
    AuctionBusiness();
    // if/goto jump 683596
    // if/goto jump 679184
    // const.alt 9816
    GetPlayerMenu("", "", _push.pri);
    // stor.s.pri -520
    // const.alt 250
    // if/goto jeq 0xa5df4
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa5dec
    // locals stack 16
    // if/goto jump 679180
    // locals stack 4
    // const.alt 199263884
    native#1023("l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    AuctionHouse();
    // if/goto jump 683596
    // if/goto jump 679592
    // const.alt 9816
    GetPlayerMenu("", "l", _push.s, _push.pri);
    // stor.s.pri -520
    // const.alt 250
    // if/goto jeq 0xa5f8c
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa5f84
    // locals stack 16
    // if/goto jump 679588
    // locals stack 4
    // const.alt 199263884
    native#1023("l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 28
    // locals stack 16
    reset_slot_auction();
    // locals stack 8
    // if/goto jzer 0xa60e4
    // locals stack 8
    // locals stack 516
    return 1;
    // if/goto jump 683596
    // if/goto jump 680196
    // const.alt 9816
    GetPlayerMenu("");
    // stor.s.pri -520
    // const.alt 250
    // if/goto jeq 0xa6290
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 199263884
    native#1023(_push.pri);
    // if/goto jneq 0xa61e0
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    // if/goto jneq 0xa6288
    // locals stack 16
    // if/goto jump 680192
    // locals stack 4
    // const.alt 199263884
    native#1023("l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa63cc
    // locals stack 8
    // locals stack 516
    return 1;
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa6500
    // locals stack 8
    // locals stack 516
    return 1;
    reset_slot_auction();
    // if/goto jump 683596
    // if/goto jump 681276
    // const.alt 9816
    GetPlayerMenu("", "àñ", _push.s);
    // stor.s.pri -520
    // const.alt 250
    // if/goto jeq 0xa677c
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 199263884
    native#1023(_push.pri);
    // if/goto jneq 0xa668c
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    // if/goto jneq 0xa6774
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 16
    // if/goto jump 681272
    // locals stack 4
    // const.alt 199263884
    native#1023("l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa68b8
    // locals stack 8
    // locals stack 516
    return 1;
    // const.alt 199263884
    native#1023();
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa69b8
    // locals stack 8
    // locals stack 516
    return 1;
    reset_slot_auction();
    // if/goto jump 683596
    // if/goto jump 682484
    // const.alt 9816
    GetPlayerMenu("", "àñ", _push.s);
    // stor.s.pri -520
    // const.alt 250
    // if/goto jeq 0xa6b80
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 199263884
    native#1023(_push.pri);
    // if/goto jneq 0xa6ad0
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    // if/goto jneq 0xa6b78
    // locals stack 16
    // if/goto jump 682480
    // locals stack 4
    // locals stack -576
    // const.alt 199263884
    native#1023("", "l", _push.s, "", "");
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa6ce4
    // locals stack 8
    // locals stack 1096
    return 1;
    // const.alt 199263884
    native#1023();
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa6de4
    // locals stack 8
    // locals stack 1096
    return 1;
    reset_slot_auction();
    // locals stack 580
    // if/goto jump 683596
}

// AMX 0xa6e64
stock reset_slot_auction()
{
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023("ÄcÿM", "", -1);
    // locals stack 16
    // const.alt 199263884
    native#1023("8", "", _push.alt, "l");
    // locals stack 16
    // const.alt 199263884
    native#1023("ú*", "", _push.alt, "l", _push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023("", "", _push.alt, "l", _push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.alt, "l", _push.pri);
    // const.alt 199263884
    native#1023(-1);
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023(-1);
    // const.alt 199263884
    native#1023(-1);
    return 1;
}

// AMX 0xa7244
stock AuctionBusiness()
{
    // locals stack -1024
    // locals stack -4
    // const.alt 199263884
    native#1023("");
    // stor.s.pri -1032
    // if/goto jump 684756
    // const.alt 9816
    GetPlayerMenu("");
    // stor.s.pri -1036
    // const.alt 250
    // if/goto jeq 0xa736c
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa7364
    // stor.s.pri -1028
    // if/goto jump 684752
    // locals stack 4
    // if/goto jump 684940
    // const.alt 9816
    GetPlayerMenu("");
    // stor.s.pri -1036
    // const.alt 250
    // if/goto jeq 0xa7480
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa7478
    // const.alt 181530104
    Streamer_SetIntData();
    // if/goto jump 684936
    // locals stack 4
    // const.alt 199263884
    native#1023(-1);
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa7588
    // locals stack 8
    // locals stack 1032
    return 1;
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 133
    // const.alt 133
    // locals stack 36
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa7698
    // locals stack 8
    // locals stack 1032
    return 1;
    // locals stack 12
    // locals stack 8
    // if/goto jzer 0xa8008
    // const.alt 181530104
    Streamer_SetIntData("àñ", "9ºàñ", "", "");
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1036
    // locals stack -4
    // stor.s.pri -1040
    // const.alt 195566420
    SetActorVirtualWorld(86400, _push.pri, "l", _push.alt, _push.alt, _push.alt);
    // const.alt 195566420
    SetActorVirtualWorld(20);
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // locals stack -96
    // const.alt 39
    // locals stack 24
    // locals stack 16
    // stor.s.pri -1140
    // locals stack 8
    // if/goto jzer 0xa7b40
    // locals stack 8
    // locals stack 1140
    return 1;
    // if/goto jump 
    // locals stack 24
    // locals stack 8
    // if/goto jzer 0xa7be0
    // locals stack 8
    // locals stack 1140
    return 1;
    // const.alt 195566420
    SetActorVirtualWorld("c÷ÄcÿM", _push.alt);
    // locals stack 20
    // stor.alt 137
    // locals stack 12
    // locals stack 16
    // const.alt 195566420
    SetActorVirtualWorld("l", _push.s, "", "", "", _push.s, "9ºàñ", "l", "", "", _push.alt, "¼ý;", _push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // locals stack 40
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa7ee4
    // locals stack 8
    // locals stack 1140
    return 1;
    // const.alt 195566420
    SetActorVirtualWorld();
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa7fd4
    // locals stack 8
    // locals stack 1140
    return 1;
    reset_slot_auction();
    // locals stack 1140
    return 1;
    // locals stack 1032
    return 1;
}

// AMX 0xa801c
stock SetBusinessName()
{
    // locals stack -496
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa8564
    // locals stack 8
    // locals stack 496
    return 1;
}

// AMX 0xa8574
stock LoadBusinessToAuction()
{
    // stor.pri 199263880
    // locals stack -456
    // locals stack 20
    // locals stack 16
    // stor.s.pri -460
    // locals stack 8
    // if/goto jzer 0xa868c
    // locals stack 8
    // locals stack 460
    return 1;
    // locals stack 8
    // if/goto jzer 0xa86e8
    // locals stack 8
    // locals stack 460
    return 1;
    // locals stack -4
    // locals stack 8
    // stor.s.pri -464
    // if/goto jzer 0xa8754
    // locals stack 468
    return 1;
    // if/goto jump 690036
    // const.alt 199263884
    native#1023("");
    // if/goto jzer 0xa87d0
    // if/goto jump 690024
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023(1);
    // const.alt 199263884
    native#1023(-2);
    // const.alt 199263884
    native#1023("ÄcÿM", "", -1);
    // locals stack 16
    // const.alt 199263884
    native#1023(_push, "ÄcÿM", _push.alt, "l");
    // locals stack 24
    // const.alt 199263884
    native#1023(_push, "Äc÷ÄcÿM", _push.s, "", _push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023("l", _push.s, "", "9ºàñ", _push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023("l", _push.s, "", "9ºàñ", _push.pri);
    // const.alt 199263884
    native#1023(_push.pri);
    // locals stack 16
    // locals stack -4
    // const.alt 21
    // stor.s.pri -488
    // locals stack -4
    // const.alt 59
    // stor.s.pri -492
    // locals stack -4
    // const.alt 59
    // stor.s.pri -496
    // locals stack -4
    // if/goto jgeq 0x2b
    // const.alt 10
    // stor.s.pri -500
    // const.alt 3600
    // stor.s.pri -500
    // const.alt 199263884
    native#1023(1800, _push.pri, "l", "", "", "");
    // locals stack 16
    // if/goto jump 691408
    // const.alt 200
    // const.alt 195566420
    SetActorVirtualWorld("", "l", _push.alt, _push.alt, _push.alt, _push.pri);
    // const.alt 199263884
    native#1023(_push.pri);
    // if/goto jneq 0xa8e14
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023("ú*", "");
    // locals stack 20
    // if/goto jump 691740
    // if/goto jump 691396
    // locals stack 4
    // locals stack 28
    // if/goto jump 690024
    // locals stack 4
    // locals stack 12
    // locals stack 12
    // locals stack 468
    return 1;
}

// AMX 0xa8eb8
stock defualt_slot()
{
    // if/goto jump 691936
    // const.alt 1024
    // const.alt 199263884
    native#1023("");
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023("ÄcÿM", "", -1);
    // locals stack 16
    // const.alt 199263884
    native#1023("ÄcÿM", "", _push.alt, "l");
    // locals stack 16
    // const.alt 199263884
    native#1023("ú*", "", _push.alt, "l", _push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023("", "", _push.alt, "l", _push.pri);
    // locals stack 16
    // const.alt 199263884
    native#1023(_push.alt, "l", _push.pri);
    // const.alt 199263884
    native#1023(-1);
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // const.alt 199263884
    native#1023();
    // if/goto jump 691924
    // locals stack 4
    return 1;
}

// AMX 0xa92d0
stock AuctionHouse()
{
    // locals stack -1024
    // if/goto jump 693008
    // const.alt 9816
    GetPlayerMenu("");
    // stor.s.pri -1028
    // const.alt 250
    // if/goto jeq 0xa9448
    // const.alt 199263884
    native#1023();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0xa9440
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData(-1);
    // if/goto jump 693004
    // locals stack 4
    // const.alt 199263884
    native#1023(-1);
    // locals stack 24
    // locals stack 16
    // const.alt 194655224
    native#899("l", _push, "", "Äc÷ÄcÿM", _push, "D ", "");
    // stor.alt 133
    // stor.alt 133
    // locals stack 36
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa9618
    // locals stack 8
    // locals stack 1024
    return 1;
    // locals stack 12
    // locals stack 8
    // if/goto jzer 0xa9e90
    // if/goto jump 693900
    // const.alt 9816
    GetPlayerMenu("", "àñ", "9ºàñ", "", "");
    // stor.s.pri -1028
    // const.alt 250
    // if/goto jeq 0xa9790
    // const.alt 181530104
    Streamer_SetIntData();
    // if/goto jneq 0xa9788
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData();
    // if/goto jump 693896
    // locals stack 4
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1028
    // locals stack -4
    // stor.s.pri -1032
    // const.alt 194655224
    native#899(86400, _push.pri, "l", _push.alt, _push.alt, _push.alt);
    // const.alt 194655224
    native#899();
    // locals stack -4
    // const.alt 194655224
    native#899();
    // stor.s.pri -1036
    // const.alt -1
    // if/goto jeq 0xa9ab0
    // stor.alt 137
    // locals stack -96
    // stor.alt 39
    // locals stack 24
    // locals stack 16
    // stor.s.pri -1040
    // locals stack 8
    // if/goto jzer 0xa9bb4
    // locals stack 8
    // locals stack 1136
    return 1;
    // locals stack 24
    // const.alt 194655224
    native#899("c÷ÄcÿM", _push.alt, _push, "Äc÷ÄcÿM", "", "", _push, "ÄcÿM");
    // locals stack 20
    // locals stack 12
    UpdateHouse();
    HouseHealthInit();
    HouseStoreInit();
    // const.alt 194655224
    native#899("", _push.s, "", "", _push.s, "", "àñ", _push.s, "", _push.s, "9ºàñ", _push.alt, "¼ý;", _push.pri);
    // const.alt 194655224
    native#899(_push.pri);
    // const.alt 194655224
    native#899(_push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0xa9e5c
    // locals stack 8
    // locals stack 1136
    return 1;
    reset_slot_auction();
    // locals stack 1136
    return 1;
    // locals stack 1024
    return 1;
}

// AMX 0xa9ea4
stock LeafAuction()
{
    // if/goto jump 696012
    // const.alt 4
    // const.alt 200080092
    Streamer_SetIntData("");
    floatadd(_push.pri);
    // if/goto jump 696000
    // locals stack 4
    // if/goto jump 696172
    // const.alt 4
    // const.alt 200039028
    Streamer_SetIntData("", "", -1);
    // const.alt 200080028
    floatadd(_push.pri);
    GetPlayerCameraFrontVector();
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // const.alt 200080028
    floatadd(_push.pri);
    GetPlayerCameraFrontVector();
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // const.alt 200080028
    floatadd(_push.pri);
    GetPlayerCameraFrontVector();
    // locals stack 16
    // if/goto jump 696160
    // locals stack 4
    // if/goto jump 696728
    // const.alt 6
    // const.alt 200039028
    Streamer_SetIntData("", "9ºàñ", "l", _push.s, _push.pri);
    GetPlayerCameraFrontVector(_push.pri);
    // locals stack 16
    // if/goto jump 696716
    // locals stack 4
    default_select_slot();
    // const.alt 200085092
    Streamer_SetIntData("àñ", _push.s, "l", _push.s, _push.pri);
    // if/goto jump 697012
    // const.alt 4
    // const.alt 200080092
    Streamer_SetIntData("");
    floatadd(_push.pri);
    // if/goto jump 697000
    // locals stack 4
    // locals stack -36
    // const.alt 200085092
    Streamer_SetIntData("", _push.pri, -1);
    // locals stack 16
    // const.alt 200039028
    Streamer_SetIntData("l", _push.pri);
    // locals stack 16
    // locals stack -4096
    // locals stack -4
    // const.alt 200085092
    Streamer_SetIntData("", "l", _push.s, _push.pri);
    // stor.s.pri -4140
    // locals stack -4
    // const.alt 200085092
    Streamer_SetIntData();
    // stor.s.pri -4144
    // if/goto jump 697580
    // const.alt 1024
    // const.alt 199263884
    native#1023("");
    // if/goto jzer 0xaa54c
    // if/goto jump 697568
    // const.alt 199263884
    native#1023();
    // const.alt 200085092
    Streamer_SetIntData(_push.pri);
    // if/goto jeq 0xaa63c
    // const.alt 199263884
    native#1023(_push.pri);
    // const.alt 2
    // if/goto jeq 0xaa63c
    // if/goto jump 697920
    // if/goto jzer 0xaa654
    // if/goto jump 697568
    // if/goto jump 698428
    // const.alt 199263884
    native#1023(1);
    // const.alt 1
    // if/goto jeq 0xaa6a8
    // if/goto jump 697568
    // if/goto jump 698428
    // const.alt 199263884
    native#1023();
    // const.alt 3
    // if/goto jeq 0xaa6fc
    // if/goto jump 697568
    // if/goto jump 698428
    // const.alt 199263884
    native#1023();
    // const.alt 4
    // if/goto jeq 0xaa750
    // if/goto jump 697568
    // if/goto jump 698428
    // const.alt 199263884
    native#1023();
    // const.alt 5
    // if/goto jeq 0xaa7a4
    // if/goto jump 697568
    // if/goto jump 698428
    // const.alt 199263884
    native#1023();
    // const.alt 6
    // if/goto jeq 0xaa7f8
    // if/goto jump 697568
    // if/goto jump 698428
}

// AMX 0xab098
stock ProbelText()
{
    // locals stack -1024
    // if/goto jump 700640
    // const.alt 256
    GetPlayerWeapon("");
    // if/goto jump 700852
    GetPlayerWeapon(95);
    // if/goto jump 700852
}

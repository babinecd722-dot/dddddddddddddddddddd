// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_cp_race.pwn
// Functions: 4

// AMX 0xd27c
stock ClearPlayerRCPInfo()
{
    // const.alt 65836
    Streamer_SetIntData();
    return 1;
}

// AMX 0xd2cc
stock n_SetPlayerRaceCheckpoint()
{
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 34
    // const.alt 65836
    Streamer_SetIntData();
    // stor.alt 34
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 65836
    Streamer_SetIntData(_push.pri);
    // if/goto jneq 0x2c
}

// AMX 0xd5dc
stock n_IsPlayerInRaceCheckpoint()
{
    // const.alt 65836
    Streamer_SetIntData();
    // load.pri 53
    // const.alt 65836
    Streamer_SetIntData();
    // const.alt 9
    // const.alt 65836
    Streamer_SetIntData(_push.pri);
    // const.alt 65836
    Streamer_SetIntData(_push.pri);
    // const.alt 65836
    Streamer_SetIntData(_push.pri);
    // if/goto jnz 0x2c
    return 1;
}

// AMX 0xd754
stock n_DisablePlayerRaceCheckpoint()
{
    // const.alt 65836
    Streamer_SetIntData();
    // load.pri 53
    // const.alt 65836
    Streamer_SetIntData();
    // if/goto jless 0x2c
    return 1;
}

// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_new_promo.pwn
// Functions: 32

// AMX 0x46690
stock blackjack_OnGameModeInit()
{
    // locals stack 8
    // locals stack 16
    // locals stack 16
    prom_OnGameModeInit();
    return 1;
}

// AMX 0x4673c
public OnPromoTimerTick()
{
    // locals stack -1024
    // const.alt 39
    // locals stack 24
    // locals stack 16
    // stor.s.pri -1028
    // locals stack 8
    // if/goto jnz 0x46880
    // locals stack 8
    // if/goto jzer 0x46880
    // if/goto jump 288904
    // if/goto jzer 0x46d4c
    // locals stack 8
    // const.alt 39
    // locals stack 16
    // if/goto jump 289044
    // const.alt 250
    // if/goto jzer 0x46968
    // if/goto jump 289032
    // if/goto jump 289160
    // const.alt 197879844
    Streamer_SetIntData(_push.pri, "", "àñ", _push.s, "", "l", _push.alt, "àñ", "9ºàñ", 1, "àñ", _push.s, "àñ", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "D ", "	'Ì¹ÏX'", "", "", "", "", "");
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // if/goto jneq 0x46cec
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // locals stack 8
    // locals stack -4
    // stor.s.pri -1060
    // if/goto jump 289492
    // const.alt 197879844
    Streamer_SetIntData(_push.pri, _push.r, "àñ", _push.pri);
    // const.alt 1
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 197863844
    Streamer_SetIntData(_push.pri);
    // load.pri 121
    // const.alt 197863844
    Streamer_SetIntData(_push.pri);
    floatsub(_push.pri);
    // const.alt 197863844
    Streamer_SetIntData();
    // load.pri 121
    // if/goto jump 289480
    // locals stack 4
    // const.alt 197879844
    Streamer_SetIntData(_push.pri);
    // if/goto jump 290036
    // if/goto jump 289148
    // locals stack 4
    // if/goto jump 289032
    // locals stack 4
    // locals stack 12
    // locals stack 1048
    return 1;
    // locals stack 16
    // stor.s.pri -1032
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1052
    // locals stack 16
    // stor.s.pri -1036
    // locals stack 16
    // stor.s.pri -1040
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1056
    // locals stack 16
    // stor.s.pri -1044
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1060
    GetPlayerIDFromAccountID();
    // stor.s.pri -1048
    // const.alt 65535
    // if/goto jeq 0x47020
    RevokePromoPrize();
    // locals stack 16
    // const.alt 39
    // locals stack 24
    // locals stack 16
    // if/goto jump 291000
    // const.alt 250
    // if/goto jzer 0x4710c
    // if/goto jump 290988
    // if/goto jump 291116
    // const.alt 197879844
    Streamer_SetIntData(_push.pri, "", "àñ", _push.s, "", "l", _push, "", "Äc÷ÄcÿM", _push, "D ", "l", _push.s, "", "", "¼ý;", _push.s, _push.s, _push.s, _push.s, "àñ", _push.s, "l", _push.alt, _push.alt, _push.alt, _push.pri, "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ");
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // if/goto jneq 0x47490
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // locals stack 8
    // locals stack -4
    // stor.s.pri -1072
    // if/goto jump 291448
    // const.alt 197879844
    Streamer_SetIntData(_push.pri, _push.r, "àñ", _push.pri);
    // const.alt 1
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 197863844
    Streamer_SetIntData(_push.pri);
    // load.pri 121
    // const.alt 197863844
    Streamer_SetIntData(_push.pri);
    floatsub(_push.pri);
    // const.alt 197863844
    Streamer_SetIntData();
    // load.pri 121
    // if/goto jump 291436
    // locals stack 4
    // const.alt 197879844
    Streamer_SetIntData(_push.pri);
    // if/goto jump 291992
    // if/goto jump 291104
    // locals stack 4
    // if/goto jump 290988
    // locals stack 4
    // if/goto jump 292152
    // const.alt 133
    // locals stack 28
    // locals stack 16
    // locals stack 12
    // locals stack 1060
    return 1;
}

// AMX 0x4757c
stock CheckAndCreatePromoTables()
{
    // locals stack -2048
    // locals stack 20
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jzer 0x477bc
    // locals stack 8
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x47798
    // locals stack 8
    // locals stack 12
    // if/goto jump 292796
    // locals stack 8
    // locals stack 12
    // locals stack 20
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jzer 0x479d4
    // locals stack 8
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x479b0
    // locals stack 8
    // locals stack 12
    // if/goto jump 293332
    // locals stack 8
    // locals stack 12
    // locals stack 20
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jzer 0x47bec
    // locals stack 8
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x47bc8
    // locals stack 8
    // locals stack 12
    // if/goto jump 293868
    // locals stack 8
    // locals stack 12
    // locals stack 20
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jnz 0x47cf8
    // locals stack 8
    // const.alt 5
    // if/goto jneq 0x47cf8
    // if/goto jump 294144
    // if/goto jzer 0x47ed4
    // locals stack 8
    // locals stack 8
    // if/goto jnz 0x47db0
    // locals stack 16
    // locals stack 8
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x47eb0
    // locals stack 8
    // locals stack 12
    // if/goto jump 294612
    // locals stack 8
    // locals stack 12
    // locals stack 20
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jnz 0x480ec
    // locals stack 8
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x480c8
    // locals stack 8
    // locals stack 12
    // if/goto jump 295148
    // locals stack 8
    // locals stack 12
    // locals stack 20
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jnz 0x48304
    // locals stack 8
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x482e0
    // locals stack 8
    // locals stack 12
    // if/goto jump 295684
    // locals stack 8
    // locals stack 12
    // locals stack 2052
    return 1;
}

// AMX 0x48340
stock LoadPromoCodesFromDatabase()
{
    // locals stack 8
    // locals stack -512
    // locals stack 20
    // locals stack 12
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // locals stack 12
    // locals stack 8
    // if/goto jzer 0x48560
    // locals stack 8
    // locals stack 12
    // locals stack 12
    // locals stack 516
    return 1;
    // locals stack 8
    // stor.pri 197806840
    // locals stack 12
    // load.pri 197806840
    // const.alt 100
    // locals stack 20
    // stor.pri 197806840
    // if/goto jump 296588
    // load.pri 197806840
    // if/goto jnz 0x4868c
    // locals stack 8
    // if/goto jump 296620
    // load.alt 197806840
    // const.alt 197791640
    TextDrawColor("", "àñ", "", 100, "¼ý;", "", "", _push.alt, 100, _push.alt, 100, "", "", "", "àñ", _push.s);
    // locals stack 16
    // const.alt 197791640
    TextDrawColor("8", "8", "l", _push.s, "", "9ºàñ", _push.pri);
    // locals stack 24
    // const.alt 197791640
    TextDrawColor(_push, "Äc÷ÄcÿM", _push.s, "");
    // locals stack 16
    // const.alt 197791640
    TextDrawColor("l", _push.s, "", "9ºàñ", _push.pri);
    // locals stack 16
    // const.alt 197791640
    TextDrawColor("l", _push.s, "", "9ºàñ", _push.pri);
    // locals stack 16
    // if/goto jump 296608
    // locals stack 4
    // locals stack 12
    // locals stack 12
    // locals stack 8
    // locals stack 516
    return 1;
}

// AMX 0x48990
stock blackjack_OnPlayerConnect()
{
    // const.alt 197879844
    Streamer_SetIntData();
    // if/goto jump 297444
    // const.alt 5
    // const.alt 197863844
    Streamer_SetIntData("");
    floatsub(_push.pri);
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // if/goto jump 297432
    // locals stack 4
    OnPlayerLogin();
    prom_OnPlayerConnect();
    return 1;
}

// AMX 0x48b10
public OnPlayerLogin()
{
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -4
    // locals stack -1024
    // locals stack 24
    // locals stack 16
    // stor.s.pri -8
    // locals stack -4
    // locals stack 8
    // stor.s.pri -1036
    // if/goto jump 298100
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1044
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1048
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1052
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1056
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1060
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1064
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1068
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1072
    // locals stack 28
    // locals stack 16
    SetPlayerPromoTimer();
    // if/goto jump 299184
    RevokePromoPrize();
    // locals stack 24
    // locals stack 16
    // locals stack 16
    // locals stack 32
    // if/goto jump 298088
    // locals stack 4
    // locals stack 12
    // locals stack 1036
    return 1;
}

// AMX 0x4910c
stock blackjack_OnPlayerDisconnect()
{
    StopPlayerPromoTimer();
    prom_OnPlayerDisconnect();
    return 1;
}

// AMX 0x49158
stock GetPlayerIDFromAccountID()
{
    // if/goto jump 299392
    // const.alt 250
    // const.alt 181530104
    Streamer_SetIntData("àñ", _push.s, "");
    // if/goto jneq 0x49214
    // if/goto jump 299544
    // if/goto jzer 0x49238
    // locals stack 4
    return 1;
    // if/goto jump 299380
    // locals stack 4
    return 1;
}

// AMX 0x49258
stock SetPlayerPromoTimer()
{
    // const.alt 197879844
    Streamer_SetIntData();
    // const.alt 5
    // stor.alt 11
    // const.alt 181530104
    Streamer_SetIntData(_push.alt);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // locals stack 24
    return 1;
    // locals stack -4
    // const.alt 197879844
    Streamer_SetIntData();
    // stor.s.pri -4
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // stor.alt 39
    // locals stack 24
    // const.alt 197879844
    Streamer_SetIntData("Äc÷ÄcÿM", "", "4k", "9ºàñ", _push.pri);
    // stor.alt 12
    Streamer_SetIntData(_push.pri);
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // locals stack 24
    // locals stack 4
    return 1;
}

// AMX 0x49564
stock StopPlayerPromoTimer()
{
    // locals stack -1024
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("");
    // stor.s.pri -1032
    // if/goto jump 300536
    // const.alt 197879844
    Streamer_SetIntData(_push.pri, "");
    // locals stack -4
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // stor.s.pri -1040
    // locals stack -4
    // const.alt 197863844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // stor.s.pri -1044
    // locals stack 8
    // locals stack 24
    // locals stack 16
    // stor.s.pri -1028
    // locals stack 8
    // if/goto jnz 0x49818
    // locals stack 8
    // if/goto jump 301084
    // if/goto jzer 0x49c64
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1048
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1052
    // locals stack -512
    // locals stack 24
    // locals stack 16
    // stor.s.pri -1060
    // locals stack 8
    // if/goto jnz 0x499d4
    // locals stack 8
    // if/goto jump 301528
    // if/goto jzer 0x49a1c
    // locals stack 16
    // stor.s.pri -1056
    // locals stack 12
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1576
    // locals stack -4
    // locals stack 12
    // stor.s.pri -1580
    // locals stack 28
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push, "", "ÄcÿM", _push, "D ", "", _push.s, "", _push.s, _push.s, "l", _push.alt, _push.alt, _push.alt, _push.pri, "", _push.s, "9ºàñ", "l", "", "", "9ºàñ", 1, "àñ", _push.s, "àñ", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "/", "", "", "", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", 1, "àñ", _push.s, "àñ", "9ºàñ", "l", _push, "9ºàñ", "Äc÷ÄcÿM", _push, "D ", "", _push.r, "àñ", _push.s);
    // locals stack 24
    // locals stack 536
    // locals stack 12
    // locals stack 8
    // if/goto jump 300524
    // locals stack 4
    // const.alt 197879844
    Streamer_SetIntData("", _push.s, "9ºàñ", "Äc÷ÄcÿM", "", _push.pri);
    // locals stack 1032
    return 1;
}

// AMX 0x49ce4
stock RevokePromoPrize()
{
    // locals stack -4
    GetPlayerIDFromAccountID();
    // stor.s.pri -4
    // if/goto jzer 0x49d48
    // locals stack 4
    return 1;
    // locals stack -1024
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("");
    // stor.s.pri -1036
    // locals stack -4
    // stor.s.pri -1040
    // const.alt 181530104
    Streamer_SetIntData();
    UpdatePlayerDatabaseInt();
    // locals stack 20
    // if/goto jump 302936
    GivePlayerMoneyEx();
    // locals stack 20
    // locals stack 8
    // if/goto jump 304660
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("¼ý;", _push.s, "", "", _push.pri, "Äc÷ÄcÿM", _push.s, _push.pri, 197904172, "9ºàñ", "9ºàñ", "¼ý;", _push.s, "", "", _push.pri, "l", _push.s, "", "");
    // stor.s.pri -1036
    // locals stack -4
    // stor.s.pri -1040
    // const.alt 181530104
    Streamer_SetIntData(197904564, "9ºàñ", "9ºàñ");
    GivePlayerDonateRub();
    // locals stack 20
    // if/goto jump 303448
    GivePlayerDonateRub();
    // locals stack 20
    // locals stack 8
    // if/goto jump 304660
    // const.alt 39
    // locals stack 32
    // locals stack 16
    // stor.s.pri -1032
    // locals stack -4
    // locals stack 8
    // stor.s.pri -1036
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1040
    // locals stack -4
    // locals stack 16
    // stor.s.pri -1044
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x4a398
    n_veh_DestroyVehicle();
    // if/goto jump 304352
    // if/goto jump 304056
    // const.alt 15000
    // const.alt 182230856
    native#14999("", "àñ", _push.s, "àñ", _push.s, "l", _push, "", "Äc÷ÄcÿM", _push, "D ", "", "l", "", "", "9ºàñ", "l", "", "", "9ºàñ", "àñ", "9ºàñ", "l", _push, "9ºàñ", "M", _push, "D ", "¼ý;", _push.s, "", "", _push.pri, "Äc÷ÄcÿM", _push.s, _push.pri, 197904564, "9ºàñ", "9ºàñ", "¼ý;", _push.s, "", "", _push.pri, "Äc÷ÄcÿM", _push.s, _push.pri);
    // if/goto jneq 0x4a474
    // const.alt 182230856
    native#14999();
    // locals stack 8
    // if/goto jzer 0x4a474
    // if/goto jump 304248
    // if/goto jzer 0x4a4d0
    // const.alt 182230856
    native#14999(1, "àñ", _push.pri);
    n_veh_DestroyVehicle();
    // if/goto jump 304344
    // if/goto jump 304044
    // locals stack 4
    // locals stack 16
    // const.alt 12
    Streamer_SetIntData("l", _push.s, "", "", "àñ", _push.pri);
    // locals stack 24
    // locals stack 8
    // locals stack 12
    // locals stack 4
    // if/goto jump 304660
    // locals stack 1032
    return 1;
    // if/goto jump 304660
}

// AMX 0x4a69c
stock GetPromoCodeDataByString()
{
    // if/goto jump 304836
    // load.alt 197806840
    // const.alt 197791640
    TextDrawColor(_push.s, "9ºàñ", "", "");
    // stor.s.pri 44
    // const.alt 197791640
    TextDrawColor(_push.pri, "¼ý;");
    // const.alt 197791640
    TextDrawColor("", "8", "8");
    // locals stack 24
    // const.alt 197791640
    TextDrawColor(_push.pri, "Äc÷ÄcÿM");
    // const.alt 197791640
    TextDrawColor(_push.pri);
    // const.alt 197791640
    TextDrawColor(_push.pri);
    // locals stack 4
    return 1;
    // if/goto jump 304824
    // locals stack 4
    return 1;
}

// AMX 0x4a93c
stock GetPromoCodeIndexByString()
{
    // if/goto jump 305508
    // load.alt 197806840
    // const.alt 197791640
    TextDrawColor(_push.s, "9ºàñ", "", "");
    // stor.s.pri 44
    // locals stack 4
    return 1;
    // if/goto jump 305496
    // locals stack 4
    return 1;
}

// AMX 0x4aa24
stock GivePromoCar()
{
    // locals stack -12
    // const.alt 137
    return 1;
    // locals stack 20
    // locals stack -4
    // stor.s.pri -24
    // locals stack -4
    // stor.s.pri -28
    // locals stack -4
    // stor.s.pri -32
    // locals stack -1024
    // load.pri 45
    // locals stack 16
    // stor.alt 12
    Streamer_SetIntData(_push.alt, "l", _push.alt, _push.alt, _push.alt, _push.alt, "", "", "");
    // locals stack 60
    // locals stack 16
    // stor.s.pri -1064
    // locals stack 12
    // locals stack 1068
    return 1;
}

// AMX 0x4ad0c
stock ShowPromoCreationConfirmation()
{
    // locals stack -4096
    // locals stack -1024
    // locals stack -128
    // const.alt 197806844
    Streamer_SetIntData("", "8", "8");
    // locals stack 24
    // locals stack -4
    // const.alt 197806844
    Streamer_SetIntData("Äc÷ÄcÿM", _push.pri);
    // stor.s.pri -5252
    // locals stack -4
    // const.alt 197806844
    Streamer_SetIntData();
    // stor.s.pri -5256
    // locals stack 16
    // locals stack 20
    // stor.alt 137
    // locals stack -128
    // if/goto jnz 0x4af80
    // locals stack 16
    // if/goto jump 307132
    // locals stack 20
    // locals stack 20
    // stor.alt 137
    // stor.alt 137
    // if/goto jump 307328
    // locals stack -4
    // const.alt 197842844
    Streamer_SetIntData("", "l", "", "ØÉ", "l", "ØÉ", _push.alt, "¼ý;", "D ", "", _push.alt, "¼ý;", "8", "", _push.alt, "l", "8", "", "l", "ØÉ", _push.alt, "¼ý;", "D ", "", _push.alt, "l", "ØÉ", "");
    floatsub(_push.pri);
    // stor.s.pri -5392
    // locals stack -4
    // const.alt 197842844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // stor.s.pri -5396
    // locals stack -4
    // const.alt 197842844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // stor.s.pri -5400
    // locals stack -512
    // locals stack -256
    // if/goto jnz 0x4b270
    // locals stack 16
    // if/goto jump 307884
    // locals stack 20
    // load.pri 45
    // locals stack 28
    // if/goto jump 308352
    // load.pri 45
    // locals stack 28
    // if/goto jump 308352
    native#2089(400, _push.pri, 308428, _push.alt, "ÄcÿM", "/", "", _push.alt, _push.alt, "ÄcÿM", "/", "", _push.alt, _push.alt, "¼ý;", "Ò,", "", _push.alt, "l", "Ò,", "");
    // load.pri 45
    // locals stack 32
    // if/goto jump 308352
}

// AMX 0x4b528
stock CreatePromoCodeInDatabase()
{
    // locals stack -4096
    // locals stack -128
    // const.alt 197806844
    Streamer_SetIntData("", "8", "8");
    // locals stack 24
    // locals stack -4
    // const.alt 197806844
    Streamer_SetIntData("Äc÷ÄcÿM", _push.pri);
    // stor.s.pri -4228
    // locals stack -4
    // const.alt 197806844
    Streamer_SetIntData();
    // stor.s.pri -4232
    // locals stack -1024
    // locals stack 36
    // locals stack 16
    // stor.s.pri -4240
    // locals stack 8
    // if/goto jzer 0x4b8a0
    // locals stack 8
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // locals stack 12
    // locals stack 12
    // locals stack 5264
    return 1;
    // locals stack 8
    // stor.s.pri -4236
    // locals stack 12
    // if/goto jnz 0x4b980
    // locals stack 16
    // locals stack 12
    // locals stack 5264
    return 1;
    // if/goto jump 309664
    // locals stack -4
    // const.alt 197842844
    Streamer_SetIntData("");
    floatsub(_push.pri);
    // stor.s.pri -5272
    // locals stack -4
    // const.alt 197842844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // stor.s.pri -5276
    // locals stack -4
    // const.alt 197842844
    Streamer_SetIntData();
    floatsub(_push.pri);
    // stor.s.pri -5280
    // locals stack 40
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x4bcf0
    // locals stack 8
    // load.pri 45
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // locals stack 20
    // locals stack 12
    // if/goto jump 309652
    // locals stack 4
    // locals stack 24
    // locals stack 16
    LoadPromoCodesFromDatabase();
    // const.alt 197806844
    Streamer_SetIntData("", "l", _push.s, "", _push.alt, "Äc÷ÄcÿM", "D ", "", "¼ý;", "", _push.alt, "àñ", "9ºàñ", "l", _push.s, "", _push.alt, "Äc÷ÄcÿM", "D ", "", _push.alt, _push.alt, "àñ", "9ºàñ", "àñ", "9ºàñ", "l", _push, "", "ð", _push, "ØÉ", "");
    // const.alt 197806844
    Streamer_SetIntData();
    // const.alt 197806844
    Streamer_SetIntData();
    // locals stack 5264
    return 1;
}

// AMX 0x4be6c
stock blackjack_OnDialogResponse()
{
    // if/goto jzer 0x4c2a8
    pc_cmd_mypromo();
    // if/goto jump 311976
    // locals stack -4096
    // locals stack -4
    GetPromoLevelForOwner();
    // stor.s.pri -4100
    // locals stack -128
    // locals stack -1320
    // if/goto jump 311220
    // const.alt 10
    // locals stack 16
    // if/goto jump 311404
    // locals stack 16
    SSCANF_Init(_push.alt, "l", "8", "", _push.alt, "l", "8", "", 1, _push.pri, "", 197912648, "àñ", _push.s, "", _push.s, "");
    // load.pri 45
    // locals stack 32
    // if/goto jump 311208
    // locals stack 4
    // locals stack 8
    // locals stack 8
    // const.alt 1
    native#1023("àñ", _push.pri, "àñ", _push.alt, "M", "ØÉ", "", _push.alt, _push.pri);
    fg_ShowPlayerDialog();
    // locals stack 5548
    // if/goto jump 311976
    fg_ShowPlayerDialog();
    // if/goto jump 311976
    pc_cmd_mypromo();
    // if/goto jump 311976
}

// AMX 0x57dc0
stock CheckUsePromoCode()
{
    // locals stack -624
    // stor.alt 39
    // locals stack 28
    // locals stack -4
    // locals stack 16
    // stor.s.pri -628
    // locals stack 8
    // locals stack 16
    // locals stack 12
    // locals stack 628
    return 1;
    // locals stack 12
    // locals stack 628
    return 1;
}

// AMX 0x57f64
public OnPromoCodeCheckComplete()
{
    // if/goto jzer 0x57fa8
    return 1;
    // locals stack -1032
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -1036
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -1040
    // locals stack -128
    // locals stack -1024
    // locals stack 24
    // locals stack 16
    // stor.s.pri -2196
    // locals stack 8
    // if/goto jzer 0x581e4
    // locals stack 16
    pc_cmd_promo();
    // locals stack 12
    // locals stack 2196
    return 1;
    // locals stack 8
    // locals stack 16
    pc_cmd_promo();
    // locals stack 12
    // locals stack 2196
    return 1;
    // locals stack 12
    // locals stack -4
    // locals stack 8
    // stor.s.pri -2200
    // const.alt 3
    // const.alt 4
    // if/goto jump 361332
    // if/goto jzer 0x583ac
    // stor.s.pri -2204
    // stor.s.pri -2208
    // if/goto jump 361544
    // const.alt 5
    // const.alt 7
    // if/goto jump 361460
    // if/goto jzer 0x58418
    // stor.s.pri -2204
    // if/goto jump 361544
    // const.alt 8
    // stor.s.pri -2204
    // const.alt 31
    // if/goto jzer 0x584a4
    // if/goto jump 361640
    // if/goto jzer 0x58508
    funcidx(1, "", 3000000, 5000000, 1, 2000, 10000000, 1, "", "", "àñ", _push.s, "", _push.s, "9ºàñ");
    // if/goto jump 361560
    funcidx(_push.pri);
    // locals stack -256
    // locals stack 24
    // if/goto jump 361976
    // locals stack 20
    // locals stack 32
    // locals stack 16
    // stor.s.pri -2196
    // locals stack 8
    // if/goto jzer 0x58750
    // locals stack 16
    pc_cmd_promo();
    // locals stack 12
    // locals stack 2468
    return 1;
    // locals stack 12
    // locals stack 24
    // locals stack 16
    pc_cmd_promo();
    // locals stack 2468
    return 1;
    GivePlayerDonateRub();
    // locals stack 24
    // locals stack 16
    pc_cmd_mypromo();
    LoadPromoCodesFromDatabase();
    // if/goto jump 363152
    GivePlayerMoneyEx();
    // locals stack 24
    // locals stack 16
    pc_cmd_mypromo();
    LoadPromoCodesFromDatabase();
    // locals stack 2468
    return 1;
}

// AMX 0x58aa8
stock HasPlayerCreatedPromo()
{
    // locals stack -512
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -516
    // locals stack -4
    // locals stack 8
    // stor.s.pri -520
    // locals stack 12
    // locals stack 520
    return 1;
}

// AMX 0x58c04
stock AddPlayerActivatedPromo()
{
    // locals stack -1024
    // stor.alt 133
    // const.alt 39
    // locals stack 28
    // locals stack 16
    // locals stack 1024
    return 1;
}

// AMX 0x58cbc
stock SavePromoLevelPrizes()
{
    // locals stack -1024
    // locals stack -80
    // stor.alt 39
    // locals stack 24
    // locals stack 16
    // const.alt 197789848
    IsPlayerConnected("l", _push, "", "Äc÷ÄcÿM", _push, "D ", 197978500, "");
    // stor.s.pri -4
    // if/goto jump 364052
    floatsub("");
    // const.alt 197790112
    float(_push.pri);
    floatsub();
    // const.alt 197790112
    float();
    floatsub();
    // const.alt 197790112
    float();
    // if/goto jump 364040
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 364464
    floatsub("");
    // const.alt 197790128
    floatmul(_push.pri);
    floatsub();
    // const.alt 197790128
    floatmul();
    floatsub();
    // const.alt 197790128
    floatmul();
    // if/goto jump 364452
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 364876
    floatsub("");
    // const.alt 197790160
    floatdiv(_push.pri);
    floatsub();
    // const.alt 197790160
    floatdiv();
    floatsub();
    // const.alt 197790160
    floatdiv();
    // if/goto jump 364864
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 365288
    floatsub("");
    // const.alt 197790208
    floatdiv(_push.pri);
    floatsub();
    // const.alt 197790208
    floatdiv();
    floatsub();
    // const.alt 197790208
    floatdiv();
    // if/goto jump 365276
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 365700
    floatsub("");
    // const.alt 197790256
    floatdiv(_push.pri);
    floatsub();
    // const.alt 197790256
    floatdiv();
    floatsub();
    // const.alt 197790256
    floatdiv();
    // if/goto jump 365688
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 366112
    floatsub("");
    // const.alt 197790304
    floatdiv(_push.pri);
    floatsub();
    // const.alt 197790304
    floatdiv();
    floatsub();
    // const.alt 197790304
    floatdiv();
    // if/goto jump 366100
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 366524
    floatsub("");
    // const.alt 197790352
    floatadd(_push.pri);
    floatsub();
    // const.alt 197790352
    floatadd();
    floatsub();
    // const.alt 197790352
    floatadd();
    // if/goto jump 366512
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 366936
    floatsub("");
    // const.alt 197790416
    floatadd(_push.pri);
    floatsub();
    // const.alt 197790416
    floatadd();
    floatsub();
    // const.alt 197790416
    floatadd();
    // if/goto jump 366924
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 367348
    floatsub("");
    // const.alt 197790480
    floatsub(_push.pri);
    floatsub();
    // const.alt 197790480
    floatsub();
    floatsub();
    // const.alt 197790480
    floatsub();
    // if/goto jump 367336
    // locals stack 4
    // if/goto jump 368232
    // if/goto jump 367760
    floatsub("");
    // const.alt 197790560
    floatsub(_push.pri);
    floatsub();
    // const.alt 197790560
    floatsub();
    floatsub();
    // const.alt 197790560
    floatsub();
    // if/goto jump 367748
    // locals stack 4
    // if/goto jump 368232
}

// AMX 0x5a0c8
stock GetPromoLevelForOwner()
{
    // locals stack -512
    // const.alt 181530104
    Streamer_SetIntData("");
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -520
    // locals stack 8
    // locals stack 16
    // stor.s.pri -516
    // locals stack 12
    // locals stack 520
    return 1;
}

// AMX 0x5a25c
stock pc_cmd_createpromo()
{
    pc_cmd_addcpromo();
    return 1;
}

// AMX 0x5a290
stock pc_cmd_createytpromo()
{
    pc_cmd_addcpromo();
    return 1;
}

// AMX 0x5a2c4
stock pc_cmd_addcpromo()
{
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 13
    // locals stack 16
    return 1;
    fg_ShowPlayerDialog();
    return 1;
}

// AMX 0x5a3a8
stock pc_cmd_promo()
{
    // locals stack -2048
    // locals stack -256
    HasPlayerCreatedPromo();
    // if/goto jzer 0x5a450
    // locals stack 16
    // if/goto jump 369796
    // locals stack 16
    // locals stack 20
    fg_ShowPlayerDialog();
    // locals stack 2304
    return 1;
}

// AMX 0x5a524
stock pc_alias_promo()
{
    // locals stack 12
    return 1;
}

// AMX 0x5a560
stock pc_cmd_mypromo()
{
    // locals stack -1024
    // locals stack -2048
    // locals stack -128
    // const.alt 181530104
    Streamer_SetIntData("", "", "");
    // locals stack 24
    // locals stack -4
    // locals stack 16
    // stor.s.pri -3216
    // locals stack 8
    // if/goto jnz 0x5a734
    // locals stack 16
    // locals stack 12
    // locals stack 3216
    return 1;
    // locals stack 24
    // locals stack 16
    // stor.s.pri -3204
    // locals stack 16
    // stor.s.pri -3208
    // const.alt 11
    // if/goto jump 370748
    // if/goto jzer 0x5a89c
    // load.pri 121
    // stor.s.pri -3212
    // if/goto jump 370856
    // locals stack 32
    fg_ShowPlayerDialog();
    // locals stack 12
    // locals stack 3216
    return 1;
}

// AMX 0x5a98c
stock pc_alias_mypromo()
{
    // locals stack 12
    return 1;
}

// AMX 0x5a9c8
stock pc_cmd_checkpromo()
{
    // locals stack -1024
    // locals stack -2048
    // locals stack -608
    // const.alt 181530104
    Streamer_SetIntData("");
    // locals stack 24
    // locals stack 16
    // stor.s.pri -3684
    // locals stack 8
    // if/goto jnz 0x5ab84
    // locals stack 16
    // locals stack 12
    // locals stack 3684
    return 1;
    // locals stack -128
    // locals stack 16
    // stor.s.pri -3828
    // locals stack 24
    // locals stack 16
    // stor.s.pri -3816
    // locals stack 16
    // stor.s.pri -3820
    // locals stack 16
    // stor.s.pri -3824
    // locals stack 12
    // if/goto jnz 0x5ad88
    // locals stack 16
    // locals stack 3828
    return 1;
    // locals stack 20
    // locals stack 28
    fg_ShowPlayerDialog();
    // if/goto jnz 0x5ae88
    // locals stack 3828
    return 1;
    GivePlayerMoneyEx();
    // locals stack 24
    // locals stack 16
    // locals stack 3828
    return 1;
}

// AMX 0x5af70
stock pc_cmd_bcode()
{
    fg_ShowPlayerDialog();
    return 1;
}

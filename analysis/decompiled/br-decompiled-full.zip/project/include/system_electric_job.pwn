// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_electric_job.pwn
// Functions: 11

// AMX 0x8a074
stock rul_OnPlayerDisconnect()
{
    OrdinaryNewElectric();
    e_OnPlayerDisconnect();
    return 1;
}

// AMX 0x8a0c0
stock rul_OnPlayerConnect()
{
    OrdinaryNewElectric();
    e_OnPlayerConnect();
    return 1;
}

// AMX 0x8a104
stock name_OnPlayerSpawn()
{
    OrdinaryNewElectric();
    e_OnPlayerSpawn();
    return 1;
}

// AMX 0x8a148
stock name_OnDialogResponse()
{
    // if/goto jzer 0x8a370
    // if/goto jzer 0x8a370
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 1000
    // const.alt 199246240
    Streamer_SetIntData();
    n_veh_CreateVehicle();
    // const.alt 199246240
    Streamer_SetIntData("", "8*", "µ-", "", "", "", "", "", "", "", "", "", "", _push.pri);
    // locals stack 16
    GivePlayerMoneyEx();
    // locals stack 16
    // if/goto jump 566128
    // locals stack 16
    // if/goto jzer 0x8a504
    // if/goto jzer 0x8a504
    // locals stack 8
    // if/goto jzer 0x8a42c
    SetPlayerSkinInit();
    // locals stack 16
    // if/goto jump 566532
    // locals stack 12
    // locals stack 16
    EnablePlayerGPS();
    // locals stack 16
    // if/goto jzer 0x8a718
    // if/goto jzer 0x8a718
    // const.alt 199245240
    Streamer_SetIntData("l", _push.s, "", "", "ÄcÿM", _push.s, "", "", "", "", "", "l", _push.s, "", "", "", _push.s, "", "l", _push.s, "", "", "àñ", _push.s, "àñ", _push.s, "l", _push.s, "", "", "l", _push.s, "", "", "Äc÷ÄcÿM", _push.s, "", 197904172, "9ºàñ", "9ºàñ", "l", _push.s, _push.pri);
    // if/goto jzer 0x8a644
    // locals stack 16
    EnablePlayerGPS();
    // locals stack 16
    // const.alt 199245240
    Streamer_SetIntData("l", _push.s, "", "", "ÄcÿM", _push.s, "", "", "", "", "", "l", _push.s, "", "");
    // if/goto jump 567064
    // locals stack 16
    OrdinaryNewElectric();
    // locals stack 8
    // if/goto jzer 0x8a718
    SetPlayerSkinInit();
    // locals stack 16
    // if/goto jzer 0x8ac98
    // if/goto jzer 0x8ac98
    // const.alt 84
    // if/goto jzer 0x8a8f4
    // locals stack -64
    // const.alt 129
    // if/goto jump 567396
    // if/goto jneq 0x33
    // if/goto jump 567396
}

// AMX 0x8acd8
stock blackjack_OnPlayerEnterDynamicA()
{
    // load.pri 199245236
    // if/goto jneq 0x8ad50
    SetPlayerPosEx();
    // load.pri 199245232
    // if/goto jneq 0x8adc0
    SetPlayerPosEx();
    // load.pri 199245224
    // if/goto jneq 0x8ae50
    // const.alt 199245240
    Streamer_SetIntData("8", _push.s, "", "", "", "", "", "", "9ºàñ", "8", _push.s, "", "", "", "", "9ºàñ", "9ºàñ", "9ºàñ");
    // if/goto jzer 0x8ae50
    Dialog();
    // load.pri 199245228
    // if/goto jneq 0x8aee0
    // const.alt 199245240
    Streamer_SetIntData("M", _push.s, "ÿE", "", "", "", "", "");
    // if/goto jzer 0x8aee0
    Dialog();
    // load.pri 199245220
    // if/goto jneq 0x8b04c
    // const.alt 181530104
    Streamer_SetIntData("M", _push.s, "E", "", "", "", "", "");
    // const.alt 7
    // const.alt 199245240
    Streamer_SetIntData();
    // if/goto jzer 0x8afc4
    Dialog();
    // if/goto jump 569360
    Dialog();
    // if/goto jump 569420
    // locals stack 16
    // if/goto jzer 0x8b380
    // const.alt 199245240
    Streamer_SetIntData(_push.pri, 199249304, _push.alt, _push.pri, 199249304, "l", _push.s, "", "", "M", _push.s, "", "", "", "", "", "", "M", _push.s, "", "", "", "", "", "");
    // if/goto jzer 0x8b380
    // const.alt 199248240
    Streamer_SetIntData();
    // if/goto jzer 0x8b154
    // locals stack 16
    return 1;
    // locals stack -4
    IsPlayerInOrdersElectric();
    // stor.s.pri -4
    // const.alt 199248240
    Streamer_SetIntData("àñ", _push.s);
    // if/goto jeq 0x8b210
    // const.alt 199248240
    Streamer_SetIntData();
    // if/goto jnz 0x8b210
    // if/goto jump 569880
    // if/goto jzer 0x8b344
    // locals stack 8
    // if/goto jzer 0x8b28c
    // locals stack 16
    // locals stack 4
    return 1;
    ApplyAnimationEx();
    // const.alt 39
    // locals stack 24
    // if/goto jump 570232
    // locals stack 16
    // locals stack 4
    e_OnPlayerEnterDynamicArea();
    return 1;
}

// AMX 0x8b3a8
stock rul_OnGameModeInit()
{
    // locals stack 8
    CreateElectric();
    e_OnGameModeInit();
    return 1;
}

// AMX 0x8b400
stock CreateElectric()
{
    // locals stack 8
    // if/goto jump 570444
    // const.alt 10
    // const.alt 199249304
    SSCANF_Init("", "àñ", "");
    // const.alt 199249304
    SSCANF_Init("", "", "", "", "", _push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // if/goto jgrtr 0x2c
    // const.alt 199249304
    SSCANF_Init(_push.pri, "8", _push.pri);
    // const.alt 1067869798
    func_0x1d0();
    // if/goto jzer 0x8b6d8
    // const.alt 199249304
    SSCANF_Init("", "", "", "", _push.alt, _push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // locals stack 36
    // if/goto jump 570432
    // locals stack 4
    CreateActorEx();
    // if/goto jgrtr 0x2c
    // stor.pri 199245220
    // locals stack 48
    // if/goto jgrtr 0x2c
    // stor.pri 199245224
    // locals stack 36
    // locals stack 48
    // if/goto jgrtr 0x2c
    // stor.pri 199245228
    // locals stack 36
    // if/goto jgrtr 0x2c
    // stor.pri 199245236
    // locals stack 36
    // if/goto jgrtr 0x2c
    // stor.pri 199245232
    // locals stack 48
    // locals stack 48
    return 1;
}

// AMX 0x8bc2c
stock pc_cmd_eorders()
{
    // const.alt 199245240
    Streamer_SetIntData();
    // if/goto jzer 0x8bc70
    return 1;
    // const.alt 199248240
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x8bcd8
    // locals stack 16
    return 1;
    // locals stack 8
    // const.alt 206
    // if/goto jeq 0x8bd44
    // locals stack 16
    return 1;
    // const.alt 199246240
    Streamer_SetIntData();
    // if/goto jzer 0x8bdac
    // locals stack 16
    return 1;
    // locals stack 8
    // const.alt 199246240
    Streamer_SetIntData(_push.pri, "àñ", _push.s);
    // if/goto jeq 0x8be34
    // locals stack 16
    return 1;
    // const.alt 199248240
    Streamer_SetIntData();
    // locals stack 8
    // locals stack -4
    // const.alt 199248240
    Streamer_SetIntData("àñ", "", _push.pri);
    // stor.s.pri -4
    // locals stack -456
    // locals stack -4
    // const.alt 199249304
    SSCANF_Init();
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // locals stack 20
    // stor.s.pri -464
    // locals stack -4
    // const.alt 199248240
    Streamer_SetIntData(_push.pri, 199249304, "¼ý;", _push.s, _push.pri);
    SSCANF_Init();
    // locals stack 12
    func_0x2c();
    // locals stack 8
    func_0x128();
    // stor.s.pri -468
    // const.alt 199247240
    Streamer_SetIntData("", _push.alt, _push.pri, "àñ", "p@", _push.pri, "", _push.alt, _push.pri, "", _push.s, "", _push.pri);
    // locals stack 12
    // const.alt 199247240
    Streamer_SetIntData("", _push.s, "", _push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // locals stack 24
    // locals stack 16
    // if/goto jzer 0x8c2b0
    // const.alt 199249240
    floatadd("", 3, _push.pri, "l", _push.s, "", _push.alt, "Äc÷ÄcÿM", ":", "", _push.pri);
    // const.alt 199249240
    floatadd(_push.pri);
    // const.alt 199249240
    floatadd(_push.pri);
    EnablePlayerGPS();
    // if/goto jump 574340
    // const.alt 199249304
    SSCANF_Init("", "ÄcÿM", _push.s, "", _push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    // const.alt 199249304
    SSCANF_Init(_push.pri);
    EnablePlayerGPS();
    // locals stack 468
    return 1;
}

// AMX 0x8c39c
stock IsPlayerInOrdersElectric()
{
    // if/goto jump 574404
    // const.alt 10
    // const.alt 199249304
    SSCANF_Init("", "");
    // locals stack 16
    // if/goto jzer 0x8c460
    // locals stack 4
    return 1;
    // if/goto jump 574392
    // locals stack 4
    return 1;
}

// AMX 0x8c480
stock OrdinaryNewElectric()
{
    // const.alt 199246240
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x8c4ec
    // const.alt 199246240
    Streamer_SetIntData();
    n_veh_DestroyVehicle();
    // const.alt 199246240
    Streamer_SetIntData("àñ", _push.pri);
    // const.alt 199245240
    Streamer_SetIntData(-1);
    // const.alt 199247240
    Streamer_SetIntData();
    // const.alt 199248240
    Streamer_SetIntData();
    // const.alt 53
    call_unknown();
    // locals stack 12
    return 1;
}

// AMX 0x8c614
stock NextStageElectric()
{
    // locals stack 12
    // locals stack -4
    // locals stack 8
    // stor.s.pri -4
    // locals stack -64
    // locals stack -736
    // if/goto jump 575320
    // if/goto jneq 0x33
    // if/goto jump 575320
}

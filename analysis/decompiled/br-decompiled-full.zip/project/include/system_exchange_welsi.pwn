// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_exchange_welsi.pwn
// Functions: 15

// AMX 0x5d2e0
stock car_OnGameModeInit()
{
    // locals stack 8
    ch_OnGameModeInit();
    return 1;
}

// AMX 0x5d324
stock car_OnPlayerDisconnect()
{
    // const.alt 197996332
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x5d428
    // locals stack -4
    // const.alt 197996332
    Streamer_SetIntData();
    // stor.s.pri -4
    // locals stack 16
    // const.alt 197996332
    Streamer_SetIntData("l", _push.s, "", "");
    // const.alt 197996332
    Streamer_SetIntData(-1);
    // locals stack 4
    name_OnPlayerDisconnect();
    return 1;
}

// AMX 0x5d450
stock car_OnPlayerConnect()
{
    // const.alt 197996332
    Streamer_SetIntData();
    ch_OnPlayerConnect();
    return 1;
}

// AMX 0x5d4a8
stock car_OnDialogResponse()
{
    // if/goto jzer 0x5d80c
    // if/goto jzer 0x5d780
    // if/goto jzer 0x5d504
    return 1;
    // locals stack -4
    // const.alt 197996332
    Streamer_SetIntData();
    // stor.s.pri -4
    // if/goto jnz 0x5d588
    // if/goto jnz 0x5d588
    // if/goto jump 382352
    // if/goto jzer 0x5d5cc
    DeleteFullPVarExchange();
    // locals stack 4
    return 1;
    // locals stack -4
    // const.alt 90
    // stor.s.pri -8
    // locals stack -4
    // if/goto jzer 0x5d63c
    // if/goto jump 382532
    // stor.s.pri -12
    // if/goto jzer 0x5d6e0
    // locals stack 16
    ShowNotification();
    // if/goto jump 382740
    // locals stack 16
    Exchange_ShowVehicleList();
    // if/goto jzer 0x5d770
    ShowDialogSelectTypeExchange();
    // locals stack 12
    // if/goto jump 382988
    // locals stack -4
    // const.alt 197996332
    Streamer_SetIntData("àñ", _push.s, "¼ý;", _push.s, _push.s, "", _push.s, "l", _push.s, "", "", "ÄcÿM", _push.s, "9ºàñ", "", "àñ", "", "", "l", _push.s, "", "", "", _push.s, "");
    // stor.s.pri -4
    // const.alt -1
    // if/goto jeq 0x5d7e8
    DeleteFullPVarExchange();
    DeleteFullPVarExchange();
    // locals stack 4
    // if/goto jzer 0x5e134
    // if/goto jzer 0x5e118
    // locals stack -4
    // const.alt 17
    // if/goto jzer 0x5d8c8
    // const.alt 197996332
    Streamer_SetIntData("", "", _push.s, "", "àñ", _push.s, "àñ", _push.s);
    // stor.s.pri -8
    // if/goto jump 383196
    // stor.s.pri -8
    // if/goto jnz 0x5d930
    // if/goto jnz 0x5d930
    // if/goto jump 383288
    // if/goto jzer 0x5d958
    // locals stack 8
    return 1;
    // locals stack -4
    // const.alt 196049960
    Streamer_SetIntData();
    native#1023(_push.pri);
    // stor.s.pri -12
    // if/goto jzer 0x5da4c
    // const.alt 12
    // load.pri 79
    Exchange_ShowVehicleList();
    // locals stack 12
    return 1;
    // if/goto jzer 0x5dae0
    // const.alt 87
    // load.pri 36
    Exchange_ShowVehicleList();
    // locals stack 12
    return 1;
    ShowDialogSelectTypeExchange();
    // locals stack 12
    return 1;
    // stor.alt 137
    // locals stack 24
    // locals stack 16
    // stor.s.pri -16
    // locals stack 8
    // if/goto jzer 0x5dc8c
    // locals stack 8
    // locals stack 12
    ShowDialogSelectTypeExchange();
    // locals stack 16
    return 1;
    // locals stack -4
    // locals stack 16
    // stor.s.pri -20
    // locals stack -272
    GetVehicleModelName();
    // locals stack 8
    // if/goto jzer 0x5dd88
    // locals stack 20
    // locals stack 16
    // locals stack 12
    // locals stack -4
    // const.alt 197996332
    Streamer_SetIntData("", _push.s, "9ºàñ", "l", _push.s, "", _push.alt, "¼ý;", "{*", "", "àñ", "l", _push.s, "{*", "l", "", "", "9ºàñ");
    // stor.s.pri -296
    // if/goto jnz 0x5de6c
    // if/goto jnz 0x5de6c
    // if/goto jump 384628
    // if/goto jzer 0x5de94
    // locals stack 296
    return 1;
    // locals stack -576
    // if/goto jzer 0x5df44
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 24
    // if/goto jump 384948
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "Äc÷ÄcÿM", "Ð", "", _push.pri);
    // locals stack 24
    // locals stack 16
    // const.alt 84
    // if/goto jzer 0x5e0bc
    ShowNotification();
    // stor.alt 137
    ShowDialogSelectTypeExchange();
    // if/goto jump 385288
    Dialog();
    // locals stack 872
    // if/goto jump 385332
    ShowDialogSelectTypeExchange();
    // if/goto jzer 0x5e76c
    // if/goto jzer 0x5e750
    // const.alt 53
    // locals stack -4
    // stor.alt 44
    // locals stack -4
    // const.alt 197996332
    Streamer_SetIntData("àñ", _push.s, "", _push.s, "", "àñ", _push.s, "M", _push.s, "8", "ºàñ", "", "", "", "", "àñ", _push.s, "l", _push.s, "", "9ºàñ", "ÄcÿM", _push.s, "9ºàñ", "", "àñ", "", "", "", _push.s, "", "l", _push.s, "", _push.alt, "Äc÷ÄcÿM", "Ð", "", _push.pri);
    // stor.s.pri -8
    // if/goto jzer 0x5e250
    // locals stack 16
    // locals stack 8
    return 1;
    // const.alt 105
    // load.alt 53
    // const.alt 181530104
    Streamer_SetIntData("", _push.s, "");
    // stor.alt 137
    SendExchange();
    // if/goto jump 385960
    // const.alt 197996332
    Streamer_SetIntData("àñ", _push.s, "l", _push.s, "", _push.s);
    // const.alt 197996332
    Streamer_SetIntData(-1);
    DeleteFullPVarExchange();
    // if/goto jump 386252
    // const.alt 181530104
    Streamer_SetIntData("àñ", _push.s, -1);
    // stor.alt 137
    SendExchange();
    // if/goto jump 386252
    // const.alt 197996332
    Streamer_SetIntData("àñ", _push.s, "l", _push.s, "", _push.s);
    // const.alt 197996332
    Streamer_SetIntData(-1);
    DeleteFullPVarExchange();
    // locals stack 8
    return 1;
    // locals stack -512
    // const.alt 197996332
    Streamer_SetIntData(_push.pri, 181530104);
    Streamer_SetIntData();
    // locals stack 20
    // locals stack 16
    // const.alt 197996332
    Streamer_SetIntData("l", _push.s, "", _push.alt, "¼ý;", "/", "", _push.pri);
    SendExchange();
    // locals stack 512
    // if/goto jump 386888
    Dialog();
    // stor.alt 51
    Dialog();
    // stor.alt 51
}

// AMX 0x5eae4
stock pc_cmd_changeprop()
{
    return 1;
    // locals stack 16
    // if/goto jzer 0x5eb74
    // locals stack 16
    // locals stack 4
    return 1;
    // if/goto jnz 0x5ebc8
    // if/goto jeq 0x5ebc8
    // if/goto jump 388048
    // if/goto jzer 0x5ec18
    // locals stack 16
    // locals stack 4
    return 1;
    IsPlayerInRangeOfPlayer();
    // if/goto jzer 0x5ec90
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 197996332
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x5ed00
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 197996332
    Streamer_SetIntData();
    // locals stack -576
    // const.alt 181530104
    Streamer_SetIntData(-1);
    // locals stack 20
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", _push.alt, "¼ý;", "Ð", "", _push.pri);
    // locals stack 20
    ShowNotificationNew();
    // stor.alt 137
    // stor.alt 137
    // locals stack 580
    return 1;
}

// AMX 0x5ef20
stock pc_cmd_yeschange()
{
    // locals stack -4
    // const.alt 17
    // if/goto jnz 0x5efb8
    // if/goto jnz 0x5efb8
    // if/goto jump 389056
    // if/goto jzer 0x5f008
    // locals stack 16
    // locals stack 4
    return 1;
    // locals stack -4
    // const.alt 17
    // if/goto jeq 0x5f0a0
    // locals stack 16
    // locals stack 8
    return 1;
    // const.alt 197996332
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jneq 0x5f108
    // const.alt 197996332
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jneq 0x5f108
    // if/goto jump 389392
    // if/goto jzer 0x5f158
    // locals stack 16
    // locals stack 8
    return 1;
    // const.alt 197996332
    Streamer_SetIntData();
    // const.alt 197996332
    Streamer_SetIntData();
    // locals stack 16
    // locals stack 16
    ShowDialogSelectTypeExchange();
    // locals stack 8
    return 1;
}

// AMX 0x5f254
stock Exchange()
{
    ExchangeHouse();
    // if/goto jump 390008
    ExchangeVehicle();
    // if/goto jump 390008
    ExchangeBusiness();
    // if/goto jump 390008
    ExchangeFuelStation();
    // if/goto jump 390008
    // locals stack 8
    // if/goto jump 390008
}

// AMX 0x5f988
stock ExchangeVehicle()
{
    // locals stack -4
    // const.alt 197996332
    Streamer_SetIntData(_push.pri, 181530104);
    Streamer_SetIntData();
    // stor.s.pri -4
    // const.alt 65535
    // if/goto jeq 0x5fae0
    // locals stack -4
    // const.alt 169148
    native#1199();
    // stor.s.pri -8
    // const.alt 182230856
    native#14999(_push);
    // if/goto jneq 0x5fad8
    // const.alt 197996332
    Streamer_SetIntData("");
    UnloadPlayerOwnableCar();
    // locals stack 4
    // stor.alt 12
    Streamer_SetIntData("", _push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x5fbe0
    // locals stack 8
    // locals stack 4
    return 1;
    // locals stack 4
    return 1;
}

// AMX 0x5fbf8
stock ExchangeFuelStation()
{
    // locals stack -4
    GetPlayerFuelStation();
    // stor.s.pri -4
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("àñ", _push.s);
    // stor.s.pri -8
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -12
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x5fdc0
    // locals stack 8
    // locals stack 12
    return 1;
    // const.alt 195649720
    strcmp();
    // locals stack 32
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x5fec8
    // locals stack 8
    // locals stack 12
    return 1;
    // locals stack 8
    // if/goto jzer 0x6058c
    // const.alt 181530104
    Streamer_SetIntData("àñ", "9ºàñ");
    // const.alt 195649720
    strcmp();
    // const.alt 195649720
    strcmp();
    // locals stack -4
    // locals stack 16
    // stor.s.pri -16
    // locals stack -4
    // stor.s.pri -20
    // const.alt 195649720
    strcmp(86400, _push.pri, "l", _push.alt, _push.alt, _push.alt);
    // const.alt 195649720
    strcmp(50);
    // const.alt 195649720
    strcmp(3);
    // const.alt 195649720
    strcmp();
    // const.alt 195649720
    strcmp();
    // const.alt 195649720
    strcmp();
    // const.alt 181530104
    Streamer_SetIntData(_push.alt);
    // const.alt 195649720
    strcmp("c÷ÄcÿM", _push.pri);
    // locals stack 20
    // stor.alt 137
    // locals stack 16
    // const.alt 195649720
    strcmp("l", _push.s, "", "", "l", "", "", _push.alt, "¼ý;", _push.pri);
    // const.alt 195649720
    strcmp(_push.pri);
    // const.alt 195649720
    strcmp(_push.pri);
    // const.alt 195649720
    strcmp(_push.pri);
    // const.alt 195649720
    strcmp(_push.pri);
    // const.alt 195649720
    strcmp(_push.pri);
    // const.alt 195649720
    strcmp(_push.pri);
    // locals stack 44
    // locals stack 16
    // const.alt 195649720
    strcmp("l", _push, "", "", _push.alt, "è)", "", ",", "", _push.pri);
    // locals stack 20
    // locals stack 16
    // locals stack 20
    return 1;
    // locals stack 12
    return 1;
}

// AMX 0x605a4
stock ExchangeBusiness()
{
    // locals stack -4
    GetPlayerBusiness();
    // stor.s.pri -4
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("àñ", _push.s);
    // stor.s.pri -8
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -12
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6076c
    // locals stack 8
    // locals stack 12
    return 1;
    // const.alt 195566420
    SetActorVirtualWorld();
    // locals stack 36
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6087c
    // locals stack 8
    // locals stack 12
    return 1;
    // locals stack 12
    // locals stack 8
    // if/goto jzer 0x6102c
    // const.alt 181530104
    Streamer_SetIntData("àñ", "9ºàñ", "", "", "");
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // locals stack -4
    // locals stack 16
    // stor.s.pri -16
    // locals stack -4
    // stor.s.pri -20
    // const.alt 195566420
    SetActorVirtualWorld(86400, _push.pri, "l", _push.alt, _push.alt, _push.alt);
    // const.alt 195566420
    SetActorVirtualWorld(20);
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 195566420
    SetActorVirtualWorld();
    // const.alt 181530104
    Streamer_SetIntData(_push.alt);
    // const.alt 195566420
    SetActorVirtualWorld("c÷ÄcÿM", _push.pri);
    // locals stack 20
    // stor.alt 137
    // locals stack 16
    // const.alt 195566420
    SetActorVirtualWorld("l", _push.s, "", "", "l", "", "", _push.alt, "¼ý;", _push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // const.alt 195566420
    SetActorVirtualWorld(_push.pri);
    // locals stack 40
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x60f24
    // locals stack 8
    // locals stack 20
    return 1;
    // const.alt 195566420
    SetActorVirtualWorld();
    // locals stack 20
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x61014
    // locals stack 8
    // locals stack 20
    return 1;
    // locals stack 20
    return 1;
    // locals stack 12
    return 1;
}

// AMX 0x61044
stock ExchangeHouse()
{
    // locals stack -4
    GetPlayerHouse();
    // stor.s.pri -4
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData("", _push.s, "");
    // stor.s.pri -8
    // locals stack -4
    // const.alt 181530104
    Streamer_SetIntData();
    // stor.s.pri -12
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData(-1);
    // locals stack 24
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x61258
    // locals stack 8
    // locals stack 12
    return 1;
    // const.alt 194655224
    native#899();
    // locals stack 36
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6137c
    // locals stack 8
    // locals stack 12
    return 1;
    // locals stack 12
    // locals stack 8
    // if/goto jzer 0x61abc
    // const.alt 181530104
    Streamer_SetIntData("àñ", "9ºàñ", "", "", "");
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // const.alt 194655224
    native#899();
    // locals stack -4
    // locals stack 16
    // stor.s.pri -16
    // locals stack -4
    // stor.s.pri -20
    // const.alt 194655224
    native#899(_push.s, "àñ", 86400, _push.pri, "l", _push.alt, _push.alt, _push.alt);
    GetElapsedTime();
    // const.alt 194655224
    native#899("l", _push.pri);
    // locals stack -4
    // const.alt 194655224
    native#899();
    // stor.s.pri -24
    // const.alt -1
    // if/goto jeq 0x617a0
    // stor.alt 137
    // locals stack -96
    // locals stack 8
    // if/goto jzer 0x61824
    // locals stack 8
    // locals stack 124
    return 1;
    // const.alt 181530104
    Streamer_SetIntData(_push.alt);
    // const.alt 194655224
    native#899("c÷ÄcÿM", _push.pri);
    // locals stack 20
    // locals stack 12
    UpdateHouse();
    HouseHealthInit();
    HouseStoreInit();
    // const.alt 194655224
    native#899("", _push.s, "", "", _push.s, "", "àñ", _push.s, "", _push.s, "9ºàñ", _push.alt, "¼ý;", _push.pri);
    // const.alt 194655224
    native#899(_push.pri);
    // const.alt 194655224
    native#899(_push.pri);
    // locals stack 28
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x61ab4
    // locals stack 8
    // locals stack 124
    return 1;
    // locals stack 112
    // locals stack 12
    return 1;
}

// AMX 0x61ad4
stock Exchange_ShowVehicleList()
{
    // if/goto jnz 0x61b30
    // if/goto jnz 0x61b30
    // if/goto jump 400184
    // if/goto jzer 0x61b4c
    return 1;
    // const.alt 181530104
    Streamer_SetIntData("");
    // locals stack 24
    // locals stack 16
    // stor.s.pri -4
    // locals stack 8
    // if/goto jzer 0x61c8c
    // locals stack 8
    // locals stack 12
    // locals stack 4
    return 1;
    // locals stack -4
    // locals stack 8
    // stor.s.pri -8
    // if/goto jzer 0x61d70
    // if/goto jzer 0x61cfc
    // if/goto jump 400644
    // locals stack 16
    // locals stack 12
    // locals stack 8
    return 1;
    // locals stack -4
    // stor.s.pri -12
    // stor.s.pri 20
    // locals stack -4
    // locals stack -4
    // stor.s.pri -20
    // locals stack -16384
    // locals stack -640
    // locals stack 16
    // locals stack -4
    // stor.s.pri -17052
    // if/goto jump 401184
    // locals stack -4
    // locals stack 16
    // stor.s.pri -17056
    // locals stack -4
    // locals stack 16
    // stor.s.pri -17060
    // locals stack -128
    GetVehicleModelName();
    // locals stack 8
    // if/goto jzer 0x62078
    // locals stack 20
    // locals stack 24
    // locals stack 8
    // locals stack 8
    // const.alt 4096
    // locals stack 136
    // if/goto jump 401888
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "t'%", "àñ", _push.pri, "àñ", _push.alt, "Äc÷ÄcÿM", "Ü", "", _push.alt, "¼ý;", "8", "", "àñ", "l", _push.s, "8", "l", _push.s, "", "9ºàñ", "l", _push.s, "", "9ºàñ", _push.alt, "l", "t'%", "", "", 20, 1);
    native#1023(_push.pri);
    // locals stack 136
    // if/goto jump 401172
    // locals stack 4
    // locals stack 16
    // locals stack 8
    // locals stack 8
    // const.alt 4096
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "t'%", "àñ", _push.pri, "àñ", _push.alt, "l", "Ü", "");
    native#1023(_push.pri);
    // locals stack 16
    // locals stack 8
    // locals stack 8
    // const.alt 4096
    // stor.alt 137
    // const.alt 196049960
    Streamer_SetIntData("l", "t'%", "àñ", _push.pri, "àñ", _push.alt, "l", "Ü", "", -1);
    native#1023(_push.pri);
    // stor.alt 137
    // stor.alt 137
    Dialog();
    // locals stack 12
    // locals stack 17048
    return 1;
}

// AMX 0x62570
stock ShowDialogSelectTypeExchange()
{
    // const.alt 197996332
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x625f4
    Dialog();
    return 1;
}

// AMX 0x62604
stock SendExchange()
{
    // locals stack -4
    // const.alt 197996332
    Streamer_SetIntData();
    // stor.s.pri -4
    // locals stack -4
    // const.alt 17
    // locals stack -192
    // locals stack 137
    // locals stack -272
    // locals stack -272
    return 1;
    // locals stack 20
    return 1;
    // locals stack 20
    // locals stack 8
    // if/goto jzer 0x627c8
    // locals stack 16
    // locals stack 8
    // if/goto jzer 0x6282c
    // locals stack 16
    // const.alt 1
    // const.alt 129
    // locals stack 20
    // if/goto jump 403744
    // locals stack 20
    // if/goto jump 403744
}

// AMX 0x62a04
stock DeleteFullPVarExchange()
{
    // const.alt 197996332
    Streamer_SetIntData();
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    call_unknown();
    // locals stack 12
    return 1;
}

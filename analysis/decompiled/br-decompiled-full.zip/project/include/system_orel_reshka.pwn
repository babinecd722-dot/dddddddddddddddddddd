// AUTO-DECOMPILED from br_gamemode.amx
// Source module: include/system_orel_reshka.pwn
// Functions: 12

// AMX 0x6580c
stock weekly_OnGameModeInit()
{
    // locals stack 8
    HAT_OnGameModeInit();
    return 1;
}

// AMX 0x65850
stock pc_cmd_spin()
{
    // locals stack 16
    // if/goto jzer 0x658e0
    // locals stack 16
    // locals stack 4
    return 1;
    IsPlayerInRangeOfPlayer();
    // if/goto jzer 0x65958
    // locals stack 16
    // locals stack 4
    return 1;
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x659d8
    // locals stack 16
    // locals stack 4
    return 1;
    fg_ShowPlayerDialog();
    // const.alt 199016644
    Streamer_SetIntData("M", _push.s, "", "9ºàñ", "", "", "", "");
    // locals stack 4
    return 1;
}

// AMX 0x65a80
stock pc_cmd_spins()
{
    // const.alt 199016644
    Streamer_SetIntData();
    // if/goto jzer 0x65b00
    // locals stack 16
    return 1;
    // const.alt 199016644
    Streamer_SetIntData();
    // if/goto jzer 0x65b78
    // locals stack 16
    return 1;
    // stor.s.pri 44
    // if/goto jzer 0x65d34
    // const.alt 199016644
    Streamer_SetIntData("¼ý;", _push.s, "", "9ºàñ", "");
    // if/goto jneq 0x65c10
    return 1;
    // locals stack -4
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.s.pri -4
    // const.alt 199023644
    Streamer_SetIntData();
    // locals stack 8
    // const.alt 199016644
    Streamer_SetIntData(_push.r, "àñ", _push.pri);
    // load.pri 53
    StartHAT();
    // if/goto jump 417060
    StartHAT();
    // locals stack 4
    // if/goto jump 417584
    // stor.s.pri 44
    // if/goto jzer 0x65efc
    // const.alt 199016644
    Streamer_SetIntData("", "¼ý;", _push.s, "", "9ºàñ", "", "", _push.s, _push.s, "", _push.s, _push.s);
    // if/goto jneq 0x65e14
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.s.pri -4
    // if/goto jump 417356
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.s.pri -4
    // locals stack 16
    // locals stack 16
    DefaultHAT();
    DefaultHAT();
    // locals stack 4
    // if/goto jump 417584
    // locals stack 16
    return 1;
}

// AMX 0x65f40
stock StartHAT()
{
    // if/goto jnz 0x65fb0
    // if/goto jnz 0x65fb0
    // if/goto jump 417720
    // if/goto jzer 0x66070
    // locals stack 16
    // locals stack 16
    DefaultHAT();
    DefaultHAT();
    return 1;
    // locals stack -4
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.alt 9
    // stor.s.pri -4
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData();
    // if/goto jump 418136
    // if/goto jzer 0x66218
    // locals stack 16
    // locals stack 16
    DefaultHAT();
    DefaultHAT();
    // locals stack 4
    return 1;
    // locals stack -576
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 9
    // if/goto jzer 0x662e8
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 20
    // if/goto jump 418640
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "¼ý;", "Ð", "", _push.pri);
    // locals stack 20
    // locals stack 16
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", "l", _push.s, "", _push.alt, "¼ý;", "Ð", "", _push.pri);
    // locals stack 20
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "¼ý;", "Ð", "", _push.pri);
    // locals stack 20
    // const.alt 199016644
    Streamer_SetIntData(_push.alt, "¼ý;", "Ð", "", _push.pri);
    // const.alt 199016644
    Streamer_SetIntData(1);
    // stor.alt 133
    // const.alt 39
    // locals stack 28
    // locals stack 580
    return 1;
}

// AMX 0x66574
stock EndHAT()
{
    // if/goto jnz 0x665e4
    // if/goto jnz 0x665e4
    // if/goto jump 419308
    // if/goto jzer 0x666a4
    // locals stack 16
    // locals stack 16
    DefaultHAT();
    DefaultHAT();
    return 1;
    // locals stack -4
    // locals stack 8
    // stor.s.pri -12
    // if/goto jzer 0x66730
    // stor.s.pri -4
    // stor.s.pri -8
    // if/goto jump 419672
    // stor.s.pri -4
    // stor.s.pri -8
    // locals stack -576
    // const.alt 199016644
    Streamer_SetIntData("", "", "àñ", "ºàñ", "", "");
    // if/goto jneq 0x66800
    // stor.s.pri -592
    // stor.s.pri -596
    // if/goto jump 419880
    // stor.s.pri -592
    // stor.s.pri -596
    // if/goto jump 419936
    // locals stack 20
    // locals stack 16
    // locals stack 16
    // locals stack -4
    // const.alt 199016644
    Streamer_SetIntData("l", _push.s, "", "l", _push.s, "", _push.alt, "¼ý;", "Ð", "", _push.pri, 199029136, 199029112);
    // stor.alt 9
    // stor.s.pri -600
    // if/goto jzer 0x66a90
    // const.alt 181530104
    Streamer_SetIntData();
    GivePlayerMoneyEx();
    GivePlayerMoneyEx();
    // if/goto jump 420496
    // locals stack 16
    // locals stack 16
    fg_ShowPlayerDialog();
    // const.alt 199016644
    Streamer_SetIntData("M", _push.s, "+", "ºàñ", "", "", "", "", "l", _push.s, "", "", "l", _push.s, "", "", "Äc÷ÄcÿM", _push.s, _push.s, "", "9ºàñ", "9ºàñ", "Äc÷ÄcÿM", _push.s, _push.pri, "", "9ºàñ", "9ºàñ");
    // const.alt 199016644
    Streamer_SetIntData(-1);
    // stor.alt 34
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 199016644
    Streamer_SetIntData();
    // locals stack 600
    return 1;
}

// AMX 0x66bf0
stock DefaultHAT()
{
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.alt 34
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 199016644
    Streamer_SetIntData(-1);
    // const.alt 199016644
    Streamer_SetIntData(-1);
    // const.alt 199016644
    Streamer_SetIntData();
    return 1;
}

// AMX 0x66d40
stock DialogThrowHAT()
{
    // locals stack -576
    // const.alt 199016644
    Streamer_SetIntData(_push.pri, 181530104);
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // locals stack 24
    fg_ShowPlayerDialog();
    // locals stack 576
    return 1;
}

// AMX 0x66e9c
stock DialogRoleHAT()
{
    // locals stack -576
    // locals stack -4
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.s.pri -580
    // const.alt 181530104
    Streamer_SetIntData();
    // const.alt 181530104
    Streamer_SetIntData(_push.pri);
    // locals stack 24
    fg_ShowPlayerDialog();
    // locals stack 580
    return 1;
}

// AMX 0x67008
stock AcceptHAT()
{
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt -1
    // if/goto jeq 0x670b0
    // locals stack 16
    DefaultHAT();
    return 1;
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 9
    // if/goto jzer 0x67138
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 34
    // if/goto jump 422268
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 34
    // const.alt 199016644
    Streamer_SetIntData(1);
    // load.pri 53
    // const.alt 199016644
    Streamer_SetIntData();
    // if/goto jump 422484
    // const.alt 199016644
    Streamer_SetIntData(2);
    // locals stack -4
    // const.alt 199016644
    Streamer_SetIntData(1);
    // stor.alt 9
    // stor.s.pri -4
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.alt 34
    // locals stack -576
    // locals stack -168
    // locals stack 20
    // const.alt 181530104
    Streamer_SetIntData(_push.alt, "¼ý;", "", "", _push, 199030696);
    // locals stack 24
    // locals stack 16
    // const.alt 199016644
    Streamer_SetIntData("l", _push.s, "", _push.alt, "Äc÷ÄcÿM", "Ð", "", _push.pri);
    // const.alt 1
    // if/goto jump 423176
    // locals stack 20
    // locals stack 16
    // const.alt 181530104
    Streamer_SetIntData("l", _push.s, "", _push.alt, "¼ý;", "Ð", "", _push.pri, 199031048, 199031024);
    // locals stack 24
    // locals stack 16
    // const.alt 199016644
    Streamer_SetIntData("l", _push.s, "", _push.alt, "Äc÷ÄcÿM", "Ð", "", _push.pri);
    // const.alt 1
    // if/goto jump 423540
    // locals stack 20
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // locals stack 16
    // const.alt 199023644
    Streamer_SetIntData("l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", "", "l", _push.s, "", _push.alt, "¼ý;", "Ð", "", _push.pri, 199031296, 199031272);
    // stor.alt 133
    // const.alt 39
    // locals stack 28
    // locals stack 748
    return 1;
}

// AMX 0x67804
stock CancelAcceptHAT()
{
    // locals stack 16
    // locals stack 16
    DefaultHAT();
    DefaultHAT();
    // const.alt 199023644
    Streamer_SetIntData("àñ", _push.s, "àñ", _push.s, "l", _push.s, "", "", "l", _push.s, "", "");
    return 1;
}

// AMX 0x678ec
stock weekly_OnDialogResponse()
{
    // if/goto jzer 0x67c2c
    // if/goto jzer 0x67bc4
    // locals stack 16
    // if/goto jzer 0x679a8
    // locals stack 16
    // if/goto jump 424884
    // const.alt 10000000
    // locals stack 16
    // locals stack 4
    return 1;
    // locals stack -4
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.s.pri -8
    IsPlayerInRangeOfPlayer();
    // if/goto jzer 0x67ac4
    // locals stack 16
    // locals stack 8
    return 1;
    // const.alt 181530104
    Streamer_SetIntData();
    // locals stack 16
    // locals stack 8
    return 1;
    // const.alt 199016644
    Streamer_SetIntData();
    // stor.alt 34
    DialogRoleHAT();
    // locals stack 4
    // locals stack 4
    // if/goto jump 425004
    // const.alt 199016644
    Streamer_SetIntData("àñ", _push.s);
    DefaultHAT();
    DefaultHAT();
    // if/goto jzer 0x67d9c
    // if/goto jzer 0x67d34
    // locals stack -4
    // const.alt 199016644
    Streamer_SetIntData("àñ", _push.s, "àñ", _push.pri);
    // stor.s.pri -4
    // if/goto jzer 0x67d00
    // const.alt 199016644
    Streamer_SetIntData();
    // const.alt 34
    AcceptHAT();
    // locals stack 4
    // if/goto jump 425372
    // const.alt 199016644
    Streamer_SetIntData("", _push.s, _push.s, 1);
    DefaultHAT();
    DefaultHAT();
    // if/goto jzer 0x67f00
    // if/goto jzer 0x67e98
    // if/goto jzer 0x67e30
    // const.alt 199016644
    Streamer_SetIntData("àñ", _push.s, "àñ", _push.pri);
    // if/goto jump 425588
    // const.alt 199016644
    Streamer_SetIntData(1);
    DialogThrowHAT();
    // if/goto jump 425728
    // const.alt 199016644
    Streamer_SetIntData("àñ", _push.s, 2);
    DefaultHAT();
    DefaultHAT();
    // if/goto jzer 0x68030
    // if/goto jzer 0x67fc8
    // if/goto jzer 0x67f6c
    DialogRoleHAT();
    // if/goto jump 425920
    // const.alt 199016644
    Streamer_SetIntData("àñ", _push.s, "àñ", _push.s, "àñ", _push.pri);
    AcceptHAT();
    // if/goto jump 426032
    // const.alt 199016644
    Streamer_SetIntData("", _push.s, _push.pri);
    DefaultHAT();
    DefaultHAT();
    HAT_OnDialogResponse();
    return 1;
}

// AMX 0x68070
stock fixp_OnPlayerSpawn()
{
    DefaultHAT();
    HAT_OnPlayerSpawn();
    return 1;
}
